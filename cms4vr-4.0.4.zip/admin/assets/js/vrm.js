/**
 * Created by lklapa on 2017-06-24.
 */

function vrmValidateForm(form) {

    var formSubmitButton = $(form).find('input[name=submit]');
    // Disable submit button to prevent form to be submitted multiple times
    formSubmitButton.prop('disabled', true);

    $('.panoError').remove();

    var formValid = true;
    var inputs = $(form).find(":input");
    $(inputs).each(function(index, elem) {
        if ($(elem).attr('data-required') && $.trim($(elem).val()).length === 0) {
            $(elem).closest('div.input').append('<div class="alert alert-danger panoError rightField">' + FORM_REQ + '</div>');
            formValid = false;
        }
    });
    if (!formValid) {
        // If form is not valid, enable submit button
        formSubmitButton.prop('disabled', false);
        // mark fieldsets if needed
        var languagesErrors = [];
        $('fieldset.languageDataContainer .panoError').closest('fieldset').find('input[name*="[language"]').each(function(){
            languagesErrors.push($(this).val());
        });

        $.each(languagesErrors, function(i, val){
            $('div.lang_switcher a[data-lang-switch="' + val + '"]').after(' <span class="panoError" style="color:#E34C4C"><i class="fa fa-warning"></i></span> ');
        });

        $.notify({icon: "ti-alert",message: "<strong>" + FORM_ERR + "!</strong> " + FORM_CHECK},{type: 'danger', timer: 4000,placement: {from: 'top', align: 'center'}});

    }

    return formValid;
}

function errorsInFieldsets(div) {
    //check if div exists
    if ($(div).length < 1) return false;

    //check if div contains lang switcher
    if ($(div + ' .lang_switcher').length < 1) return false;

    //find all errors in fieldsets
    $(div).find('ul.alert-danger').each(function (index, target) {
        var langId = $(target).parents('fieldset[data-lang-id]').attr('data-lang-id');

        if (langId < 1) return false;

        var langSwitcher = $(div + ' .lang_switcher');

        if (langSwitcher.find('a[data-lang-switch="' + langId + '"]').find('span.poiError').length == 0) {
            langSwitcher.find('a[data-lang-switch="' + langId + '"]').append(' <span class="poiError" style="color:#E34C4C"><i class="fa fa-warning"></i></span>');
        }
    });
}

/** Disable submitting the whole form through ENTER key */
$('form input').keydown(function (e) {
    if (e.keyCode === 13) {
        e.preventDefault();
        return false;
    }
});

function refreshAudioPreview() {
    // remove old instances
    $('.audioPreviewControl, .audioRemove').remove();
    // audio tag for files
    var audioNumber = 1;
    $('input[name*="[media_id]"]').each(function () {
        if ($(this).val()) {
            var filePath = '../media/a' + $(this).val() + '.mp3';
            if (filePath !== '') {
                $(this).closest('fieldset').find('button[data-media="audio"]').parent().append(' <audio class="audioPreviewControl" id="audioFile' + audioNumber + '" controls="false" src="' + filePath + '" style="display:none"></audio>');
                $(this).closest('fieldset').find('button[data-media="audio"]').parent().append(' <button type="button" data-playing="0" data-audio="audioFile' + audioNumber + '" class="btn btn-primary audioPreview audioPreviewControl"><i class="fa fa-play"></i></button>');
                $(this).closest('fieldset').find('button[data-media="audio"]').parent().append(' <button type="button" class="btn btn-danger audioRemove"><i class="fa fa-remove"></i></button>');
                audioNumber++;
            }
        }
    });
}

/**
 * Loads media picker
 *
 * @param mediaType
 */
function loadMedia(mediaType) {

    /*if (mediaType.constructor !== Array) {
        mediaType = [mediaType];
    }

    $.ajax({
        type: 'POST',
        url: '/admin/?c=media&a=showMediaAjax&type=' + mediaType.join(','),
        success: function (data) {
            if (data.success) {
                $('#mediaSelector').find('.modal-body').html(data.html);
                $('#mediaSelector').modal('show');
            }
        }
    });*/
}

function poiShowPhoto() {
    var krpano = document.getElementById("krpanoSWFObject");
    var currentPhotoId = '';
    if (krpano.get('poi_obj.src')) {
        currentPhotoId = krpano.get('poi_obj.src').replace('.jpg', '').replace('i', '');
    }
    var updateField = "#updateMe";
    $.ajax({
        type: 'POST',
        url: '?c=media&a=showMediaAjax&type=photo',
        success: function (data) {
            if (data.success) {
                $('#mediaSelector').find('.modal-body').html(data.html);
                $('#mediaSelector').attr('data-update-field', updateField);
                $('#mediaSelector').attr('data-upload-callback', 'poiShowPhoto');
                $('#mediaSelector').modal('show');
                $('#mediaSelector button.vrm-select[data-id=' + currentPhotoId + ']').addClass('btn-fill');
            }
        }
    });
}

function poiShowAudio() {
    var krpano = document.getElementById("krpanoSWFObject");
    var currentAudioId = '';
    if (krpano.get('poi_obj.src')) {
        currentAudioId = krpano.get('poi_obj.src').replace('.mp3', '');
    }
    var updateField = "#updateMe";
    $.ajax({
        type: 'POST',
        url: '?c=media&a=showMediaAjax&type=audio',
        success: function (data) {
            if (data.success) {
                $('#mediaSelector').find('.modal-body').html(data.html);
                $('#mediaSelector').attr('data-update-field', updateField);
                $('#mediaSelector').attr('data-upload-callback', 'poiShowAudio');
                $('#mediaSelector').modal('show');
                $('#mediaSelector button.vrm-select[data-id=' + currentAudioId + ']').addClass('btn-fill');
            }
        }
    });
}

function poiShowVideo() {
    var krpano = document.getElementById("krpanoSWFObject");
    var currentVideoSrc = '';
    if (krpano.get('poi_obj.src')) {
        currentVideoSrc = krpano.get('poi_obj.src');
    }
    var updateField = "#updateMe";
    $.ajax({
        type: 'POST',
        url: '?c=media&a=showMediaAjax&type=youtube,vimeo',
        success: function (data) {
            if (data.success) {
                $('#mediaSelector').find('.modal-body').html(data.html);
                $('#mediaSelector').attr('data-update-field', updateField);
                $('#mediaSelector').attr('data-upload-callback', 'poiShowVideo');
                $('#mediaSelector').modal('show');
                $('#mediaSelector button.vrm-select[data-src=' + currentVideoSrc + ']').addClass('btn-fill');
            }
        }
    });
}

function bindSelectMedia() {

    $('.vrm-select-media').off().click(function(e){
        e.preventDefault();
        var mediaType = $(this).attr('data-media');
        var extensions = $(this).attr('data-extensions') ? $(this).attr('data-extensions') : '';

        var updateField = $(this).attr('data-update-field');

        var callback = $(this).attr('data-upload-callback');

        var currentValue = $(this).attr('data-current-value');

        var amazonVoice = $(this).attr('data-amazon-voice');

        $.ajax({
            type: 'POST',
            url: '?c=media&a=showMediaAjax&type=' + mediaType + '&extensions=' + extensions,
            data: {voice: amazonVoice},
            success: function (data) {
                if (data.success) {
                    $('#mediaSelector').find('.modal-body').html(data.html);
                    $('#mediaSelector').attr('data-update-field', updateField);
                    $('#mediaSelector').attr('data-upload-callback', callback);

                    if ($.isArray(currentValue)) {

                    } else if (parseInt(currentValue)) {
                        $('#mediaSelector').find('*[data-id=' + currentValue + ']').addClass('btn-fill');
                    }

                    if (typeof amazonVoice !== "undefined") {
                        var amazonTextField = $(updateField).closest('fieldset').find('.quill').attr('name');
                        $('#mediaSelector').attr('data-amazon-text-field', amazonTextField);
                        $('#mediaSelector').attr('data-amazon-voice', amazonVoice);
                    } else {
                        $('#mediaSelector').attr('data-amazon-text-field', '');
                    }

                    $('#mediaSelector').modal('show');
                }
            }
        });
    });

}

$(document).ready(function(){

    bindSelectMedia();

    $('#mediaSelector').on('click', '.vrm-select', function(e){
        e.preventDefault();

        $(this).blur();

        if ($(this).hasClass('btn-fill')) {
            $(this).removeClass('btn-fill');
        } else {
            $(this).addClass('btn-fill');
        }

        if (!$('#mediaSelector').attr('data-multiple')) {
            $(this).closest('.vrm-container').find('.btn-fill').not($(this)).removeClass('btn-fill');
            var selected = $('#mediaSelector button.btn-fill').length;
            // disable "Save selection" button if no selection was made
            if (selected === 0) {
                $('#mediaSelector .vrm-save-selection').attr('disabled', true);
            } else {
                $('#mediaSelector .vrm-save-selection').attr('disabled', false);
            }
        }
    });

    $('.vrm-save-selection').click(function(e){
        e.preventDefault();

        var callback = $(this).attr('data-callback');

        if (callback) {
            window[callback]();
            return;
        }

        var selected = $('#mediaSelector button.btn-fill').attr('data-id');
        if (typeof selected === "undefined") {
            selected = '';
        }

        $($('#mediaSelector').attr('data-update-field')).val(selected);

        $('button[data-update-field="' + $('#mediaSelector').attr('data-update-field') + '"]').attr('data-current-value', selected);

        // refresh audio preview files if needed
        if ($('input[name*="[media_id]"]').length) {
            refreshAudioPreview();
        }

        $('#mediaSelector').modal('hide');

    });
});

/**
 * Draggable Background plugin for jQuery
 *
 * v1.2.4
 *
 * Copyright (c) 2014 Kenneth Chung
 *
 * Licensed under the MIT license:
 *   http://www.opensource.org/licenses/mit-license.php
 */
;(function($) {
    var $window = $(window);

    // Helper function to guarantee a value between low and hi unless bool is false
    var limit = function(low, hi, value, bool) {
        if (arguments.length === 3 || bool) {
            if (value < low) return low;
            if (value > hi) return hi;
        }
        return value;
    };

    // Adds clientX and clientY properties to the jQuery's event object from touch
    var modifyEventForTouch = function(e) {
        e.clientX = e.originalEvent.touches[0].clientX;
        e.clientY = e.originalEvent.touches[0].clientY;
    };

    var getBackgroundImageDimensions = function($el) {
        var bgSrc = ($el.css('background-image').match(/^url\(['"]?(.*?)['"]?\)$/i) || [])[1];
        if (!bgSrc) return;

        var imageDimensions = { width: 0, height: 0 },
            image = new Image();

        image.onload = function() {
            if ($el.css('background-size') == "cover") {
                var elementWidth = $el.innerWidth(),
                    elementHeight = $el.innerHeight(),
                    elementAspectRatio = elementWidth / elementHeight;
                imageAspectRatio = image.width / image.height,
                    scale = 1;

                if (imageAspectRatio >= elementAspectRatio) {
                    scale = elementHeight / image.height;
                } else {
                    scale = elementWidth / image.width;
                }

                imageDimensions.width = image.width * scale;
                imageDimensions.height = image.height * scale;
            } else {
                imageDimensions.width = image.width;
                imageDimensions.height = image.height;
            }
        };

        image.src = bgSrc;

        return imageDimensions;
    };

    function Plugin(element, options) {
        this.element = element;
        this.options = options;
        this.init();
    }

    Plugin.prototype.init = function() {
        var $el = $(this.element),
            bgSrc = ($el.css('background-image').match(/^url\(['"]?(.*?)['"]?\)$/i) || [])[1],
            options = this.options;

        if (!bgSrc) return;

        // Get the image's width and height if bound
        var imageDimensions = { width: 0, height: 0 };
        if (options.bound) {
            imageDimensions = getBackgroundImageDimensions($el);
        }

        $el.on('mousedown.dbg touchstart.dbg', function(e) {
            if (e.target !== $el[0]) {
                return;
            }
            e.preventDefault();

            if (e.originalEvent.touches) {
                modifyEventForTouch(e);
            } else if (e.which !== 1) {
                return;
            }

            var x0 = e.clientX,
                y0 = e.clientY,
                pos = $el.css('background-position').match(/(-?\d+).*?\s(-?\d+)/) || [],
                xPos = parseInt(pos[1]) || 0,
                yPos = parseInt(pos[2]) || 0;

            $window.on('mousemove.dbg touchmove.dbg', function(e) {
                e.preventDefault();

                if (e.originalEvent.touches) {
                    modifyEventForTouch(e);
                }

                var x = e.clientX,
                    y = e.clientY;

                xPos = options.axis === 'y' ? xPos : limit($el.innerWidth()-imageDimensions.width, 0, xPos+x-x0, options.bound);
                yPos = options.axis === 'x' ? yPos : limit($el.innerHeight()-imageDimensions.height, 0, yPos+y-y0, options.bound);

                if (imageDimensions.width <= parseInt($('div.siteplan').width())) {
                    xPos = 0;
                }

                if (imageDimensions.height <= parseInt($('div.siteplan').height())) {
                    yPos = 0;
                }

                var markerX = parseInt($('#markerCoords').attr('data-x')) + xPos - 17;
                var markerY = parseInt($('#markerCoords').attr('data-y')) + yPos - 28;

                if (markerX <= imageDimensions.width && markerY <= imageDimensions.height) {
                    $('#marker').css('left', markerX).css('top', markerY);
                }

                x0 = x;
                y0 = y;

                $el.css('background-position', xPos + 'px ' + yPos + 'px');
                $('#siteplanpanos').css({top: yPos, left: xPos});

            });

            $window.on('mouseup.dbg touchend.dbg mouseleave.dbg', function() {
                if (options.done) {
                    options.done();
                }

                $window.off('mousemove.dbg touchmove.dbg');
                $window.off('mouseup.dbg touchend.dbg mouseleave.dbg');
            });
        });
    };

    Plugin.prototype.disable = function() {
        var $el = $(this.element);
        $el.off('mousedown.dbg touchstart.dbg');
        $window.off('mousemove.dbg touchmove.dbg mouseup.dbg touchend.dbg mouseleave.dbg');
    }

    $.fn.backgroundDraggable = function(options) {
        var options = options;
        var args = Array.prototype.slice.call(arguments, 1);

        return this.each(function() {
            var $this = $(this);

            if (typeof options == 'undefined' || typeof options == 'object') {
                options = $.extend({}, $.fn.backgroundDraggable.defaults, options);
                var plugin = new Plugin(this, options);
                $this.data('dbg', plugin);
            } else if (typeof options == 'string' && $this.data('dbg')) {
                var plugin = $this.data('dbg');
                Plugin.prototype[options].apply(plugin, args);
            }
        });
    };

    $.fn.backgroundDraggable.defaults = {
        bound: true,
        axis: undefined
    };
}(jQuery));

function get_center(ath, atv, scale, rotate)
{
    $('input[name="ath"]').val(ath);
    $('input[name="atv"]').val(atv);
    $('input[name="scale"]').val(scale);
    $('input[name="rotate"]').val(rotate);
}

function initializeQuill() {
    $('.quill').each(function(k, v){
        var field = $(this);
        $(this).summernote({
            dialogsInBody: true
        });
        if ($(field).hasClass('full-width') === false) {
            field.closest('.input').addClass('rightField');
        }
    });

    /*$('.quill').summernote({
        dialogsInBody: true
    });*/
    /*var quillNumber = 0;

    var toolbarOptions = [
        [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
        ['bold', 'italic', 'underline'],
        ['link'],
        [{ 'list': 'ordered'}, { 'list': 'bullet' }],
        [{ 'align': [] }],
        ['clean']
    ];

    $('.quill').each(function(k, v){
        if ($(this).attr('data-initialized')) {
            return;
        }
        var field = $(this);
        if ($(field).hasClass('full-width')) {
            field.parent().append('<div><div class="quill-editor' + quillNumber + '">' + field.val() + '</div></div>');
        } else {
            field.parent().append('<div class="rightField"><div class="quill-editor' + quillNumber + '">' + field.val() + '</div></div>');
        }
        var quill = new Quill('.quill-editor' + quillNumber, {
            modules: {
                toolbar: toolbarOptions
            },
            theme: 'snow',
            formats: ['bold', 'italic', 'link', 'underline', 'list', 'align', 'header']
        });
        quill.on('text-change', function() {
            var txt = quill.root.innerHTML;
            field.val(txt);
        });
        $(this).attr('data-initialized', 1);
        quillNumber++;
    });*/
}

$(document).ready(function(){
    $('input[type=file]').bootstrapFileInput();
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    });

    initializeQuill();

    $('.changeLang').on('click', 'a', function(e){
        e.preventDefault();
        var lang = $(this).attr('data-lang');
        $.ajax({
            type: 'POST',
            url: '?c=auth&a=setLangAjax',
            data: {lang: lang},
            success: function (data) {
                if (data.success) {
                    window.location.reload();
                }
            }
        });
    });
});

