<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

const PANEL_TYTUL = 'cms4vr system';
const PANO_WIDTH = 100;
const PANO_HEIGHT = 100;
const PANO_THUMB = 360;
const IMG_QUALITY = 90;
const CAT_WIDTH = 100;
const CAT_HEIGHT = 100;
const GALLERY_WIDTH = 200;
const GALLERY_HEIGHT = 120;
const AVATAR_WIDTH = 128;
const AVATAR_HEIGHT = 128;

return [
    'appFolder' => '/admin/',
    'appIndex' => '/admin/index.php'
];
