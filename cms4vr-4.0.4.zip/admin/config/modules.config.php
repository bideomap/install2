<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

return [
    'Laminas\ZendFrameworkBridge',
    'Laminas\Form',
    'Laminas\InputFilter',
    'Laminas\Filter',
    'Laminas\Hydrator',
    'Laminas\Mvc\Plugin\FlashMessenger',
    'Laminas\Session',
    'Laminas\Db',
    'Laminas\Router',
    'Laminas\Validator',
    'Application',
    'Laminas\I18n',
    'Laminas\Mvc\I18n',
    'CurrentRoute'
];
