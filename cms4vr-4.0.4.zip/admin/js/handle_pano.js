function get_center(ath, atv, scale, rotate)
{
    $('input[name="ath"]').val(ath);
    $('input[name="atv"]').val(atv);
    $('input[name="scale"]').val(scale);
    $('input[name="rotate"]').val(rotate);
}