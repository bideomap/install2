//<![CDATA[

// global "map" variable
var map = null;
var marker = null;
var canPut = true;

var infowindow = new google.maps.InfoWindow(
		{
			size: new google.maps.Size(250, 250)
		});

// A function to create the marker and set up the event window function
function createMarker(latlng, name, html) {
	var contentString = html;
	var marker = new google.maps.Marker({
		position: latlng,
		map: map,
		zIndex: Math.round(latlng.lat() * -100000) << 5
	});

	google.maps.event.addListener(marker, 'click', function() {
		infowindow.setContent(contentString);
		infowindow.open(map, marker);
	});
	google.maps.event.trigger(marker, 'click');
	return marker;
}



function initialize(glat, glng, gzoom, gtype) {
	// create the map
	var myOptions = {
		zoom: (gzoom != undefined) ? gzoom : 6,
		center: new google.maps.LatLng((glat != undefined) ? glat : 51.971345808851716, (glng != undefined) ? glng : 19.44580078125),
		mapTypeControl: true,
		mapTypeControlOptions: {style: google.maps.MapTypeControlStyle.DROPDOWN_MENU},
		navigationControl: true,
		mapTypeId: (gtype != undefined) ? gtype : google.maps.MapTypeId.HYBRID
	}
	map = new google.maps.Map(document.getElementById("map_canvas"),
			myOptions);

	google.maps.event.addListener(map, 'click', function() {
		infowindow.close();
	});


    google.maps.event.addListener(map, 'zoom_changed', function() {
        $('#gmap_zoom').val(map.getZoom());
    });

    google.maps.event.addListener(map, 'maptypeid_changed', function() {
        $('#gmap_view').val(map.getMapTypeId());
    });

	if (glat != undefined && glng != undefined)
		marker = createMarker(new google.maps.LatLng(glat, glng), "name", "<div class=\"map_infowindow\"><b>Współrzędne:</b><br><span>LAT:</span>" + glat + "<br /><span>LNG:</span>" + glng + "</div>");

	google.maps.event.addListener(map, 'click', function(event) {
		//call function to create marker
		if (marker) {
			marker.setMap(null);
			marker = null;
			$('#gmap_lat').val('');
			$('#gmap_lng').val('');
		}
		else {
			marker = createMarker(event.latLng, "name", "<div class=\"map_infowindow\"><b>Współrzędne:</b><br><span>LAT:</span>" + event.latLng.lat() + "<br /><span>LNG:</span>" + event.latLng.lng() + "</div>");
			$('#gmap_lat').val(event.latLng.lat());
			$('#gmap_lng').val(event.latLng.lng());
		}
	});

	// Create the search box and link it to the UI element.
	var input = /** @type {HTMLInputElement} */(
			document.getElementById('pac-input'));
	map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

	var searchBox = new google.maps.places.SearchBox(
			/** @type {HTMLInputElement} */(input));

	// Listen for the event fired when the user selects an item from the
	// pick list. Retrieve the matching places for that item.
	google.maps.event.addListener(searchBox, 'places_changed', function() {
		var places = searchBox.getPlaces();

		if (places.length == 0) {
			return;
		}

		// For each place, get the icon, place name, and location.
		var bounds = new google.maps.LatLngBounds();
		for (var i = 0, place; place = places[i]; i++) {
			var image = {
				url: place.icon,
				size: new google.maps.Size(71, 71),
				origin: new google.maps.Point(0, 0),
				anchor: new google.maps.Point(17, 34),
				scaledSize: new google.maps.Size(25, 25)
			};

			// Create a marker for each place.
			if (marker) {
				marker.setMap(null);
				marker = null;
				$('#gmap_lat').val('');
				$('#gmap_lng').val('');
			}

			marker = createMarker(place.geometry.location, "name", "<div class=\"map_infowindow\"><b>"+place.name+"</b><br><span>LAT:</span>" + place.geometry.location.lat() + "<br /><span>LNG:</span>" + place.geometry.location.lng() + "</div>");
			$('#gmap_lat').val(place.geometry.location.lat());
			$('#gmap_lng').val(place.geometry.location.lng());

			bounds.extend(place.geometry.location);
		}

		map.fitBounds(bounds);
	});

	// Bias the SearchBox results towards places that are within the bounds of the
	// current map's viewport.
	google.maps.event.addListener(map, 'bounds_changed', function() {
		var bounds = map.getBounds();
		searchBox.setBounds(bounds);
	});


}
//]]>
