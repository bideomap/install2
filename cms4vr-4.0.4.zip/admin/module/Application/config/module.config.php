<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application;

use Application\Controller\Plugin\UserInfoPlugin;
use Application\Factory\AdministrationControllerFactory;
use Application\Factory\AuthAdapterFactory;
use Application\Factory\AuthControllerFactory;
use Application\Factory\AuthManagerFactory;
use Application\Factory\CategoriesControllerFactory;
use Application\Factory\GalleriesControllerFactory;
use Application\Factory\GamificationControllerFactory;
use Application\Factory\LanguagesControllerFactory;
use Application\Factory\MediaControllerFactory;
use Application\Factory\PanoControllerFactory;
use Application\Factory\PoiControllerFactory;
use Application\Factory\ProjectInfoFactory;
use Application\Factory\SettingsControllerFactory;
use Application\Factory\SitePlansControllerFactory;
use Application\Factory\UserInfoFactory;
use Application\Factory\UserInfoPluginFactory;
use Application\Factory\UserManagerFactory;
use Application\Route\VrmRoute;
use Application\Validators\PoiNameValidator;
use Application\View\Helper\ProjectInfo;
use Application\View\Helper\UserInfo;
use Laminas\Authentication\AuthenticationService;
use Laminas\I18n\View\Helper\Translate;
use Laminas\ServiceManager\Factory\InvokableFactory;

return [
    'router' => [
        'routes' => [
            'vrm' => [
                'type' => VrmRoute::class,
                'options' => [
                    'route'    => '/index.php',
                    'defaults' => [
                        'controller' => Controller\IndexController::class,
                        'action'     => 'index',
                    ],
                ],
            ],
        ],
    ],
    'translator' => array(
        'locale' => 'en_US',
        'translation_file_patterns' => array(
            array(
                'type'     => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern'  => '%s.mo',
            ),
        ),
    ),
    'view_helpers' => [
        'invokables' => [
            'translate' => Translate::class
        ],
        'factories' => [
            UserInfo::class => UserInfoFactory::class,
            ProjectInfo::class => ProjectInfoFactory::class
        ],
        'aliases' => [
            'userInfo' => UserInfo::class,
            'projectInfo' => ProjectInfo::class
        ]
    ],
    'controller_plugins' => [
        'factories' => [
            UserInfoPlugin::class => UserInfoPluginFactory::class,
        ],
        'aliases' => [
            'userInfo' => UserInfoPlugin::class,
        ]
    ],
    'controllers' => [
        'factories' => [
            Controller\IndexController::class => InvokableFactory::class,
            Controller\PanoController::class => PanoControllerFactory::class,
            Controller\CategoriesController::class => CategoriesControllerFactory::class,
            Controller\PoiController::class => PoiControllerFactory::class,
            Controller\LanguagesController::class => LanguagesControllerFactory::class,
            Controller\MediaController::class => MediaControllerFactory::class,
            Controller\SitePlansController::class => SitePlansControllerFactory::class,
            Controller\GalleriesController::class => GalleriesControllerFactory::class,
            Controller\SettingsController::class => SettingsControllerFactory::class,
            Controller\AuthController::class => AuthControllerFactory::class,
            Controller\AdministrationController::class => AdministrationControllerFactory::class,
            Controller\GamificationController::class => GamificationControllerFactory::class
        ],
    ],
    'view_manager' => [
        'display_not_found_reason' => false,
        'display_exceptions'       => false,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => [
            'layout/layout'           => __DIR__ . '/../view/layout/layout.phtml',
            'layout/banned'           => __DIR__ . '/../view/layout/layout-banned.phtml',
            'application/index/index' => __DIR__ . '/../view/application/index/index.phtml',
            'error/404'               => __DIR__ . '/../view/error/404.phtml',
            'error/index'             => __DIR__ . '/../view/error/index.phtml',
        ],
        'template_path_stack' => [
            __DIR__ . '/../view',
        ],
        'strategies' => array(
            'ViewJsonStrategy',
        ),
    ],
    'validators' => [
        'invokables' => [
            'PoiNameValidator' => PoiNameValidator::class
        ],
    ],
    'access_filter' => [
        'options' => [
            // The access filter can work in 'restrictive' (recommended) or 'permissive'
            // mode. In restrictive mode all controller actions must be explicitly listed
            // under the 'access_filter' config key, and access is denied to any not listed
            // action for not logged in users. In permissive mode, if an action is not listed
            // under the 'access_filter' key, access to it is permitted to anyone (even for
            // not logged in users. Restrictive mode is more secure and recommended to use.
            'mode' => 'restrictive'
        ],
        'controllers' => [
            Controller\AuthController::class => [
                // Allow anyone to visit "login" action
                ['actions' => ['login'], 'allow' => '*'],
            ],
            Controller\PanoController::class => [
                ['actions' => ['getShortLinkAjax', 'showShareWindowAjax', 'searchAjax', 'saveFrontendXmlAjax', 'addProjectAjax'], 'allow' => '*']
            ],
            Controller\MediaController::class => [
                ['actions' => ['getMediaFile'], 'allow' => '*']
            ]
        ]
    ],
    'service_manager' => [
        'factories' => [
            AuthenticationService::class => Factory\AuthenticationServiceFactory::class,
            Service\AuthAdapter::class => AuthAdapterFactory::class,
            Service\AuthManager::class => AuthManagerFactory::class,
            Service\UserManager::class => UserManagerFactory::class
        ],
    ],
];
