<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Controller;

use Application\Model\CategoriesTable;
use Application\Model\SettingsTable;
use Application\Model\UserTable;
use Application\Form\UserEditForm;
use Application\Model\User;
use Application\Model\VRMCommon;
use Application\Model\XmlWriter;
use Application\Service\UserManager;
use Laminas\Db\Adapter\Adapter;
use Laminas\Db\TableGateway\Feature\GlobalAdapterFeature;
use Laminas\InputFilter\Input;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\Validator\EmailAddress;
use Laminas\Validator\NotEmpty;
use Laminas\View\Model\JsonModel;
use Laminas\View\Model\ViewModel;

/**
 * Class AdministrationController
 *
 * @package Project\Controller
 */
class AdministrationController extends AbstractActionController
{

    private $staticDbAdapter;
    private $userTable;
    private $userManager;
    private $categoriesTable;
    private $settingsTable;
    private $xmlWriter;

    public function __construct(Adapter $staticDbAdapter, UserTable $userTable, UserManager $userManager, CategoriesTable $categoriesTable, SettingsTable $settingsTable, XmlWriter $xmlWriter)
    {
        $this->staticDbAdapter = $staticDbAdapter;
        $this->userTable = $userTable;
        $this->userManager = $userManager;
        $this->categoriesTable = $categoriesTable;
        $this->settingsTable = $settingsTable;
        $this->xmlWriter = $xmlWriter;
    }

    /**
     * Default action - returns users list
     */
    public function indexAction()
    {
        $messages = [];
        if ($this->request->isPost()) {

            if ($this->userInfo()->getUser()->usertype != User::TYPE_DEV) {
                header('HTTP/1.0 403 Forbidden');
                exit;
            }

            $file = $this->params()->fromFiles('restore');

            $dbDir = __DIR__ . '/../../../../data/';
            $dbFile = $dbDir . DIRECTORY_SEPARATOR . 'vrm.db';

            $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
            if ($fileExtension == 'vrm') {
                move_uploaded_file($file['tmp_name'], $dbFile);
                $this->xmlWriter->checkDataIntegrity();

                $jsonResponse = new JsonModel();
                $jsonResponse->setVariables([
                    'success' => true
                ]);

                return $jsonResponse;

            } else {
               $messages[] = _('Incorrect backup type');
            }
        }

        $usersList = $this->userTable->getAllUsers();

        $krpanoLicense = null;

        if ($this->userInfo()->getUser()->usertype == User::TYPE_DEV) {
            $krpanoLicense = $this->settingsTable->get('krpano_license');
        }

        return new ViewModel(['usersList' => $usersList, 'krpanoLicense' => $krpanoLicense]);
    }

    /**
     * Edit user, or create a new one
     */
    public function editAction()
    {
        //get projects categories
        $categoryList = $this->categoriesTable->getCategories();

        //get user id
        $userId = $this->params()->fromRoute('id', false);

        // set static DB adapter to be used by fieldsets validation
        GlobalAdapterFeature::setStaticAdapter($this->staticDbAdapter);

        //get user form
        $userForm = new UserEditForm();

        $allowedCategories = [];
        if ($userId > 0) {
            //get user data
            $userData = (array)$this->userTable->getUserById($userId);

            //unset unnecessary data
            unset($userData['password']);
            unset($userData['token']);
            unset($userData['date_add']);

            $userSettings = json_decode($userData['settings'], true);
            if (isset($userSettings['allowed_categories'])) {
                $allowedCategories = array_flip($userSettings['allowed_categories']);
            }
            if (isset($userSettings['new_pano'])) {
                $userData['new_pano'] = $userSettings['new_pano'];
            }

            $userForm->populateValues($userData);

        }

        if ($this->userInfo()->getUser()->usertype === User::TYPE_DEV) {
            $userForm->get('system_logo_link')->setValue($this->settingsTable->get('system_logo_link'));
        }

        $submission = false;

        $defaultProjectLang = $this->settingsTable->get('default_language');

        //set categories in form
        $populateArray = [];
        foreach ($categoryList as $key => $value) {
            if (!isset($value['name'][$defaultProjectLang])) {
                continue;
            }
            $populateArray[] = [
                'label'    => ' ' . $value['name'][$defaultProjectLang],
                'value'    => $key,
                'selected' => isset($allowedCategories[$key]) ? true : false
            ];
        }
        $userForm->get('allowed_categories')->setValueOptions($populateArray);

        if ($this->request->isPost()) {

            $data = $this->getRequest()->getPost()->toArray();

            if (!empty($data['id'])) {

                //validation
                $loginFilter = new Input('login');
                $loginFilter->getValidatorChain()->attach(new NotEmpty());
                $loginFilter->getValidatorChain()->attach(new EmailAddress());

                $userForm->getInputFilter()->remove('login');
                $userForm->getInputFilter()->add($loginFilter);

                if (!$data['change_password']) {
                    $userForm->getInputFilter()->get('password')->setRequired(false);
                }

                if ($this->userInfo()->getUser()->usertype == User::TYPE_DEV && $this->userInfo()->getUser()->id == $data['id']) {
                    $userForm->remove('usertype');
                    $userForm->getInputFilter()->get('usertype')->setRequired(false);
                    $userForm->remove('active');
                    $userForm->getInputFilter()->get('active')->setRequired(false);
                    $userForm->remove('new_pano');
                    $userForm->getInputFilter()->get('new_pano')->setRequired(false);
                }

            }

            //set data in form
            $userForm->setData($data);

            //validation
            if ($userForm->isValid()) {

                $this->userManager->saveUser($userForm->getData(), $this->userInfo()->getUser()->usertype);

                if ($this->userInfo()->getUser()->usertype == User::TYPE_DEV && $this->userInfo()->getUser()->id == $data['id']) {
                    $mediaDir = __DIR__ . '/../../../../../media/';
                    if (!is_dir($mediaDir)) {
                        mkdir($mediaDir, 0777, true);
                    }
                    $logo = $this->getRequest()->getFiles()->getArrayCopy();
                    if (isset($logo['system_logo']['error']) && $logo['system_logo']['error'] === UPLOAD_ERR_OK) {
                        $tmpFile = uniqid() . $logo['system_logo']['name'];
                        move_uploaded_file($logo['system_logo']['tmp_name'], $mediaDir . $tmpFile);
                        @unlink($mediaDir . 'system_logo.png');
                        VRMCommon::resizeImage($mediaDir . $tmpFile, $mediaDir . 'system_logo.png', 220, 74);
                        @unlink($mediaDir . $tmpFile);
                    }

                    $this->settingsTable->set('system_logo_link', $userForm->get('system_logo_link')->getValue());

                    if ($userForm->get('system_logo_remove')->getValue() == 1) {
                        @unlink($mediaDir . 'system_logo.png');
                        $this->settingsTable->set('system_logo_link', '');
                    }
                }

                $this->flashMessenger()->addSuccessMessage(true);

                //redirect to administration
                $this->redirect()->toRoute('vrm', [
                    'controller' => 'administration',
                    'action'     => 'index'
                ]);
            } else {
                $submission = 'error';
            }
        }

        return new ViewModel(['form' => $userForm, 'submission' => $submission]);
    }


    /**
     * Deletes user from db
     */
    public function removeUserAjaxAction()
    {
        //get user id
        $userId = $this->params()->fromPost('id', false);

        //get user table
        $this->userTable->deleteById($userId);

        $jsonResponse = new JsonModel();
        $jsonResponse->setVariables([
                                        'success' => true
                                    ]);

        return $jsonResponse;
    }

    /**
     * Creates a backup and sends the database file to the user
     */
    public function createBackupAction()
    {
        if ($this->userInfo()->getUser()->usertype != User::TYPE_DEV) {
            header('HTTP/1.0 403 Forbidden');
            exit;
        }

        $dbDir = __DIR__ . '/../../../../data/';
        $dbFile = $dbDir . DIRECTORY_SEPARATOR . 'vrm.db';
        $backupName = 'vrm-backup-' . date('Y-m-d') . '.vrm';

        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $backupName . '"');
        header('Content-Transfer-Encoding: binary');
        readfile($dbFile);
        exit;
    }

    /**
     * Resets the system to new install
     */
    public function resetAction()
    {

        if ($this->userInfo()->getUser()->usertype != User::TYPE_DEV) {
            header('HTTP/1.0 403 Forbidden');
            exit;
        }

        $floorPlansDir = __DIR__ . '/../../../../../floorplans/';
        VRMCommon::removeDirectory($floorPlansDir, true);

        $panosDir = __DIR__ . '/../../../../../panos/';
        VRMCommon::removeDirectory($panosDir, true);

        $mediaDir = __DIR__ . '/../../../../../media/';
        VRMCommon::removeDirectory($mediaDir, true);

        $stickersDir = __DIR__ . '/../../../../../skin/stickers';
        VRMCommon::removeDirectory($stickersDir, true);

        $dbDir = __DIR__ . '/../../../../data/';

        // replace DB
        @copy($dbDir . 'vrm-init.db', $dbDir . 'vrm.db');

        // remove files
        @unlink(__DIR__ . '/../../../../../tour.js');
        @unlink(__DIR__ . '/../../../../../tour.xml');
        @unlink(__DIR__ . '/../../../../../tourdata.xml');

        return $this->redirect()->toRoute('vrm', [
            'controller' => 'auth',
            'action'     => 'logout'
        ]);
    }

    /**
     * Clones the system to new directory
     */
    public function cloneSystemAjaxAction()
    {

        if ($this->userInfo()->getUser()->usertype != User::TYPE_DEV) {
            header('HTTP/1.0 403 Forbidden');
            exit;
        }

        $newProjectName = trim($this->params()->fromPost('newProjectName'));
        $newDirectory = trim($this->params()->fromPost('newDirectory'));
        $saveLicense = (int)$this->params()->fromPost('saveLicense');
        $fullCopy = (int)$this->params()->fromPost('fullCopy');

        $messages = [];
        // validate new directory name
        if (!preg_match('/^[a-z0-9-_]+$/', $newDirectory)) {
            $messages[] = 'new-directory';
        }

        if (!$newProjectName) {
            $messages[] = 'new-project-name';
        }

        if ($messages) {
            $jsonResponse = new JsonModel();
            $jsonResponse->setVariables(['success' => false, 'messages' => $messages]);
            return $jsonResponse;
        }

        $source = __DIR__ . '/../../../../..';
        $source = realpath($source);
        $destination = __DIR__ . '/../../../../../..';
        $destination = realpath($destination) . DIRECTORY_SEPARATOR . $newDirectory;

        // check if the directory does not exist
        if (is_dir($destination)) {
            $messages[] = 'dir-error-exists';
            $jsonResponse = new JsonModel();
            $jsonResponse->setVariables(['success' => false, 'messages' => $messages]);
            return $jsonResponse;
        }

        // try to create new directory
        $result = @mkdir($destination);
        if (!$result) {
            $messages[] = 'dir-error';
            $jsonResponse = new JsonModel();
            $jsonResponse->setVariables(['success' => false, 'messages' => $messages]);
            return $jsonResponse;
        }

        if ($fullCopy === 1) {
            VRMCommon::copyDirectory($source, $destination);
        } else {
            $copyPaths = ['admin', 'editor', 'js', 'plugins', 'skin', 'livepano', 'gamification'];
            $copyFiles = ['.htaccess', 'index.php', 'panoenv.xml', 'tooltip.html', 'tooltip.xml'];

            foreach ($copyPaths as $copyPath) {
                VRMCommon::copyDirectory($source . DIRECTORY_SEPARATOR . $copyPath, $destination . DIRECTORY_SEPARATOR . $copyPath);
            }

            foreach ($copyFiles as $copyFile) {
                copy($source . DIRECTORY_SEPARATOR . $copyFile, $destination . DIRECTORY_SEPARATOR . $copyFile);
            }

            // remove old stickers
            $stickersDir = $destination . '/skin/stickers';
            VRMCommon::removeDirectory($stickersDir, true);
        }

        // remove cache
        $cacheDir = $destination . '/admin/data/cache';
        VRMCommon::removeDirectory($cacheDir, true);

        // refresh database and change project title
        $dbDir = $destination . '/admin/data/';

        if ($fullCopy !== 1) {
            @copy($dbDir . 'vrm-init.db', $dbDir . 'vrm.db');
        }

        $db = new \SQLite3($dbDir . 'vrm.db');

        $q = $db->prepare('SELECT value FROM settings WHERE key="project_lang_settings"');
        $result = $q->execute()->fetchArray();
        $langSettings = json_decode($result['value'], true);
        foreach ($langSettings as $newLang => $newSettings) {
            $langSettings[$newLang]['name'] = filter_var($newProjectName);
        }

        $newLangSettings = str_replace("'", "''", json_encode($langSettings));

        $db->exec('UPDATE settings SET `value`=\'' . $newLangSettings . '\' WHERE key="project_lang_settings"');

        // update developer password to the current one
        $userPassword = $this->userInfo()->getUser()->password;
        $db->exec('UPDATE users SET `password`=\'' . $userPassword . '\' WHERE usertype="developer"');

        // update version of the system for shallow copy
        if ($fullCopy !== 1) {
            $db->exec('UPDATE settings SET `value`=\'' . $this->settingsTable->get('version') . '\' WHERE key="version"');
        }

        // make krpano executable
        shell_exec('chmod +x ' . $destination . '/admin/data/bin/krpano/krpanotools');

        // register krpano (if code provided)
        $regCode = filter_var(str_replace([PHP_EOL, "\n", "\r"], '', trim($this->params()->fromPost('krpanoLicense'))), FILTER_SANITIZE_STRING);
        if ($regCode) {
            shell_exec($destination . '/admin/data/bin/krpano/krpanotools register ' . $regCode);
        }

        if ($saveLicense === 1) {
            $this->settingsTable->set('krpano_license', $regCode);
            $db->exec('DELETE FROM settings WHERE key="krpano_license"');
            $db->exec('INSERT INTO settings(`id`, `key`, `value`) VALUES(NULL, "krpano_license", \'' . $regCode . '\')');
        }

        $httpHost = isset($_SERVER['HTTP_HOST'])?$_SERVER['HTTP_HOST']:'localhost';
        $isSSL = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != '' ? "https" : "http";
        $subdirPart = str_replace('/admin', '', dirname($_SERVER['PHP_SELF']));
        $subdirPartArray = explode('/', $subdirPart);
        array_pop($subdirPartArray);
        $subdirPartNew = implode('/', $subdirPartArray);
        $newAdminLink = $isSSL . '://' . $httpHost . $subdirPartNew . '/' . $newDirectory . '/admin/';

        $jsonResponse = new JsonModel();
        $jsonResponse->setVariables(['success' => true, 'link' => $newAdminLink]);
        return $jsonResponse;
    }

    /**
     * Triggers registration of krpanotools
     */
    public function registerKrpanoAjaxAction()
    {

        if ($this->userInfo()->getUser()->usertype != User::TYPE_DEV) {
            header('HTTP/1.0 403 Forbidden');
            exit;
        }

        $krpanoLicense = trim($this->params()->fromPost('krpanoLicense'));
        $saveLicense = (int)$this->params()->fromPost('saveLicense');

        // register krpano
        $regCode = filter_var(str_replace([PHP_EOL, "\n", "\r"], '', $krpanoLicense), FILTER_SANITIZE_STRING);

        if (!$regCode) {
            $jsonResponse = new JsonModel();
            $jsonResponse->setVariables(['success' => false, 'message' => 'no-code']);
            return $jsonResponse;
        }

        @shell_exec('chmod +x ' . __DIR__ . '/../../../../data/bin/krpano/krpanotools');
        $krpanoOut = @shell_exec(__DIR__ . '/../../../../data/bin/krpano/krpanotools register ' . $regCode);

        if ($krpanoOut === null) {
            $krpanoOut = _('Unable to execute krpanotools library');
        } else {
            // write a new tour.js file
            @shell_exec(__DIR__ . '/../../../../data/bin/krpano/krpanotools protect -o=tour.js -bf');
        }

        if ($saveLicense === 1) {
            $this->settingsTable->set('krpano_license', $regCode);
        }

        $jsonResponse = new JsonModel();
        $jsonResponse->setVariables(['success' => true, 'message' => $krpanoOut]);
        return $jsonResponse;
    }

    /**
     * Removes krpano license key from the database
     */
    public function unregisterAction()
    {
        if ($this->userInfo()->getUser()->usertype != User::TYPE_DEV) {
            header('HTTP/1.0 403 Forbidden');
            exit;
        }

        $this->settingsTable->set('krpano_license', '');

        return $this->redirect()->toRoute('vrm', [
            'controller' => 'administration',
            'action'     => 'index'
        ]);
    }
}
