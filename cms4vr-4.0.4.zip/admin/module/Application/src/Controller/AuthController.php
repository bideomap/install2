<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Controller;

use Application\Model\SettingsTable;
use Application\Model\UserTable;
use Application\Service\AuthManager;
use Application\Service\UserManager;
use Laminas\Authentication\AuthenticationService;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\JsonModel;
use Laminas\View\Model\ViewModel;
use Laminas\Authentication\Result;
use Laminas\Uri\Uri;
use Application\Form\LoginForm;

/**
 * This controller is responsible for letting the user to log in and log out.
 */
class AuthController extends AbstractActionController
{

    private $userTable;
    private $authManager;
    private $authService;
    private $userManager;
    private $settingsTable;

    /**
     * Constructor.
     *
     * @param UserTable             $userTable
     * @param AuthManager           $authManager
     * @param AuthenticationService $authService
     * @param UserManager           $userManager
     */
    public function __construct(UserTable $userTable, AuthManager $authManager, AuthenticationService $authService, UserManager $userManager, SettingsTable $settingsTable)
    {
        $this->userTable = $userTable;
        $this->authManager = $authManager;
        $this->authService = $authService;
        $this->userManager = $userManager;
        $this->settingsTable = $settingsTable;
    }

    /**
     * Authenticates user given email address and password credentials.
     */
    public function loginAction()
    {
        // Retrieve the redirect URL (if passed). We will redirect the user to this
        // URL after successful login.
        $redirectUrl = (string)$this->params()->fromQuery('redirectUrl', '');
        if (strlen($redirectUrl)>2048) {
            throw new \Exception("Too long redirectUrl argument passed");
        }

        // Create login form
        $form = new LoginForm();
        $form->get('redirect_url')->setValue($redirectUrl);

        // Store login status.
        $isLoginError = false;

        // Check if user has submitted the form
        if ($this->getRequest()->isPost()) {

            // Fill in the form with POST data
            $data = $this->params()->fromPost();

            $form->setData($data);

            // Validate form
            if($form->isValid()) {

                // Get filtered and validated data
                $data = $form->getData();

                // Perform login attempt.
                $result = $this->authManager->login($data['email'],
                                                    $data['password'], $data['remember_me']);

                // Check result.
                if ($result->getCode() == Result::SUCCESS) {

                    unset($_SESSION['license_checked'], $_SESSION['krpanoRegError']);

                    // Get redirect URL.
                    $redirectUrl = $this->params()->fromPost('redirect_url', '');

                    if (!empty($redirectUrl)) {
                        // The below check is to prevent possible redirect attack
                        // (if someone tries to redirect user to another domain).
                        $uri = new Uri($redirectUrl);
                        if (!$uri->isValid() || $uri->getHost()!=null)
                            throw new \Exception('Incorrect redirect URL: ' . $redirectUrl);
                    }

                    // check if shell_exec is available and update database if needed
                    @shell_exec('chmod +x ' . __DIR__ . '/../../../../data/bin/krpano/krpanotools');
                    $shellExec = trim(@shell_exec(__DIR__ . '/../../../../data/bin/krpano/krpanotools')) !== '';
                    $this->settingsTable->set('shellExec_enabled', (int)$shellExec);

                    // register if there is a key in the database
                    $regCode = $this->settingsTable->get('krpano_license');
                    if ($shellExec && $regCode && (int)$this->settingsTable->get('upd_2019.11.1') !== 1) {
                        @shell_exec(__DIR__ . '/../../../../data/bin/krpano/krpanotools register ' . $regCode);
                    }

                    // check krpano registration
                    if ($shellExec) {
                        $regInfo = trim(@shell_exec(__DIR__ . '/../../../../data/bin/krpano/krpanotools register show'));
                        if ($regInfo === 'Not registered.') {
                            $_SESSION['krpanoRegError'] = true;
                        } else {
                            @shell_exec(__DIR__ . '/../../../../data/bin/krpano/krpanotools protect -o=tour.js -bf');
                            $this->settingsTable->set('upd_2019.11.1', 1);
                        }
                    }

                    // If redirect URL is provided, redirect the user to that URL;
                    // otherwise redirect to Home page.
                    if(empty($redirectUrl)) {
                        return $this->redirect()->toRoute('vrm', ['controller' => 'index', 'action' => 'index']);
                    } else {
                        $this->redirect()->toUrl($redirectUrl);
                    }
                } else {
                    $isLoginError = true;
                }
            } else {
                $isLoginError = true;
            }
        }

        $this->layout('layout/layout-login');

        return new ViewModel([
                                 'form' => $form,
                                 'isLoginError' => $isLoginError,
                                 'redirectUrl' => $redirectUrl
                             ]);
    }

    /**
     * The "logout" action performs logout operation.
     */
    public function logoutAction()
    {
        $this->authManager->logout();

        return $this->redirect()->toRoute('vrm', ['controller' => 'auth', 'action' => 'login']);
    }


    public function resetPasswordAction()
    {
        $changeRequested = false;

        if ($this->getRequest()->isPost()) {
            $email = $this->params()->fromPost('email');
            $this->userManager->generatePasswordResetToken($email);
            $changeRequested = true;
        }
        $this->layout('layout/layout-login');

        return new ViewModel([
            'changeRequested' => $changeRequested
        ]);
    }

    public function setPasswordAction()
    {
        $changeRequested = false;
        $token = $this->params()->fromQuery('token');

        if ($this->getRequest()->isPost()) {

            $password = $this->params()->fromPost('password');
            $this->userManager->setNewPasswordByToken($token, $password);
            $changeRequested = true;
        }
        $this->layout('layout/layout-login');

        $isTokenValid = $this->userManager->validatePasswordResetToken($token);

        return new ViewModel([
            'changeRequested' => $changeRequested,
            'isTokenValid' => $isTokenValid
        ]);
    }

    /**
     * Sets user lang
     *
     * @return JsonModel
     */
    public function setLangAjaxAction()
    {
        if (!$this->getRequest()->isPost() || !$this->authService->hasIdentity()) {
            return new JsonModel(['success' => false]);
        }

        $language = $this->params()->fromPost('lang');
        $login = $this->authService->getIdentity();

        $this->userTable->setLangForUser($login, $language);

        return new JsonModel(['success' => true]);
    }
}
