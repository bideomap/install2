<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Controller;

use Application\Form\CategoryForm;
use Application\Model\Categories;
use Application\Model\CategoriesTable;
use Application\Model\CategoryPhrases;
use Application\Model\CategoryPhrasesTable;
use Application\Model\LanguagesTable;
use Application\Model\PanoCategoryConnections;
use Application\Model\PanoCategoryConnectionsTable;
use Application\Model\PanoCMSCommon;
use Application\Model\PanosTable;
use Application\Model\VRMCommon;
use Application\Model\XmlWriter;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\JsonModel;
use Laminas\View\Model\ViewModel;

/**
 * Class CategoriesController
 *
 * @package Project\Controller
 */
class CategoriesController extends AbstractActionController
{

    private $categoriesTable;
    private $categoryPhrasesTable;
    private $panoCategoryConnectionsTable;
    private $languagesTable;
    private $panosTable;
    private $xmlWriter;

    public function __construct(CategoriesTable $categoriesTable, CategoryPhrasesTable $categoryPhrasesTable, PanoCategoryConnectionsTable $panoCategoryConnectionsTable, LanguagesTable $languagesTable, PanosTable $panosTable, XmlWriter $xmlWriter)
    {
        $this->categoriesTable = $categoriesTable;
        $this->categoryPhrasesTable = $categoryPhrasesTable;
        $this->panoCategoryConnectionsTable = $panoCategoryConnectionsTable;
        $this->languagesTable = $languagesTable;
        $this->panosTable = $panosTable;
        $this->xmlWriter = $xmlWriter;
    }
    /**
     * Default action - returns category list
     *
     * @return viewModel
     */
    public function indexAction()
    {

        // get allowed categories
        $allowedCategories = $this->userInfo()->allowedCategories();

        $categoryList = $this->categoriesTable->getCategories($allowedCategories);

        return new ViewModel(['categoryList' => $categoryList]);
    }

    /**
     * Lists panoramas from specific category
     * @return ViewModel
     */
    public function indexPanoAction()
    {
        $categoryId = $this->params()->fromRoute('cat');
        $allowedCategories = $this->userInfo()->allowedCategories();
        $panoList = $this->panosTable->getPanoList($categoryId, 'langShort', $allowedCategories);
        return new ViewModel(['panoList' => $panoList, 'categoryId' => $categoryId]);

    }

    /**
     * Updates position of categories
     */
    public function updatePositionAjaxAction()
    {
        //get params
        $rowsPositions = $this->params()->fromPost('rowsPositions', false);

        //set flag
        $success = false;

        if (!empty($rowsPositions)) {
            //update target table rows
            foreach ($rowsPositions as $position => $row) {
                $this->categoriesTable->update($row['rowId'], ['position' => $position]);
            }
            $this->xmlWriter->writeTourDataFile();
            $success = true;
        }


        //return json model
        $result = new JsonModel([
            'success' => $success
        ]);

        return $result;
    }

    /**
     * Edit action - edit existing category or save new one
     *
     */
    public function editAction()
    {
        // build a form
        $categoryForm = new CategoryForm();

        // get category id from route
        $categoryId = $this->params()->fromRoute('id', false);

        //get project languages
        $projectLanguages = $this->languagesTable->getLanguages(false)->toArray();

        //remove thumbnail validation
        if ($categoryId !== false) {
            $categoryForm->getInputFilter()->remove('thumbnail');
        }

        // the user clicked "save", let's proceed
        if ($this->request->isPost()) {

            // dump all data to an array and bind them to the form
            $data = $this->getRequest()->getPost()->toArray();

            //get files
            $files = $this->getRequest()->getFiles()->toArray();

            //merge array for validation
            $mergedValidationData = $data;
            foreach ($mergedValidationData['category_fs'] as $key => $value) {
                if (!empty($files['category_fs'][$key]['mp3']['name'])) {
                    $mergedValidationData['category_fs'][$key]['mp3'] = $files['category_fs'][$key]['mp3'];
                }
            }

            $formValidate = $categoryForm->setData($mergedValidationData);

            if ($formValidate->isValid()) {

                //create array to save
                $categoriesTableData = [
                    'id'            => $data['id'],
                ];

                //add position of category - needed for table relation
                if (empty($categoriesTableData['id'])) {
                    $categoriesTableData['position'] = $this->categoriesTable->countCategories(); // 0-index based order
                }

                //save category ang get id
                $category = new Categories();
                $category->exchangeArray($categoriesTableData);
                $categoryId = $this->categoriesTable->save($category);

                //save name and desc
                if (!empty($data['category_fs'])) {
                    foreach ($data['category_fs'] as $key => $value) {

                        //create array for exchange
                        $categoriesPhrasesTableData = [
                            'id'            => ($value['category_phrase_id'] > 0 ? $value['category_phrase_id'] : null),
                            'categories_id' => $categoryId,
                            'languages_id'  => $value['language_id'],
                            'name'          => $value['name'],
                            'description'   => $value['description'],
                            'media_id'      => $value['media_id']
                        ];

                        //save category phrases foreach project language
                        $categoryPhrase = new CategoryPhrases();
                        $categoryPhrase->exchangeArray($categoriesPhrasesTableData);
                        $this->categoryPhrasesTable->save($categoryPhrase);
                    }
                }

                //save panoramas connections
                if (!empty($data['panorama'])) {

                    $oldConnections = $this->panoCategoryConnectionsTable->getConnectionsByCategoryId($categoryId);

                    //clear all connections
                    $this->panoCategoryConnectionsTable->clearConnectionsByCategoryId($categoryId);

                    foreach ($data['panorama'] as $panoId => $value) {
                        if ($value == 0) continue;

                        $position = isset($oldConnections[$panoId]) ? $oldConnections[$panoId] : count($oldConnections);

                        //create array to exchange
                        $categories = ['pano_id' => $panoId, 'category_id' => $categoryId, 'pano_position' => $position];

                        //get connections model
                        $categoriesConnections = new PanoCategoryConnections();
                        $categoriesConnections->exchangeArray($categories);

                        //save connection
                        $this->panoCategoryConnectionsTable->save($categoriesConnections);
                    }
                }

                $this->flashMessenger()->addSuccessMessage($categoryId);

                // update tourdata.xml file
                $this->xmlWriter->writeTourDataFile();

                //redirect to category list after saving form
                return $this->redirect()->toRoute('vrm', [
                    'controller' => 'categories',
                    'action'     => 'index'
                ]);
            }

        } else {
            //if user is opening existing category set data to fields

            if ($categoryId) {
                //get and set category data
                $categoryData = $this->categoriesTable->getByCategoryId($categoryId);

                //check if all languages are included
                foreach ($projectLanguages as $key => $value) {
                    if (!isset($categoryData['category_fs'][$value['id']])) {
                        $categoryData['category_fs'][$value['id']] =
                            ['language' => $value['short'], 'language_id' => $value['id']];
                    }
                }

                //populate values
                $categoryForm->populateValues($categoryData);

            } else {
                //create fieldsets
                $populateLanguageArray = [];
                foreach ($projectLanguages as $key => $value) {
                    $populateLanguageArray[] = ['language' => $value['short'], 'language_id' => $value['id']];
                }
                $categoryForm->populateValues(['category_fs' => $populateLanguageArray]);
            }

        }

        //get panoramas
        $orderByName = $categoryId ? false : true;
        $panosList = $this->panosTable->getConnections($orderByName);
        foreach ($panosList as $key => $value) {

            //set pano thumb path
            $thumbDir = '../panos/p' . $value['id'] . '.tiles/' . 'thumb.jpg';

            //set thumbs
            $panosList[$key]['thumb_dir'] = $thumbDir;
        }

        return new ViewModel([
                                 'categoryId'        => $categoryId,
                                 'form'              => $categoryForm,
                                 'languageList'      => $projectLanguages,
                                 'panosList'         => $panosList
                             ]);

    }

    /**
     * Delete category ajax action - deletes all data related to category
     *
     * @return viewModel
     */
    public function deleteCategoryAjaxAction()
    {
        //get category id
        $categoryId = $this->params()->fromPost('categoryId', false);

        $success = false;

        if ($categoryId) {

            //remove connections
            $this->panoCategoryConnectionsTable->clearConnectionsByCategoryId($categoryId);

            //remove category phrases
            $this->categoryPhrasesTable->deleteByCategoryId($categoryId);

            //remove data from category table
            $this->categoriesTable->deleteById($categoryId);

            // update tourdata.xml file
            $this->xmlWriter->writeTourDataFile();

            $success = true;

        }

        //return json model
        $result = new JsonModel([
                                    'success' => $success
                                ]);

        return $result;
    }

    /**
     * Changes visibility of category in the project (publish/unpublish operations)
     *
     * @return JsonModel
     */
    public function changeCategoryVisibilityAjaxAction()
    {
        $id = $this->params()->fromPost('id');
        $visible = $this->params()->fromPost('visible');

        $visible ^= 1;

        $result = $this->categoriesTable->changeVisibility($id, $visible);

        $this->xmlWriter->writeTourDataFile();

        return new JsonModel(['success' => $result ? true : false]);

    }

    /**
     *
     * @return JsonModel
     */
    public function updateCategoryNameAjaxAction()
    {
        $id = $this->params()->fromPost('id');
        $name = $this->params()->fromPost('name');
        $lang = $this->params()->fromPost('lang');

        $langId = $this->languagesTable->getLanguageByShortName($lang)->id;
        $categoryPhrases = $this->categoryPhrasesTable->getByCategoryIdAndLanguageId($id, $langId);
        $categoryPhrases->name = $name;

        $this->categoryPhrasesTable->save($categoryPhrases);

        $this->xmlWriter->writeTourDataFile();

        return new JsonModel(['success' => true]);

    }
}
