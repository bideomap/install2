<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Controller;

use Application\Form\CategoryForm;
use Application\Form\GalleryForm;
use Application\Model\Categories;
use Application\Model\CategoryPhrases;
use Application\Model\Galleries;
use Application\Model\GalleriesTable;
use Application\Model\GalleryPhrases;
use Application\Model\GalleryPhrasesTable;
use Application\Model\LanguagesTable;
use Application\Model\MediaGalleriesConnections;
use Application\Model\MediaGalleriesConnectionsTable;
use Application\Model\PanoCategoryConnections;
use Application\Model\PanoCMSCommon;
use Application\Model\XmlWriter;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\JsonModel;
use Laminas\View\Model\ViewModel;
use Laminas\View\Renderer\PhpRenderer;

/**
 * Class GalleriesController
 *
 * @package Application\Controller
 */
class GalleriesController extends AbstractActionController
{

    private $galleriesTable;
    private $galleryPhrasesTable;
    private $languagesTable;
    private $mediaGalleriesConnectionsTable;
    private $renderer;
    private $xmlWriter;

    public function __construct(GalleriesTable $galleriesTable, GalleryPhrasesTable $galleryPhrasesTable, LanguagesTable $languagesTable, MediaGalleriesConnectionsTable $mediaGalleriesConnectionsTable, PhpRenderer $renderer, XmlWriter $xmlWriter)
    {
        $this->galleriesTable = $galleriesTable;
        $this->galleryPhrasesTable = $galleryPhrasesTable;
        $this->languagesTable = $languagesTable;
        $this->mediaGalleriesConnectionsTable = $mediaGalleriesConnectionsTable;
        $this->renderer = $renderer;
        $this->xmlWriter = $xmlWriter;
    }
    /**
     * Default action - returns galleries list
     *
     * @return viewModel
     */
    public function indexAction()
    {

        $galleriesList = $this->galleriesTable->getGalleriesList();

        return new ViewModel(['galleriesList' => $galleriesList]);
    }

    /**
     * Edit action - edit existing category or save new one
     *
     */
    public function editAction()
    {
        // build a form
        $galleryForm = new GalleryForm();

        // get gallery id from route
        $galleryId = $this->params()->fromRoute('id', false);

        //get project languages
        $projectLanguages = $this->languagesTable->getLanguages(false)->toArray();

        // the user clicked "save", let's proceed
        if ($this->request->isPost()) {

            // dump all data to an array and bind them to the form
            $data = $this->getRequest()->getPost()->toArray();

            $formValidate = $galleryForm->setData($data);

            if ($formValidate->isValid()) {

                //save gallery ang get id
                $gallery = new Galleries();
                $gallery->exchangeArray($data);
                $galleryId = $this->galleriesTable->save($gallery);

                //save name and desc
                if (!empty($data['gallery_fs'])) {
                    foreach ($data['gallery_fs'] as $key => $value) {

                        //create array for exchange
                        $galleryPhrasesTableData = [
                            'id'            => ($value['gallery_phrase_id'] > 0 ? $value['gallery_phrase_id'] : null),
                            'galleries_id' => $galleryId,
                            'languages_id'  => $value['language_id'],
                            'name'          => $value['name']
                        ];


                        //save gallery phrases foreach project language
                        $galleryPhrase = new GalleryPhrases();
                        $galleryPhrase->exchangeArray($galleryPhrasesTableData);
                        $this->galleryPhrasesTable->save($galleryPhrase);
                    }
                }

                // update tourdata.xml file
                $this->xmlWriter->writeTourDataFile();


                $this->flashMessenger()->addSuccessMessage(true);

                //redirect to category list after saving form
                return $this->redirect()->toRoute('vrm', [
                    'controller' => 'galleries',
                    'action'     => 'index'
                ]);
            }


        } else {
            //if user is opening existing category set data to fields

            if ($galleryId) {
                //get and set category data
                $galleryData = $this->galleriesTable->getByGalleryId($galleryId);

                //check if all languages are included
                foreach ($projectLanguages as $key => $value) {
                    if (!isset($galleryData['gallery_fs'][$value['id']])) {
                        $galleryData['gallery_fs'][$value['id']] =
                            ['language' => $value['short'], 'language_id' => $value['id']];
                    }
                }

                //populate values
                $galleryForm->populateValues($galleryData);

            } else {
                //create fieldsets
                $populateLanguageArray = [];
                foreach ($projectLanguages as $key => $value) {
                    $populateLanguageArray[] = ['language' => $value['short'], 'language_id' => $value['id']];
                }
                $galleryForm->populateValues(['gallery_fs' => $populateLanguageArray]);
            }

        }

        //get connections
        $connections = $this->mediaGalleriesConnectionsTable->getConnectionsByGallery($galleryId);

        return new ViewModel([
                                 'galleryId'        => $galleryId,
                                 'form'              => $galleryForm,
                                 'languageList'      => $projectLanguages,
                                 'connections'     => $connections,

                             ]);

    }

    /**
     * Retrieves connections between galleries and media items
     *
     * @return JsonModel
     */
    public function getGalleriesConnectionsAjaxAction()
    {
        if (!$this->getRequest()->isPost())
            die('Only internal calls');

        // get gallery id from route
        $galleryId = $this->params()->fromPost('galleriesId', false);

        //get connections
        $connections = $this->mediaGalleriesConnectionsTable->getConnectionsByGallery($galleryId);

        $htmlViewPart = new ViewModel();
        $htmlViewPart->setTerminal(true)
                     ->setTemplate('application/galleries/connections')
                     ->setVariables(['connections' => $connections]);

        // render the content
        $htmlOutput = $this->renderer->render($htmlViewPart);

        // build and return JSON
        $jsonModel = new JsonModel();
        $jsonModel->setVariables([
                                     'success' => true,
                                     'html'    => $htmlOutput
                                 ]);

        return $jsonModel;

    }

    /**
     * Deletes all data related to gallery
     *
     * @return viewModel
     */
    public function deleteGalleryAjaxAction()
    {
        //get gallery id
        $galleryId = $this->params()->fromPost('galleryId', false);

        $success = false;

        if ($galleryId) {

            //remove connections
            $this->mediaGalleriesConnectionsTable->clearConnectionsByGalleryId($galleryId);

            //remove gallery phrases
            $this->galleryPhrasesTable->deleteByGalleryId($galleryId);

            //remove data from category table
            $this->galleriesTable->deleteById($galleryId);

            // update tourdata.xml file
            $this->xmlWriter->writeTourDataFile();

            $this->flashMessenger()->addSuccessMessage(true);

            $success = true;

        }

        //return json model
        $result = new JsonModel([
                                    'success' => $success
                                ]);

        return $result;
    }

    /**
     * Saves or updates connections between galleries and media resources
     */
    public function saveConnectionsAjaxAction()
    {
        if (!$this->getRequest()->isPost())
            die('Only internal calls');

        $data = $this->getRequest()->getPost()->toArray();

        if (!isset($data['connectionIds'])) {
            $data['connectionIds'] = [];
        }

        $this->mediaGalleriesConnectionsTable->saveConnections($data['galleriesId'], $data['connectionIds']);

        // update tourdata.xml file
        $this->xmlWriter->writeTourDataFile();

        //return json model
        $result = new JsonModel([
                                    'success' => true
                                ]);

        return $result;

    }
}
