<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Controller;

use Application\Model\GamificationTable;
use Application\Model\LanguagesTable;
use Application\Model\XmlWriter;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\JsonModel;
use Laminas\View\Model\ViewModel;

/**
 * This controller is responsible for letting the user to log in and log out.
 */
class GamificationController extends AbstractActionController
{

    private $gamificationTable;
    private $languagesTable;
    private $xmlWriter;

    public function __construct(GamificationTable $gamificationTable, LanguagesTable $languagesTable, XmlWriter $xmlWriter)
    {
        $this->gamificationTable = $gamificationTable;
        $this->languagesTable = $languagesTable;
        $this->xmlWriter = $xmlWriter;
    }

    /**
     * @return ViewModel
     */
    public function indexAction()
    {
        $games = $this->gamificationTable->fetchAll();
        return new ViewModel(['games' => $games]);
    }

    /**
     * @return JsonModel
     */
    public function changeGameVisibilityAjaxAction()
    {
        $data = $this->getRequest()->getPost()->toArray();

        $gameId = $data['id'];
        $gameVisible = (bool)$data['visible'];

        $this->gamificationTable->changeVisibility($gameId, !$gameVisible);

        // update tourdata.xml file
        $this->xmlWriter->writeTourDataFile();

        return new JsonModel(['success' => true]);
    }
}
