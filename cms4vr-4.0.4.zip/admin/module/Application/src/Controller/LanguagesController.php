<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Controller;

use Application\Form\LanguagesForm;
use Application\Model\Languages;
use Application\Model\LanguagesTable;
use Application\Model\SettingsTable;
use Application\Model\XmlWriter;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\JsonModel;
use Laminas\View\Model\ViewModel;

/**
 * Class CategoriesController manages languages in the scope of the project
 *
 * @package Project\Controller
 */
class LanguagesController extends AbstractActionController
{

    private $languagesTable;
    private $xmlWriter;
    private $settingsTable;

    public function __construct(LanguagesTable $languagesTable, XmlWriter $xmlWriter, SettingsTable $settingsTable)
    {
        $this->languagesTable = $languagesTable;
        $this->xmlWriter = $xmlWriter;
        $this->settingsTable = $settingsTable;
    }
    /**
     * Shows list of languages in the project
     *
     * @return viewModel
     */
    public function indexAction()
    {
        $languagesList = $this->languagesTable->getLanguages(false);

        return new ViewModel(['languagesList' => $languagesList]);
    }

    /**
     * Edit action - edits existing language or saves a new one
     *
     */
    public function editAction()
    {

        // get language id from route
        $languageId = $this->params()->fromRoute('id', false);

        // build a form
        $languagesForm = new LanguagesForm();

        $submission = false;

        // get language
        $languageItem = $this->languagesTable->getById($languageId);

        // get Amazon voices
        try {
            $amazonVoicesPool = $this->xmlWriter->getAmazonClient()->describeVoices()->toArray();

            $amazonVoices = [];

            foreach ($amazonVoicesPool['Voices'] as $voiceId => $voice) {
                $amazonVoices[$voice['Id']] = $voice['Name'] . ' (' . $voice['LanguageName'] . ', ' . $voice['Gender'] . ')';
            }

            if ($amazonVoices) {
                array_unshift($amazonVoices, sprintf('- %s', _('None')));
                $languagesForm->get('voice')->setValueOptions($amazonVoices);
                $languagesForm->get('voice')->setAttributes(['value' => 0]);
            }
        } catch (\Exception $exception) {
            $languagesForm->get('voice')->setValueOptions(['' => _('Amazon Polly needs to be activated first')]);
        }

        // the user clicked "save", let's proceed
        if ($this->request->isPost()) {

            // dump all data to an array and bind them to the form
            $data = $this->getRequest()->getPost()->toArray();

            $languagesForm->setData($data);

            if ($languagesForm->isValid()) {

                if ($data['id'] == 0) {
                    // new language is being added
                    // fill in other relevant fields

                    $data['position'] = 1;
                    $data['public'] = 0;

                    $language = new Languages();
                    $language->exchangeArray($data);

                    $languageId = $this->languagesTable->save($language);

                    $this->copyLanguageStrings($languageId);

                } else {

                    // an existing language is being edited
                    // change default language if needed, and make it public
                    if ($data['default_language']) {
                        $this->settingsTable->set('default_language', $data['short']);
                        $data['public'] = 1;
                    }

                    $language = new Languages();
                    $language->exchangeArray($data);
                    $this->languagesTable->save($language);
                }

                $this->xmlWriter->writeTourDataFile();

                $this->flashMessenger()->addSuccessMessage(true);

                //redirect after saving form
                return $this->redirect()->toRoute('vrm', ['controller' => 'languages']);
            } else {
                $submission = 'error';
            }
        }

        if ($languageItem) {
            $languagesForm->bind($languageItem);
        } else {
            $languagesForm->get('id')->setValue(0);
        }

        // get current languages to be filtered out (same language can be added only once)
        $currentLanguages = [];
        $currentLanguagesQuery = $this->languagesTable->getLanguages(false);
        foreach ($currentLanguagesQuery as $item) {
            if (isset($languageItem->short) && $languageItem->short == $item->short) {
                continue;
            }
            $currentLanguages[] = strtolower($item->short);
        }

        return new ViewModel(['form' => $languagesForm, 'submission' => $submission, 'currentLanguages' => $currentLanguages]);

    }

    /**
     * Changes visibility of a language in the project (publish/unpublish operations)
     *
     * @return JsonModel
     */
    public function changeLanguageVisibilityAjaxAction()
    {
        $id = $this->params()->fromPost('id');
        $public = $this->params()->fromPost('public');

        $public ^= 1;

        $result = $this->languagesTable->changeVisibility($id, $public);

        if ($result) {
            $this->xmlWriter->writeTourDataFile();
            return new JsonModel(['success' => true]);
        } else {
            return new JsonModel(['success' => false]);
        }

    }


    /**
     * Delete language
     *
     * @return JsonModel
     */
    public function deleteLanguageAjaxAction()
    {
        $languageId = $this->params()->fromPost('id');

        if ($this->languagesTable->deleteById($languageId)) {
            $this->xmlWriter->writeTourDataFile();
            return new JsonModel(['success' => true]);
        }

        return new JsonModel(['success' => false]);

    }

    /**
     * Copies language strings from default language to the newly created one
     *
     * @param $newLangId
     */
    private function copyLanguageStrings($newLangId)
    {
        $defaultLang = $this->settingsTable->get('default_language');
        if (!$defaultLang) {
            $this->settingsTable->set('default_language', 'en');
            $defaultLang = 'en';
        }
        $language = $this->languagesTable->getByShort($defaultLang);

        $this->xmlWriter->writeTourDataFile();

        $this->languagesTable->copyLanguagePhrases($language->id, $newLangId);
    }

    /**
     * Updates position of languages
     */
    public function updatePositionAjaxAction()
    {
        //get params
        $rowsPositions = $this->params()->fromPost('rowsPositions', false);

        //set flag
        $success = false;

        if (!empty($rowsPositions)) {
            //update target table rows
            foreach ($rowsPositions as $position => $row) {
                $this->languagesTable->update($row['rowId'], ['position' => $position]);
            }
            $this->xmlWriter->writeTourDataFile();
            $success = true;
        }


        //return json model
        $result = new JsonModel([
                                    'success' => $success
                                ]);

        return $result;
    }

}
