<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Controller;


use Application\Form\MediaForm;
use Application\Model\Media;
use Application\Model\MediaTable;
use Application\Model\PoiTable;
use Application\Model\SettingsTable;
use Application\Model\User;
use Application\Model\VRMCommon;
use Application\Model\XmlWriter;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\JsonModel;
use Laminas\View\Model\ViewModel;
use Laminas\View\Renderer\PhpRenderer;

/**
 * Class MediaController
 *
 * @package Application\Controller
 */
class MediaController extends AbstractActionController
{
    const CHUNK_SIZE = 8388608; // 8MB

    private $renderer;
    private $mediaTable;
    private $settingsTable;
    private $poiTable;
    private $xmlWriter;

    public function __construct(PhpRenderer $renderer, MediaTable $mediaTable, SettingsTable $settingsTable, PoiTable $poiTable, XmlWriter $xmlWriter)
    {
        $this->renderer = $renderer;
        $this->mediaTable = $mediaTable;
        $this->settingsTable = $settingsTable;
        $this->poiTable = $poiTable;
        $this->xmlWriter = $xmlWriter;
    }

    /**
     * Returns a view model responsible for media management
     *
     * @todo embed videos as images only - example: https://www.labnol.org/internet/light-youtube-embeds/27941/
     *
     * @return ViewModel
     */
    public function indexAction()
    {
        $media = $this->mediaTable->getMedia();

        $mediaArray = [];

        foreach ($media as $item) {
            $originalFileName = $item['original_name'];
            $originalFileExt = explode('.', $originalFileName);
            $originalFileExt = end($originalFileExt);
            $item['extension'] = $originalFileExt;

            $mediaArray[] = $item;
        }

        return new ViewModel(['media' => $mediaArray]);
    }

    /**
     * Adds a new media item
     *
     * @return \Laminas\Http\Response|ViewModel
     */
    public function addAction()
    {
        $form = new MediaForm();

        $ffmpegEnabled = $this->settingsTable->get('ffmpeg_enabled');
        $form->setValidation($ffmpegEnabled);

        // the user clicked "save", let's proceed
        if ($this->request->isPost()) {
            // dump all data to an array and bind them to the form
            $data = $this->getRequest()->getPost()->toArray();

            //get files
            $files = $this->getRequest()->getFiles()->toArray();

            // verify if the form is valid
            $form->setData(array_merge($data, $files));

            if (trim($data['medialink']) != '') {
                $form->setValidationGroup(['medialink']);
            } else {
                $form->setValidationGroup(['mediafile']);
            }

            if ($form->isValid()) {

                //store YouTube/Vimeo links
                $mediaLink = $form->get('medialink')->getValue();

                if ($mediaLink) {
                    //get video type
                    $videoType = preg_match('/youtu/i', $mediaLink) ? 'youtube' : 'vimeo';

                    //get video link
                    if ($videoType == 'youtube') {
                        $videoCode = str_replace('https://youtu.be/', '', $mediaLink);
                    } else {
                        $videoCode = str_replace('https://vimeo.com/', '', $mediaLink);
                    }

                    $media = new Media();
                    $media->exchangeArray(['type' => $videoType, 'resource' => $videoCode, 'date_uploaded' => date('Y-m-d H:i:s'),
                        'original_name' => $mediaLink]);
                    $mediaId = $this->mediaTable->save($media);
                }

                //define files directory
                $mediaDir = __DIR__ . '/../../../../../media';

                //create media directory if not present
                if (!is_dir($mediaDir)) {
                    mkdir($mediaDir, 0777, true);
                }

                foreach ($files['mediafile'] as $key => $file) {
                    if ($file['error'] !== UPLOAD_ERR_OK) {
                        continue;
                    }

                    $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

                    $type = 'file';

                    if (in_array($fileExtension, ['jpg', 'jpeg', 'png'])) {
                        $type = 'photo';
                    }

                    if ($fileExtension === 'pdf') {
                        $type = 'pdf';
                    }

                    if (in_array($fileExtension,
                                 [
                                     'mp3',
                                     'ogg',
                                     'wav',
                                     'acc',
                                     'wma',
                                     'aa',
                                     'aiff',
                                     'flac',
                                     'm4a',
                                 ]
                    )) {
                        $type = 'audio';
                    }

                    if (in_array($fileExtension,
                                 [
                                     'mkv',
                                     'ogv',
                                     'avi',
                                     'mov',
                                     'qt',
                                     'wmv',
                                     'mp4',
                                     'm4v',
                                     'mpg',
                                     'mpeg',
                                     '3gp',
                                     'flv',
                                     'webm',
                                 ]
                    )) {
                        $type = 'video';
                    }

                    $media = new Media();
                    $media->exchangeArray([
                        'type' => $type,
                        'resource' => 'file',
                        'date_uploaded' => date('Y-m-d H:i:s'),
                        'original_name' => $file['name']
                    ]);
                    $mediaId = $this->mediaTable->save($media);

                    if ($type == 'photo') {
                        //save file in temporary folder
                        $imageTemporaryDir = $mediaDir . '/i' . $mediaId . '_temp.' . $fileExtension;
                        move_uploaded_file($file['tmp_name'], $imageTemporaryDir);

                        //resize image and save file in gallery folder
                        $mainImage = $mediaDir . '/i' . $mediaId . '.jpg';
                        VRMCommon::resizeImage($imageTemporaryDir, $mainImage, 1200, 1000, 'contain');

                        //create thumb for image
                        $thumbImage = $mediaDir . '/i' . $mediaId . '_thumb.jpg';
                        VRMCommon::resizeImage($imageTemporaryDir, $thumbImage, GALLERY_WIDTH, GALLERY_HEIGHT, 'cover');

                        //unlink temporary file
                        @unlink($imageTemporaryDir);
                    }

                    if ($type == 'audio') {
                        //save file in media folder
                        $audioTemporaryFile = $mediaDir . '/a' . $mediaId . '.' . $fileExtension;
                        move_uploaded_file($file['tmp_name'], $audioTemporaryFile);

                        //convert audio file to mp3 if needed
                        if (strtolower($fileExtension) != 'mp3') {
                            VRMCommon::convertAudio($audioTemporaryFile);
                            //unlink temporary file
                            @unlink($audioTemporaryFile);
                        }
                    }

                    if($type === 'file') {
                        //save file in media folder
                        $temporaryFile = $mediaDir . '/f' . $mediaId . '.' . $fileExtension;
                        move_uploaded_file($file['tmp_name'], $temporaryFile);
                    }

                    if($type === 'video') {
                        //save file in media folder
                        $temporaryFile = $mediaDir . '/v' . $mediaId . '.' . $fileExtension;
                        move_uploaded_file($file['tmp_name'], $temporaryFile);
                    }

                    if($type === 'pdf') {
                        //save file in media folder
                        $temporaryFile = $mediaDir . '/p' . $mediaId . '.' . $fileExtension;
                        move_uploaded_file($file['tmp_name'], $temporaryFile);
                    }

                }

                $this->flashMessenger()->addMessage(_('Media directory has been successfully updated'));

                // build and return JSON
                $jsonModel = new JsonModel();
                $jsonModel->setVariables([
                                             'success' => true,
                                         ]);
                return $jsonModel;

            } else {
                $errors = [];

                foreach ($form->getElements() as $field) {
                    if (in_array($field->getName(), ['submit', 'cancel'])) {
                        continue;
                    }
                    if ($field->getMessages()) {
                        $fieldErrors = [];
                        $fieldMessages = $field->getMessages();
                        array_walk_recursive($fieldMessages, function ($v) use (&$fieldErrors) {
                            $fieldErrors[] = $v;
                        });
                        $errors[$field->getName()] = implode('<br />', $fieldErrors);
                    }
                }

                $jsonModel = new JsonModel();
                $jsonModel->setVariables([
                                             'success' => false,
                                             'errors'  => $errors
                                         ]);

                return $jsonModel;
            }
        }

        return new ViewModel([
            'form' => $form
        ]);
    }

    /**
     * Shows a modal windows used to select media files
     *
     * @return JsonModel
     */
    public function showMediaAjaxAction()
    {
        if (!$this->request->isPost()) {
            return new JsonModel(['success' => false]);
        }

        $type = $this->params()->fromQuery('type');
        $extensions = $this->params()->fromQuery('extensions');
        $type = $type ? explode(',', $type) : null;
        $extensions = $extensions ? explode(',', $extensions) : null;

        $media = $this->mediaTable->getMedia($type, $extensions);

        $amazonEnabled = false;
        $voice = $this->params()->fromPost('voice');
        $awsAccessKeyId = $this->settingsTable->get('aws_access_key');
        $awsSecretKey = $this->settingsTable->get('aws_secret_key');

        if ($voice && $awsAccessKeyId && $awsSecretKey) {
            $amazonEnabled = true;
        }

        $htmlViewPart = new ViewModel();
        $htmlViewPart->setTerminal(true)
            ->setTemplate('application/media/showMediaAjax')
            ->setVariables(['media' => $media, 'amazonEnabled' => $amazonEnabled]);

        // render the content
        $htmlOutput = $this->renderer->render($htmlViewPart);

        // build and return JSON
        $jsonModel = new JsonModel();
        $jsonModel->setVariables([
            'success' => true,
            'html'    => $htmlOutput
        ]);

        return $jsonModel;
    }

    /**
     * Receives a synthesised speech from Amazon Polly integration and stores it as a new audio file
     *
     * @return JsonModel
     */
    public function getAudioFromAmazonAjaxAction()
    {

        $jsonModel = new JsonModel();

        $text = trim(strip_tags($this->params()->fromPost('text')));
        $voice = $this->params()->fromPost('voice');

        if (!$text) {
            $jsonModel->setVariables(['success' => false]);
            return $jsonModel;
        }

        $client = $this->xmlWriter->getAmazonClient();

        // chop text if needed
        $textBlocks = VRMCommon::breakLongText($text);

        $resultData = [];
        foreach ($textBlocks as $textBlock) {
            $result         = $client->synthesizeSpeech([
                'OutputFormat' => 'mp3',
                'Text'         => $textBlock,
                'TextType'     => 'text',
                'VoiceId'      => $voice
            ]);
            $resultData[]     = $result->get('AudioStream')->getContents();
        }

        $resultData = implode('', $resultData);

        // save resulting file and store it both as a file resource and a new media entry
        $media = new Media();
        $date = date('Y-m-d H:i:s');
        $media->exchangeArray(['type' => 'audio', 'resource' => 'file', 'date_uploaded' => $date,
            'original_name' => 'amazon ' . $date]);
        $mediaId = $this->mediaTable->save($media);

        //define files directory
        $mediaDir = __DIR__ . '/../../../../../media';

        //create media directory if not present
        if (!is_dir($mediaDir)) {
            mkdir($mediaDir, 0777, true);
        }

        file_put_contents($mediaDir . DIRECTORY_SEPARATOR . 'a' . $mediaId . '.mp3', $resultData);

        $jsonModel->setVariables(['success' => true, 'mediaId' => $mediaId]);
        return $jsonModel;
    }

    /**
     * Shows a modal windows used to upload media files
     *
     * @return JsonModel
     */
    public function showMediaUploadAjaxAction()
    {
        if (!$this->request->isPost()) {
            return new JsonModel(['success' => false]);
        }

        $form = new MediaForm();

        $ffmpegEnabled = $this->settingsTable->get('ffmpeg_enabled');
        $form->setValidation($ffmpegEnabled);

        // the user clicked "save", let's proceed
        if ($this->request->isPost() && $this->params()->fromQuery('save')) {
            // dump all data to an array and bind them to the form
            $data = $this->getRequest()->getPost()->toArray();

            //get files
            $files = $this->getRequest()->getFiles()->toArray();

            // verify if the form is valid
            $form->setData(array_merge($data, $files));

            if (trim($data['medialink']) != '') {
                $form->setValidationGroup(['medialink']);
            } else {
                $form->setValidationGroup(['mediafile']);
            }

            if ($form->isValid()) {

                //store YouTube/Vimeo links
                $mediaLink = $form->get('medialink')->getValue();

                if ($mediaLink) {
                    //get video type
                    $videoType = preg_match('/youtu/i', $mediaLink) ? 'youtube' : 'vimeo';

                    //get video link
                    if ($videoType == 'youtube') {
                        $videoCode = str_replace('https://youtu.be/', '', $mediaLink);
                    } else {
                        $videoCode = str_replace('https://vimeo.com/', '', $mediaLink);
                    }

                    $media = new Media();
                    $media->exchangeArray(['type' => $videoType, 'resource' => $videoCode, 'date_uploaded' => date('Y-m-d H:i:s'),
                        'original_name' => $mediaLink]);
                    $mediaId = $this->mediaTable->save($media);
                }

                //define files directory
                $mediaDir = __DIR__ . '/../../../../../media';

                //create media directory if not present
                if (!is_dir($mediaDir)) {
                    mkdir($mediaDir, 0777, true);
                }

                $lastAudioFileId = 0;

                foreach ($files['mediafile'] as $key => $file) {

                    if ($file['error'] !== UPLOAD_ERR_OK) {
                        continue;
                    }

                    $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

                    $type = 'audio';

                    if (in_array($fileExtension, ['jpg', 'jpeg', 'png'])) {
                        $type = 'photo';
                    }

                    $media = new Media();
                    $media->exchangeArray(['type' => $type, 'resource' => 'file', 'date_uploaded' => date('Y-m-d H:i:s'),
                        'original_name' => $file['name']]);
                    $mediaId = $this->mediaTable->save($media);

                    if ($type == 'photo') {
                        //save file in temporary folder
                        $imageTemporaryDir = $mediaDir . '/i' . $mediaId . '_temp.' . $fileExtension;
                        move_uploaded_file($file['tmp_name'], $imageTemporaryDir);

                        //resize image and save file in gallery folder
                        $mainImage = $mediaDir . '/i' . $mediaId . '.jpg';
                        VRMCommon::resizeImage($imageTemporaryDir, $mainImage, 1200, 1000, 'contain');

                        //create thumb for image
                        $thumbImage = $mediaDir . '/i' . $mediaId . '_thumb.jpg';
                        VRMCommon::resizeImage($imageTemporaryDir, $thumbImage, GALLERY_WIDTH, GALLERY_HEIGHT, 'cover');

                        //unlink temporary file
                        @unlink($imageTemporaryDir);
                    }

                    if ($type == 'audio') {
                        //save file in media folder
                        $audioTemporaryFile = $mediaDir . '/a' . $mediaId . '.' . $fileExtension;
                        move_uploaded_file($file['tmp_name'], $audioTemporaryFile);

                        //convert audio file to mp3 if needed
                        if (strtolower($fileExtension) != 'mp3') {
                            VRMCommon::convertAudio($audioTemporaryFile);
                            //unlink temporary file
                            @unlink($audioTemporaryFile);
                        }
                        $lastAudioFileId = $mediaId;
                    }

                }

                $jsonModel = new JsonModel();
                $jsonModel->setVariables(['success' => true, 'lastAudioFileId' => $lastAudioFileId]);

                return $jsonModel;

            } else {

                $errors = [];

                foreach ($form->getElements() as $field) {
                    if (in_array($field->getName(), ['submit', 'cancel'])) {
                        continue;
                    }
                    if ($field->getMessages()) {
                        $fieldErrors = [];
                        $fieldMessages = $field->getMessages();
                        array_walk_recursive($fieldMessages, function ($v) use (&$fieldErrors) {
                            $fieldErrors[] = $v;
                        });
                        $errors[$field->getName()] = implode('<br />', $fieldErrors);
                    }
                }

                $jsonModel = new JsonModel();
                $jsonModel->setVariables(['success' => false, 'errors' => $errors]);

                return $jsonModel;
            }
        }

        $htmlViewPart = new ViewModel();
        $htmlViewPart->setTerminal(true)
                     ->setTemplate('application/media/add')
                     ->setVariables(['form' => $form, 'modal' => true]);

        // render the content
        $htmlOutput = $this->renderer->render($htmlViewPart);

        // build and return JSON
        $jsonModel = new JsonModel();
        $jsonModel->setVariables([
                                     'success' => true,
                                     'html'    => $htmlOutput
                                 ]);

        return $jsonModel;
    }

    /**
     * Deletes given media through an AJAX call
     *
     * @return JsonModel
     */
    public function deleteMediaAjaxAction()
    {

        if ($this->userInfo()->getUser()->usertype === User::TYPE_EDITOR) {
            return new JsonModel(['success' => false]);
        }

        $id = $this->params()->fromPost('id');
        $oldMedia = $this->mediaTable->getById($id);
        $type = $this->params()->fromPost('type');

        $result = $this->mediaTable->deleteById($id);

        $mediaDir = __DIR__ . '/../../../../../media/';

        if ($result == 1) {

            // delete files in local storage if needed
            if ($type == 'photo') {
                @unlink($mediaDir . 'i' . $id . '.jpg');
                @unlink($mediaDir . 'i' . $id . '_thumb.jpg');
                $this->poiTable->deletePoiByMedia('{"src":"i' . $id . '.jpg"', 'photo');
            }
            if ($type == 'audio') {
                @unlink($mediaDir . 'a' . $id . '.mp3');
                $this->poiTable->deletePoiByMedia('{"src":"a' . $id . '"', 'audio');
            }
            if ($type == 'video') {
                $this->poiTable->deletePoiByMedia('{"src":"' . $oldMedia->resource . '"', 'video');
            }

            // update tourdata.xml file
            $this->xmlWriter->writeTourDataFile();

            $this->flashMessenger()->addMessage(_('Media resource has been successfully deleted'));

            return new JsonModel(['success' => true]);
        } else {
            return new JsonModel(['success' => false]);
        }
    }

    public function getMediaFileAction()
    {
        $fileId = (int)$this->params()->fromQuery('id', 0);
        $fileType = (string)$this->params()->fromQuery('type', 'f');
        $file = $this->mediaTable->getById($fileId);

        if (!$file) {
            http_response_code(404);
            die();
        }

        $mediaDir = __DIR__ . '/../../../../../media/';

        $originalFileName = $file->original_name;
        $originalFileExt = explode('.', $originalFileName);
        $originalFileExt = end($originalFileExt);
        $fsFilePath = "{$mediaDir}{$fileType}{$fileId}.{$originalFileExt}";

        if (!file_exists($fsFilePath)) {
            http_response_code(404);
            die();
        }

        $fileSize = filesize($fsFilePath);

        header('Content-type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $originalFileName . '"');
        header("Content-Length: " . $fileSize);

        // set IE-specific headers
        if (strpos($_SERVER['HTTP_USER_AGENT'], "MSIE") !== false) {
            header('Pragma: cache');
            header('Cache-Control: private, max-age=1');
        }

        // if a file is larger than the default chunksize (8MB), serve it in chunks
        if ($fileSize > self::CHUNK_SIZE) {
            // get the handle to the file and set up empty buffor
            $handle = fopen($fsFilePath, 'rb');

            // scan the file in 8MB chunks and send it to the user
            while (!feof($handle) && (connection_status() === CONNECTION_NORMAL)) {
                $buffer = fread($handle, self::CHUNK_SIZE);
                print $buffer;

                //check if buffer buffer is not empty, then clean it
                if (ob_get_length() > 0) {
                    ob_flush();
                }
                flush();
                // make sure that while downloading no time limit will occur unexpectedly
                set_time_limit(300);
            }

            // if the connection is lost, do the cleanup
            if (connection_status() !== CONNECTION_NORMAL) {
                return false;
            }
            // close the handle to the file
            fclose($handle);
            return true;
        }

        // if the file is smaller than 8MB, send it to the user immediately
        //check if buffer buffer is not empty, then clean it
        if (ob_get_length() > 0) {
            ob_clean();
        }
        flush();
        readfile($fsFilePath);
        return true;
    }
}
