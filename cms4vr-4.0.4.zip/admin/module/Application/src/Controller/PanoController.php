<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Controller;


use Application\Form\PanoEditForm;
use Application\Form\PanoForm;
use Application\Form\PanoZipForm;
use Application\Form\VideoSceneForm;
use Application\Model\CategoriesTable;
use Application\Model\GalleriesTable;
use Application\Model\LanguagesTable;
use Application\Model\MediaTable;
use Application\Model\PanoCategoryConnections;
use Application\Model\PanoCategoryConnectionsTable;
use Application\Model\PanoPhrases;
use Application\Model\PanoPhrasesTable;
use Application\Model\Panos;
use Application\Model\PanoSitePlansConnectionsTable;
use Application\Model\PanosTable;
use Application\Model\SettingsTable;
use Application\Model\Shortlink;
use Application\Model\ShortlinkTable;
use Application\Model\SitePlansTable;
use Application\Model\VRMCommon;
use Application\Model\XmlWriter;
use Application\Service\XmlReaderService;
use Laminas\Db\Adapter\Adapter;
use Laminas\Db\TableGateway\Feature\GlobalAdapterFeature;
use Laminas\Filter\Decompress;
use Laminas\Json\Json;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\JsonModel;
use Laminas\View\Model\ViewModel;
use Laminas\View\Renderer\PhpRenderer;

class PanoController extends AbstractActionController
{

    const CHUNK_SIZE = 8388608; // 8MB

    /** @var $panosTable PanosTable */
    private $panosTable;
    /** @var $languagesTable LanguagesTable */
    private $languagesTable;
    /** @var $panoPhrasesTable PanoPhrasesTable */
    private $panoPhrasesTable;
    /** @var  $categoriesTable CategoriesTable */
    private $categoriesTable;
    /** @var  $galleriesTable GalleriesTable */
    private $galleriesTable;
    /** @var  $panoCategoryConnectionsTable PanoCategoryConnectionsTable */
    private $panoCategoryConnectionsTable;
    /** @var  $sitePlansTable SitePlansTable */
    private $sitePlansTable;
    /** @var  $panoSitePlansConnectionsTable PanoSitePlansConnectionsTable */
    private $panoSitePlansConnectionsTable;
    /** @var $staticDbAdapter Adapter */
    private $staticDbAdapter;
    /** @var $xmlWriter XmlWriter */
    private $xmlWriter;
    /** @var  $settingsTable SettingsTable */
    private $settingsTable;
    /** @var  $shortlinkTable ShortlinkTable */
    private $shortlinkTable;
    /** @var $mediaTable MediaTable */
    private $mediaTable;
    /** @var  $renderer PhpRenderer */
    private $renderer;

    public function __construct(
        Adapter $staticDbAdapter,
        PanosTable $panosTable,
        LanguagesTable $languagesTable,
        PanoPhrasesTable $panoPhrasesTable,
        CategoriesTable $categoriesTable,
        GalleriesTable $galleriesTable,
        PanoCategoryConnectionsTable $panoCategoryConnectionsTable,
        SitePlansTable $sitePlansTable,
        PanoSitePlansConnectionsTable $panoSitePlansConnectionsTable,
        XmlWriter $xmlWriter,
        SettingsTable $settingsTable,
        ShortlinkTable $shortlinkTable,
        MediaTable $mediaTable,
        PhpRenderer $renderer
    ) {
        $this->staticDbAdapter = $staticDbAdapter;
        $this->panosTable = $panosTable;
        $this->languagesTable = $languagesTable;
        $this->panoPhrasesTable = $panoPhrasesTable;
        $this->categoriesTable = $categoriesTable;
        $this->galleriesTable = $galleriesTable;
        $this->panoCategoryConnectionsTable = $panoCategoryConnectionsTable;
        $this->sitePlansTable = $sitePlansTable;
        $this->panoSitePlansConnectionsTable = $panoSitePlansConnectionsTable;
        $this->xmlWriter = $xmlWriter;
        $this->settingsTable = $settingsTable;
        $this->shortlinkTable = $shortlinkTable;
        $this->mediaTable = $mediaTable;
        $this->renderer = $renderer;
    }

    /**
     * Default action - returns pano list
     *
     * @return viewModel
     */
    public function indexAction()
    {
        $categoryId = $this->params()->fromRoute('cat');
        $allowedCategories = $this->userInfo()->allowedCategories();
        $panoList = $this->panosTable->getPanoList($categoryId, 'langShort', $allowedCategories);
        return new ViewModel(['panoList' => $panoList, 'categoryId' => $categoryId]);

    }

    private function checkMaxUpload()
    {
        if (isset($_SERVER['CONTENT_LENGTH']) && empty($_POST)) {
            $max = min(VRMCommon::getIniBytes('post_max_size'), VRMCommon::getIniBytes('upload_max_filesize'));
            $send = $_SERVER['CONTENT_LENGTH'];

            if($max < $_SERVER['CONTENT_LENGTH']) {
                $errorMsg = 'The amount of data sent (' .
                    number_format($send/(1024*1024), 2) . 'MB) exceeds the server limit (' . number_format($max/(1024*1024), 2) . 'MB). Upload a smaller file or contact server administrator.';
                $jsonModel = new JsonModel();
                $jsonModel->setVariables([
                    'success' => false,
                    'filetoobig' => $errorMsg
                ]);

                return $jsonModel;
            }
        }
    }

    /**
     * Creates a new pano from uploaded JPG file
     *
     */
    public function createAction()
    {

        // build a form
        $panoForm = new PanoForm();

        if ($this->settingsTable->get('cms_dev_version') !== 'vip') {
            $panoAttributes = $panoForm->get('pano')->getAttributes();
            $panoAttributes['multiple'] = false;
            $panoForm->get('pano')->setAttributes($panoAttributes);
        }

        // set static DB adapter to be used by fieldsets validation
        GlobalAdapterFeature::setStaticAdapter($this->staticDbAdapter);

        // get project languages
        $projectLanguages = $this->languagesTable->getLanguages(false)->toArray();

        $projectCategories = $this->categoriesTable->getCategories();

        foreach ($projectCategories as $categoryId => $category) {
            $projectCategoriesSelect[$categoryId] = reset($category['name']);
        }

        $panoForm->get('category_id')->setValueOptions($projectCategoriesSelect);

        $submission = false;

        // the user clicked "save", let's proceed
        if ($this->request->isPost()) {

            if (isset($_SERVER['CONTENT_LENGTH']) && empty($_POST)) {
                $max = min(VRMCommon::getIniBytes('post_max_size'), VRMCommon::getIniBytes('upload_max_filesize'));
                $send = $_SERVER['CONTENT_LENGTH'];

                if($max < $_SERVER['CONTENT_LENGTH']) {
                    $errorMsg = 'The amount of data sent (' .
                        number_format($send/(1024*1024), 2) . 'MB) exceeds the server limit (' . number_format($max/(1024*1024), 2) . 'MB). Upload a smaller file or contact server administrator.';
                    $jsonModel = new JsonModel();
                    $jsonModel->setVariables([
                        'success' => false,
                        'filetoobig' => $errorMsg
                    ]);

                    return $jsonModel;
                }
            }

            // dump all data to an array and bind them to the form
            $data = $this->getRequest()->getPost()->toArray();

            //get files
            $files = $this->getRequest()->getFiles()->toArray();

            // verify if the form is valid
            $panoForm->setData(array_merge($data, $files));
            if ($panoForm->isValid()) {

                $panoDir = __DIR__ . '/../../../../../';

                // check if file is ok to be processed
                if ($data['pano_type'] === 'sphere' || $data['pano_type'] === 'cubic') {
                    $panoSize = getimagesize($files['pano']['tmp_name']);
                    if ($panoSize && $panoSize[0] !== 0 && $panoSize[1] !== 0) {
                        if (!($panoSize[0] / $panoSize[1] === 2 || $panoSize[1] / $panoSize[0] === 2 || $panoSize[0] === $panoSize[1])) {
                            $this->flashMessenger()->addErrorMessage($files['pano']['name'] . ': ' . _('Spherical panorama should have 2:1 or 1:1 proportions!'));
                            exit;
                        }
                    }
                }

                //get position
                $panoCount = $this->panosTable->countPanos();

                //create array for new pano
                $panoDataArray = [
                    'building_id' => 0,
                    'position' => $panoCount + 1,
                    'dir' => '',
                    'lat' => '',
                    'lng' => '',
                    'north' => '',
                    'start_view' => '',
                    'visible' => 1,
                    'processed' => 1
                ];

                //save data in pano table
                $pano = new Panos();
                $pano->exchangeArray($panoDataArray);
                $panoId = $this->panosTable->save($pano);

                //save name and desc to pano_phrases
                foreach ($data['panos_fs'] as $key => $value) {
                    $panoName = (int)$data['multiple'] === 1 ? pathinfo($files['pano']['name'], PATHINFO_FILENAME) : $value['name'];
                    $panoPhraseArray = [
                        'panos_id' => $panoId,
                        'languages_id' => $value['language_id'],
                        'name' => $panoName,
                        'description' => '',
                        'gallery_name' => '',
                        'gallery_description' => '',
                    ];
                    $panoPhrase = new PanoPhrases();
                    $panoPhrase->exchangeArray($panoPhraseArray);

                    $this->panoPhrasesTable->save($panoPhrase);
                }

                //save files - move files to $panoDir
                $fileExtension = strtolower(pathinfo($files['pano']['name'], PATHINFO_EXTENSION));
                $panoFile = $panoDir . 'p' . $panoId . '.' . $fileExtension;
                move_uploaded_file($files['pano']['tmp_name'], $panoFile);

                // save category if one was selected
                if ($data['category_id']) {
                    $connection = new PanoCategoryConnections();
                    $connection->category_id = $data['category_id'];
                    $connection->pano_id = $panoId;
                    $connection->pano_position = 1;
                    $this->panoCategoryConnectionsTable->save($connection);
                }

                $panoType = $data['pano_type'];
                if (!in_array($panoType, ['sphere', 'flat', 'cubic'])) {
                    $panoType = 'sphere';
                }

                // PROCESS THE PANO!!!!
                $panoConfig = 'nasz_vtour_vr_' . $panoType;

//                file_put_contents($panoFile . '.vrm', __DIR__ . '/../../../../data/bin/krpano/krpanotools makepano -config=templates/' . $panoConfig . '.config ' . $panoFile
//                    . PHP_EOL . $panoDir . PHP_EOL . $panoType . PHP_EOL . $panoId . PHP_EOL . $panoFile
//
//                );

                shell_exec(
                    __DIR__ . '/../../../../data/bin/krpano/krpanotools makepano -config=templates/' . $panoConfig . '.config ' . $panoFile
                );

                // create thumbnails
                $dest_image = $panoDir . '/thumb.jpg';
                $retina_image = $panoDir . '/thumb_retina.jpg';
                $temp_image = $panoType === 'multires' ? $panoDir . '/pano.tiles/mobile_f.jpg' : $panoDir . '/pano.tiles/preview.jpg';

                VRMCommon::resizeImage($temp_image, $dest_image, PANO_THUMB, PANO_THUMB, 'cover');
                VRMCommon::resizeImage($temp_image, $retina_image, PANO_THUMB * 2, PANO_THUMB * 2, 'cover');

                @unlink($panoFile);

                $this->panosTable->changeProcessingStatus($panoId, Panos::PROCESSING_DONE);

                // write generated scene data to the database
                $coords = $this->xmlWriter->storeSceneData($panoId);

                $this->panosTable->updatePanoCoords($panoId, $coords);

                // move pX.js to tour.js
                @rename($panoDir . 'p' . $panoId . '.js', $panoDir . 'tour.js');

                // delete pX.html
                @unlink($panoDir . 'p' . $panoId . '.html');


                // update tour.xml file
                $this->xmlWriter->writeTourFile();
                $this->xmlWriter->writeTourDataFile();

                // trigger new license check
                unset($_SESSION['license_checked']);

                $this->flashMessenger()->addMessage(_('Panorama has been successfully created'));

                $jsonModel = new JsonModel();
                $jsonModel->setVariables([
                    'success' => true,
                ]);

                return $jsonModel;

            } else {
                $errors = [];

                foreach ($panoForm->getElements() as $field) {
                    if (in_array($field->getName(), ['panos_fs', 'submit', 'cancel'])) {
                        continue;
                    }
                    if ($field->getMessages()) {
                        $fieldErrors = [];
                        $fieldMessages = $field->getMessages();
                        array_walk_recursive($fieldMessages, function ($v) use (&$fieldErrors) {
                            $fieldErrors[] = $v;
                        });
                        $errors[$field->getName()] = implode('<br />', $fieldErrors);
                    }
                }

                $fieldsets = $panoForm->get('panos_fs')->getFieldsets();

                foreach ($fieldsets as $lang => $fields) {
                    foreach ($fields as $field) {
                        if ($field->getMessages()) {
                            $fieldErrors = [];
                            $fieldMessages = $field->getMessages();
                            array_walk_recursive($fieldMessages, function ($v) use (&$fieldErrors) {
                                $fieldErrors[] = $v;
                            });
                            $errors['panos_fs[' . $lang . '][' . $field->getName() . ']'] =
                                implode('<br />', $fieldErrors);
                        }
                    }
                }

                $jsonModel = new JsonModel();
                $jsonModel->setVariables([
                    'success' => false,
                    'errors'  => $errors
                ]);

                return $jsonModel;
            }

        } else {
            $languagesToPopulate = [];
            foreach ($projectLanguages as $key => $value) {
                $languagesToPopulate['panos_fs'][$value['id']]['language_id'] = $value['id'];
                $languagesToPopulate['panos_fs'][$value['id']]['language'] = $value['short'];
            }

            $panoForm->populateValues($languagesToPopulate);
        }

        return new ViewModel(['form' => $panoForm, 'languageList' => $projectLanguages, 'submission' => $submission]);

    }

    /**
     * @deprecated not used, we process the panos as they are received by the backend
     */
    public function processMultiplePanosAction()
    {

        set_time_limit(0);
        ini_set('max_execution_time', 0);

        // Buffer all upcoming output...
        ob_start();

        // Send your response.
        echo json_encode(['success' => true]);

        // Disable compression (in case content length is compressed).
        header("Content-Encoding: none");

        // Set the content length of the response.
        header('Content-Length: '.ob_get_length());

        // Close the connection.
        header("Connection: close");

        // Flush all output.
        ob_end_flush();
        if (ob_get_level() > 0) {
            ob_flush();
        }
        flush();

        // Close current session (if it exists).
        if(session_id()) {
            session_write_close();
        }

        if (is_callable('litespeed_finish_request')) {
            litespeed_finish_request();
        }

        if (is_callable('fastcgi_finish_request')) {
            fastcgi_finish_request();
        }

        $queue = glob(__DIR__ . '/../../../../../p*.vrm');

        // . PHP_EOL . $panoDir . PHP_EOL . $panoType . PHP_EOL . $panoId . PHP_EOL . $panoFile
        foreach ($queue as $process) {

            set_time_limit(0);
            ini_set('max_execution_time', 0);

            $input = file($process, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            [$command, $panoDir, $panoType, $panoId, $panoFile] = $input;

            shell_exec('nice -n 19 ' . $command);

            // create thumbnails
            $dest_image = $panoDir . '/thumb.jpg';
            $retina_image = $panoDir . '/thumb_retina.jpg';
            $temp_image = $panoType === 'multires' ? $panoDir . '/pano.tiles/mobile_f.jpg' : $panoDir . '/pano.tiles/preview.jpg';

            VRMCommon::resizeImage($temp_image, $dest_image, PANO_THUMB, PANO_THUMB, 'cover');
            VRMCommon::resizeImage($temp_image, $retina_image, PANO_THUMB * 2, PANO_THUMB * 2, 'cover');

            @unlink($panoFile);

            $this->panosTable->changeProcessingStatus($panoId, Panos::PROCESSING_DONE);

            // write generated scene data to the database
            $coords = $this->xmlWriter->storeSceneData($panoId);

            $this->panosTable->updatePanoCoords($panoId, $coords);

            // move pX.js to tour.js
            @rename($panoDir . 'p' . $panoId . '.js', $panoDir . 'tour.js');

            // delete pX.html
            @unlink($panoDir . 'p' . $panoId . '.html');

            // delete processing file
            @unlink($process);

        }

        if ($queue) {
            // update tour.xml file
            $this->xmlWriter->writeTourFile();
            $this->xmlWriter->writeTourDataFile();

            // trigger new license check
            unset($_SESSION['license_checked']);
        }

        exit;
    }


    /**
     * Creates a new panorama from uploaded ZIP archive
     *
     * @return \Laminas\Http\Response|ViewModel
     */
    public function createFromZipAction()
    {

        // build a form
        $panoForm = new PanoZipForm();

        // set static DB adapter to be used by fieldsets validation
        GlobalAdapterFeature::setStaticAdapter($this->staticDbAdapter);

        // get project languages
        $projectLanguages = $this->languagesTable->getLanguages(false)->toArray();

        $projectCategories = $this->categoriesTable->getCategories();

        foreach ($projectCategories as $categoryId => $category) {
            $projectCategoriesSelect[$categoryId] = reset($category['name']);
        }

        $panoForm->get('category_id')->setValueOptions($projectCategoriesSelect);

        $submission = false;

        // the user clicked "save", let's proceed
        if ($this->request->isPost()) {

            if (isset($_SERVER['CONTENT_LENGTH']) && empty($_POST)) {
                $max = min(VRMCommon::getIniBytes('post_max_size'), VRMCommon::getIniBytes('upload_max_filesize'));
                $send = $_SERVER['CONTENT_LENGTH'];

                if($max < $_SERVER['CONTENT_LENGTH']) {
                    $errorMsg = 'The amount of data sent (' .
                        number_format($send/(1024*1024), 2) . 'MB) exceeds the server limit (' . number_format($max/(1024*1024), 2) . 'MB). Upload a smaller file or contact server administrator.';
                    $jsonModel = new JsonModel();
                    $jsonModel->setVariables([
                        'success' => false,
                        'filetoobig' => $errorMsg
                    ]);

                    return $jsonModel;
                }
            }

            // dump all data to an array and bind them to the form
            $data = $this->getRequest()->getPost()->toArray();

            //get files
            $files = $this->getRequest()->getFiles()->toArray();

            // verify if the form is valid
            $panoForm->setData(array_merge($data, $files));
            if ($panoForm->isValid()) {

                //get position
                $panoCount = $this->panosTable->countPanos();

                //save files - move uploaded archive to $panoDir
                if (!empty($files['pano'])) {

                    $uId = uniqid('pano_zip_');
                    $panoZipDir = __DIR__ . '/../../../../../panos' . DIRECTORY_SEPARATOR . $uId . DIRECTORY_SEPARATOR;

                    if (!is_dir($panoZipDir)) {
                        mkdir($panoZipDir, 0777, true);
                    }

                    $panoZip = $panoZipDir . DIRECTORY_SEPARATOR . 'pano.zip';
                    move_uploaded_file($files['pano']['tmp_name'], $panoZip);

                    // extract ZIP archive in place
                    $filter = new Decompress([
                        'adapter' => 'Zip',
                        'options' => [
                            'target' => $panoZipDir,
                        ]
                    ]);
                    $filter->filter($panoZip);

                    if(is_dir($panoZipDir . DIRECTORY_SEPARATOR . 'vtour')) {
                        // New multi-panorama zip
                        $xmlContent = file_get_contents($panoZipDir . DIRECTORY_SEPARATOR . 'vtour' . DIRECTORY_SEPARATOR . 'tour.xml');
                        $krPanoXml = new XmlReaderService($xmlContent);

                        $panosProcessed = 0;
                        foreach ($krPanoXml->getScenes() as $scene) {
                            // Add only one pano from archive if uploaded from non-vip account
                            if($this->settingsTable->get('cms_dev_version') !== 'vip' && $panosProcessed > 0) {
                                continue;
                            }

                            //create array for new pano
                            $panoDataArray = [
                                'building_id' => 0,
                                'position' => $panoCount + 1,
                                'lat' => $scene['lat'],
                                'lng' => $scene['lng'],
                                'heading' => $scene['heading'],
                                'visible' => 1,
                                'processed' => 1
                            ];

                            //save data in pano table
                            $pano = new Panos();
                            $pano->exchangeArray($panoDataArray);
                            $panoId = $this->panosTable->save($pano);
                            //after saving new pano - create folders
                            $panoDir = __DIR__ . '/../../../../../panos/p' . $panoId . '.tiles';

                            // if (!is_dir($panoDir)) {
                            //     mkdir($panoDir, 0777, true);
                            // }

                            @rename($panoZipDir . DIRECTORY_SEPARATOR . 'vtour' . DIRECTORY_SEPARATOR . 'panos' . DIRECTORY_SEPARATOR . $scene['dir'], $panoDir);

                            $this->panosTable->updatePanoCoords($panoId, [
                                'lat' => $scene['lat'],
                                'lng' => $scene['lng'],
                                'north' => $scene['heading'],
                            ]);

                            //save name and desc to pano_phrases
                            foreach ($projectLanguages as $value) {
                                $panoPhraseArray = [
                                    'panos_id'     => $panoId,
                                    'languages_id' => $value['id'],
                                    'name'         => $scene['title'],
                                    'description'         => '',
                                    'gallery_name' => '',
                                    'gallery_description' => '',
                                ];
                                $panoPhrase = new PanoPhrases();
                                $panoPhrase->exchangeArray($panoPhraseArray);

                                $this->panoPhrasesTable->save($panoPhrase);
                            }

                            if ($data['category_id']) {
                                $connection = new PanoCategoryConnections();
                                $connection->category_id = $data['category_id'];
                                $connection->pano_id = $panoId;
                                $connection->pano_position = 1;
                                $this->panoCategoryConnectionsTable->save($connection);
                            }

                            $this->xmlWriter->storeSceneDataFromZip($panoId, $scene);
                            $this->panosTable->changeProcessingStatus($panoId, Panos::PROCESSING_DONE);

                            $panosProcessed++;
                        }
                        @rename($panoZipDir . DIRECTORY_SEPARATOR . 'tour.js', __DIR__ . '/../../../../../tour.js');
                    } else {
                        $jsonModel = new JsonModel();
                        $jsonModel->setVariables([
                                                     'success' => false,
                                                     'errors'  => _('vtour directory not found in zip archive'),
                                                     'wrongformat' => true,
                                                 ]);

                        return $jsonModel;
                    }

                    // delete working directory
                    VRMCommon::removeDirectory($panoZipDir);

                    // after decompressing, set panorama as already processed
                    $this->panosTable->changeProcessingStatus($panoId, Panos::PROCESSING_DONE);
                }

                // update tour.xml file
                $this->xmlWriter->writeTourFile();
                $this->xmlWriter->writeTourDataFile();

                // trigger new license check
                unset($_SESSION['license_checked']);

                $this->flashMessenger()->addMessage(_('Panorama has been successfully created'));

                // build and return JSON
                $jsonModel = new JsonModel();
                $jsonModel->setVariables([
                    'success' => true,
                ]);

                return $jsonModel;

            } else {

                $errors = [];

                foreach ($panoForm->getElements() as $field) {
                    if (in_array($field->getName(), ['panos_fs', 'submit', 'cancel'])) {
                        continue;
                    }
                    if ($field->getMessages()) {
                        $fieldErrors = [];
                        $fieldMessages = $field->getMessages();
                        array_walk_recursive($fieldMessages, function ($v) use (&$fieldErrors) {
                            $fieldErrors[] = $v;
                        });
                        $errors[$field->getName()] = implode('<br />', $fieldErrors);
                    }
                }

                $fieldsets = $panoForm->get('panos_fs')->getFieldsets();

                foreach ($fieldsets as $lang => $fields) {
                    foreach ($fields as $field) {
                        if ($field->getMessages()) {
                            $fieldErrors = [];
                            $fieldMessages = $field->getMessages();
                            array_walk_recursive($fieldMessages, function ($v) use (&$fieldErrors) {
                                $fieldErrors[] = $v;
                            });
                            $errors['panos_fs[' . $lang . '][' . $field->getName() . ']'] =
                                implode('<br />', $fieldErrors);
                        }
                    }
                }

                $jsonModel = new JsonModel();
                $jsonModel->setVariables([
                    'success' => false,
                    'errors'  => $errors
                ]);

                return $jsonModel;
            }

        } else {

            $languagesToPopulate = [];

            foreach ($projectLanguages as $key => $value) {
                $languagesToPopulate['panos_fs'][$value['id']]['language_id'] = $value['id'];
                $languagesToPopulate['panos_fs'][$value['id']]['language'] = $value['short'];
            }

            $panoForm->populateValues($languagesToPopulate);
        }

        return new ViewModel(['form' => $panoForm, 'languageList' => $projectLanguages, 'submission' => $submission]);
    }

    /**
     * Manages editing pano - this is very different from creating a new pano, hence this method is separated
     *
     * @see createAction
     *
     * @return \Laminas\Http\Response|ViewModel
     */
    public function editAction()
    {

        $modulesSettings = Json::decode($this->settingsTable->get('global_modules'));
        $googleMapAPIKey = isset($modulesSettings->m_map->id) ? $modulesSettings->m_map->id : '';

        $panoId = $this->params()->fromRoute('id');

        $panoEditForm = new PanoEditForm($panoId);

        // set static DB adapter to be used by fieldsets validation
        GlobalAdapterFeature::setStaticAdapter($this->staticDbAdapter);

        // get project languages, categories
        $projectLanguages = $this->languagesTable->getLanguages(false)->toArray();
        $projectCategories = $this->categoriesTable->getCategories();
        $projectGalleries = $this->galleriesTable->getGalleriesList();

        $languagesMapping = [];

        foreach ($projectLanguages as $projectLanguage) {
            $languagesMapping[$projectLanguage['id']] = $projectLanguage['short'];
        }

        $projectGalleriesSelect[0] = _('- no assignment');
        foreach ($projectGalleries as $galleryId => $gallery) {
            $projectGalleriesSelect[$galleryId] = reset($gallery['name']);
        }

        $submission = false;

        $panoEditForm->get('galleries_id')->setValueOptions($projectGalleriesSelect);

        // the user clicked "save", let's proceed
        if ($this->request->isPost()) {

            if (isset($_SERVER['CONTENT_LENGTH']) && empty($_POST)) {
                $max = min(VRMCommon::getIniBytes('post_max_size'), VRMCommon::getIniBytes('upload_max_filesize'));
                $send = $_SERVER['CONTENT_LENGTH'];

                if($max < $_SERVER['CONTENT_LENGTH']) {
                    $errorMsg = 'The amount of data sent (' .
                        number_format($send/(1024*1024), 2) .
                        'MB) exceeds the server limit (' . number_format($max/(1024*1024), 2) .
                        'MB). Upload a smaller file or contact server administrator.';

                    $jsonModel = new JsonModel();
                    $jsonModel->setVariables([
                        'success' => false,
                        'filetoobig' => $errorMsg
                    ]);

                    return $jsonModel;
                }
            }

            // dump all data to an array and bind them to the form
            $data = $this->getRequest()->getPost()->toArray();

            //get files
            $files = $this->getRequest()->getFiles()->toArray();

            $panosData = $this->panosTable->getPano($data['id']);
            if ($panosData->type === 'video') {
                $panoEditForm->get('pano_type')->setValueOptions([
                    'spherical' => _('Spherical'),
                    'flat' => _('Flat'),
                ]);
            }

            // verify if the form is valid
            $panoEditForm->setData(array_replace_recursive($data, $files));

            if ($panoEditForm->isValid()) {

                // prepare main pano data
                $pano = new Panos();
                $pano->exchangeArray($data);

                //save depthmap files
                $panoDir = __DIR__ . '/../../../../../panos/p' . $panoId . '.tiles/';
                if (!is_dir($panoDir)) {
                    mkdir($panoDir, 0777, true);
                }

                if (isset($files['depthmap_file']) && $files['depthmap_file']['error'] == UPLOAD_ERR_OK) {
                    @unlink($panoDir . 'dmap.jpg');
                    @unlink($panoDir . 'dmap.jpeg');
                    @unlink($panoDir . 'dmap.png');
                    @unlink($panoDir . 'dmap.depth');
                    @unlink($panoDir . 'dmap.stl');
                    @unlink($panoDir . 'dmap.obj');
                    $fileExtension = strtolower(pathinfo($files['depthmap_file']['name'], PATHINFO_EXTENSION));
                    $depthmapFile = $panoDir . 'dmap.' . $fileExtension;
                    move_uploaded_file($files['depthmap_file']['tmp_name'], $depthmapFile);
                    $pano->depthmap_visible = 1;
                }

                // replace video
                if ($panosData->type === 'video') {
                    $mediaId = $data['media_id'];
                    $mediaFile = $this->mediaTable->getById($mediaId);
                    $originalName = $mediaFile->original_name;
                    $originalExtension = pathinfo($originalName, PATHINFO_EXTENSION);
                    $sceneData = preg_replace('/(videourl="%FIRSTXML%\/media\/).*?(")/m', '$1' . "v$mediaId.$originalExtension" . '$2', $panosData->scene_data);
                    $this->panosTable->saveSceneData($panoId, $sceneData);
                    $this->panosTable->updateVideoSceneMediaId($panoId, $data['media_id'], $data['pano_type']);
                }

                // save pano
                $panoId = $this->panosTable->save($pano);

                // prepare phrases using panos_fs, panos_gallery_fs fieldsets
                foreach ($data['panos_fs'] as $phrase) {

                    $panoPhrase = new PanoPhrases();

                    $panoPhrase->id = $phrase['id'];
                    $panoPhrase->panos_id = $panoId;
                    $panoPhrase->languages_id = $phrase['languages_id'];
                    $panoPhrase->media_id = $phrase['media_id'];
                    $panoPhrase->name = $phrase['name'];
                    $panoPhrase->description = $phrase['description'];

                    $this->panoPhrasesTable->save($panoPhrase);

                }

                    if (isset($files['replace_pano']) && $files['replace_pano']['error'] == UPLOAD_ERR_OK) {

                    // check if file is ok to be processed
                    if ($data['pano_type'] === 'sphere' || $data['pano_type'] === 'cubic') {
                        $panoSize = getimagesize($files['replace_pano']['tmp_name']);
                        if ($panoSize && $panoSize[0] !== 0 && $panoSize[1] !== 0) {
                            if (!($panoSize[0] / $panoSize[1] === 2 || $panoSize[1] / $panoSize[0] === 2 || $panoSize[0] === $panoSize[1])) {
                                $jsonModel = new JsonModel();
                                $jsonModel->setVariables([
                                    'success' => false,
                                    'filetoobig' => _('Spherical panorama should have 2:1 or 1:1 proportions!')
                                ]);

                                return $jsonModel;
                            }
                        }
                    }

                    $panoDirReplace = __DIR__ . '/../../../../../';

                    $fileExtension = strtolower(pathinfo($files['replace_pano']['name'], PATHINFO_EXTENSION));
                    $panoFile = $panoDirReplace . 'p' . $panoId . '.' . $fileExtension;
                    move_uploaded_file($files['replace_pano']['tmp_name'], $panoFile);

                    $panoType = $data['pano_type'];
                    if (!in_array($panoType, ['sphere', 'flat', 'cubic'])) {
                        $panoType = 'sphere';
                    }

                    // Purge pano directory
                    VRMCommon::purgePanoDirectory($panoId);

                    // PROCESS THE PANO!!!!
                    $panoConfig = 'nasz_vtour_vr_' . $panoType;

                    shell_exec(__DIR__ . '/../../../../data/bin/krpano/krpanotools makepano -config=templates/' . $panoConfig . '.config ' . $panoFile);

                    // create thumbnails
                    $dest_image = $panoDirReplace . '/thumb.jpg';
                    $retina_image = $panoDirReplace . '/thumb_retina.jpg';
                    $temp_image = $panoType === 'multires' ? $panoDirReplace . '/pano.tiles/mobile_f.jpg' : $panoDirReplace . '/pano.tiles/preview.jpg';

                    VRMCommon::resizeImage($temp_image, $dest_image, PANO_THUMB, PANO_THUMB, 'cover');
                    VRMCommon::resizeImage($temp_image, $retina_image, PANO_THUMB * 2, PANO_THUMB * 2, 'cover');

                    @unlink($panoFile);

                    // write generated scene data to the database
                    $coords = $this->xmlWriter->storeSceneData($panoId);

                    $this->panosTable->updatePanoCoords($panoId, $coords);

                    // move pX.js to tour.js
                    @rename($panoDirReplace . 'p' . $panoId . '.js', $panoDirReplace . 'tour.js');

                    // delete pX.html
                    @unlink($panoDirReplace . 'p' . $panoId . '.html');
                } elseif (isset($files['replace_pano_zip']) && $files['replace_pano_zip']['error'] == UPLOAD_ERR_OK) {

                    //after saving new pano - create folders
                    $panoDirZip = __DIR__ . '/../../../../../panos/p' . $panoId;

                    if (!is_dir($panoDirZip)) {
                        mkdir($panoDirZip, 0777, true);
                    }

                    //save files - move uploaded archive to $panoDir

                    $panoZip = $panoDirZip . DIRECTORY_SEPARATOR . 'pano.zip';
                    move_uploaded_file($files['replace_pano_zip']['tmp_name'], $panoZip);

                    // extract ZIP archive in place
                    $filter = new Decompress([
                        'adapter' => 'Zip',
                        'options' => [
                            'target' => $panoDirZip,
                        ]
                    ]);
                    $filter->filter($panoZip);

                    // Purge pano directory
                    VRMCommon::purgePanoDirectory($panoId);

                    $newPanoDir = __DIR__ . '/../../../../../panos/p' . $panoId . '.tiles';
                    VRMCommon::recurse_copy($panoDirZip . DIRECTORY_SEPARATOR . 'panos' . DIRECTORY_SEPARATOR . 'cms4vr-newpano.tiles', $newPanoDir);

                    // move cms4vr-newpano.js to tour.js
                    @rename($panoDirZip . DIRECTORY_SEPARATOR . 'cms4vr-newpano.js', __DIR__ . '/../../../../../tour.js');

                    // move cms4vr-newpano.xml to pX.xml
                    @rename($panoDirZip . DIRECTORY_SEPARATOR . 'cms4vr-newpano.xml', __DIR__ . '/../../../../../p' . $panoId . '.xml');

                    $coords = $this->xmlWriter->storeSceneData($panoId);

                    $this->panosTable->updatePanoCoords($panoId, $coords);

                    // delete pX.html
                    @unlink($panoDirZip . 'p' . $panoId . '.html');

                    // delete working directory
                    VRMCommon::removeDirectory($panoDirZip);
                }

                if (isset($files['thumbnail_file']) && $files['thumbnail_file']['error'] === UPLOAD_ERR_OK) {
                    // create thumbnails
                    $dest_image = $panoDir . '/thumb.jpg';
                    $retina_image = $panoDir . '/thumb_retina.jpg';
                    $fb_image = $panoDir . '/fb_thumb.jpg';
                    move_uploaded_file($files['thumbnail_file']["tmp_name"], $fb_image);

                    VRMCommon::resizeImage($fb_image, $dest_image, PANO_THUMB, PANO_THUMB, 'cover');
                    VRMCommon::resizeImage($fb_image, $retina_image, PANO_THUMB * 2, PANO_THUMB * 2, 'cover');
                }

                $this->xmlWriter->writeTourFile();
                $this->xmlWriter->writeTourDataFile();

                // trigger new license check
                unset($_SESSION['license_checked']);

                $this->flashMessenger()->addMessage(_('Panorama has been successfully edited'));

                // build and return JSON
                $jsonModel = new JsonModel();
                $jsonModel->setVariables([
                    'success' => true,
                ]);

                return $jsonModel;

            } else {
                $errors = [];

                foreach ($panoEditForm->getElements() as $field) {
                    if (in_array($field->getName(), ['panos_fs', 'submit', 'cancel'])) {
                        continue;
                    }
                    if ($field->getMessages()) {
                        $fieldErrors = [];
                        $fieldMessages = $field->getMessages();
                        array_walk_recursive($fieldMessages, function ($v) use (&$fieldErrors) {
                            $fieldErrors[] = $v;
                        });
                        $errors[$field->getName()] = implode('<br />', $fieldErrors);
                    }
                }

                $fieldsets = $panoEditForm->get('panos_fs')->getFieldsets();

                foreach ($fieldsets as $lang => $fields) {
                    foreach ($fields as $field) {
                        if ($field->getMessages()) {
                            $fieldErrors = [];
                            $fieldMessages = $field->getMessages();
                            array_walk_recursive($fieldMessages, function ($v) use (&$fieldErrors) {
                                $fieldErrors[] = $v;
                            });
                            $errors['panos_fs[' . $lang . '][' . $field->getName() . ']'] =
                                implode('<br />', $fieldErrors);
                        }
                    }
                }

                $jsonModel = new JsonModel();
                $jsonModel->setVariables([
                    'success' => false,
                    'errors'  => $errors
                ]);

                return $jsonModel;
            }

        } else {

            // get pano data
            $panosData = $this->panosTable->getPano($panoId);

            $panoEditForm->populateValues($panosData->getArrayCopy());

            $panoValues = [];

            foreach ($projectLanguages as $key => $value) {
                $panoValues['panos_fs'][$value['id']]['languages_id'] = $value['id'];
                $panoValues['panos_fs'][$value['id']]['id'] = null;
                $panoValues['panos_fs'][$value['id']]['name'] = null;
                $panoValues['panos_fs'][$value['id']]['description'] = null;
            }

            $panoPhrases = $this->panoPhrasesTable->getPhrasesForPano($panoId);

            foreach ($panoPhrases as $phrase) {
                $panoValues['panos_fs'][$phrase->languages_id]['id'] = $phrase->id;
                $panoValues['panos_fs'][$phrase->languages_id]['name'] = $phrase->name;
                $panoValues['panos_fs'][$phrase->languages_id]['description'] = $phrase->description;
                $panoValues['panos_fs'][$phrase->languages_id]['media_id'] = $phrase->media_id;
            }

            if ($panosData->type === 'video') {
                $panoEditForm->get('pano_type')->setValueOptions([
                    'spherical' => _('Spherical'),
                    'flat' => _('Flat'),
                ]);

                // set pano type field
                preg_match_all('/videotyp="(.*?)"/m', $panosData->scene_data, $matches, PREG_SET_ORDER, 0);
                $panosType = $matches[0][1];
                $panoValues['pano_type'] = $panosType;
            }

            $panoEditForm->populateValues($panoValues);

            if ($panosData->type === 'video') {
                $panoEditForm->get('pano_type')->setValueOptions([
                    'spherical' => _('Spherical'),
                    'flat' => _('Flat'),
                ]);
            }

        }

        $dmapFile = glob(__DIR__ . '/../../../../../panos/p' . $panoId . '.tiles/dmap*');

        return new ViewModel([
            'form'                   => $panoEditForm,
            'languageList'           => $projectLanguages,
            'panoId'                 => $panoId,
            'projectCategories'      => $projectCategories,
            'submission'             => $submission,
            'googleMapAPIKey'        => $googleMapAPIKey,
            'dmapthFilePresent'      => isset($dmapFile[0]),
            'panoList'               => $this->panosTable->getPanoList(),
            'panoDetails'            => $this->panosTable->getPano($panoId),
        ]);
    }

    /**
     * Manages editing pano - this is very different from creating a new pano, hence this method is separated
     *
     * @see createAction
     *
     * @return \Laminas\Http\Response|ViewModel
     */
    public function editAjaxAction()
    {

        $modulesSettings = Json::decode($this->settingsTable->get('global_modules'));
        $googleMapAPIKey = isset($modulesSettings->m_map->id) ? $modulesSettings->m_map->id : '';

        $panoId = $this->params()->fromPost('id');

        $panoEditForm = new PanoEditForm($panoId);

        $panosData = $this->panosTable->getPano($panoId);
        $panosType = '';
        if ($panosData->type === 'video') {
            $panoEditForm->get('pano_type')->setValueOptions([
                'spherical' => _('Spherical'),
                'flat' => _('Flat'),
            ]);

            // set pano type field
            preg_match_all('/videotyp="(.*?)"/m', $panosData->scene_data, $matches, PREG_SET_ORDER, 0);
            $panosType = $matches[0][1];
        }

        // set static DB adapter to be used by fieldsets validation
        GlobalAdapterFeature::setStaticAdapter($this->staticDbAdapter);

        // get project languages, categories
        $projectLanguages = $this->languagesTable->getLanguages(false)->toArray();
        $projectCategories = $this->categoriesTable->getCategories();
        $projectGalleries = $this->galleriesTable->getGalleriesList();

        $languagesMapping = [];

        foreach ($projectLanguages as $projectLanguage) {
            $languagesMapping[$projectLanguage['id']] = $projectLanguage['short'];
        }

        $projectGalleriesSelect[0] = _('- no assignment');
        foreach ($projectGalleries as $galleryId => $gallery) {
            $projectGalleriesSelect[$galleryId] = reset($gallery['name']);
        }

        $submission = false;

        $panoEditForm->get('galleries_id')->setValueOptions($projectGalleriesSelect);

        // get pano data
        $panosData = $this->panosTable->getPano($panoId);

        $panosData->pano_type = $panosType;

        $panoEditForm->populateValues($panosData->getArrayCopy());

        $panoValues = [];

        foreach ($projectLanguages as $key => $value) {
            $panoValues['panos_fs'][$value['id']]['languages_id'] = $value['id'];
            $panoValues['panos_fs'][$value['id']]['id'] = null;
            $panoValues['panos_fs'][$value['id']]['name'] = null;
            $panoValues['panos_fs'][$value['id']]['description'] = null;
        }

        $panoPhrases = $this->panoPhrasesTable->getPhrasesForPano($panoId);

        foreach ($panoPhrases as $phrase) {
            $panoValues['panos_fs'][$phrase->languages_id]['id'] = $phrase->id;
            $panoValues['panos_fs'][$phrase->languages_id]['name'] = $phrase->name;
            $panoValues['panos_fs'][$phrase->languages_id]['description'] = $phrase->description;
            $panoValues['panos_fs'][$phrase->languages_id]['media_id'] = $phrase->media_id;
        }

        $panoEditForm->populateValues($panoValues);

        $dmapFile = glob(__DIR__ . '/../../../../../panos/p' . $panoId . '.tiles/dmap*');

        $htmlViewPart = new ViewModel();
        $htmlViewPart
            ->setTemplate('application/pano/edit-ajax')
            ->setVariables([
                'form'                   => $panoEditForm,
                'languageList'           => $projectLanguages,
                'panoId'                 => $panoId,
                'projectCategories'      => $projectCategories,
                'submission'             => $submission,
                'googleMapAPIKey'        => $googleMapAPIKey,
                'dmapthFilePresent'      => isset($dmapFile[0]),
                'panoList'               => $this->panosTable->getPanoList(),
                'panoDetails'            => $this->panosTable->getPano($panoId),
            ]);

        // render the content
        $htmlOutput = $this->renderer->render($htmlViewPart);

        // build and return JSON
        $jsonModel = new JsonModel();
        $jsonModel->setVariables([
                                     'success' => true,
                                     'html'    => $htmlOutput
                                 ]);

        return $jsonModel;
    }

    /**
     * Deletes given panorama through an AJAX call
     *
     * @return JsonModel
     */
    public function deletePanoAjaxAction()
    {
        $id = $this->params()->fromPost('id');

        $result = $this->panosTable->deletePano($id);

        if ($result == 1) {
            // delete files in local storage
            $dir = __DIR__ . '/../../../../../panos/p' . $id . '.tiles';

            VRMCommon::removeDirectory($dir);

            // update XML files
            $this->xmlWriter->writeTourFile();
            $this->xmlWriter->writeTourDataFile();

            $this->flashMessenger()->addMessage(_('Panorama has been successfully deleted'));

            return new JsonModel(['success' => true]);
        } else {
            return new JsonModel(['success' => false]);
        }
    }

    /**
     * Changes visibility of pano in the project (publish/unpublish operations)
     *
     * @return JsonModel
     */
    public function changePanoVisibilityAjaxAction()
    {
        $id = $this->params()->fromPost('id');
        $visible = $this->params()->fromPost('visible');

        $visible ^= 1;

        $result = $this->panosTable->changeVisibility($id, $visible);

        $this->xmlWriter->writeTourDataFile();

        return new JsonModel(['success' => $result ? true : false]);

    }

    /**
     * Sets pano start_view
     *
     * @return JsonModel
     */
    public function changePanoStartViewAjaxAction()
    {
        $id = $this->params()->fromPost('id');
        $startView = $this->params()->fromPost('start_view');

        $result = $this->panosTable->setPanoStartView($id, $startView);

        $this->xmlWriter->writeTourDataFile();

        return new JsonModel(['success' => $result ? true : false]);

    }

    /**
     * Sets pano north
     *
     * @return JsonModel
     */
    public function changePanoNorthAjaxAction()
    {
        $id = $this->params()->fromPost('id');
        $north = $this->params()->fromPost('north');

        if ((int)$north === 0) {
            $north = '0.00001';
        }

        $result = $this->panosTable->setPanoNorth($id, $north);

        $this->xmlWriter->writeTourDataFile();

        return new JsonModel(['success' => $result ? true : false]);

    }

    /**
     * Updates position of panoramas within specific category
     */
    public function updatePositionAjaxAction()
    {
        //get params
        $rowsPositions = $this->params()->fromPost('rowsPositions', false);
        $categoryId = $this->params()->fromPost('categoryId', false);

        //set flag
        $success = false;

        if (!empty($rowsPositions)) {
            //update target table rows
            foreach ($rowsPositions as $position => $row) {
                $this->panoCategoryConnectionsTable->updatePosition($row['panoId'], $categoryId, $position);
            }
            $this->xmlWriter->writeTourDataFile();
            $success = true;
        }


        //return json model
        $result = new JsonModel([
                                    'success' => $success
                                ]);

        return $result;
    }

    /**
     * Generates shortlinks for different resources
     *
     * @return JsonModel
     */
    public function getShortlinkAjaxAction()
    {
        $data = $this->getRequest()->getPost()->toArray();
        $link = uniqid();

        $shortlink = new Shortlink();
        $shortlink->link = $link;
        $shortlink->params = json_encode($data);

        $subdirPart = str_replace('/admin', '', dirname($_SERVER['PHP_SELF']));
        $newLink = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != '' ? "https" : "http") . '://' . $_SERVER['HTTP_HOST'] . $subdirPart;

        if (isset($data['type']) && $data['type'] == 'sticker') {
            $newLink .= '/sticker/' . $link;
        } else {
            $type = explode('|', $data['mydata']);
            $newLink .= '/' . $type[0] . '/' . $link;
        }

        $this->shortlinkTable->save($shortlink);

        //return json model
        $result = new JsonModel([
            'success' => true,
            'link' => $newLink,
        ]);

        return $result;
    }

    /**
     * Presents share window through an AJAX call
     *
     * @return JsonModel
     */
    public function showShareWindowAjaxAction()
    {
        $link = $this->params()->fromPost('link', false);

        $htmlViewPart = new ViewModel();
        $htmlViewPart->setTemplate('application/pano/sharewindow')->setVariables(['link' => $link]);

        // render the content
        $htmlOutput = $this->renderer->render($htmlViewPart);

        // build and return JSON
        $jsonModel = new JsonModel();
        $jsonModel->setVariables([
            'success' => true,
            'html'    => $htmlOutput
        ]);

        return $jsonModel;
    }

    /**
     * Triggers the search function
     *
     * @return JsonModel
     */
    public function searchAjaxAction()
    {

        $run = $this->params()->fromQuery('run', false);

        if (!$run) {
            $htmlViewPart = new ViewModel();
            $htmlViewPart->setTemplate('application/pano/search');

            // render the content
            $htmlOutput = $this->renderer->render($htmlViewPart);

            // build and return JSON
            $jsonModel = new JsonModel();
            $jsonModel->setVariables([
                'success' => true,
                'html'    => $htmlOutput
            ]);

            return $jsonModel;
        }


        $lang = $this->params()->fromPost('lang', false);
        $term = mb_strtolower(trim($this->params()->fromPost('term', false)));

        $data = $this->panosTable->getPanosWithPoi(true, $lang);

        $corpus = [];
        $corpusDetails = [];

        $i = 0;
        foreach ($data as $panosId => $pano) {

            if (trim($pano['panoDetails']['phrases'][$lang]['name'])) {
                $corpus[$i] = $pano['panoDetails']['phrases'][$lang]['name'];
                $corpusDetails[$i] = ['type' => 'pano', 'src' => 'name', 'id' => $panosId, 'name' => $pano['panoDetails']['phrases'][$lang]['name']];
                $i++;
            }

            if (trim(strip_tags($pano['panoDetails']['phrases'][$lang]['description']))) {
                $corpus[$i] = trim(preg_replace('/<[^>]*>/', ' ', $pano['panoDetails']['phrases'][$lang]['description']));
                $corpusDetails[$i] = ['type' => 'pano', 'src' => 'description', 'id' => $panosId,  'name' => $pano['panoDetails']['phrases'][$lang]['name']];
                $i++;
            }

            foreach ($pano['poi'] as $poiId => $poi) {

                if (!in_array($poi['type'], ['info', 'popup']) || !isset($poi['phrases'][$lang])) {
                    continue;
                }

                if (trim($poi['phrases'][$lang]['name'])) {
                    $corpus[$i] = $poi['phrases'][$lang]['name'];
                    $corpusDetails[$i] = ['type' => 'poi', 'src' => 'name', 'panosId' => $panosId, 'id' => $poiId, 'name' => $poi['phrases'][$lang]['name'], 'poiName' => $poi['name']];
                    $i++;
                }

                $params = json_decode($poi['phrases'][$lang]['params'], true);

                if (isset($params['description']) && trim(strip_tags($params['description']))) {
                    $corpus[$i] = trim(preg_replace('/<[^>]*>/', ' ', $params['description']));
                    $corpusDetails[$i] = ['type' => 'poi', 'src' => 'description', 'panosId' => $panosId, 'id' => $poiId, 'name' => $poi['phrases'][$lang]['name'], 'poiName' => $poi['name']];
                    $i++;
                }
            }
        }

        $results = [];
        $termsExploded = explode(' ', $term);

        foreach ($termsExploded as $searchItem) {
            foreach ($corpus as $searchId => $searchString) {
                $searchTmpString = mb_strtolower(trim($searchString));
                if (preg_match('~(' . $searchItem . ')~', $searchTmpString)) {
                    if (!isset($results[$searchId])) {
                        $results[$searchId] = 0;
                    }
                    $results[$searchId]++;
                }
            }
        }

        $htmlViewPart = new ViewModel();
        $htmlViewPart->setTemplate('application/pano/search-results')->setVariables(['results' => $results, 'corpusDetails' => $corpusDetails]);

        // render the content
        $htmlOutput = $this->renderer->render($htmlViewPart);

        // build and return JSON
        $jsonModel = new JsonModel();
        $jsonModel->setVariables([
            'success' => true,
            'html'    => $htmlOutput
        ]);

        return $jsonModel;

    }

    /**
     * Saves XML file with content generated by krpano (stickers)
     *
     * @return JsonModel
     */
    public function saveFrontendXmlAjaxAction()
    {
        $xml = $this->params()->fromPost('data');
        $fileName = $this->params()->fromPost('losowa');
        $fileName = preg_replace('/\D/', '', $fileName);

        if (!$xml || !$fileName) {
            // build and return JSON
            $jsonModel = new JsonModel();
            $jsonModel->setVariables([
                'success' => false,
            ]);

            return $jsonModel;
        }

        $dir = __DIR__ . '/../../../../../skin/stickers';
        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }
        $file = $dir . DIRECTORY_SEPARATOR . $fileName . '.xml';
        file_put_contents($file, $xml);

        // build and return JSON
        $jsonModel = new JsonModel();
        $jsonModel->setVariables([
            'success' => true,
        ]);

        return $jsonModel;
    }

    /**
     * Registers project on a main server
     *
     * @return JsonModel
     */
    public function addProjectAjaxAction()
    {

        $forceCheck = (int)$this->params()->fromPost('force');

        if ($forceCheck === 0) {
            $lastCheck = (int)$this->settingsTable->get('lastCheck');

            if (!$lastCheck) {
                $lastCheck = time();
                $this->settingsTable->set('lastCheck', $lastCheck);
            }

            if (time() - $lastCheck < 3600) {
                $jsonModel = new JsonModel();
                $jsonModel->setVariables([
                    'success' => true,
                ]);

                return $jsonModel;
            }
        }

        $license = $this->settingsTable->get('license');

        $kruser = $this->params()->fromPost('kruser');
        $kremail = $this->params()->fromPost('kremail');

        $subdirPart = str_replace('/admin', '', dirname($_SERVER['PHP_SELF']));
        $newLink = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != '' ? "https" : "http") . '://' . $_SERVER['HTTP_HOST'] . $subdirPart;

        $currentVersion = $this->settingsTable->get('version');

        if (!$currentVersion) {
            $currentVersion = '1.0.0';
        }

        $url = 'https://cms4vr.com/licenses/api.php?a=addProject';
        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, ['dev-license' => $license, 'dev-kruser' => $kruser, 'dev-kremail' => $kremail, 'dev-url' => $newLink, 'version' => $currentVersion]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_CAINFO, __DIR__ . '/../../../../data/cacert.pem');

        $response = curl_exec($ch);
        curl_close($ch);

        // in case of error, skip checking - will try during the next session
        if (!$response) {
            $_SESSION['license_checked'] = true;

            // build and return JSON
            $jsonModel = new JsonModel();
            $jsonModel->setVariables([
                'success' => true,
            ]);

            return $jsonModel;
        }

        $responseJson = json_decode($response);

        if ($responseJson->success) {
            $this->settingsTable->set('cms_dev_version', $responseJson->version);
        } else {
            $this->settingsTable->set('cms_dev_version', 'banned');
        }

        $this->settingsTable->set('lastCheck', time());

        // update XML files
        $this->xmlWriter->writeTourFile();
        $this->xmlWriter->writeTourDataFile();

        $_SESSION['license_checked'] = true;

        // build and return JSON
        $jsonModel = new JsonModel();
        $jsonModel->setVariables([
            'success' => true,
        ]);

        return $jsonModel;
    }

    /**
     * Checks for update
     *
     * @return JsonModel
     */
    public function checkUpdateAjaxAction()
    {

        $currentVersion = $this->settingsTable->get('version');
        $license = $this->settingsTable->get('license');

        if (!$currentVersion) {
            $currentVersion = '1.0.0';
        }

        $url = 'https://cms4vr.com/licenses/api.php?a=checkUpdate';
        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, ['version' => $currentVersion, 'license' => $license]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

        $response = curl_exec($ch);
        curl_close($ch);

        $responseJson = json_decode($response);

        if ($responseJson && $responseJson->success) {
            // build and return JSON
            $jsonModel = new JsonModel();
            $jsonModel->setVariables([
                                         'success' => true,
                                         'update' => $responseJson->update
                                     ]);

            return $jsonModel;
        }

        exit;
    }

    public function downloadZipUpdateAction()
    {
        $toVersion = $this->params()->fromQuery('toVersion');

        $license = $this->settingsTable->get('license');

        $url = 'https://cms4vr.com/licenses/api.php?a=getUpdate';
        $ch = curl_init($url);

        $fileName = 'update-' . $toVersion . '.zip';
        $fsFilePath = $fileName;
        $fp = fopen($fsFilePath, 'wb+');

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, ['version' => $toVersion, 'license' => $license]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_FILE,  $fp);

        $response = curl_exec($ch);
        curl_close($ch);

        if (!$response) {
            http_response_code(404);
            die();
        }

        $fileSize = filesize($fsFilePath);

        header('Content-type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $fileName . '"');
        header("Content-Length: " . $fileSize);

        // set IE-specific headers
        if (strpos($_SERVER['HTTP_USER_AGENT'], "MSIE") !== false) {
            header('Pragma: cache');
            header('Cache-Control: private, max-age=1');
        }

        // if a file is larger than the default chunksize (8MB), serve it in chunks
        if ($fileSize > self::CHUNK_SIZE) {
            // get the handle to the file and set up empty buffor
            $handle = fopen($fsFilePath, 'rb');

            // scan the file in 8MB chunks and send it to the user
            while (!feof($handle) && (connection_status() === CONNECTION_NORMAL)) {
                $buffer = fread($handle, self::CHUNK_SIZE);
                print $buffer;

                //check if buffer buffer is not empty, then clean it
                if (ob_get_length() > 0) {
                    ob_flush();
                }
                flush();
                // make sure that while downloading no time limit will occur unexpectedly
                set_time_limit(300);
            }

            // if the connection is lost, do the cleanup
            if (connection_status() !== CONNECTION_NORMAL) {
                @unlink($fsFilePath);
                return false;
            }
            // close the handle to the file
            fclose($handle);
            @unlink($fsFilePath);
            return true;
        }

        // if the file is smaller than 8MB, send it to the user immediately
        //check if buffer buffer is not empty, then clean it
        if (ob_get_length() > 0) {
            ob_clean();
        }
        flush();
        readfile($fsFilePath);
        @unlink($fsFilePath);
        return true;
    }

    /**
     * Executes for update
     *
     * @return JsonModel
     */
    public function triggerUpdateAjaxAction()
    {

        $toVersion = $this->params()->fromPost('toVersion');

        $license = $this->settingsTable->get('license');

        $url = 'https://cms4vr.com/licenses/api.php?a=getUpdate';
        $ch = curl_init($url);

        $fileName = 'update-' . uniqid() . '.zip';
        $fp = fopen($fileName, 'wb+');

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, ['version' => $toVersion, 'license' => $license]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_FILE,  $fp);

        $response = curl_exec($ch);
        curl_close($ch);

        if (!$response) {
            // build and return JSON
            $jsonModel = new JsonModel();
            $jsonModel->setVariables([
                'success' => false
            ]);

            return $jsonModel;
            exit;
        }

        // extract ZIP archive in place
        $filter = new Decompress([
                                     'adapter' => 'Zip',
                                     'options' => [
                                         'target' => '.',
                                     ]
                                 ]);
        $decompressed = $filter->filter($fileName);

        @unlink($fileName);

        @shell_exec('chmod +x ' . __DIR__ . '/../../../../data/bin/krpano/krpanotools');
        $shellExec = trim(@shell_exec(__DIR__ . '/../../../../data/bin/krpano/krpanotools')) !== '';
        $this->settingsTable->set('shellExec_enabled', (int)$shellExec);

        // register if there is a key in the database
        $regCode = $this->settingsTable->get('krpano_license');
        if ($shellExec && $regCode) {
            @shell_exec(__DIR__ . '/../../../../data/bin/krpano/krpanotools register ' . $regCode);
        }

        // check krpano registration
        if ($shellExec) {
            $regInfo = trim(@shell_exec(__DIR__ . '/../../../../data/bin/krpano/krpanotools register show'));
            if ($regInfo === 'Not registered.') {
                $_SESSION['krpanoRegError'] = true;
            } else {
                @shell_exec(__DIR__ . '/../../../../data/bin/krpano/krpanotools protect -o=tour.js -bf');
            }
        }

        $success = false;
        if ($decompressed) {
            $success = true;
            VRMCommon::removeDirectory(__DIR__ . '/../../../../data/cache');
            // remove not needed files
            if (file_exists(__DIR__ . '/../../../../config/autoload/development.local.php')) {
                @unlink(__DIR__ . '/../../../../config/autoload/development.local.php');
            }
            if (file_exists(__DIR__ . '/../../../../config/development.config.php')) {
                @unlink(__DIR__ . '/../../../../config/development.config.php');
            }
            if (file_exists(__DIR__ . '/../../../../vendor/zendframework')) {
                VRMCommon::removeDirectory(__DIR__ . '/../../../../vendor/zendframework');
            }
            $this->settingsTable->set('version', $toVersion);
            $this->xmlWriter->writeTourDataFile();
        }

        // build and return JSON
        $jsonModel = new JsonModel();
        $jsonModel->setVariables([
                                     'success' => $success
                                 ]);

        return $jsonModel;

        exit;
    }

    /**
     * Executes for update
     *
     * @return JsonModel
     */
    public function triggerUpdateFromLocalAjaxAction()
    {
        $files = $this->getRequest()->getFiles()->toArray();
        $file = $files['local_zip'];

        if(empty($file)) {
            $jsonModel = new JsonModel();
            $jsonModel->setVariables(
                [
                    'success' => false
                ]
            );
        }

        $toVersion = explode('-', basename($file['name'], '.zip'))[1];

        $fileName = 'update-' . uniqid() . '.zip';

        move_uploaded_file($file['tmp_name'], $fileName);

        // extract ZIP archive in place
        $filter = new Decompress(
            [
                'adapter' => 'Zip',
                'options' => [
                    'target' => '.',
                ]
            ]
        );
        $decompressed = $filter->filter($fileName);

        @unlink($fileName);

        @shell_exec('chmod +x ' . __DIR__ . '/../../../../data/bin/krpano/krpanotools');
        $shellExec = trim(@shell_exec(__DIR__ . '/../../../../data/bin/krpano/krpanotools')) !== '';
        $this->settingsTable->set('shellExec_enabled', (int)$shellExec);

        // register if there is a key in the database
        $regCode = $this->settingsTable->get('krpano_license');
        if ($shellExec && $regCode) {
            @shell_exec(__DIR__ . '/../../../../data/bin/krpano/krpanotools register ' . $regCode);
        }

        // check krpano registration
        if ($shellExec) {
            $regInfo = trim(@shell_exec(__DIR__ . '/../../../../data/bin/krpano/krpanotools register show'));
            if ($regInfo === 'Not registered.') {
                $_SESSION['krpanoRegError'] = true;
            } else {
                @shell_exec(__DIR__ . '/../../../../data/bin/krpano/krpanotools protect -o=tour.js -bf');
            }
        }

        $success = false;
        if ($decompressed) {
            $success = true;
            VRMCommon::removeDirectory(__DIR__ . '/../../../../data/cache');
            // remove not needed files
            if (file_exists(__DIR__ . '/../../../../config/autoload/development.local.php')) {
                @unlink(__DIR__ . '/../../../../config/autoload/development.local.php');
            }
            if (file_exists(__DIR__ . '/../../../../config/development.config.php')) {
                @unlink(__DIR__ . '/../../../../config/development.config.php');
            }
            if (file_exists(__DIR__ . '/../../../../vendor/zendframework')) {
                VRMCommon::removeDirectory(__DIR__ . '/../../../../vendor/zendframework');
            }
            $this->settingsTable->set('version', $toVersion);
            $this->xmlWriter->writeTourDataFile();
        }

        // build and return JSON
        $jsonModel = new JsonModel();
        $jsonModel->setVariables(
            [
                'success' => $success
            ]
        );

        return $jsonModel;

        exit;
    }

    /**
     * Saves new thumbnail created from POI editor
     *
     * @return JsonModel
     */
    public function saveNewThumbnailAjaxAction()
    {
        $imgB64 = $this->params()->fromPost('imgBase64');
        $sceneName = $this->params()->fromPost('sceneName');
        $panoId = str_replace('scene_', '', $sceneName);
        $panoDir = __DIR__ . '/../../../../../panos/' . $panoId . '.tiles';

        $data = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $imgB64));
        $filepath = $panoDir . '/fb_thumb.jpg';
        $out = file_put_contents($filepath, $data);

        if ($out) {
            // create thumbnails
            $dest_image = $panoDir . '/thumb.jpg';
            $retina_image = $panoDir . '/thumb_retina.jpg';
            $temp_image = $filepath;

            VRMCommon::resizeImage($temp_image, $dest_image, PANO_THUMB, PANO_THUMB, 'cover');
            VRMCommon::resizeImage($temp_image, $retina_image, PANO_THUMB * 2, PANO_THUMB * 2, 'cover');

            // build and return JSON
            $jsonModel = new JsonModel();
            $jsonModel->setVariables(['success' => true]);

            return $jsonModel;
        }

        // build and return JSON
        $jsonModel = new JsonModel();
        $jsonModel->setVariables(['success' => false]);

        return $jsonModel;
    }

    /**
     *
     * @return JsonModel
     */
    public function updatePanoNameAjaxAction()
    {
        $id = $this->params()->fromPost('id');
        $name = $this->params()->fromPost('name');
        $lang = $this->params()->fromPost('lang');

        $langId = $this->languagesTable->getLanguageByShortName($lang)->id;
        $panoPhrases = $this->panoPhrasesTable->getByPanoIdAndLanguageId($id, $langId);
        $panoPhrases->name = $name;

        $this->panoPhrasesTable->save($panoPhrases);

        $this->xmlWriter->writeTourDataFile();

        return new JsonModel(['success' => true]);

    }

    public function createVideoSceneAction()
    {

        $videoSceneEditForm = new VideoSceneForm();

        $projectCategories = $this->categoriesTable->getCategories();

        $projectCategoriesSelect = [];
        foreach ($projectCategories as $categoryId => $category) {
            $projectCategoriesSelect[$categoryId] = reset($category['name']);
        }

        $videoSceneEditForm->get('category_id')->setValueOptions($projectCategoriesSelect);

        // get project languages
        $projectLanguages = $this->languagesTable->getLanguages(false)->toArray();

        $languagesToPopulate = [];
        foreach ($projectLanguages as $key => $value) {
            $languagesToPopulate['panos_fs'][$value['id']]['language_id'] = $value['id'];
            $languagesToPopulate['panos_fs'][$value['id']]['language'] = $value['short'];
        }

        $videoSceneEditForm->populateValues($languagesToPopulate);

        if ($this->request->isPost()) {

            // dump all data to an array and bind them to the form
            $data = $this->getRequest()->getPost()->toArray();

            // verify if the form is valid
            $videoSceneEditForm->setData($data);
            if ($videoSceneEditForm->isValid()) {

                //get position
                $panoCount = $this->panosTable->countPanos();

                //create array for new pano
                $panoDataArray = [
                    'building_id' => 0,
                    'position' => $panoCount + 1,
                    'dir' => '',
                    'lat' => '',
                    'lng' => '',
                    'north' => '',
                    'start_view' => '',
                    'visible' => 1,
                    'processed' => 2,
                    'type' => 'video',
                    'media_id' => $data['media_id']
                ];

                $pano = new Panos();
                $pano->exchangeArray($panoDataArray);

                $panoId = $this->panosTable->save($pano);

                foreach ($data['panos_fs'] as $phrase) {
                    $panoPhrase = new PanoPhrases();
                    $panoPhrase->id = 0;
                    $panoPhrase->panos_id = $panoId;
                    $panoPhrase->languages_id = $phrase['language_id'];
                    $panoPhrase->name = $phrase['name'];
                    $this->panoPhrasesTable->save($panoPhrase);
                }

                // save category if one was selected
                if ($data['category_id']) {
                    $connection = new PanoCategoryConnections();
                    $connection->category_id = $data['category_id'];
                    $connection->pano_id = $panoId;
                    $connection->pano_position = 1;
                    $this->panoCategoryConnectionsTable->save($connection);
                }

                // thumbs
                $panoDir = __DIR__ . '/../../../../../panos/p' . $panoId . '.tiles';
                if (!mkdir($panoDir) && !is_dir($panoDir)) {
                    throw new \RuntimeException(sprintf('Directory "%s" was not created', $panoDir));
                }
                copy(__DIR__ . '/../../../../../admin/img/video-thumb.jpg', $panoDir . '/thumb.jpg');
                copy(__DIR__ . '/../../../../../admin/img/video-thumb_retina.jpg', $panoDir . '/thumb_retina.jpg');

                $mediaId = $data['media_id'];
                $mediaFile = $this->mediaTable->getById($mediaId);
                $originalName = $mediaFile->original_name;
                $originalExtension = pathinfo($originalName, PATHINFO_EXTENSION);

                $panoType = $data['pano_type'];

                // scene data
                $sceneData = <<<EOM
	<scene name="scene_p$panoId" videoscene="true" videotyp="$panoType" title="p$panoId" lat="" lng="" heading="" thumburl="panos/p$panoId.tiles/thumb.jpg">

        <plugin name="video_p$panoId" url="%FIRSTXML%/plugins/videoplayer.js"
        videourl="%FIRSTXML%/media/v$mediaId.$originalExtension"
            posterurl=""
            panovideo="true"
            loop="true" volume="1.0"
            onvideoready="onvideoready_pano_video()"
            onvideoplay="onvideoplay_pano_video()"
            onvideopaused="onvideopaused_pano_video()"
            onvideocomplete="onvideocomplete_pano_video()"
            onerror="onerror_pano_video()"/>

        <image>
            <sphere url="plugin:video_p$panoId" />
        </image>

    </scene>

EOM;
                $this->panosTable->saveSceneData($panoId, $sceneData);

                // update tour.xml file
                $this->xmlWriter->writeTourFile();
                $this->xmlWriter->writeTourDataFile();

                // trigger new license check
                unset($_SESSION['license_checked']);

                $this->flashMessenger()->addMessage(_('Video scene has been successfully created'));

                $this->redirect()->toRoute('vrm', [
                    'controller' => 'pano',
                    'action'     => 'index'
                ]);

            } else {
                return new ViewModel([
                    'form' => $videoSceneEditForm,
                    'languageList' => $projectLanguages
                ]);
            }
        }

        return new ViewModel([
            'form'                   => $videoSceneEditForm,
            'languageList' => $projectLanguages
        ]);
    }
}
