<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Controller\Plugin;

use Application\Model\SettingsTable;
use Application\Model\User;
use Application\Model\UserTable;
use Laminas\Authentication\AuthenticationService;
use Laminas\Mvc\Controller\Plugin\AbstractPlugin;
use Laminas\View\Helper\AbstractHelper;

/**
 * Class UserInfo is a simple helper to provide basic information about the user in controllers
 *
 * @package Application\View\Helper
 */
class UserInfoPlugin extends AbstractPlugin
{
    private $userTable;
    private $authenticationService;
    private $user;
    private $settingsTable;

    public function __construct(UserTable $userTable, AuthenticationService $authenticationService, SettingsTable $settingsTable)
    {
        $this->userTable = $userTable;
        $this->authenticationService = $authenticationService;
        $login = $this->authenticationService->getIdentity();
        $this->user = $this->userTable->getUserByLogin($login);
        $this->settingsTable = $settingsTable;
    }

    public function getUser()
    {
        return $this->user;
    }

    public function getCmsDevVersion()
    {
        return $this->settingsTable->get('cms_dev_version');
    }

    public function allowedCategories()
    {
        $limitCategories = false;
        if ($this->user->usertype == User::TYPE_EDITOR) {
            $limitCategories = [0];
            // get list of accessible categories
            $userSettings = json_decode($this->user->settings, true);
            if (!empty($userSettings)) {
                $limitCategories = $userSettings['allowed_categories'];
            }
        }
        return $limitCategories;
    }
}
