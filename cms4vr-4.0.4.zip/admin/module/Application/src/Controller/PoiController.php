<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Controller;

use Application\Form\PanoEditForm;
use Application\Form\PoiEditForm;
use Application\Model\CategoriesTable;
use Application\Model\GalleriesTable;
use Application\Model\LanguagesTable;

use Application\Model\MediaTable;
use Application\Model\PanoPhrases;
use Application\Model\PanoPhrasesTable;
use Application\Model\Panos;
use Application\Model\PanosTable;
use Application\Model\Poi;
use Application\Model\PoiPhrases;
use Application\Model\PoiPhrasesTable;
use Application\Model\PoiTable;
use Application\Model\SettingsTable;
use Application\Model\VRMCommon;
use Application\Model\XmlWriter;
use Laminas\Db\TableGateway\Feature\GlobalAdapterFeature;
use Laminas\Db\Adapter\Adapter;
use Laminas\Filter\Decompress;
use Laminas\Json\Json;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\JsonModel;
use Laminas\View\Model\ViewModel;
use Laminas\View\Renderer\PhpRenderer;

/**
 * Class PoiController
 *
 * @package Administration\Controller
 */
class PoiController extends AbstractActionController
{
    private $renderer;
    private $poiTable;
    private $poiPhrasesTable;
    private $languagesTable;
    private $panosTable;
    private $galleriesTable;
    private $xmlWriter;
    private $settingsTable;
    private $categoriesTable;
    private $staticDbAdapter;
    private $panoPhrasesTable;
    private $mediaTable;

    public function __construct(PhpRenderer $renderer, PoiTable $poiTable, PoiPhrasesTable $poiPhrasesTable, LanguagesTable $languagesTable, PanosTable $panosTable, PanoPhrasesTable $panoPhrasesTable, GalleriesTable $galleriesTable, XmlWriter $xmlWriter, SettingsTable $settingsTable, CategoriesTable $categoriesTable, Adapter $staticDbAdapter, MediaTable $mediaTable)
    {
        $this->renderer = $renderer;
        $this->poiTable = $poiTable;
        $this->poiPhrasesTable = $poiPhrasesTable;
        $this->languagesTable = $languagesTable;
        $this->panosTable = $panosTable;
        $this->panoPhrasesTable = $panoPhrasesTable;
        $this->galleriesTable = $galleriesTable;
        $this->xmlWriter = $xmlWriter;
        $this->settingsTable = $settingsTable;
        $this->categoriesTable = $categoriesTable;
        $this->staticDbAdapter = $staticDbAdapter;
        $this->mediaTable = $mediaTable;
    }

    /**
     * Returns a view model responsible for POI management
     *
     * @return \Laminas\Http\Response|ViewModel
     */
    public function indexAction()
    {

        $projectLanguages = $this->languagesTable->getLanguages(false)->toArray();

        $allowedCategories = $this->categoriesTable->getCategories($this->userInfo()->allowedCategories());
        $allowedCategoriesList = [];
        foreach ($allowedCategories as $allowedCategoryId => $allowedCategory) {
            $allowedCategoriesList[] = 'cat_' . $allowedCategoryId;
        }

        $modulesSettings = Json::decode($this->settingsTable->get('global_modules'));
        $googleMapAPIKey = isset($modulesSettings->m_map->id) ? $modulesSettings->m_map->id : '';

        $submission = false;

        if ($this->request->isPost()) {

            if (isset($_SERVER['CONTENT_LENGTH']) && empty($_POST)) {
                $max = min(VRMCommon::getIniBytes('post_max_size'), VRMCommon::getIniBytes('upload_max_filesize'));
                $send = $_SERVER['CONTENT_LENGTH'];

                if($max < $_SERVER['CONTENT_LENGTH']) {
                    $errorMsg = 'The amount of data sent (' .
                        number_format($send/(1024*1024), 2) . 'MB) exceeds the server limit (' . number_format($max/(1024*1024), 2) . 'MB). Upload a smaller file or contact server administrator.';
                    $jsonModel = new JsonModel();
                    $jsonModel->setVariables([
                        'success' => false,
                        'filetoobig' => $errorMsg
                    ]);

                    return $jsonModel;
                }
            }

            $panoId = $this->params()->fromPost('id');

            $panoEditForm = new PanoEditForm($panoId);

            // set static DB adapter to be used by fieldsets validation
            GlobalAdapterFeature::setStaticAdapter($this->staticDbAdapter);

            // get project galleries
            $projectGalleries = $this->galleriesTable->getGalleriesList();

            $languagesMapping = [];

            foreach ($projectLanguages as $projectLanguage) {
                $languagesMapping[$projectLanguage['id']] = $projectLanguage['short'];
            }

            $projectGalleriesSelect[0] = _('- no assignment');
            foreach ($projectGalleries as $galleryId => $gallery) {
                $projectGalleriesSelect[$galleryId] = reset($gallery['name']);
            }

            $panoEditForm->get('galleries_id')->setValueOptions($projectGalleriesSelect);

            // dump all data to an array and bind them to the form
            $data = $this->getRequest()->getPost()->toArray();

            //get files
            $files = $this->getRequest()->getFiles()->toArray();

            $panosData = $this->panosTable->getPano($data['id']);
            if ($panosData->type === 'video') {
                $panoEditForm->get('pano_type')->setValueOptions([
                    'spherical' => _('Spherical'),
                    'flat' => _('Flat'),
                ]);
            }

            // verify if the form is valid
            $panoEditForm->setData(array_replace_recursive($data, $files));

            if ($panoEditForm->isValid()) {

                // prepare main pano data
                $pano = new Panos();
                $pano->exchangeArray($data);

                //save depthmap files
                $panoDir = __DIR__ . '/../../../../../panos/p' . $panoId . '.tiles/';
                if (!is_dir($panoDir)) {
                    mkdir($panoDir, 0777, true);
                }

                if (isset($files['depthmap_file']) && $files['depthmap_file']['error'] == UPLOAD_ERR_OK) {
                    @unlink($panoDir . 'dmap.jpg');
                    @unlink($panoDir . 'dmap.jpeg');
                    @unlink($panoDir . 'dmap.png');
                    @unlink($panoDir . 'dmap.depth');
                    @unlink($panoDir . 'dmap.stl');
                    @unlink($panoDir . 'dmap.obj');
                    $fileExtension = strtolower(pathinfo($files['depthmap_file']['name'], PATHINFO_EXTENSION));
                    $depthmapFile = $panoDir . 'dmap.' . $fileExtension;
                    move_uploaded_file($files['depthmap_file']['tmp_name'], $depthmapFile);
                    $pano->depthmap_visible = 1;
                }

                // replace video
                if ($panosData->type === 'video') {
                    $mediaId = $data['media_id'];
                    $mediaFile = $this->mediaTable->getById($mediaId);
                    $originalName = $mediaFile->original_name;
                    $originalExtension = pathinfo($originalName, PATHINFO_EXTENSION);
                    $sceneData = preg_replace('/(videourl="%FIRSTXML%\/media\/).*?(")/m', '$1' . "v$mediaId.$originalExtension" . '$2', $panosData->scene_data);
                    $this->panosTable->saveSceneData($panoId, $sceneData);
                    $this->panosTable->updateVideoSceneMediaId($panoId, $data['media_id'], $data['pano_type']);
                }

                // save pano
                $panoId = $this->panosTable->save($pano);

                // prepare phrases using panos_fs, panos_gallery_fs fieldsets
                foreach ($data['panos_fs'] as $phrase) {

                    $panoPhrase = new PanoPhrases();

                    $panoPhrase->id = $phrase['id'];
                    $panoPhrase->panos_id = $panoId;
                    $panoPhrase->languages_id = $phrase['languages_id'];
                    $panoPhrase->media_id = $phrase['media_id'];
                    $panoPhrase->name = $phrase['name'];
                    $panoPhrase->description = $phrase['description'];

                    $this->panoPhrasesTable->save($panoPhrase);
                }

                if (isset($files['replace_pano']) && $files['replace_pano']['error'] == UPLOAD_ERR_OK) {

                    // check if file is ok to be processed
                    if ($data['pano_type'] === 'sphere' || $data['pano_type'] === 'cubic') {
                        $panoSize = getimagesize($files['replace_pano']['tmp_name']);
                        if ($panoSize && $panoSize[0] !== 0 && $panoSize[1] !== 0) {
                            if (!($panoSize[0] / $panoSize[1] === 2 || $panoSize[1] / $panoSize[0] === 2 || $panoSize[0] === $panoSize[1])) {
                                $jsonModel = new JsonModel();
                                $jsonModel->setVariables([
                                    'success' => false,
                                    'filetoobig' => _('Spherical panorama should have 2:1 or 1:1 proportions!')
                                ]);

                                return $jsonModel;
                            }
                        }
                    }

                    $panoDirReplace = __DIR__ . '/../../../../../';

                    $fileExtension = strtolower(pathinfo($files['replace_pano']['name'], PATHINFO_EXTENSION));
                    $panoFile = $panoDirReplace . 'p' . $panoId . '.' . $fileExtension;
                    move_uploaded_file($files['replace_pano']['tmp_name'], $panoFile);

                    $panoType = $data['pano_type'];
                    if (!in_array($panoType, ['sphere', 'flat', 'cubic'])) {
                        $panoType = 'sphere';
                    }

                    // Purge pano directory
                    VRMCommon::purgePanoDirectory($panoId);

                    // PROCESS THE PANO!!!!
                    $panoConfig = 'nasz_vtour_vr_' . $panoType;

                    shell_exec(__DIR__ . '/../../../../data/bin/krpano/krpanotools makepano -config=templates/' . $panoConfig . '.config ' . $panoFile);

                    // create thumbnails
                    $dest_image = $panoDirReplace . '/thumb.jpg';
                    $retina_image = $panoDirReplace . '/thumb_retina.jpg';
                    $temp_image = $panoType === 'multires' ? $panoDirReplace . '/pano.tiles/mobile_f.jpg' : $panoDirReplace . '/pano.tiles/preview.jpg';

                    VRMCommon::resizeImage($temp_image, $dest_image, PANO_THUMB, PANO_THUMB, 'cover');
                    VRMCommon::resizeImage($temp_image, $retina_image, PANO_THUMB * 2, PANO_THUMB * 2, 'cover');

                    @unlink($panoFile);

                    // write generated scene data to the database
                    $coords = $this->xmlWriter->storeSceneData($panoId);

                    $this->panosTable->updatePanoCoords($panoId, $coords);

                    // move pX.js to tour.js
                    @rename($panoDirReplace . 'p' . $panoId . '.js', $panoDirReplace . 'tour.js');

                    // delete pX.html
                    @unlink($panoDirReplace . 'p' . $panoId . '.html');
                } elseif (isset($files['replace_pano_zip']) && $files['replace_pano_zip']['error'] == UPLOAD_ERR_OK) {
                    //after saving new pano - create folders
                    $panoDirZip = __DIR__ . '/../../../../../panos/p' . $panoId;

                    if (!is_dir($panoDirZip)) {
                        mkdir($panoDirZip, 0777, true);
                    }

                    //save files - move uploaded archive to $panoDir

                    $panoZip = $panoDirZip . DIRECTORY_SEPARATOR . 'pano.zip';
                    move_uploaded_file($files['replace_pano_zip']['tmp_name'], $panoZip);

                    // extract ZIP archive in place
                    $filter = new Decompress([
                        'adapter' => 'Zip',
                        'options' => [
                            'target' => $panoDirZip,
                        ]
                    ]);
                    $filter->filter($panoZip);

                    // Purge pano directory
                    VRMCommon::purgePanoDirectory($panoId);

                    $newPanoDir = __DIR__ . '/../../../../../panos/p' . $panoId . '.tiles';
                    VRMCommon::recurse_copy($panoDirZip . DIRECTORY_SEPARATOR . 'panos' . DIRECTORY_SEPARATOR . 'cms4vr-newpano.tiles', $newPanoDir);

                    // move cms4vr-newpano.js to tour.js
                    @rename($panoDirZip . DIRECTORY_SEPARATOR . 'cms4vr-newpano.js', __DIR__ . '/../../../../../tour.js');

                    // move cms4vr-newpano.xml to pX.xml
                    @rename($panoDirZip . DIRECTORY_SEPARATOR . 'cms4vr-newpano.xml', __DIR__ . '/../../../../../p' . $panoId . '.xml');

                    $coords = $this->xmlWriter->storeSceneData($panoId);

                    $this->panosTable->updatePanoCoords($panoId, $coords);

                    // delete pX.html
                    @unlink($panoDirZip . 'p' . $panoId . '.html');

                    // delete working directory
                    VRMCommon::removeDirectory($panoDirZip);
                }

                $files = $this->getRequest()->getFiles()->toArray();

                if (isset($files['thumbnail_file']) && $files['thumbnail_file']['error'] === UPLOAD_ERR_OK) {
                    // create thumbnails
                    $dest_image = $panoDir . '/thumb.jpg';
                    $retina_image = $panoDir . '/thumb_retina.jpg';
                    $fb_image = $panoDir . '/fb_thumb.jpg';
                    move_uploaded_file($files['thumbnail_file']["tmp_name"], $fb_image);

                    VRMCommon::resizeImage($fb_image, $dest_image, PANO_THUMB, PANO_THUMB, 'cover');
                    VRMCommon::resizeImage($fb_image, $retina_image, PANO_THUMB * 2, PANO_THUMB * 2, 'cover');
                }

                $this->xmlWriter->writeTourFile();
                $this->xmlWriter->writeTourDataFile();

                // trigger new license check
                unset($_SESSION['license_checked']);

                // build and return JSON
                $jsonModel = new JsonModel();
                $jsonModel->setVariables([
                    'success' => true,
                ]);

                return $jsonModel;

            } else {
                $errors = [];

                foreach ($panoEditForm->getElements() as $field) {
                    if (in_array($field->getName(), ['panos_fs', 'submit', 'cancel'])) {
                        continue;
                    }
                    if ($field->getMessages()) {
                        $fieldErrors = [];
                        $fieldMessages = $field->getMessages();
                        array_walk_recursive($fieldMessages, function ($v) use (&$fieldErrors) {
                            $fieldErrors[] = $v;
                        });
                        $errors[$field->getName()] = implode('<br />', $fieldErrors);
                    }
                }

                $fieldsets = $panoEditForm->get('panos_fs')->getFieldsets();

                foreach ($fieldsets as $lang => $fields) {
                    foreach ($fields as $field) {
                        if ($field->getMessages()) {
                            $fieldErrors = [];
                            $fieldMessages = $field->getMessages();
                            array_walk_recursive($fieldMessages, function ($v) use (&$fieldErrors) {
                                $fieldErrors[] = $v;
                            });
                            $errors['panos_fs[' . $lang . '][' . $field->getName() . ']'] =
                                implode('<br />', $fieldErrors);
                        }
                    }
                }

                $jsonModel = new JsonModel();
                $jsonModel->setVariables([
                    'success' => false,
                    'errors'  => $errors
                ]);

                return $jsonModel;
            }
        }

        return new ViewModel([
            'languageList' => $projectLanguages,
            'allowedCategories' => implode('|', $allowedCategoriesList),
            'template' => $this->settingsTable->get('template'),
            'googleMapAPIKey' => $googleMapAPIKey,
            'submission' => $submission,
            'defaultProjectLanguageId' => $this->languagesTable->getByShort($this->settingsTable->get('default_language'))
        ]);
    }

    public function getPoiOverlayAjaxAction()
    {
        if (!$this->getRequest()->isPost())
            die('Only internal calls');

        $poiType = $this->params()->fromRoute('type');
        $poiName = $this->params()->fromRoute('poi');

        $projectLanguages = $this->languagesTable->getLanguages(false)->toArray();

        $form = new PoiEditForm();
        $form->setType($poiType);

        if ($this->params()->fromQuery('save')) {

            // dump all data to an array and bind them to the form
            $data = $this->getRequest()->getPost()->toArray();
            $form->setData($data);

            if ($form->isValid()) {

                // we need to distinguish between general POI settings and phrase params that are language-aware entries
                $poiPhrases = $data['poi_fs'];
                unset($data['poi_fs']);
                $poiSettings = $data;
                unset($poiSettings['id'], $poiSettings['type'], $poiSettings['atv'], $poiSettings['ath'], $poiSettings['panos_id'], $poiSettings['name'], $poiSettings['depth']);

                // prepare main pano data
                $poi = new Poi();
                $poi->id = $data['id'];
                $poi->panos_id = $data['panos_id'];
                $poi->name = $data['name'];
                $poi->atv = $data['atv'];
                $poi->ath = $data['ath'];
                $poi->type = $data['type'];
                $poi->settings = Json::encode($poiSettings);

                // save POI
                $poiId = $this->poiTable->save($poi);

                // prepare phrases using poi_fs fieldset
                foreach ($poiPhrases as $phrase) {

                    $poiPhrase = new PoiPhrases();

                    $poiPhrase->id = $phrase['id'];
                    $poiPhrase->poi_id = $poiId;
                    $poiPhrase->languages_id = $phrase['languages_id'];

                    $poiPhrase->name = isset($phrase['name']) ? $phrase['name'] : '';

                    // unset already used keys
                    unset($phrase['id'], $phrase['languages_id'], $phrase['name']);

                    $poiPhrase->params = Json::encode($phrase);

                    $this->poiPhrasesTable->save($poiPhrase);
                }

                // update tourdata.xml file
                $this->xmlWriter->writeTourDataFile();

                // build and return JSON
                $jsonModel = new JsonModel();
                $jsonModel->setVariables([
                    'success' => true,
                ]);

                return $jsonModel;

            } else {
                $errors = [];

                foreach ($form->getElements() as $field) {
                    if (in_array($field->getName(), ['poi_fs', 'submit', 'cancel'])) {
                        continue;
                    }
                    if ($field->getMessages()) {
                        $fieldErrors = [];
                        $fieldMessages = $field->getMessages();
                        array_walk_recursive($fieldMessages, function ($v) use (&$fieldErrors) {
                            $fieldErrors[] = $v;
                        });
                        $errors[$field->getName()] = implode('<br />', $fieldErrors);
                    }
                }

                $fieldsets = $form->get('poi_fs')->getFieldsets();

                foreach ($fieldsets as $lang => $fields) {
                    foreach ($fields as $field) {
                        if ($field->getMessages()) {
                            $fieldErrors = [];
                            $fieldMessages = $field->getMessages();
                            array_walk_recursive($fieldMessages, function ($v) use (&$fieldErrors) {
                                $fieldErrors[] = $v;
                            });
                            $errors['poi_fs[' . $lang . '][' . $field->getName() . ']'] =
                                implode('<br />', $fieldErrors);
                        }
                    }
                }

                $jsonModel = new JsonModel();
                $jsonModel->setVariables([
                    'success' => false,
                    'errors'  => $errors
                ]);

                return $jsonModel;
            }
        }

        $languagesToPopulate = [];

        foreach ($projectLanguages as $key => $value) {
            $languagesToPopulate['poi_fs'][$value['id']]['languages_id'] = $value['id'];
        }

        // store all form data in $formData
        $formData = $languagesToPopulate;

        $form->get('type')->setValue($poiType);

        // get poi data
        $poiData = current($this->poiTable->getPoiByName($poiName, 'languagesId'));

        $mediaFiles = [];

        // these will only be valid for already existing POIs stored in the database
        if ($poiData && key($poiData['phrases'])) {
            $formData = array_replace_recursive($formData, $poiData);
            $settings = Json::decode($poiData['settings'], true);
            if ($settings) {
                $formData = array_replace_recursive($formData, $settings);
            }

            $poiFieldset = [];

            foreach ($poiData['phrases'] as $language => $phrase) {
                $poiFieldset['poi_fs'][$language]['id'] = $phrase['id'];
                $poiFieldset['poi_fs'][$language]['name'] = $phrase['name'];

                $params = Json::decode($phrase['params'], true);

                foreach ($params as $paramName => $paramValue) {
                    if ($paramName === 'media_id') {
                        $mediaFiles[$paramValue] = $this->mediaTable->getById($paramValue);
                    }
                    $poiFieldset['poi_fs'][$language][$paramName] = $paramValue;
                }
            }

            $formData = array_replace_recursive($formData, $poiFieldset);
        }

        if ($poiData && (!key($poiData['phrases'])
                ||
                ($poiData['type'] === 'photo' && empty(array_column($poiData['phrases'], 'media_id')))
                ||
                (in_array($poiData['type'], ['popup', 'video']) && empty(array_column($poiData['phrases'], 'src')))
            )) {
            $formData = array_replace_recursive($formData, $poiData);
            $settings = Json::decode($poiData['settings'], true);
            if ($settings) {
                $formData = array_replace_recursive($formData, $settings);
            }

            // backwards compatibility for POI without xx_src attributes (no phrases defined)
            $compatibilityData = [];

            if ($poiData['type'] === 'photo' && isset($settings['src'])) {
                preg_match_all('/i(\d+).jpg/m', $settings['src'], $matches, PREG_SET_ORDER, 0);
                $src = isset($matches[0][1]) ? $matches[0][1] : '';
                foreach ($projectLanguages as $key => $value) {
                    $compatibilityData['poi_fs'][$value['id']]['id'] = 0;
                    $compatibilityData['poi_fs'][$value['id']]['media_id'] = $src;
                }
                $mediaFiles[$src] = $this->mediaTable->getById($src);
            }

            if ($poiData['type'] === 'popup' && isset($settings['src'])) {
                foreach ($projectLanguages as $key => $value) {
                    $compatibilityData['poi_fs'][$value['id']]['id'] = 0;
                    $compatibilityData['poi_fs'][$value['id']]['src'] = $settings['src'];
                }
            }

            if ($poiData['type'] === 'video' && isset($settings['src'])) {
                $mediaObject = $this->mediaTable->getByresource($settings['src']);
                foreach ($projectLanguages as $key => $value) {
                    $compatibilityData['poi_fs'][$value['id']]['id'] = 0;
                    $compatibilityData['poi_fs'][$value['id']]['media_id'] = $mediaObject->id;
                }
                $mediaFiles[$mediaObject->id] = $this->mediaTable->getById($mediaObject->id);
            }

            if ($compatibilityData) {
                $formData = array_replace_recursive($formData, $compatibilityData);
            }
        }

        $form->populateValues($formData);

        $htmlViewPart = new ViewModel();
        $htmlViewPart//->setTerminal(true)
            ->setTemplate('application/poi/show-' . $poiType)
            ->setVariables(['form' => $form, 'poiType' => $poiType, 'languageList' => $projectLanguages, 'mediaFiles' => $mediaFiles]);

        // render the content
        $htmlOutput = $this->renderer->render($htmlViewPart);

        // build and return JSON
        $jsonModel = new JsonModel();
        $jsonModel->setVariables([
            'success' => true,
            'html'    => $htmlOutput
        ]);

        return $jsonModel;
    }

    /**
     * Removes POI
     *
     * @todo add more strict control and return values from deletePoi() method
     *
     * @return JsonModel
     */
    public function deletePoiAjaxAction()
    {
        if (!$this->getRequest()->isPost())
            die('Only internal calls');

        $poiName = $this->params()->fromPost('poiName');

        $this->poiTable->deletePoiByName($poiName);

        // update tourdata.xml file
        $this->xmlWriter->writeTourDataFile();

        // build and return JSON
        $jsonModel = new JsonModel();
        $jsonModel->setVariables([
                                     'success' => true,
                                 ]);

        return $jsonModel;
    }

    /**
     * Saves POI data from POI editor - one POI at a time
     *
     * It also updates relevant XML files
     *
     * @return JsonModel
     */
    public function saveSinglePoiAjaxAction()
    {
        if (!$this->getRequest()->isPost())
            die('Only internal calls');

        // dump all data to an array
        $data = $this->getRequest()->getPost()->toArray();
        $poi = new Poi();
        $poi->exchangeArray($data);

        $poiSettings = $data;
        unset($poiSettings['id'], $poiSettings['type'], $poiSettings['atv'], $poiSettings['ath'], $poiSettings['panos_id'], $poiSettings['name'], $poiSettings['depth']);

        $poi->settings = Json::encode($poiSettings);

        $this->poiTable->savePoiByName($poi);

        // update tourdata.xml file
        $this->xmlWriter->writeTourDataFile();

        // build and return JSON
        $jsonModel = new JsonModel();
        $jsonModel->setVariables([
            'success' => true,
        ]);

        return $jsonModel;
    }

    /**
     * Keeps user session alive
     *
     * @return JsonModel
     */
    public function keepSessionAjaxAction()
    {
        // build and return JSON
        $jsonModel = new JsonModel();
        $jsonModel->setVariables([
                                     'success' => true,
                                 ]);

        return $jsonModel;
    }
}
