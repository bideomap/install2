<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Controller;


use Application\Form\ModulesForm;
use Application\Model\LanguagesTable;
use Application\Model\SettingsTable;
use Application\Model\Templates;
use Application\Model\VRMCommon;
use Application\Model\XmlWriter;
use Laminas\Filter\Decompress;
use Laminas\Json\Json;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\JsonModel;
use Laminas\View\Model\ViewModel;

class SettingsController extends AbstractActionController
{

    private $settingsTable;
    private $languagesTable;
    private $xmlWriter;

    public function __construct(SettingsTable $settingsTable, LanguagesTable $languagesTable, XmlWriter $xmlWriter)
    {
        $this->settingsTable = $settingsTable;
        $this->languagesTable = $languagesTable;
        $this->xmlWriter = $xmlWriter;
    }

    /**
     * Default action
     *
     * @return viewModel
     */
    public function indexAction()
    {

        // parse stickers
        $stickersDir = __DIR__ . '/../../../../../livepano';

        if (is_dir($stickersDir)) {
            $dirContents = array_diff(scandir($stickersDir), ['..', '.', 'livepano_data.xml']);

            $stickerFiles = [];

            foreach ($dirContents as $file) {
                $stickerFiles[] = pathinfo($stickersDir . DIRECTORY_SEPARATOR . $file, PATHINFO_FILENAME);
            }

            $stickerFiles = array_unique($stickerFiles);

            $stickersContents = '<krpano><stickergroup>
      <stic name="livepano" livepano="true" items="' . implode('|', $stickerFiles) . '" />
</stickergroup></krpano>';

            file_put_contents($stickersDir . DIRECTORY_SEPARATOR . 'livepano_data.xml', $stickersContents);
        }

        //get modules form
        $modulesForm = new ModulesForm();

        //get project languages
        $projectLanguages = $this->languagesTable->getLanguages(false)->toArray();

        $templateSettingsMapping = Templates::getTemplateSettingsMapping();

        //define files directory
        $mediaDir = __DIR__ . '/../../../../../media';

        $awsKeysGiven = false;

        $submission = false;
        if ($this->request->isPost()) {

            //get data
            $data = $this->getRequest()->getPost()->toArray();

            $modulesForm->setData($data);

            if (!isset($data['logo_remove'])) {
                $modulesForm->getInputFilter()->get('logo_remove')->setRequired(false);
            }

            if ($modulesForm->isValid()) {

                $globalModules = [];

                // map
                $globalModules['m_map'] = [
                    'aktyw' => (string)$data['m_map'],
                    'maptype' => $data['map_type'],
                    'distance' => $data['map_distance'],
                    'id' => $data['map_id'],
                ];

                // facebook
                $globalModules['m_facebook'] = [
                    'aktyw' => (string)$data['m_facebook'],
                    'id' => $data['facebook_id'],
                    'app_id' => $data['facebook_app']
                ];

                // analytics
                $globalModules['m_analytics'] = [
                    'aktyw' => (string)$data['m_analytics'],
                    'id' => $data['analytics_id']
                ];

                // logo
                $globalModules['m_logo'] = [
                    'aktyw' => (string)$data['m_logo'],
                    'id' => $data['logo_tooltip'],
                    'www' => $data['logo_www']
                ];

                // copyright
                $globalModules['m_copyright'] = [
                    'aktyw' => (string)$data['m_copyright'],
                    'id' => $data['copyright_id'],
                    'www' => $data['copyright_www']
                ];

                // privacy
                $this->settingsTable->set('m_privacy', (string)$data['m_privacy']);

                $globalModules['m_social'] = [
                    'aktyw' => (string)$data['m_social'],
                ];

                $globalModules['m_stickers'] = [
                    'aktyw' => (string)$data['m_stickers'],
                    'groups' => $data['stickers_groups'],
                ];

                $globalModules['m_infobox'] = [
                    'aktyw' => (string)$data['m_infobox'],
                ];

                $globalModules['m_keepview'] = [
                    'aktyw' => (string)$data['m_keepview'],
                ];

                $globalModules['m_arrowmode'] = [
                    'aktyw' => (string)$data['m_arrowmode'],
                ];

                $globalModules['m_radarmode'] = [
                    'aktyw' => (string)$data['m_radarmode'],
                ];

                $globalModules['m_floorplans'] = [
                    'aktyw' => (string)$data['m_floorplans'],
                ];

                $globalModules['m_autotour'] = [
                    'aktyw' => (string)$data['m_autotour'],
                    'speed' => (int)$data['autotour_speed'] !== 0 ? (int)$data['autotour_speed'] : 10,
                ];

                $globalModules['m_simple_content_menu'] = [
                    'aktyw' => (string)$data['m_simple_content_menu'],
                ];

                $globalModules['m_poi_settings'] = [
                    'poi_size' => isset($data['poi_size']) ? (int)$data['poi_size'] : 28,
                    'poi_css_size' => isset($data['poi_css_size']) ? (int)$data['poi_css_size'] : 18,
                    'poi_flip_color' => $data['poi_flip_color'] ?? 'false',
                    'poi_hide_popup_to_pano_vr' => $data['poi_hide_popup_to_pano_vr'] ?? 'false',
                    'poi_rotate' => isset($data['poi_rotate']) ? (int)$data['poi_rotate'] : 1,
                    'poi_roundedge' => isset($data['poi_roundedge']) ? (int)$data['poi_roundedge'] : 6,

                    'streetview_effect' => $data['poi_streetview_effect'] ?? 'true',
                    'static_panorama_preview' => $data['poi_static_panorama_preview'] ?? 'false',
                    'streetview_poimove_effect' => $data['poi_streetview_poimove_effect'] ?? '-0.3',
                    'block_moveto_poi' => $data['poi_block_moveto_poi'] ?? 'false',
                    'poi_hide_popup_to_pano_normal' => $data['poi_hide_popup_to_pano_normal'] ?? 'false',
                    'ignore_preview_custom_view' => $data['poi_ignore_preview_custom_view'] ?? 'false',
                    'auto_generate_poi_to_pano' => $data['poi_auto_generate_poi_to_pano'] ?? 'false',
                    'auto_generate_dollhouse_floor_poi' => $data['poi_auto_generate_dollhouse_floor_poi'] ?? 'false',
                    'label_background' => $data['poi_label_background'] ?? 'false',
                ];

                $globalModules['m_video_livepresenter'] = [
                    'aktyw' => (string)$data['m_video_livepresenter'],
                    'agora_app_id' => $data['video_livepresenter_agora_app_id'] ?? '',
                    'turn_server' => $data['video_livepresenter_turn_server'] ?? '',
                    'turn_username' => $data['video_livepresenter_turn_username'] ?? '',
                    'turn_password' => $data['video_livepresenter_turn_password'] ?? '',
                    'password' => $data['video_livepresenter_password'] ?? '',
                ];


                $globalModules['m_autodescription'] = [
                    'aktyw' => (string)$data['m_autodescription'],
                    'volume' => $data['autodescription_volume'] ?? 100,
                    'pitch' => $data['autodescription_pitch'] ?? 1,
                    'rate' => $data['autodescription_rate'] ?? 1,
                    'auto_read' => $data['autodescription_auto_read'] ?? 'false'
                ];

                $globalModules['m_nadir'] = [
                    'aktyw' => (string)$data['m_nadir'],
                    'id' => $data['nadir_tooltip'] ?? '',
                    'www' => $data['nadir_www'] ?? '',
                    'scale' => $data['nadir_scale'] ?? '',
                    'static' => $data['nadir_static'] ?? 'false',
                ];

                $this->settingsTable->set('global_modules', Json::encode($globalModules));

                //save template phrases
                $projectLangSettings = [];
                foreach ($data['project_settings_fs'] as $key => $value) {
                    $projectLangSettings[$value['language']] = [];
                    $projectLangSettings[$value['language']]['name'] = $value['name'];
                    $projectLangSettings[$value['language']]['description'] = $value['description'];
                    $projectLangSettings[$value['language']]['media_id'] = $value['media_id'];
                }
                $this->settingsTable->set('project_lang_settings', Json::encode($projectLangSettings));

                foreach ($data['privacy_fe_fs'] as $key => $value) {
                    if ($value['description'] && strip_tags($value['description']) !== '') {
                        $this->settingsTable->set('privacy_fe_' . $value['language'], $value['description']);
                    } else {
                        $this->settingsTable->set('privacy_fe_' . $value['language'], '');
                    }
                }

                foreach ($data['privacy_be_fs'] as $key => $value) {
                    if ($value['description'] && strip_tags($value['description']) !== '') {
                        $this->settingsTable->set('privacy_be_' . $value['language'], $value['description']);
                    } else {
                        $this->settingsTable->set('privacy_be_' . $value['language'], '');
                    }
                }


                // save other settings
                $this->settingsTable->set('primary_color', $data['primary_color']);
                $this->settingsTable->set('secondary_color', $data['secondary_color']);
                $this->settingsTable->set('force_ssl', $data['force_ssl']);

                if ($data['aws_access_key']) {
                    $this->settingsTable->set('aws_access_key', $data['aws_access_key']);
                    $modulesForm->get('aws_access_key')->setValue('');
                }

                if ($data['aws_secret_key']) {
                    $this->settingsTable->set('aws_secret_key', $data['aws_secret_key']);
                    $modulesForm->get('aws_secret_key')->setValue('');
                }

                if ($this->settingsTable->get('aws_access_key') && $this->settingsTable->get('aws_secret_key')) {
                    $awsKeysGiven = true;
                }

                $this->settingsTable->set('template', $data['template']);

                $files = $this->getRequest()->getFiles()->toArray();

                // logo
                if (isset($files['logo_file'])) {
                    $file = $files['logo_file'];
                    if ($file['error'] === UPLOAD_ERR_OK) {
                        $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

                        //create media directory if not present
                        if (!is_dir($mediaDir)) {
                            mkdir($mediaDir, 0777, true);
                        }

                        //save file in temporary folder
                        $imageTemporaryDir = $mediaDir . '/logo.' . $fileExtension;
                        move_uploaded_file($file['tmp_name'], $imageTemporaryDir);

                        //create thumb for logo
                        $thumbImage = $mediaDir . '/logo_thumb.' . $fileExtension;
                        VRMCommon::resizeImage($imageTemporaryDir, $thumbImage, GALLERY_WIDTH, GALLERY_HEIGHT, 'contain');

                        $this->settingsTable->set('project_logo', 'logo.' . $fileExtension);
                    }
                }

                if (isset($data['logo_remove']) && (int)$data['logo_remove'] === 1) {
                    $currentLogo = $this->settingsTable->get('project_logo');
                    $fileExtension = strtolower(pathinfo($currentLogo, PATHINFO_EXTENSION));
                    @unlink($mediaDir . '/logo_thumb.' . $fileExtension);
                    @unlink($mediaDir . '/logo.' . $fileExtension);
                    $this->settingsTable->remove('project_logo');
                }

                // nadir
                if (isset($files['nadir_file'])) {
                    $file = $files['nadir_file'];
                    if ($file['error'] === UPLOAD_ERR_OK) {
                        $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

                        //create media directory if not present
                        if (!is_dir($mediaDir)) {
                            mkdir($mediaDir, 0777, true);
                        }

                        //save file in temporary folder
                        $imageTemporaryDir = $mediaDir . '/nadir.' . $fileExtension;
                        move_uploaded_file($file['tmp_name'], $imageTemporaryDir);

                        //create thumb for nadir
                        $thumbImage = $mediaDir . '/nadir_thumb.' . $fileExtension;
                        VRMCommon::resizeImage($imageTemporaryDir, $thumbImage, GALLERY_WIDTH, GALLERY_HEIGHT, 'contain');

                        $this->settingsTable->set('nadir_logo', 'nadir.' . $fileExtension);
                    }
                }

                // template
                if (isset($files['new_template'])) {
                    $file = $files['new_template'];
                    if ($file['error'] === UPLOAD_ERR_OK) {
                        $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

                        if ($fileExtension == 'zip') {
                            $templatesDir = __DIR__ . '/../../../../../skin/templates';

                            //create templates directory if not present
                            if (!is_dir($templatesDir)) {
                                mkdir($templatesDir, 0777, true);
                            }

                            //save file in temporary folder
                            $templateTemporaryFile = $templatesDir . '/' . uniqid() . '.zip';
                            move_uploaded_file($file['tmp_name'], $templateTemporaryFile);

                            // extract ZIP archive in place
                            $filter = new Decompress([
                                                         'adapter' => 'Zip',
                                                         'options' => [
                                                             'target' => $templatesDir,
                                                         ]
                                                     ]);
                            $filter->filter($templateTemporaryFile);
                            unlink($templateTemporaryFile);
                        }
                    }
                }

                // update tourdata.xml file
                $this->xmlWriter->writeTourDataFile();

                $submission = 1;

            } else {
                $submission = 'error';
            }

        } else {
            // populate form values from the database
            $templateSettings = Json::decode($this->settingsTable->get('global_modules'), Json::TYPE_ARRAY);
            if ($templateSettings) {
                foreach ($templateSettings as $module => $settings) {
                    // visibility
                    if (isset($settings['aktyw'])) {
                        $modulesForm->get($module)->setValue($settings['aktyw']);
                    }
                }
            }

            $modulesForm->get('m_privacy')->setValue($this->settingsTable->get('m_privacy'));

            // custom settings
            $modulesForm->get('map_type')->setValue($templateSettings['m_map']['maptype']);
            $modulesForm->get('map_distance')->setValue($templateSettings['m_map']['distance']);
            $modulesForm->get('map_id')->setValue($templateSettings['m_map']['id']);

            $modulesForm->get('facebook_id')->setValue($templateSettings['m_facebook']['id']);
            $modulesForm->get('facebook_app')->setValue($templateSettings['m_facebook']['app_id']);

            $modulesForm->get('m_video_livepresenter')->setValue($templateSettings['m_video_livepresenter']['aktyw'] ?? '');
            $modulesForm->get('video_livepresenter_agora_app_id')->setValue($templateSettings['m_video_livepresenter']['agora_app_id'] ?? '');
            $modulesForm->get('video_livepresenter_turn_server')->setValue($templateSettings['m_video_livepresenter']['turn_server'] ?? '');
            $modulesForm->get('video_livepresenter_turn_username')->setValue($templateSettings['m_video_livepresenter']['turn_username'] ?? '');
            $modulesForm->get('video_livepresenter_turn_password')->setValue($templateSettings['m_video_livepresenter']['turn_password'] ?? '');
            $modulesForm->get('video_livepresenter_password')->setValue($templateSettings['m_video_livepresenter']['password'] ?? '');

            $modulesForm->get('m_autodescription')->setValue($templateSettings['m_autodescription']['aktyw'] ?? '');
            $modulesForm->get('autodescription_volume')->setValue($templateSettings['m_autodescription']['volume'] ?? 100);
            $modulesForm->get('autodescription_pitch')->setValue($templateSettings['m_autodescription']['pitch'] ?? 1);
            $modulesForm->get('autodescription_rate')->setValue($templateSettings['m_autodescription']['rate'] ?? 1);
            $modulesForm->get('autodescription_auto_read')->setValue($templateSettings['m_autodescription']['auto_read'] ?? 'false');

            $modulesForm->get('m_nadir')->setValue($templateSettings['m_nadir']['aktyw'] ?? '');
            $modulesForm->get('nadir_www')->setValue($templateSettings['m_nadir']['www'] ?? '');
            $modulesForm->get('nadir_tooltip')->setValue($templateSettings['m_nadir']['id'] ?? '');
            $modulesForm->get('nadir_scale')->setValue($templateSettings['m_nadir']['scale'] ?? 1);
            $modulesForm->get('nadir_static')->setValue($templateSettings['m_nadir']['static'] ?? 'false');

            $modulesForm->get('analytics_id')->setValue($templateSettings['m_analytics']['id']);

            $modulesForm->get('logo_tooltip')->setValue($templateSettings['m_logo']['id']);
            $modulesForm->get('logo_www')->setValue($templateSettings['m_logo']['www']);

            $modulesForm->get('copyright_id')->setValue($templateSettings['m_copyright']['id']);
            $modulesForm->get('copyright_www')->setValue($templateSettings['m_copyright']['www']);

            $modulesForm->get('stickers_groups')->setValue($templateSettings['m_stickers']['groups']);

            $primaryColor = $this->settingsTable->get('primary_color') ? $this->settingsTable->get('primary_color') : '#006bbe';
            $secondaryColor = $this->settingsTable->get('secondary_color') ? $this->settingsTable->get('secondary_color') : '#ffffff';
            $forceSSL = $this->settingsTable->get('force_ssl') ? $this->settingsTable->get('force_ssl') : 0;

            $modulesForm->get('primary_color')->setValue($primaryColor);
            $modulesForm->get('secondary_color')->setValue($secondaryColor);
            $modulesForm->get('force_ssl')->setValue($forceSSL);

            $modulesForm->get('autotour_speed')->setValue($templateSettings['m_autotour']['speed'] ?? 10);

            $modulesForm->get('poi_size')->setValue($templateSettings['m_poi_settings']['poi_size'] ?? 28);
            $modulesForm->get('poi_css_size')->setValue($templateSettings['m_poi_settings']['poi_css_size'] ?? 18);
            $modulesForm->get('poi_flip_color')->setValue($templateSettings['m_poi_settings']['poi_flip_color'] ?? 'false');
            $modulesForm->get('poi_hide_popup_to_pano_vr')->setValue($templateSettings['m_poi_settings']['poi_hide_popup_to_pano_vr'] ?? 'false');
            $modulesForm->get('poi_rotate')->setValue($templateSettings['m_poi_settings']['poi_rotate'] ?? 1);
            $modulesForm->get('poi_roundedge')->setValue($templateSettings['m_poi_settings']['poi_roundedge'] ?? 6);

            $modulesForm->get('poi_streetview_effect')->setValue($templateSettings['m_poi_settings']['streetview_effect'] ?? 'true');
            $modulesForm->get('poi_static_panorama_preview')->setValue($templateSettings['m_poi_settings']['static_panorama_preview'] ?? 'false');
            $modulesForm->get('poi_streetview_poimove_effect')->setValue($templateSettings['m_poi_settings']['streetview_poimove_effect'] ?? -0.3);
            $modulesForm->get('poi_block_moveto_poi')->setValue($templateSettings['m_poi_settings']['block_moveto_poi'] ?? 'false');
            $modulesForm->get('poi_hide_popup_to_pano_normal')->setValue($templateSettings['m_poi_settings']['poi_hide_popup_to_pano_normal'] ?? 'false');
            $modulesForm->get('poi_ignore_preview_custom_view')->setValue($templateSettings['m_poi_settings']['ignore_preview_custom_view'] ?? 'false');
            $modulesForm->get('poi_auto_generate_poi_to_pano')->setValue($templateSettings['m_poi_settings']['auto_generate_poi_to_pano'] ?? 'false');
            $modulesForm->get('poi_auto_generate_dollhouse_floor_poi')->setValue($templateSettings['m_poi_settings']['auto_generate_dollhouse_floor_poi'] ?? 'false');
            $modulesForm->get('poi_label_background')->setValue($templateSettings['m_poi_settings']['label_background'] ?? 'false');

            if ($this->settingsTable->get('aws_access_key') && $this->settingsTable->get('aws_secret_key')) {
                $awsKeysGiven = true;
            }

            $modulesForm->get('template')->setValue($this->settingsTable->get('template'));

            // other global fields
            $projectLangData = Json::decode($this->settingsTable->get('project_lang_settings'), Json::TYPE_ARRAY);
            //create fieldsets
            $populateLanguageArray = [];
            $populatePrivacyFeLanguageArray = [];

            foreach ($projectLanguages as $key => $value) {
                $populateLanguageArray[$value['id']] = [
                    'language' => $value['short'],
                    'language_id' => $value['id'],
                    'name' => isset($projectLangData[$value['short']]['name']) ? $projectLangData[$value['short']]['name'] : '',
                    'description' => isset($projectLangData[$value['short']]['description']) ? $projectLangData[$value['short']]['description'] : '',
                    'media_id' => isset($projectLangData[$value['short']]['media_id']) ? $projectLangData[$value['short']]['media_id'] : '',
                ];
                $populatePrivacyFeLanguageArray[$value['id']] = [
                    'language' => $value['short'],
                    'language_id' => $value['id'],
                    'description' => $this->settingsTable->get('privacy_fe_' . $value['short'])
                ];
            }

            $systemLanguages = VRMCommon::getAvailableLanguages();

            $populatePrivacyBeLanguageArray = [];
            foreach ($systemLanguages as $systemLanguage) {
                $populatePrivacyBeLanguageArray[$systemLanguage] = [
                    'language' => $systemLanguage,
                    'language_id' => $systemLanguage,
                    'description' => $this->settingsTable->get('privacy_be_' . $systemLanguage)
                ];
            }
            $modulesForm->populateValues(['project_settings_fs' => $populateLanguageArray, 'privacy_fe_fs' => $populatePrivacyFeLanguageArray, 'privacy_be_fs' => $populatePrivacyBeLanguageArray]);

        }

        $projectLogo = $this->settingsTable->get('project_logo');
        $templatesList = $this->getAvailableTemplates();
        $currentTemplate = $this->settingsTable->get('template');
        $currentVersion = $this->settingsTable->get('version');

        if (!$currentVersion) {
            $currentVersion = '1.0.0';
        }

        // check if shell_exec is available
        @shell_exec('chmod +x ' . __DIR__ . '/../../../../data/bin/krpano/krpanotools');
        $shellExec = trim(@shell_exec(__DIR__ . '/../../../../data/bin/krpano/krpanotools')) !== '';
        $this->settingsTable->set('shellExec_enabled', (int)$shellExec);

        // check krpano registration
        if ($shellExec) {
            $regInfo = trim(@shell_exec(__DIR__ . '/../../../../data/bin/krpano/krpanotools register show'));
            if ($regInfo === 'Not registered.') {
                $_SESSION['krpanoRegError'] = true;
            }
        }

        // stickers from template
        $templateStickersDir = __DIR__ . '/../../../../../skin/templates/' . $currentTemplate . '/modules/img/stickers';
        $templateStickers = array_diff(scandir($templateStickersDir), ['..', '.', 'settings.xml']);

        $templateStickersGroups = [];

        foreach ($templateStickers as $dir) {
            $files = array_diff(scandir($templateStickersDir . DIRECTORY_SEPARATOR . $dir), ['..', '.']);
            $items = [];
            foreach ($files as $file) {
                $items[] = pathinfo($file, PATHINFO_FILENAME);
            }
            $templateStickersGroups[] = '<stic name="' . $dir . '" items="' . implode('|', $items) . '" />';
        }

        $stickersContents = '<krpano>' . PHP_EOL . '<stickergroup>' . PHP_EOL . implode(PHP_EOL, $templateStickersGroups) . PHP_EOL . '</stickergroup>' . PHP_EOL . '</krpano>';
        file_put_contents($templateStickersDir . DIRECTORY_SEPARATOR . 'settings.xml', $stickersContents);

        return new ViewModel([
                                 'templateSettingsMapping' => $templateSettingsMapping,
                                 'form'                    => $modulesForm,
                                 'languageList'            => $projectLanguages,
                                 'projectLogo'             => $projectLogo,
                                 'submission'              => $submission,
                                 'templatesList'           => $templatesList,
                                 'currentTemplate'         => $currentTemplate,
                                 'awsKeysGiven'            => $awsKeysGiven,
                                 'currentVersion'          => $currentVersion,
                                 'templateStickers'        => $templateStickers
                             ]);
    }

    /**
     * Scans the directory and gets available templates
     *
     * @return array
     */
    private function getAvailableTemplates()
    {
        $templates = [];
        $templatesDir = __DIR__ . '/../../../../../skin/templates/';

        foreach(glob($templatesDir . '*', GLOB_ONLYDIR) as $dir) {
            $xmlFile = $dir . DIRECTORY_SEPARATOR . 'settings.xml';
            if (!file_exists($xmlFile)) {
                continue;
            }
            $xmlDetails = \simplexml_load_file($xmlFile);
            $templateName = (string)$xmlDetails->xpath('template')[0]->attributes()['name'];

            $templates[basename($dir)] = $templateName;
        }

        return $templates;
    }

    /**
     * Saves in the database the mark for the user that agrees with backend privacy message
     *
     * @return JsonModel
     */
    public function markPrivacyAsSeenAjaxAction()
    {
        $userId = $this->userInfo()->getUser()->id;
        $this->settingsTable->set('privacy_seen_' . $userId, 1);

        return new JsonModel(['success' => true]);
    }

}
