<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Controller;

use Application\Form\SitePlanForm;
use Application\Model\CategoriesTable;
use Application\Model\LanguagesTable;
use Application\Model\PanoCMSCommon;
use Application\Model\PanoSitePlansConnections;
use Application\Model\PanoSitePlansConnectionsTable;
use Application\Model\PanosTable;
use Application\Model\SettingsTable;
use Application\Model\SitePlans;
use Application\Model\SitePlansPhrases;
use Application\Model\SitePlansPhrasesTable;
use Application\Model\SitePlansTable;
use Application\Model\VRMCommon;
use Application\Model\XmlWriter;
use Laminas\Json\Json;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\Mvc\MvcEvent;
use Laminas\View\Model\JsonModel;
use Laminas\View\Model\ViewModel;

/**
 * Class SitePlansController
 *
 * @package Project\Controller
 */
class SitePlansController extends AbstractActionController
{

    private $sitePlansTable;
    private $panoSitePlansConnectionsTable;
    private $panosTable;
    private $languagesTable;
    private $sitePlansPhrasesTable;
    private $xmlWriter;
    private $categoriesTable;
    private $settingsTable;

    public function __construct(SitePlansTable $sitePlansTable, PanoSitePlansConnectionsTable $panoSitePlansConnectionsTable, PanosTable $panosTable, LanguagesTable $languagesTable, SitePlansPhrasesTable $sitePlansPhrasesTable, XmlWriter $xmlWriter, CategoriesTable $categoriesTable, SettingsTable $settingsTable)
    {
        $this->sitePlansTable = $sitePlansTable;
        $this->panoSitePlansConnectionsTable = $panoSitePlansConnectionsTable;
        $this->panosTable = $panosTable;
        $this->languagesTable = $languagesTable;
        $this->sitePlansPhrasesTable = $sitePlansPhrasesTable;
        $this->xmlWriter = $xmlWriter;
        $this->categoriesTable = $categoriesTable;
        $this->settingsTable = $settingsTable;
    }

    /**
     * Users on medium plan are not allowed to use this module
     *
     * @param MvcEvent $e
     * @return \Laminas\Http\Response
     */
    public function onDispatch(MvcEvent $e)
    {
        $cmsDevVersion = $this->userInfo()->getCmsDevVersion();
        if ($cmsDevVersion == 'medium') {
            return $this->redirect()->toRoute('vrm', [
                'controller' => 'index',
                'action'     => 'index'
            ]);
        }

        return parent::onDispatch($e);
    }

    /**
     * Default action - returns category list
     *
     * @return viewModel
     */
    public function indexAction()
    {

        $sitePlansList = $this->sitePlansTable->getPlans();

        return new ViewModel(['sitePlansList' => $sitePlansList]);
    }

    /**
     * Edit action - edit existing category or save new one
     *
     */
    public function editAction()
    {
        // build a form
        $sitePlanForm = new SitePlanForm();

        // get site plan id from route
        $sitePlanId = $this->params()->fromRoute('id', false);

        //get main site plans dir
        $mainDir = __DIR__ . '/../../../../../floorplans/';

        $projectLanguages = $this->languagesTable->getLanguages(false)->toArray();

        // the user clicked "save", let's proceed
        if ($this->request->isPost()) {

            // dump all data to an array and bind them to the form
            $data = $this->getRequest()->getPost()->toArray();

            //get files
            $files = $this->getRequest()->getFiles()->toArray();

            //remove validation for already existing site plans
            if ($sitePlanId) {
                $sitePlanForm->getInputFilter()->remove('image');
            }

            $formValidate = $sitePlanForm->setData(array_merge($data, $files));

            if ($formValidate->isValid()) {

                //create array to save
                $sitePlanTableData = [
                    'id'            => $data['id'],
                ];

                //save category ang get id
                $sitePlan = new SitePlans();
                $sitePlan->exchangeArray($sitePlanTableData);
                $sitePlanId = $this->sitePlansTable->save($sitePlan);

                //create category dir if not exists
                if (!is_dir($mainDir)) {
                    mkdir($mainDir, 0777, true);
                }

                //save thumbnail
                if (!empty($files['image'])) {
                    //get thumbnail extension
                    $ext = strtolower(pathinfo($files['image']['name'], PATHINFO_EXTENSION));

                    //create paths for files
                    $dest_image = $mainDir . 's' . $sitePlanId . '.' . $ext;
                    $thumb = $mainDir . 's' . $sitePlanId . '-thumb.jpg';

                    //move file to temporary directory
                    move_uploaded_file($_FILES['image']['tmp_name'], $dest_image);

                    /*if ($ext != 'jpg' && $ext != 'jpeg') {
                        VRMCommon::convertToJpg($dest_image, $ext);
                    }*/

                    VRMCommon::resizeImage($dest_image, $thumb, CAT_WIDTH * 2, CAT_HEIGHT * 2, 'cover');

                    $sitePlanExt = new SitePlans();
                    $sitePlanExt->exchangeArray([
                        'id'            => $sitePlanId,
                        'extension'     => $ext
                    ]);
                    $this->sitePlansTable->save($sitePlanExt);

                }

                // save names
                if (!empty($data['site_plan_fs'])) {
                    foreach ($data['site_plan_fs'] as $key => $value) {

                        // create array for data exchange
                        $phrasesTableData = [
                            'id'            => ($value['id'] > 0 ? $value['id'] : null),
                            'site_plans_id' => $sitePlanId,
                            'languages_id'  => $value['language_id'],
                            'name'          => $value['name'],
                        ];

                        // save site plan category phrases for each project language
                        $phrase = new SitePlansPhrases();
                        $phrase->exchangeArray($phrasesTableData);
                        $this->sitePlansPhrasesTable->save($phrase);
                    }
                }

                // update tourdata.xml file
                $this->xmlWriter->writeTourDataFile();


                $this->flashMessenger()->addSuccessMessage(true);

                //redirect to category list after saving form
                return $this->redirect()->toRoute('vrm', [
                    'controller' => 'sitePlans',
                    'action'     => 'index'
                ]);
            }


        } else {
            //if user is opening existing category set data to fields
            $sitePlanData = [];
            if ($sitePlanId) {

                $sitePlanForm->get('id')->setValue($sitePlanId);

                $sitePlanData = $this->sitePlansTable->getByIdWithLanguages($sitePlanId);
            }

            // check if all languages are included
            foreach ($projectLanguages as $key => $value) {
                if (!isset($sitePlanData['site_plan_fs'][$value['id']])) {
                    $sitePlanData['site_plan_fs'][$value['id']] =
                        ['language' => $value['short'], 'language_id' => $value['id']];
                }
            }

            // populate values
            $sitePlanForm->populateValues($sitePlanData);

        }

        $panosList = $this->panosTable->getPanoList();
        $existingConnections = $this->panoSitePlansConnectionsTable->getConnectionsBySitePlan($sitePlanId);

        $allowedCategories = $this->categoriesTable->getCategories($this->userInfo()->allowedCategories());
        $allowedCategoriesList = [];
        foreach ($allowedCategories as $allowedCategoryId => $allowedCategory) {
            $allowedCategoriesList[] = 'cat_' . $allowedCategoryId;
        }

        $modulesSettings = Json::decode($this->settingsTable->get('global_modules'));
        $googleMapAPIKey = isset($modulesSettings->m_map->id) ? $modulesSettings->m_map->id : '';

        return new ViewModel([
                                 'sitePlanId'        => $sitePlanId,
                                 'extension'         => isset($sitePlanData['extension']) ? $sitePlanData['extension'] : '',
                                 'form'              => $sitePlanForm,
                                 'panosList'         => $panosList,
                                 'existingConnections' => $existingConnections,
                                 'languageList' => $projectLanguages,
                                 'allowedCategories' => implode('|', $allowedCategoriesList),
                                 'template' => $this->settingsTable->get('template'),
                                 'googleMapAPIKey' => $googleMapAPIKey,
                                 'defaultProjectLanguageId' => $this->languagesTable->getByShort($this->settingsTable->get('default_language'))
                             ]);

    }

    /**
     * Delete floorplan ajax action
     *
     * @return viewModel
     */
    public function deleteSitePlanAjaxAction()
    {
        //get floorplan id
        $sitePlanId = $this->params()->fromPost('sitePlanId', false);

        $success = false;

        if ($sitePlanId) {

            //remove data from database
            $this->sitePlansTable->deleteById($sitePlanId);
            $this->panoSitePlansConnectionsTable->deleteBySitePlanId($sitePlanId);

            //get category path
            $mainDir = __DIR__ . '/../../../../../floorplans/';

            @unlink($mainDir . 's' . $sitePlanId . '.jpg');
            @unlink($mainDir . 's' . $sitePlanId . '-thumb.jpg');

            // update tourdata.xml file
            $this->xmlWriter->writeTourDataFile();

            $success = true;

        }

        //return json model
        $result = new JsonModel([
                                    'success' => $success
                                ]);

        return $result;
    }

    /**
     * Saves connection data between site plan and pano
     *
     * @return JsonModel
     */
    public function saveSitePlanConnectionAjaxAction()
    {
        if (!$this->getRequest()->isPost())
            die('Only internal calls');

        $data = $this->getRequest()->getPost()->toArray();

        $connection = new PanoSitePlansConnections();
        $connection->id = $data['id'];
        // do not update panos_id for drag and drop actions
        if (isset($data['panoId']) && $data['panoId'] != false) {
            $connection->panos_id = $data['panoId'];
        }
        $connection->site_plans_id = $data['sitePlanId'];
        $connection->coordinates = round($data['x']) . ',' . round($data['y']);

        $connectionId = $this->panoSitePlansConnectionsTable->save($connection);

        // update tourdata.xml file
        $this->xmlWriter->writeTourDataFile();

        //return json model
        $result = new JsonModel([
                                    'success' => true,
                                    'id' => $connectionId
                                ]);

        return $result;
    }

    /**
     * Triggers removal of an existing connection
     *
     * @return JsonModel
     */
    public function deleteSitePlanConnectionAjaxAction()
    {
        if (!$this->getRequest()->isPost())
            die('Only internal calls');

        $data = $this->getRequest()->getPost()->toArray();

        $this->panoSitePlansConnectionsTable->deleteById($data['id']);

        // update tourdata.xml file
        $this->xmlWriter->writeTourDataFile();

        //return json model
        $result = new JsonModel([
                                    'success' => true
                                ]);

        return $result;
    }

    /**
     * Sets scale for given site plan
     *
     * @return JsonModel
     */
    public function updateScaleAjaxAction()
    {
        if (!$this->getRequest()->isPost())
            die('Only internal calls');

        $data = $this->getRequest()->getPost()->toArray();

        $this->sitePlansTable->updateScale($data['planId'], $data['scale']);

        // update tourdata.xml file
        $this->xmlWriter->writeTourDataFile();

        //return json model
        return new JsonModel([
            'success' => true
        ]);
    }
}
