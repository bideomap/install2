<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Factory;

use Application\Controller\AdministrationController;
use Application\Controller\CategoriesController;
use Application\Model\CategoriesTable;
use Application\Model\CategoryPhrasesTable;
use Application\Model\LanguagesTable;
use Application\Model\PanoCategoryConnectionsTable;
use Application\Model\PanosTable;
use Application\Model\SettingsTable;
use Application\Model\UserTable;
use Application\Model\XmlWriter;
use Application\Service\UserManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;

class AdministrationControllerFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        $staticDbAdapter = $container->get('Laminas\Db\Adapter\Adapter');
        $userTable = $container->get(UserTable::class);
        $userManager = $container->get(UserManager::class);
        $categoriesTable = $container->get(CategoriesTable::class);
        $settingsTable = $container->get(SettingsTable::class);
        $xmlWriter = $container->get(XmlWriter::class);

        return new AdministrationController($staticDbAdapter, $userTable, $userManager, $categoriesTable, $settingsTable, $xmlWriter);
    }
}
