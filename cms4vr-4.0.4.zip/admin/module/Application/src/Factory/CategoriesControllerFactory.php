<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Factory;

use Application\Controller\CategoriesController;
use Application\Model\CategoriesTable;
use Application\Model\CategoryPhrasesTable;
use Application\Model\LanguagesTable;
use Application\Model\PanoCategoryConnectionsTable;
use Application\Model\PanosTable;
use Application\Model\XmlWriter;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;

class CategoriesControllerFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        $panosTable = $container->get(PanosTable::class);
        $languagesTable = $container->get(LanguagesTable::class);
        $categoriesTable = $container->get(CategoriesTable::class);
        $categoryPhrasesTable = $container->get(CategoryPhrasesTable::class);
        $panoCategoryConnectionsTable = $container->get(PanoCategoryConnectionsTable::class);
        $xmlWriter = $container->get(XmlWriter::class);

        return new CategoriesController($categoriesTable, $categoryPhrasesTable, $panoCategoryConnectionsTable, $languagesTable, $panosTable, $xmlWriter);
    }
}
