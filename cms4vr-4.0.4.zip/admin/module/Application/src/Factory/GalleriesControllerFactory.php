<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Factory;

use Application\Controller\GalleriesController;
use Application\Model\GalleriesTable;
use Application\Model\GalleryPhrasesTable;
use Application\Model\LanguagesTable;
use Application\Model\MediaGalleriesConnectionsTable;
use Application\Model\XmlWriter;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use Laminas\View\Renderer\PhpRenderer;

class GalleriesControllerFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        $galleriesTable = $container->get(GalleriesTable::class);
        $galleryPhrasesTable = $container->get(GalleryPhrasesTable::class);
        $languagesTable = $container->get(LanguagesTable::class);
        $mediaGalleriesConnectionsTable = $container->get(MediaGalleriesConnectionsTable::class);
        $renderer = $container->get(PhpRenderer::class);
        $xmlWriter = $container->get(XmlWriter::class);

        return new GalleriesController($galleriesTable, $galleryPhrasesTable, $languagesTable, $mediaGalleriesConnectionsTable, $renderer, $xmlWriter);
    }
}
