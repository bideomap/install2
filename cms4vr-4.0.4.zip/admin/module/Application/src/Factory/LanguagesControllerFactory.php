<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Factory;

use Application\Controller\LanguagesController;
use Application\Model\LanguagesTable;
use Application\Model\SettingsTable;
use Application\Model\XmlWriter;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;

class LanguagesControllerFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {

        $languagesTable = $container->get(LanguagesTable::class);
        $xmlWriter = $container->get(XmlWriter::class);
        $settingsTable = $container->get(SettingsTable::class);

        return new LanguagesController($languagesTable, $xmlWriter, $settingsTable);
    }
}
