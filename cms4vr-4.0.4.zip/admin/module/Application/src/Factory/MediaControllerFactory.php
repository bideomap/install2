<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Factory;

use Application\Controller\MediaController;
use Application\Model\MediaTable;
use Application\Model\PoiTable;
use Application\Model\SettingsTable;
use Application\Model\XmlWriter;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use Laminas\View\Renderer\PhpRenderer;

class MediaControllerFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        $renderer = $container->get(PhpRenderer::class);
        $mediaTable = $container->get(MediaTable::class);
        $settingsTable = $container->get(SettingsTable::class);
        $poiTable = $container->get(PoiTable::class);
        $xmlWriter = $container->get(XmlWriter::class);

        return new MediaController($renderer, $mediaTable, $settingsTable, $poiTable, $xmlWriter);
    }
}
