<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Factory;

use Application\Controller\PanoController;
use Application\Model\CategoriesTable;
use Application\Model\GalleriesTable;
use Application\Model\LanguagesTable;
use Application\Model\MediaTable;
use Application\Model\PanoCategoryConnectionsTable;
use Application\Model\PanoPhrasesTable;
use Application\Model\PanoSitePlansConnectionsTable;
use Application\Model\PanosTable;
use Application\Model\SettingsTable;
use Application\Model\ShortlinkTable;
use Application\Model\SitePlansTable;
use Application\Model\XmlWriter;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use Laminas\View\Renderer\PhpRenderer;

class PanoControllerFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        $staticDbAdapter = $container->get('Laminas\Db\Adapter\Adapter');
        $panosTable = $container->get(PanosTable::class);
        $languagesTable = $container->get(LanguagesTable::class);
        $panoPhrasesTable = $container->get(PanoPhrasesTable::class);
        $categoriesTable = $container->get(CategoriesTable::class);
        $galleriesTable = $container->get(GalleriesTable::class);
        $panoCategoryConnectionsTable = $container->get(PanoCategoryConnectionsTable::class);
        $sitePlans = $container->get(SitePlansTable::class);
        $panoSitePlansConnectionsTable = $container->get(PanoSitePlansConnectionsTable::class);
        $xmlWriter = $container->get(XmlWriter::class);
        $settingsTable = $container->get(SettingsTable::class);
        $shortlinkTable = $container->get(ShortlinkTable::class);
        $mediaTable = $container->get(MediaTable::class);
        $renderer = $container->get(PhpRenderer::class);

        return new PanoController($staticDbAdapter, $panosTable, $languagesTable, $panoPhrasesTable, $categoriesTable, $galleriesTable, $panoCategoryConnectionsTable, $sitePlans, $panoSitePlansConnectionsTable, $xmlWriter, $settingsTable, $shortlinkTable, $mediaTable, $renderer);
    }
}
