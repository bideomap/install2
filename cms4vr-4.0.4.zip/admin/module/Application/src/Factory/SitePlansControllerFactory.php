<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Factory;

use Application\Controller\SitePlansController;
use Application\Model\CategoriesTable;
use Application\Model\LanguagesTable;
use Application\Model\PanoSitePlansConnectionsTable;
use Application\Model\PanosTable;
use Application\Model\SettingsTable;
use Application\Model\SitePlansPhrasesTable;
use Application\Model\SitePlansTable;
use Application\Model\XmlWriter;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;

class SitePlansControllerFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        $sitePlansTable = $container->get(SitePlansTable::class);
        $panoSitePlanConnectionsTable = $container->get(PanoSitePlansConnectionsTable::class);
        $panosTable = $container->get(PanosTable::class);
        $languagesTable = $container->get(LanguagesTable::class);
        $sitePlansPhrasesTable = $container->get(SitePlansPhrasesTable::class);
        $xmlWriter = $container->get(XmlWriter::class);
        $categoriesTable = $container->get(CategoriesTable::class);
        $settingsTable = $container->get(SettingsTable::class);

        return new SitePlansController($sitePlansTable, $panoSitePlanConnectionsTable, $panosTable, $languagesTable, $sitePlansPhrasesTable, $xmlWriter, $categoriesTable, $settingsTable);
    }
}
