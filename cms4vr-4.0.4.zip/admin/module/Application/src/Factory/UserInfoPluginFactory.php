<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Factory;

use Application\Controller\Plugin\UserInfoPlugin;
use Application\Model\SettingsTable;
use Application\Model\UserTable;
use Interop\Container\ContainerInterface;
use Laminas\Authentication\AuthenticationService;
use Laminas\ServiceManager\Factory\FactoryInterface;

class UserInfoPluginFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        $userTable = $container->get(UserTable::class);
        $authenticationService = $container->get(AuthenticationService::class);
        $settingsTable = $container->get(SettingsTable::class);

        return new UserInfoPlugin($userTable, $authenticationService, $settingsTable);
    }
}
