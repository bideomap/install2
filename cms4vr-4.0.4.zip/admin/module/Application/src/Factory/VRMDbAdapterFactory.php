<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Factory;

use Interop\Container\ContainerInterface;
use Laminas\Db\Adapter\Adapter;
use Laminas\ServiceManager\Factory\FactoryInterface;

/**
 * Custom Adapter Factory that triggers initial foreign keys support for SQlite database
 */
class VRMDbAdapterFactory implements FactoryInterface
{
    /**
     * Prepares the service and enables foreign key support
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return Adapter
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        $config = $container->get('config');
        $dbAdapter = new Adapter($config['db']);
        $dbAdapter->query('PRAGMA foreign_keys = ON');
        return $dbAdapter;
    }
}
