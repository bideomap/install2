<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Factory;

use Application\Model\UserTable;
use Application\Model\VRMCommon;
use Interop\Container\ContainerInterface;
use Laminas\Authentication\AuthenticationService;
use Laminas\ServiceManager\Factory\DelegatorFactoryInterface;

class VRMTranslatorFactory implements DelegatorFactoryInterface
{
    public function __invoke(ContainerInterface $container, $name, callable $callback, array $options = null)
    {
        $translator = call_user_func($callback);

        $authService = $container->get(AuthenticationService::class);

        $userTable = $container->get(UserTable::class);

        $userLang = '';

        if ($authService->hasIdentity()) {
            $user = $userTable->getUserByLogin($authService->getIdentity());
            $userLang = $user->language != '' ? $user->language : '';
        }


        $browserLang = $_SERVER["HTTP_ACCEPT_LANGUAGE"];
        $browserLang = explode(',', $browserLang)[0];

        $availableLanguages = VRMCommon::getAvailableLanguages();

        // try to set the language selected by user
        if ($userLang != '' && in_array($userLang, $availableLanguages)) {
            $translator->setLocale($userLang);
        } elseif (in_array($browserLang, $availableLanguages)) {
            $translator->setLocale($userLang);
        } else {
            $translator->setLocale('en');
        }

        return $translator;
    }
}
