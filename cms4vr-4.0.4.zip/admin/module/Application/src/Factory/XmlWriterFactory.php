<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Factory;

use Application\Model\CategoriesTable;
use Application\Model\GalleriesTable;
use Application\Model\GamificationTable;
use Application\Model\LanguagesTable;
use Application\Model\MediaTable;
use Application\Model\PanosTable;
use Application\Model\SettingsTable;
use Application\Model\SitePlansTable;
use Application\Model\XmlWriter;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;

class XmlWriterFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        $panosTable = $container->get(PanosTable::class);
        $categoriesTable = $container->get(CategoriesTable::class);
        $sitePlansTable = $container->get(SitePlansTable::class);
        $settingsTable = $container->get(SettingsTable::class);
        $galleriesTable = $container->get(GalleriesTable::class);
        $languagesTable = $container->get(LanguagesTable::class);
        $gamificationTable = $container->get(GamificationTable::class);
        $mediaTable = $container->get(MediaTable::class);

        return new XmlWriter(
            $panosTable,
            $categoriesTable,
            $sitePlansTable,
            $settingsTable,
            $galleriesTable,
            $languagesTable,
            $gamificationTable,
            $mediaTable
        );
    }
}
