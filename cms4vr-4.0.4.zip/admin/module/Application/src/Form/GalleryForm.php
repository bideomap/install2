<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;


use Laminas\Form\Element\File;
use Laminas\Form\Element\Hidden;
use Laminas\Form\Element\Select;
use Laminas\Form\Element\Text;
use Laminas\Form\Form;
use Laminas\InputFilter\Input;
use Laminas\InputFilter\InputFilter;
use Laminas\Validator\File\Extension;
use Laminas\Validator\NotEmpty;

class GalleryForm extends Form
{

    public function __construct()
    {
        parent::__construct('gallery-form');

        $this->add(new Hidden('id'));

        //add fieldset
        $galleryFS = new GalleryFieldsetForm();
        $this->add(array(
            'type' => 'Laminas\Form\Element\Collection',
            'name' => 'gallery_fs',
            'options' => array(
                'count' => 0,
                'should_create_template' => false,
                'allow_add' => true,
                'target_element' => $galleryFS
            ), 'attributes' => array(
                'id' => 'languageFieldset'
            )
        ));

        $this->add(array(
            'name'       => 'submit',
            'attributes' => array(
                'type'  => 'submit',
                'value' => _('Save'),
                'id'    => 'submit',
                'class' => 'btn btn-success',
            ),
        ));
    }

}
