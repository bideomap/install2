<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;

use Laminas\Form\Form;

class GamificationForm extends Form
{

    public function __construct()
    {
        parent::__construct('gamification-form');

        $this->setAttribute('method', 'post');
    }

}
