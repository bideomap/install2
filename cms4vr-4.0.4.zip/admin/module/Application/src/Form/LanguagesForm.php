<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;

use Application\Model\VRMCommon;
use Laminas\Form\Element\Checkbox;
use Laminas\Form\Element\Select;
use Laminas\Form\Form;
use Laminas\Filter\StringTrim;
use Laminas\Form\Element\Hidden;
use Laminas\Form\Element\Text;
use Laminas\InputFilter\Input;
use Laminas\InputFilter\InputFilter;
use Laminas\Validator\NotEmpty;

/**
 * Class LanguagesForm delivers a functionality to manage languages within an existing project
 * This form is used by developers only
 *
 * @package Application\Form
 */

class LanguagesForm extends Form
{

    public function __construct($name = null)
    {
        parent::__construct('languages-form');

        $this->add(new Hidden('id'));

        $this->add(new Hidden('short'));

        $long = new Text('long');
        $long->setAttributes(array('placeholder' => _('Long name'), 'class' => 'form-control text-input'));
        $this->add($long);

        $voice = new Select('voice');
        $voice->setAttributes(array('placeholder' => _('Voice'), 'class' => 'form-control text-input'));
        // $voice->setValueOptions($amazonVoices);
        $this->add($voice);

        $defaultLanguage = new Checkbox('default_language');
        $this->add($defaultLanguage);

        $this->add(array(
            'name'       => 'submit',
            'attributes' => array(
                'type'  => 'submit',
                'value' => _('Save'),
                'id'    => 'submit',
                'class' => 'btn btn-success',
            ),
        ));

        //validation
        $inputFilter = new InputFilter();

        $longFilter = new Input('long');
        $longFilter->getFilterChain()->attach(new StringTrim());
        $longFilter->getValidatorChain()->attach(new NotEmpty());
        $inputFilter->add($longFilter);

        $voiceFilter = new Input('voice');
        $voiceFilter->setRequired(false);
        $inputFilter->add($voiceFilter);

        $this->setInputFilter($inputFilter);
    }
}




