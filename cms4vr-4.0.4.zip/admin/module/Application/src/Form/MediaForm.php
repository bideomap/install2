<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;


use Application\Model\Languages;
use Application\Model\Panos;
use Laminas\Form\Element\File;
use Laminas\Form\Element\Hidden;
use Laminas\Form\Element\Text;
use Laminas\Form\Form;
use Laminas\InputFilter\Input;
use Laminas\InputFilter\InputFilter;
use Laminas\Stdlib\Hydrator\ClassMethods as ClassMethodsHydrator;
use Laminas\Validator\File\ExcludeExtension;
use Laminas\Validator\File\ExcludeMimeType;
use Laminas\Validator\File\Extension;
use Laminas\Validator\File\MimeType;

class MediaForm extends Form
{

    /**
     *
     */
    public function __construct()
    {
        parent::__construct('media-form');

        $this->setAttribute('method', 'post');

        $this->add(new Hidden('id'));

        $mediaFile = new File('mediafile');
        $mediaFile->setLabel(_('Media files') . ' <span>*</span>');
        $mediaFile->setLabelOptions(array('disable_html_escape' => true));
        $mediaFile->setAttributes(array('class' => 'btn-success', 'id' => '', 'multiple' => true));
        $this->add($mediaFile);

        $mediaLink = new Text('medialink');
        $mediaLink->setLabel(_('Media link') . ' <span>*</span>');
        $mediaLink->setLabelOptions(array('disable_html_escape' => true));
        $mediaLink->setAttributes(array('class' => 'form-control'));
        $this->add($mediaLink);


        //add buttons
        $this->add(array(
            'name'       => 'submit',
            'attributes' => array(
                'type'  => 'submit',
                'value' => _('Save'),
                'id'    => 'submit',
                'class' => 'btn btn-success',
            ),
        ));

        $this->add(array(
            'name'       => 'cancel',
            'attributes' => array(
                'type'  => 'button',
                'value' => _('Cancel'),
                'id'    => 'cancel',
                'class' => 'btn btn-danger',
            ),
        ));


    }

    public function setValidation($ffmpegEnabled = false)
    {
        //validation
        $inputFilter = new InputFilter();

        $mediaFile = new Input('mediafile');
        $mediaFile->setRequired(true);
        $mediaFile->getValidatorChain()->attach(
            new ExcludeExtension(
                [
                    'php',
                    'js',
                    'css',
                    'bat',
                    'asp',
                    'aspx',
                    'dll',
                    'exe',
                    'msi',
                    'ps1',
                    'reg',
                    'scr',
                    'vbs',
                    'vbscript',
                    'ws',
                    'wsf',
                    'wsh',
                    'jar',
                ]
            )
        );

        $inputFilter->add($mediaFile);

        $this->setInputFilter($inputFilter);
    }
}




