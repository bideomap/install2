<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;

use Laminas\Form\Element\Checkbox;
use Laminas\Form\Element\Color;
use Laminas\Form\Element\File;
use Laminas\Form\Element\Number;
use Laminas\Form\Element\Range;
use Laminas\Form\Element\Select;
use Laminas\Form\Element\Text;
use Laminas\Form\Element\Textarea;
use Laminas\Form\Form;
use Laminas\InputFilter\Input;
use Laminas\InputFilter\InputFilter;
use Laminas\InputFilter\InputFilterProviderInterface;
use Laminas\Validator\File\Extension;

class ModulesForm extends Form implements InputFilterProviderInterface
{

    public function __construct()
    {
        parent::__construct('modules-form');

        $this->setAttribute('method', 'post');

        // visibility of modules
        foreach (
            [
                'm_map',
                'm_facebook',
                'm_analytics',
                'm_logo',
                'm_copyright',
                'm_privacy',
                'm_social',
                'm_stickers',
                'm_infobox',
                'm_keepview',
                'm_arrowmode',
                'm_radarmode',
                'm_floorplans',
                'm_autotour',
                'm_simple_content_menu',
                'm_poi_settings',
                'm_video_livepresenter',
                'm_autodescription',
                'm_nadir'
            ] as $item) {
            $this->add([
                'type'       => 'Laminas\Form\Element\Hidden',
                'name'       => $item
            ]);
        }

        $facebook_id = new Text('facebook_id');
        $facebook_id->setLabel(_('Facebook ID'));
        $facebook_id->setAttributes(array('class' => 'form-control text-input', 'id' => ''));
        $this->add($facebook_id);

        $facebook_app = new Text('facebook_app');
        $facebook_app->setLabel(_('Facebook App'));
        $facebook_app->setAttributes(array('class' => 'form-control text-input', 'id' => ''));
        $this->add($facebook_app);

        $analytics_id = new Text('analytics_id');
        $analytics_id->setLabel(_('Google analytics tracking ID'));
        $analytics_id->setAttributes(array('class' => 'form-control', 'id' => ''));
        $this->add($analytics_id);

        $primary_color = new Color('primary_color');
        $primary_color->setLabel(_('Primary color'));
        $primary_color->setAttributes(array('class' => 'form-control', 'id' => '', 'style' => 'width:120px'));
        $this->add($primary_color);

        $secondary_color = new Color('secondary_color');
        $secondary_color->setLabel(_('Secondary color'));
        $secondary_color->setAttributes(array('class' => 'form-control', 'id' => '', 'style' => 'width:120px'));
        $this->add($secondary_color);

        $new_template = new File('new_template');
        $new_template->setLabel(_('New template'));
        $new_template->setAttributes(array('class' => 'btn-success'));
        $this->add($new_template);

        $force_ssl = new Checkbox('force_ssl');
        $force_ssl->setLabel(_('Force HTTPS'));
        $force_ssl->setCheckedValue(1);
        $force_ssl->setUncheckedValue(0);
        $this->add($force_ssl);

        $awsAccessKey = new Text('aws_access_key');
        $awsAccessKey->setLabel(_('AWS Access Key'));
        $this->add($awsAccessKey);

        $awsSecretKey = new Text('aws_secret_key');
        $awsSecretKey->setLabel(_('AWS Secret Key'));
        $this->add($awsSecretKey);

        // map
        $mapType = new Select('map_type');
        $mapType->setLabel(_('Map type'));
        $mapType->setValueOptions(['normal' => _('normal'), 'satelite' => _('satellite'), 'hybrid' => _('hybrid'), 'terrain' => _('terrain')]);
        $this->add($mapType);

        $mapDistance = new Select('map_distance');
        $mapDistance->setLabel(_('Distance'));
        $mapDistance->setValueOptions(['kilometers' => _('kilometers'), 'miles' => _('miles')]);
        $this->add($mapDistance);

        $mapId = new Text('map_id');
        $mapId->setLabel(_('Google API Key'));
        $this->add($mapId);

        // autotour
        $autotourSpeed = new Text('autotour_speed');
        $autotourSpeed->setLabel(_('Speed'));
        $this->add($autotourSpeed);

        // POI settings
        $poiSize = new Text('poi_size');
        $poiSize->setLabel(_('background size'));
        $this->add($poiSize);
        $poiCssSize = new Text('poi_css_size');
        $poiCssSize->setLabel(_('ICO size'));
        $this->add($poiCssSize);

        $poiRotate = new Checkbox('poi_rotate');
        $poiRotate->setLabel(_('POI rotate'));
        $poiRotate->setCheckedValue(1);
        $poiRotate->setUncheckedValue(0);
        $this->add($poiRotate);

        $poiRoundEdge = new Text('poi_roundedge');
        $poiRoundEdge->setLabel(_('background round edge'));
        $this->add($poiRoundEdge);

        $poiFlipColor = new Checkbox('poi_flip_color');
        $poiFlipColor->setLabel(_('Flip colors'));
        $poiFlipColor->setCheckedValue('true');
        $poiFlipColor->setUncheckedValue('false');
        $this->add($poiFlipColor);

        $poiHidePopupToPanoVt = new Checkbox('poi_hide_popup_to_pano_vr');
        $poiHidePopupToPanoVt->setLabel(_('Hide panorama popup in VR mode'));
        $poiHidePopupToPanoVt->setCheckedValue('true');
        $poiHidePopupToPanoVt->setUncheckedValue('false');
        $this->add($poiHidePopupToPanoVt);

        $poiStreetViewEffect = new Checkbox('poi_streetview_effect');
        $poiStreetViewEffect->setLabel(_('Streetview effect'));
        $poiStreetViewEffect->setCheckedValue('true');
        $poiStreetViewEffect->setUncheckedValue('false');
        $poiStreetViewEffect->setValue('true');
        $this->add($poiStreetViewEffect);

        $poiStaticPanoramaPreview = new Checkbox('poi_static_panorama_preview');
        $poiStaticPanoramaPreview->setLabel(_('Static panorama preview'));
        $poiStaticPanoramaPreview->setCheckedValue('true');
        $poiStaticPanoramaPreview->setUncheckedValue('false');
        $poiStaticPanoramaPreview->setValue('false');
        $this->add($poiStaticPanoramaPreview);

        $poiStreetViewPoiMoveEffect = new Number('poi_streetview_poimove_effect');
        $poiStreetViewPoiMoveEffect->setLabel(_('Streetview POI move effect'));
        $poiStreetViewPoiMoveEffect->setValue(-0.3);
        $poiStreetViewPoiMoveEffect->setAttributes(
            [
                'step' => 0.1,
            ]);
        $this->add($poiStreetViewPoiMoveEffect);

        $poiHidePopupNormalMode = new Checkbox('poi_hide_popup_to_pano_normal');
        $poiHidePopupNormalMode->setLabel(_('Hide panorama popup in normal mode'));
        $poiHidePopupNormalMode->setCheckedValue('true');
        $poiHidePopupNormalMode->setUncheckedValue('false');
        $poiHidePopupNormalMode->setValue('false');
        $this->add($poiHidePopupNormalMode);

        $poiBlockMoveto = new Checkbox('poi_block_moveto_poi');
        $poiBlockMoveto->setLabel(_('Block moveto POI'));
        $poiBlockMoveto->setCheckedValue('true');
        $poiBlockMoveto->setUncheckedValue('false');
        $poiBlockMoveto->setValue('false');
        $this->add($poiBlockMoveto);

        $poiIgnorePreviewCustom = new Checkbox('poi_ignore_preview_custom_view');
        $poiIgnorePreviewCustom->setLabel(_('Ignore preview custom view POI'));
        $poiIgnorePreviewCustom->setCheckedValue('true');
        $poiIgnorePreviewCustom->setUncheckedValue('false');
        $poiIgnorePreviewCustom->setValue('false');
        $this->add($poiIgnorePreviewCustom);

        $poiAutoGeneratePoi = new Checkbox('poi_auto_generate_poi_to_pano');
        $poiAutoGeneratePoi->setLabel(_('Auto generate POI to scene'));
        $poiAutoGeneratePoi->setCheckedValue('true');
        $poiAutoGeneratePoi->setUncheckedValue('false');
        $poiAutoGeneratePoi->setValue('false');
        $this->add($poiAutoGeneratePoi);

        $poiAutoDoolhausePoi = new Checkbox('poi_auto_generate_dollhouse_floor_poi');
        $poiAutoDoolhausePoi->setLabel(_('Auto generate dollhouse FLOOR POI'));
        $poiAutoDoolhausePoi->setCheckedValue('true');
        $poiAutoDoolhausePoi->setUncheckedValue('false');
        $poiAutoDoolhausePoi->setValue('false');
        $this->add($poiAutoDoolhausePoi);

        $poiLabelBackgroundPoi = new Checkbox('poi_label_background');
        $poiLabelBackgroundPoi->setLabel(_('Label background POI'));
        $poiLabelBackgroundPoi->setCheckedValue('true');
        $poiLabelBackgroundPoi->setUncheckedValue('false');
        $poiLabelBackgroundPoi->setValue('false');
        $this->add($poiLabelBackgroundPoi);

        // copyright
        $companyName = new Text('copyright_id');
        $companyName->setLabel(_('Company name'));
        $this->add($companyName);

        $companyUrl = new Text('copyright_www');
        $companyUrl->setLabel(_('URL with https://'));
        $this->add($companyUrl);

        // logo
        $logo = new File('logo_file');
        $logo->setLabel(_('Logo file'));
        $logo->setAttributes(array('class' => 'btn-success', 'accept' => 'image/png'));
        $this->add($logo);

        $logoTooltip = new Text('logo_tooltip');
        $logoTooltip->setLabel(_('Tooltip logo'));
        $this->add($logoTooltip);

        $logoUrl = new Text('logo_www');
        $logoUrl->setLabel(_('URL with https://'));
        $this->add($logoUrl);

        $logoRemove = new Checkbox('logo_remove');
        $logoRemove->setLabel(_('Remove logo'));
        $logoRemove->setCheckedValue(1);
        $logoRemove->setUncheckedValue(0);
        $logoRemove->setValue(0);
        $this->add($logoRemove);

        $vlp_agora_api = new Text('video_livepresenter_agora_app_id');
        $vlp_agora_api->setLabel(_('agora.io API key'));
        $vlp_agora_api->setAttributes(['class' => 'form-control text-input', 'id' => '']);
        $this->add($vlp_agora_api);

        $vlp_turn_server = new Text('video_livepresenter_turn_server');
        $vlp_turn_server->setLabel(_('TURN_server'));
        $vlp_turn_server->setAttributes(['class' => 'form-control text-input', 'id' => '']);
        $this->add($vlp_turn_server);

        $vlp_turn_username = new Text('video_livepresenter_turn_username');
        $vlp_turn_username->setLabel(_('TURN_username'));
        $vlp_turn_username->setAttributes(['class' => 'form-control text-input', 'id' => '']);
        $this->add($vlp_turn_username);

        $vlp_turn_password = new Text('video_livepresenter_turn_password');
        $vlp_turn_password->setLabel(_('TURN_password'));
        $vlp_turn_password->setAttributes(['class' => 'form-control text-input', 'id' => '']);
        $this->add($vlp_turn_password);

        $vlp_password = new Text('video_livepresenter_password');
        $vlp_password->setLabel(_('password'));
        $vlp_password->setAttributes(['class' => 'form-control text-input', 'id' => '']);
        $vlp_password->setValue('STRING');
        $this->add($vlp_password);

        $autoDescription_volume = new Range('autodescription_volume');
        $autoDescription_volume->setLabel(_('Volume'));
        $autoDescription_volume->setAttributes(
            [
                'class' => 'form-control autoDescription-range',
                'id' => '',
                'min' => 0,
                'max' => 100,
                'step' => 1,
        ]);
        $autoDescription_volume->setValue(100);
        $this->add($autoDescription_volume);

        $autoDescription_pitch = new Range('autodescription_pitch');
        $autoDescription_pitch->setLabel(_('Pitch'));
        $autoDescription_pitch->setAttributes(
            [
                'class' => 'form-control autoDescription-range',
                'id' => '',
                'min' => 0.1,
                'max' => 1,
                'step' => 0.1,
            ]);
        $autoDescription_pitch->setValue(1);
        $this->add($autoDescription_pitch);

        $autoDescription_rate = new Range('autodescription_rate');
        $autoDescription_rate->setLabel(_('Rate'));
        $autoDescription_rate->setAttributes(
            [
                'class' => 'form-control autoDescription-range',
                'id' => '',
                'min' => 0.1,
                'max' => 1,
                'step' => 0.1,
            ]);
        $autoDescription_rate->setValue(1);
        $this->add($autoDescription_rate);

        $autoDescription_auto_read = new Checkbox('autodescription_auto_read');
        $autoDescription_auto_read->setLabel(_('Read automatically'));
        $autoDescription_auto_read->setCheckedValue('true');
        $autoDescription_auto_read->setUncheckedValue('false');
        $autoDescription_auto_read->setValue('false');
        $this->add($autoDescription_auto_read);

        $nadir = new File('nadir_file');
        $nadir->setLabel(_('Nadir file'));
        $nadir->setAttributes(array('class' => 'btn-success', 'accept' => 'image/png'));
        $this->add($nadir);

        $nadirTooltip = new Text('nadir_tooltip');
        $nadirTooltip->setLabel(_('Tooltip nadir'));
        $this->add($nadirTooltip);

        $nadirUrl = new Text('nadir_www');
        $nadirUrl->setLabel(_('URL with https://'));
        $this->add($nadirUrl);

        $nadirScale = new Range('nadir_scale');
        $nadirScale->setLabel(_('Scale'));
        $nadirScale->setAttributes(
            [
                'class' => 'form-control nadir-scale',
                'id' => '',
                'min' => 0.1,
                'max' => 10,
                'step' => 0.1,
            ]);
        $nadirScale->setValue(1.0);
        $this->add($nadirScale);

        $nadirStatic = new Checkbox('nadir_static');
        $nadirStatic->setLabel(_('Static'));
        $nadirStatic->setCheckedValue('true');
        $nadirStatic->setUncheckedValue('false');
        $this->add($nadirStatic);

        $this->add([
            'type'       => 'Laminas\Form\Element\Hidden',
            'name'       => 'stickers_groups',
            'attributes' => [
                'id' => 'stickers_groups',
            ],
        ]);

        $this->add([
            'type'       => 'Laminas\Form\Element\Hidden',
            'name'       => 'template',
            'attributes' => [
                'id' => 'template',
            ],
        ]);

        $projectSettingsFs = new ModulesProjectSettingsFieldsetForm();
        $this->add([
            'type'       => 'Laminas\Form\Element\Collection',
            'name'       => 'project_settings_fs',
            'options'    => [
                'count'                  => 1,
                'should_create_template' => false,
                'allow_add'              => true,
                'target_element'         => $projectSettingsFs
            ],
        ]);

        $privacyFs = new ModulesPrivacyFieldsetForm();
        $this->add([
            'type'       => 'Laminas\Form\Element\Collection',
            'name'       => 'privacy_fe_fs',
            'options'    => [
                'count'                  => 1,
                'should_create_template' => false,
                'allow_add'              => true,
                'target_element'         => $privacyFs
            ],
        ]);

        $this->add([
            'type'       => 'Laminas\Form\Element\Collection',
            'name'       => 'privacy_be_fs',
            'options'    => [
                'count'                  => 1,
                'should_create_template' => false,
                'allow_add'              => true,
                'target_element'         => $privacyFs
            ],
        ]);

        //add buttons
        $this->add(array(
            'name'       => 'submit',
            'attributes' => array(
                'type'  => 'submit',
                'value' => _('Save'),
                'id'    => 'submit',
                'class' => 'btn btn-success',
            ),
        ));

        $inputFilter = new InputFilter();

        $logo = new Input('logo_file');
        $logo->getValidatorChain()->attach(new Extension(array('jpg', 'jpeg', 'png', 'gif')));
        $logo->setRequired(false);
        $logo->allowEmpty();
        $inputFilter->add($logo);
    }

    public function getInputFilterSpecification()
    {
        return [
            'autodescription_pitch' => [
                'filters'           => [
                    ['name' => 'ToFloat'],
                ],
            ],
            'autodescription_rate' => [
                'filters'           => [
                    ['name' => 'ToFloat'],
                ],
            ],
            'nadir_scale' => [
                'filters'           => [
                    ['name' => 'ToFloat'],
                ],
            ],
        ];
    }

}
