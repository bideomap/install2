<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;

use Laminas\Form\Element\Hidden;
use Laminas\Form\Element\Textarea;
use Laminas\Form\Fieldset;

class ModulesPrivacyFieldsetForm extends Fieldset
{

    public function __construct($name = null, $options = [])
    {
        parent::__construct('privacy_fs', $options);

        $this->add(new Hidden('language'));

        $this->add(new Hidden('language_id'));

        $desc = new Textarea('description');
        $desc->setAttributes(array('class' => 'quill full-width'));
        $this->add($desc);
    }

}
