<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;

use Laminas\Form\Element\Checkbox;
use Laminas\Form\Element\File;
use Laminas\Form\Element\Hidden;
use Laminas\Form\Element\Text;
use Laminas\Form\Element\Textarea;
use Laminas\Form\Fieldset;
use Laminas\InputFilter\InputFilterProviderInterface;
use Laminas\Validator\File\Extension;
use Laminas\Validator\NotEmpty;

class ModulesProjectSettingsFieldsetForm extends Fieldset implements InputFilterProviderInterface
{

    public function __construct($name = null, $options = [])
    {
        parent::__construct('project_settings_fs', $options);

        $this->add(new Hidden('language'));

        $this->add(new Hidden('language_id'));

        $name = new Text('name');
        $name->setLabel(_('Name'));
        $name->setAttributes(array('placeholder' => _('Project name'), 'class' => 'form-control text-input'));
        $this->add($name);

        //media id input
        $this->add(new Hidden('media_id'));

        $desc = new Textarea('description');
        $desc->setAttributes(array('class' => 'quill'));
        $this->add($desc);
    }

    public function getInputFilterSpecification()
    {
        return [
            'name' => [
                'validators' => [
                    new NotEmpty()
                ]
            ],
        ];
    }

}
