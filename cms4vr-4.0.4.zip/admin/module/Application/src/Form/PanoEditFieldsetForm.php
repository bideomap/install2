<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;

use Laminas\Db\Sql\Select;
use Laminas\Db\Sql\Where;
use Laminas\Db\TableGateway\Feature\GlobalAdapterFeature;
use Laminas\Form\Element\Checkbox;
use Laminas\Form\Element\File;
use Laminas\Form\Element\Hidden;
use Laminas\Form\Element\Text;
use Laminas\Form\Element\Textarea;
use Laminas\Form\Fieldset;
use Laminas\InputFilter\InputFilterProviderInterface;
use Laminas\Validator\Db\NoRecordExists;
use Laminas\Validator\NotEmpty;

class PanoEditFieldsetForm extends Fieldset // implements InputFilterProviderInterface
{

    protected $project_id;
    protected $pano_id;

    public function __construct($pano_id)
    {
        parent::__construct('panos_fs');

        $this->pano_id = $pano_id;

        $this->add(new Hidden('id'));

        $this->add(new Hidden('languages_id'));

        $name = new Text('name');
        $name->setLabel(_('Name') . ' <span>*</span>');
        $name->setLabelOptions(['disable_html_escape' => true]);
        $name->setAttributes([
            'placeholder' => _('Panorama name'),
            'class'       => 'form-control text-input input',
            'id'          => '',
            'data-required' => 1
        ]);
        $this->add($name);

        $desc = new Textarea('description');
        $desc->setAttributes(array('class' => 'quill'));
        $this->add($desc);

        //media id input
        $this->add(new Hidden('media_id'));

    }

    /**
     * Verifies that panorama name is unique across the same project
     *
     * It is important for the checked element (name field here) to be listed FIRST in WHERE clause, as otherwise
     * it won't be checked against provided input.
     *
     * @return array
     */
    // disabled as requested on 25.10.2017
    /*public function getInputFilterSpecification()
    {
        $select = new Select();

        $where = new Where();
        $where->equalTo('name', '');
        $where->notEqualTo('panos_id', $this->pano_id);

        $select->from('pano_phrases')->columns(['name'])->join('panos', 'panos.id = pano_phrases.panos_id', []);
        $select->where($where);

        $noPanoWithSameName = new NoRecordExists($select);
        $noPanoWithSameName->setAdapter(GlobalAdapterFeature::getStaticAdapter());
        $noPanoWithSameName->setMessages(['recordFound' => _('Panorama name should be unique')]);

        return [
            'name' => [
                'validators' => [
                    new NotEmpty(),
                    $noPanoWithSameName,
                ]
            ]
        ];
    }*/
}




