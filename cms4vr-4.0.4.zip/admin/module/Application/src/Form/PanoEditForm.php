<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;

use Laminas\Form\Element;
use Laminas\Form\Element\File;
use Laminas\Form\Element\Hidden;
use Laminas\Form\Form;
use Laminas\I18n\Validator\IsFloat;
use Laminas\InputFilter\Input;
use Laminas\InputFilter\InputFilter;
use Laminas\Validator\File\Extension;

class PanoEditForm extends Form
{

    public function __construct($pano_id)
    {
        parent::__construct('pano-edit-form');

        $this->setAttribute('method', 'post');

        $this->add(new Hidden('id'));

        $this->add(new Hidden('media_id'));

        $panoFS = new PanoEditFieldsetForm($pano_id);

        $this->add([
                       'type'       => 'Laminas\Form\Element\Collection',
                       'name'       => 'panos_fs',
                       'options'    => [
                           'count'                  => 0,
                           'should_create_template' => false,
                           'allow_add'              => true,
                           'target_element'         => $panoFS
                       ],
                   ]);

        $this->add([
                       'type'       => 'Laminas\Form\Element\Hidden',
                       'name'       => 'lat',
                       'attributes' => [
                           'id' => 'gmap_lat',
                       ],
                   ]);

        $this->add([
                       'type'       => 'Laminas\Form\Element\Hidden',
                       'name'       => 'lng',
                       'attributes' => [
                           'id' => 'gmap_lng',
                       ],
                   ]);

        $this->add([
            'type'       => 'Laminas\Form\Element\Text',
            'name'       => 'altitude',
            'attributes' => [
                'id' => 'altitude',
            ],
            'options'    => [
                'label' => _('Panorama altitude'),
            ]
        ]);

        $this->add([
                       'type'       => 'Laminas\Form\Element\Select',
                       'name'       => 'galleries_id',
                       'attributes' => [
                           'id' => 'galleries_id',
                       ],
                       'options'    => [
                           'label' => _('Choose photo gallery'),
                       ]
                   ]);

        $this->add([
            'type'       => 'Laminas\Form\Element\Select',
            'name'       => 'pano_type',
            'options'    => [
                'label' => _('Panorama type'),
                'value_options' => array(
                    'sphere' => _('Spherical (MULTIRES)'),
                    'cubic' => _('Spherical (NORMAL)'),
                    'flat' => _('Flat'),
                ),
            ]
        ]);

        $this->add([
            'type'       => 'Laminas\Form\Element\File',
            'name'       => 'replace_pano',
            'options'    => [
                'label' => _('Replace panorama')
            ],
            'attributes' => [
                'class' => 'btn-success',
                'title' => _('Select panorama file'),
            ]
        ]);

        $this->add([
            'type'       => 'Laminas\Form\Element\File',
            'name'       => 'replace_pano_zip',
            'options'    => [
                'label' => _('Replace panorama (ZIP file)')
            ],
            'attributes' => [
                'class' => 'btn-success',
                'title' => _('Select ZIP panorama file'),
            ]
        ]);

        $this->add(
            [
                'type' => 'Laminas\Form\Element\File',
                'name' => 'thumbnail_file',
                'options' => [
                    'label' => _('Upload thumbnail')
                ],
                'attributes' => [
                    'class' => 'btn-success',
                    'title' => _('Upload thumbnail'),
                    'accept' => 'image/jpg, image/jpeg',
                    'id' => 'thumbnail_file'
                ]
            ]
        );

        $this->add([
            'type'       => 'Laminas\Form\Element\File',
            'name'       => 'depthmap_file',
            'options'    => [
                'label' => _('Select depthmap file')
            ],
            'attributes' => [
                'class' => 'btn-success',
                'title' => _('Select depthmap file'),
            ]
        ]);

        /*$this->add([
            'type'       => 'Laminas\Form\Element\Select',
            'name'       => 'rendermode',
            'attributes' => [
                'id' => 'rendermode',
                'class' => 'form-control'
            ],
            'options'    => [
                'label' => _('rendermode'),
                'value_options' => [
                    'depthmap' => _('depthmap'),
                    '3dmodel' => _('3dmodel'),
                ],
            ],
        ]);*/

        $this->add([
            'type'       => 'Laminas\Form\Element\Select',
            'name'       => 'background',
            'attributes' => [
                'id' => 'background',
                'class' => 'form-control'
            ],
            'options'    => [
                'label' => _('background'),
                'value_options' => [
                    'none' => _('none'),
                    'pano' => _('pano'),
                ],
            ],
        ]);

        $this->add([
            'type'       => 'Laminas\Form\Element\Text',
            'name'       => 'scale',
            'attributes' => [
                'id' => 'scale',
                'class' => 'form-control'
            ],
            'options'    => [
                'label' => _('scale'),
            ]
        ]);

        $this->add([
            'type'       => 'Laminas\Form\Element\Text',
            'name'       => 'offset',
            'attributes' => [
                'id' => 'offset',
                'class' => 'form-control'
            ],
            'options'    => [
                'label' => _('offset'),
            ]
        ]);

        $this->add([
            'type'       => 'Laminas\Form\Element\Text',
            'name'       => 'subdiv',
            'attributes' => [
                'id' => 'subdiv',
                'class' => 'form-control form-small',
            ],
            'options'    => [
                'label' => _('subdiv'),
            ]
        ]);

        $this->add([
            'type'       => 'Laminas\Form\Element\Hidden',
            'name'       => 'depthmap_visible',
            'attributes' => [
                'id' => 'depthmap_visible',
            ],
        ]);

        $this->add([
            'type'       => 'Laminas\Form\Element\Hidden',
            'name'       => 'dollhouse_visible',
            'attributes' => [
                'id' => 'dollhouse_visible',
            ],
        ]);

        $this->add([
            'type'       => 'Laminas\Form\Element\Text',
            'name'       => 'prealign_x',
            'attributes' => [
                'id' => 'prealign_x',
                'class' => 'form-control form-small',
            ],
            'options'    => [
                'label' => _('Prealign'),
            ]
        ]);

        $this->add([
            'type'       => 'Laminas\Form\Element\Text',
            'name'       => 'prealign_y',
            'attributes' => [
                'id' => 'prealign_y',
                'class' => 'form-control form-small',
            ],
        ]);

        $this->add([
            'type'       => 'Laminas\Form\Element\Text',
            'name'       => 'prealign_z',
            'attributes' => [
                'id' => 'prealign_z',
                'class' => 'form-control form-small',
            ],
        ]);

        $this->add([
            'type'       => 'Laminas\Form\Element\Text',
            'name'       => 'ox',
            'attributes' => [
                'id' => 'ox',
                'class' => 'form-control form-small',
            ],
            'options'    => [
                'label' => _('ox'),
            ]
        ]);

        $this->add([
            'type'       => 'Laminas\Form\Element\Text',
            'name'       => 'oy',
            'attributes' => [
                'id' => 'oy',
                'class' => 'form-control form-small',
            ],
            'options'    => [
                'label' => _('oy'),
            ]
        ]);

        $this->add([
            'type'       => 'Laminas\Form\Element\Text',
            'name'       => 'oz',
            'attributes' => [
                'id' => 'oz',
                'class' => 'form-control form-small',
            ],
            'options'    => [
                'label' => _('oz'),
            ]
        ]);

        //add buttons
        $this->add([
                       'name'       => 'submit',
                       'attributes' => [
                           'type'  => 'submit',
                           'value' => _('Save'),
                           'id'    => 'submit',
                           'class' => 'btn btn-success',
                       ],
                   ]);

        $this->add([
                       'name'       => 'cancel',
                       'attributes' => [
                           'type'  => 'button',
                           'value' => _('Cancel'),
                           'id'    => 'cancel',
                           'class' => 'btn btn-danger',
                       ],
                   ]);

        //validation
        $inputFilter = new InputFilter();

        $mediaFile = new Input('depthmap_file');
        $mediaFile->setRequired(false);
        $mediaFile->getValidatorChain()->attach(new Extension(['jpg', 'jpeg', 'png', 'depth', 'stl', 'obj']));
        $inputFilter->add($mediaFile);

       /* $rendermode = new Input('rendermode');
        $rendermode->setRequired(false);
        $inputFilter->add($rendermode);*/

        $background = new Input('background');
        $background->setRequired(false);
        $inputFilter->add($background);

        $scale = new Input('scale');
        $scale->setRequired(false);
        $scale->getValidatorChain()->attach(new IsFloat(array('locale' => 'en_US')));
        $inputFilter->add($scale);

        $offset = new Input('offset');
        $offset->setRequired(false);
        $offset->getValidatorChain()->attach(new IsFloat(array('locale' => 'en_US')));
        $inputFilter->add($offset);

        $subdiv = new Input('subdiv');
        $subdiv->setRequired(false);
        $inputFilter->add($subdiv);

        $replacePano = new Input('replace_pano');
        $replacePano->setRequired(false);
        $replacePano->getValidatorChain()->attach(new Extension(['jpg', 'jpeg', 'tif', 'tiff', 'psb']));
        $inputFilter->add($replacePano);

        $replacePanoZip = new Input('replace_pano_zip');
        $replacePanoZip->setRequired(false);
        $replacePanoZip->getValidatorChain()->attach(new Extension(['zip']));
        $inputFilter->add($replacePanoZip);

        $panoType = new Input('pano_type');
        $panoType->setRequired(false);
        $inputFilter->add($panoType);

        $this->setInputFilter($inputFilter);

    }

}
