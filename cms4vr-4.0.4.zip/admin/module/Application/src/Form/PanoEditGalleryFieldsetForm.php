<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;

use Laminas\Form\Element\Hidden;
use Laminas\Form\Element\Text;
use Laminas\Form\Element\Textarea;
use Laminas\Form\Fieldset;

class PanoEditGalleryFieldsetForm extends Fieldset
{

    public function __construct($name = null, $options = [])
    {
        parent::__construct('panos_gallery_fs', $options);

        $this->add(new Hidden('languages_id'));

        $name = new Text('name');
        $name->setLabel(_('Name') . ' <span>*</span>');
        $name->setLabelOptions(['disable_html_escape' => true]);
        $name->setAttributes([
                                 'placeholder' => _('Gallery name'),
                                 'class'       => 'form-control text-input input',
                                 'id'          => ''
                             ]);
        $this->add($name);

        $desc = new Textarea('description');
        $desc->setAttributes(array('class' => 'quill'));
        $this->add($desc);

    }

}
