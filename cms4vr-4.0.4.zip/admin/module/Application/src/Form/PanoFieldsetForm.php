<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;


use Laminas\Db\Sql\Select;
use Laminas\Db\TableGateway\Feature\GlobalAdapterFeature;
use Laminas\Form\Element\Hidden;
use Laminas\Form\Element\Text;
use Laminas\Form\Fieldset;
use Laminas\InputFilter\InputFilter;
use Laminas\InputFilter\InputFilterProviderInterface;
use Laminas\Validator\Db\NoRecordExists;
use Laminas\Validator\NotEmpty;

class PanoFieldsetForm extends Fieldset //implements InputFilterProviderInterface
{

    // project_id is used to check during validation if panorama name is unique
    protected $project_id;

    public function __construct()
    {
        parent::__construct('panos_fs');

        $this->add(new Hidden('language_id'));
        $this->add(new Hidden('language'));

        $name = new Text('name');
        $name->setLabel(_('Name') . ' <span>*</span>');
        $name->setLabelOptions(array('disable_html_escape' => true));
        $name->setAttributes(array('placeholder' => _('Panorama name'), 'class' => 'form-control text-input input', 'id' => '', 'data-required' => 1));
        $this->add($name);

    }

    /**
     * Verify that newly created panorama has a different name than others in the same project
     *
     * Without that check the system won't be able to display the correct panorama for external users, resorting to the
     * first record matched based on the name of the panorama.
     *
     * @return array
     */
    // disabled as requested on 25.10.2017
    /*public function getInputFilterSpecification()
    {

        $select = new Select();
        $select->from('pano_phrases')->columns(['name'])->join('panos', 'panos.id = pano_phrases.panos_id', []);
        $select->where(['name' => '', 'projects_id' => $this->project_id]);

        $noPanoWithSameName = new NoRecordExists($select);
        $noPanoWithSameName->setAdapter(GlobalAdapterFeature::getStaticAdapter());
        $noPanoWithSameName->setMessages(['recordFound' => _('Panorama name should be unique across this project')]);

        return [
            'name' => [
                'validators' => [
                    new NotEmpty(),
                    $noPanoWithSameName,
                ]
            ]
        ];
    }*/

}




