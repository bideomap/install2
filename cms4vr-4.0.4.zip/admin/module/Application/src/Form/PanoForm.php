<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;


use Laminas\Form\Element\File;
use Laminas\Form\Element\Hidden;
use Laminas\Form\Form;
use Laminas\InputFilter\Input;
use Laminas\InputFilter\InputFilter;
use Laminas\Validator\File\Extension;

class PanoForm extends Form
{

    /**
     *
     */
    public function __construct()
    {
        parent::__construct('pano-form');

        $this->setAttribute('method', 'post');

        $this->add(new Hidden('id'));

        $this->add(new Hidden('multiple'));

        $panoFS = new PanoFieldsetForm();
        $this->add(array(
            'type' => 'Laminas\Form\Element\Collection',
            'name' => 'panos_fs',
            'options' => array(
                'count' => 0,
                'should_create_template' => false,
                'allow_add' => true,
                'target_element' => $panoFS
            ),
            'attributes' => array(
                'class' => 'languageFieldset'
            )
        ));

        $this->add([
            'type'       => 'Laminas\Form\Element\Select',
            'name'       => 'pano_type',
            'options'    => [
                'label' => _('Panorama type'),
                'value_options' => array(
                    'sphere' => _('Spherical (MULTIRES)'),
                    'cubic' => _('Spherical (NORMAL)'),
                    'flat' => _('Flat'),
                ),
            ]
        ]);

        $pano = new File('pano');
        $pano->setLabel(_('Panorama (JPG file)') . ' <span>*</span>');
        $pano->setLabelOptions(array('disable_html_escape' => true));
        $pano->setAttributes(array('multiple' => true, 'class' => 'btn-success', 'id' => '', 'data-required' => 1, 'accept' => '.jpg, .jpeg, .tiff, .tif, .psb'));
        $this->add($pano);

        $this->add([
                       'type'       => 'Laminas\Form\Element\Select',
                       'name'       => 'category_id',
                       'attributes' => [
                           'id' => 'category_id',
                       ],
                       'options'    => [
                           'label' => _('Category'),
                       ]
                   ]);

        //add buttons
        $this->add(array(
            'name' => 'submit',
            'attributes' => array(
                'type' => 'submit',
                'value' => _('Save'),
                'id' => 'submit',
                'class' => 'btn btn-success',
            ),
        ));

        $this->add(array(
            'name' => 'cancel',
            'attributes' => array(
                'type' => 'button',
                'value' => _('Cancel'),
                'id' => 'cancel',
                'class' => 'btn btn-danger',
            ),
        ));


        //validation
        $inputFilter = new InputFilter();

        $pano = new Input('pano');
        $pano->setRequired(true);
        $pano->getValidatorChain()->attach(new Extension(['jpg', 'jpeg', 'tif', 'tiff', 'psb']));
        $inputFilter->add($pano);

        $this->setInputFilter($inputFilter);

    }

}
