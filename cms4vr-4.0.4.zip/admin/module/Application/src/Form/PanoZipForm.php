<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;


use Application\Model\Languages;
use Application\Model\Panos;
use Laminas\Form\Element\File;
use Laminas\Form\Element\Hidden;
use Laminas\Form\Element\Text;
use Laminas\Form\Form;
use Laminas\InputFilter\Input;
use Laminas\InputFilter\InputFilter;
use Laminas\Stdlib\Hydrator\ClassMethods as ClassMethodsHydrator;
use Laminas\Validator\File\Extension;

class PanoZipForm extends Form
{

    /**
     *
     */
    public function __construct()
    {
        parent::__construct('pano-form');

        $this->setAttribute('method', 'post');

        $this->add(new Hidden('id'));

        $pano = new File('pano');
        $pano->setLabel(_('Panorama (ZIP file)') . ' <span>*</span>');
        $pano->setLabelOptions(array('disable_html_escape' => true));
        $pano->setAttributes(array('class' => 'btn-success', 'id' => '', 'data-required' => 1, 'accept' => '.zip'));
        $this->add($pano);

        $this->add([
                       'type'       => 'Laminas\Form\Element\Select',
                       'name'       => 'category_id',
                       'attributes' => [
                           'id' => 'category_id',
                       ],
                       'options'    => [
                           'label' => _('Category'),
                       ]
                   ]);

        //add buttons
        $this->add(array(
            'name'       => 'submit',
            'attributes' => array(
                'type'  => 'submit',
                'value' => _('Save'),
                'id'    => 'submit',
                'class' => 'btn btn-success',
            ),
        ));

        $this->add(array(
            'name'       => 'cancel',
            'attributes' => array(
                'type'  => 'button',
                'value' => _('Cancel'),
                'id'    => 'cancel',
                'class' => 'btn btn-danger',
            ),
        ));

        //validation
        $inputFilter = new InputFilter();

        $pano = new Input('pano');
        $pano->setRequired(true);
        $pano->getValidatorChain()->attach(new Extension(['zip']));
        $inputFilter->add($pano);

        $this->setInputFilter($inputFilter);

    }

}
