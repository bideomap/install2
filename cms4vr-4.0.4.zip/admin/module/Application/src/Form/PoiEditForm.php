<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;

use Application\Model\Poi;
use Laminas\Form\Element\File;
use Laminas\Form\Element\Hidden;
use Laminas\Form\Element\Select;
use Laminas\Form\Element\Text;
use Laminas\Form\Form;
use Laminas\InputFilter\InputFilterProviderInterface;

class PoiEditForm extends Form implements InputFilterProviderInterface
{
    private $type;

    public function __construct()
    {
        parent::__construct('poi-form');

        $this->setAttribute('method', 'post');

        $this->add(new Hidden('id'));
        $this->add(new Hidden('type'));

        $this->add([
                       'type'       => 'Laminas\Form\Element\Hidden',
                       'name'       => 'panos_id',
                       'attributes' => [
                           'id' => 'panos_id',
                       ],
                   ]);

        $this->add([
                       'type'       => 'Laminas\Form\Element\Hidden',
                       'name'       => 'atv',
                       'attributes' => [
                           'id' => 'gmap_lat',
                       ],
                   ]);

        $this->add([
                       'type'       => 'Laminas\Form\Element\Hidden',
                       'name'       => 'ath',
                       'attributes' => [
                           'id' => 'gmap_lng',
                       ],
                   ]);

        $this->add([
            'type'       => 'Laminas\Form\Element\Hidden',
            'name'       => 'name',
            'attributes' => [
                'id' => 'poi_name',
            ],
        ]);
        $this->add([
                       'type'       => 'Laminas\Form\Element\Hidden',
                       'name'       => 'ico_scale',
                       'attributes' => [
                           'id' => 'poi_ico_scale',
                       ],
                   ]);
        $this->add([
                       'type'       => 'Laminas\Form\Element\Hidden',
                       'name'       => 'ico_color',
                       'attributes' => [
                           'id' => 'poi_ico_color',
                       ],
                   ]);
        $this->add([
                       'type'       => 'Laminas\Form\Element\Hidden',
                       'name'       => 'ico',
                       'attributes' => [
                           'id' => 'poi_ico',
                       ],
                   ]);
        $this->add([
                       'type'       => 'Laminas\Form\Element\Hidden',
                       'name'       => 'ico_rotate',
                       'attributes' => [
                           'id' => 'poi_ico_rotate',
                       ],
                   ]);
        $this->add([
                       'type'       => 'Laminas\Form\Element\Hidden',
                       'name'       => 'ico_bg_alpha',
                       'attributes' => [
                           'id' => 'poi_ico_bg_alpha',
                       ],
                   ]);
        $this->add([
                       'type'       => 'Laminas\Form\Element\Hidden',
                       'name'       => 'ico_bg_color',
                       'attributes' => [
                           'id' => 'poi_ico_bg_color',
                       ],
                   ]);

    }

    public function setType($type)
    {

        $this->type = $type;

        // text
        if ($type == Poi::POI_INFO || $type == Poi::POI_PHOTO || $type == Poi::POI_VIDEO || $type == Poi::POI_DOWNLOAD || $type == Poi::POI_PDF || $type == Poi::POI_LABEL) {
            $langFS = new PoiInfoLangFieldsetForm();
            $this->add([
                           'type'    => 'Laminas\Form\Element\Collection',
                           'name'    => 'poi_fs',
                           'options' => [
                               'count'                  => 0,
                               'should_create_template' => false,
                               'allow_add'              => true,
                               'target_element'         => $langFS
                           ],
                       ]);
        }

        if ($type == Poi::POI_LABEL) {
            // add position
            $this->add([
                'type'       => 'Laminas\Form\Element\Hidden',
                'name'       => 'anchor',
                'attributes' => [
                    'id' => 'anchor',
                    'label' => _('Anchor x')
                ],

            ]);
        }

        // popup
        if ($type == Poi::POI_POPUP || $type == Poi::POI_OBJECT3D) {
            $langFS = new PoiPopupLangFieldsetForm();
            $this->add(
                [
                    'type' => 'Laminas\Form\Element\Collection',
                    'name' => 'poi_fs',
                    'options' => [
                        'count' => 0,
                        'should_create_template' => false,
                        'allow_add' => true,
                        'target_element' => $langFS
                    ],
                ]
            );
        }

        // remove <span>*</span> from label
        if ($type == Poi::POI_PHOTO || $type == Poi::POI_VIDEO) {
            current($this->get('poi_fs'))->get('name')->setLabel(_('Name'));
        }

    }

    /**
     * Validation for specific types of POI
     *
     * Name of a given POI is validated in all but Pano types. This is because names are taken directly from Pano itself
     *
     * @return array
     */
    public function getInputFilterSpecification()
    {

        // start with an empty input filter array
        $inputFilter = [];

        // validate language-aware name for all but Pano POI types
        if ($this->type !== Poi::POI_PANO && $this->type !== Poi::POI_PHOTO && $this->type !== Poi::POI_VIDEO) {
            $inputFilter['type'] = [
                'validators' => [
                    [
                        'name'    => 'Application\Validators\PoiNameValidator',
                        'options' => ['messages' => ['NAME_EMPTY' => _('Please specify a name for this POI in at least one language')]]
                    ]
                ],
            ];
        }

        return $inputFilter;
    }
}




