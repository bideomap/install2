<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;

use Laminas\Form\Element\Hidden;
use Laminas\Form\Element\Text;
use Laminas\Form\Element\Textarea;
use Laminas\Form\Fieldset;

/**
 * Class PoiInfoLangFieldsetForm provides required language-aware fields for text POI
 *
 * @package Project\Form
 */
class PoiInfoLangFieldsetForm extends Fieldset
{

    public function __construct($name = null, $options = [])
    {
        parent::__construct('poi_fs', $options);

        $this->add(new Hidden('id'));

        $this->add(new Hidden('languages_id'));

        $name = new Text('name');
        $name->setLabel(_('Name') . ' <span>*</span>');
        $name->setLabelOptions(['disable_html_escape' => true]);
        $name->setAttributes([
                                 'placeholder' => _('POI name'),
                                 'class'       => 'form-control text-input input',
                                 'id'          => ''
                             ]);
        $this->add($name);

        $desc = new Textarea('description');
        $desc->setAttributes(array('class' => 'quill'));
        $this->add($desc);

        //media id input
        $this->add(new Hidden('media_id'));

    }

}
