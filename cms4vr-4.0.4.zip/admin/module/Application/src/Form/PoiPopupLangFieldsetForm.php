<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;

use Laminas\Form\Element\Hidden;
use Laminas\Form\Element\Text;
use Laminas\Form\Element\Textarea;
use Laminas\Form\Fieldset;
use Laminas\InputFilter\InputFilterProviderInterface;
use Laminas\Validator\Callback;

/**
 * Class PoiPopupLangFieldsetForm provides required language-aware fields for popup POI
 *
 * @package Application\Form
 */
class PoiPopupLangFieldsetForm extends Fieldset implements InputFilterProviderInterface
{

    public function __construct($name = null, $options = [])
    {
        parent::__construct('poi_fs', $options);

        $this->add(new Hidden('id'));

        $this->add(new Hidden('languages_id'));

        $poiName = new Text('name');
        $poiName->setLabel(_('Name'));
        $poiName->setLabelOptions(['disable_html_escape' => true]);
        $poiName->setAttributes(
            [
                'placeholder' => _('POI name'),
                'class' => 'form-control text-input input w-100',
                'id' => ''
            ]
        );
        $this->add($poiName);

        $poiLink = new Text('src');
        $poiLink->setLabel(_('Link'));
        $poiLink->setLabelOptions(['disable_html_escape' => true]);
        $poiLink->setAttributes(
            [
                'placeholder' => _('Link'),
                'class' => 'form-control text-input input w-100',
                'id' => ''
            ]
        );
        $this->add($poiLink);

    }

    /**
     * Set relevant validators for current fieldset
     *
     * @return array
     */
    public function getInputFilterSpecification()
    {
        return [
            'link' => [
                'required'          => false,
                'allow_empty'       => true,
                'continue_if_empty' => true,
                'validators'        => [
                    [
                        'name'    => 'Callback',
                        'break_chain_on_failure' => true,
                        'options' => [
                            'messages' => [
                                Callback::INVALID_VALUE => _('Please provide a link'),
                            ],
                            'callback' => function ($value, $context = []) {
                                if (trim($context['name']) != '') {
                                    return $value ? true : false;
                                }
                                return true;
                            },
                        ],
                    ],
                ],
            ],
            'name' => [
                'required'          => false,
                'allow_empty'       => true,
                'continue_if_empty' => true,
                'filters'           => [
                    ['name' => 'StringTrim'],
                ],
            ],
        ];
    }

}
