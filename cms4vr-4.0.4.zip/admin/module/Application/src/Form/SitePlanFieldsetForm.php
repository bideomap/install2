<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;

use Laminas\Form\Element\Hidden;
use Laminas\Form\Element\Text;
use Laminas\Form\Fieldset;
use Laminas\InputFilter\InputFilterProviderInterface;
use Laminas\Validator\NotEmpty;

class SitePlanFieldsetForm extends Fieldset implements InputFilterProviderInterface
{

    public function __construct($name = null, $options = [])
    {
        parent::__construct('site_plan_fs', $options);

        $this->add(new Hidden('id'));

        $this->add(new Hidden('language'));

        $this->add(new Hidden('language_id'));

        $name = new Text('name');
        $name->setLabel(_('Name'));
        $name->setAttributes(array('placeholder' => _('Plan name'), 'class' => 'form-control text-input', 'data-required' => 1));
        $this->add($name);

    }

    public function getInputFilterSpecification()
    {
        return [
            'name' => [
                'validators' => [
                    new NotEmpty()
                ]
            ],
        ];
    }

}
