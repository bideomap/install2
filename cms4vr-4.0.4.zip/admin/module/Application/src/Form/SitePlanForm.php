<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;


use Laminas\Form\Element\File;
use Laminas\Form\Element\Hidden;
use Laminas\Form\Form;
use Laminas\InputFilter\Input;
use Laminas\InputFilter\InputFilter;
use Laminas\Validator\File\Extension;

class SitePlanForm extends Form
{

    public function __construct()
    {
        parent::__construct('site-plan-form');

        $this->add(new Hidden('id'));

        //add fieldset
        $planFS = new SitePlanFieldsetForm();
        $this->add([
                       'type'       => 'Laminas\Form\Element\Collection',
                       'name'       => 'site_plan_fs',
                       'options'    => [
                           'count'                  => 0,
                           'should_create_template' => false,
                           'allow_add'              => true,
                           'target_element'         => $planFS
                       ],
                       'attributes' => [
                           'id' => 'languageFieldset'
                       ]
                   ]);

        $image = new File('image');
        $image->setLabel(_('Image'));
        $image->setAttributes(array('class' => 'btn-success', 'data-required' => 1));
        $this->add($image);

        $this->add(array(
            'name'       => 'submit',
            'attributes' => array(
                'type'  => 'submit',
                'value' => _('Save'),
                'id'    => 'submit',
                'class' => 'btn btn-success',
            ),
        ));

        //validation
        $inputFilter = new InputFilter();

        $image = new Input('image');
        $image->getValidatorChain()->attach(new Extension(array('jpg', 'jpeg', 'png')));
        $image->setRequired(true);
        $inputFilter->add($image);

        $this->setInputFilter($inputFilter);
    }

}
