<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;

use Application\Validator\UserNameValidator;
use Application\Model\User;
use Laminas\Db\TableGateway\Feature\GlobalAdapterFeature;
use Laminas\Form\Element\Checkbox;
use Laminas\Form\Element\File;
use Laminas\Form\Element\MultiCheckbox;
use Laminas\Form\Element\Password;
use Laminas\Form\Element\Radio;
use Laminas\InputFilter\Input;
use Laminas\InputFilter\InputFilter;
use Laminas\Validator\Db\NoRecordExists;
use Laminas\Validator\EmailAddress;
use Laminas\Validator\NotEmpty;
use Laminas\Form\Element\Hidden;
use Laminas\Form\Element\Text;
use Laminas\Form\Form;
use Laminas\Validator\StringLength;


class UserEditForm extends Form
{

    public function __construct()
    {
        parent::__construct('user-form');

        $this->setAttribute('method', 'post');

        $this->add(new Hidden('id'));

        $changePass = new Checkbox('change_password');
        $changePass->setLabel(_('Change password'));
        $changePass->setCheckedValue(1);
        $changePass->setUncheckedValue(0);
        $this->add($changePass);

        $password = new Password('password');
        $password->setLabel(_('Password') . ' <span>*</span>');
        $password->setLabelOptions(['disable_html_escape' => true]);
        $password->setAttributes([
            'placeholder' => _('Password'),
            'class' => 'form-control border-input',
        ]);
        $this->add($password);


        $login = new Text('login');
        $login->setLabel(_('Login (e-mail)') . ' <span>*</span>');
        $login->setLabelOptions(['disable_html_escape' => true]);
        $login->setAttributes([
            'placeholder' => _('Login (e-mail)'),
            'class' => 'form-control border-input',
        ]);
        $this->add($login);


        $display_name = new Text('display_name');
        $display_name->setLabel(_('Display name'));
        $display_name->setAttributes([
            'placeholder' => _('Display name'),
            'class' => 'form-control border-input',
        ]);
        $this->add($display_name);


        $radio = new Radio('usertype');
        $radio->setLabel(_('User type'));
        $radio->setValueOptions(array(
            User::TYPE_EDITOR => _('Editor'),
            User::TYPE_ADMIN => _('Administrator'),
        ));
        $radio->setValue(User::TYPE_EDITOR);
        $this->add($radio);

        $active = new Checkbox('active');
        $active->setLabel(_('Active'));
        $active->setCheckedValue(1);
        $active->setUncheckedValue(0);
        $this->add($active);

        $multiCheckbox = new MultiCheckbox('allowed_categories');
        $multiCheckbox->setLabel(_('Allowed categories'));
        $multiCheckbox->setValueOptions(array());
        $this->add($multiCheckbox);

        $newPano = new Checkbox('new_pano');
        $newPano->setLabel(_('New pano creation'));
        $newPano->setCheckedValue(1);
        $newPano->setUncheckedValue(0);
        $this->add($newPano);

        $systemLogo = new File('system_logo');
        $systemLogo->setLabel(_('Logo'));
        $systemLogo->setAttributes([
            'placeholder' => _('Display name'),
            'class' => 'btn btn-success',
        ]);
        $this->add($systemLogo);

        $systemLogoLink = new Text('system_logo_link');
        $systemLogoLink->setLabel('Logo link');
        $systemLogoLink->setAttributes([
            'placeholder' => _('System logo link'),
            'class' => 'form-control border-input',
        ]);
        $this->add($systemLogoLink);

        $systemLogoRemove = new Checkbox('system_logo_remove');
        $systemLogoRemove->setLabel(_('Remove branding'));
        $systemLogoRemove->setCheckedValue(1);
        $systemLogoRemove->setUncheckedValue(0);
        $this->add($systemLogoRemove);

        $this->add(array(
            'name' => 'submit',
            'attributes' => array(
                'type' => 'submit',
                'value' => _('Save'),
                'id' => 'submit',
                'class' => 'btn btn-success',
            ),
        ));

        //validation
        $inputFilter = new InputFilter();

        $passwordFilter = new Input('password');
        $passwordFilter->getValidatorChain()->attach(new NotEmpty())->attach(new StringLength([
            'min' => 6,
            'max' => 64
        ]));
        $inputFilter->add($passwordFilter);

        $changePasswordFilter = new Input('change_password');
        $changePasswordFilter->setRequired(false);
        $inputFilter->add($changePasswordFilter);

        $nameFilter = new Input('allowed_categories');
        $nameFilter->setRequired(false);
        $inputFilter->add($nameFilter);

        $logoFilter = new Input('system_logo');
        $logoFilter->setRequired(false);
        $inputFilter->add($logoFilter);

        $logoFilter = new Input('system_logo');
        $logoFilter->setRequired(false);
        $inputFilter->add($logoFilter);

        $logoLinkFilter = new Input('system_logo_link');
        $logoLinkFilter->setRequired(false);
        $inputFilter->add($logoLinkFilter);

        $logoRemoveFilter = new Input('system_logo_remove');
        $logoRemoveFilter->setRequired(false);
        $inputFilter->add($logoRemoveFilter);

        $this->setInputFilter($inputFilter);

    }
}
