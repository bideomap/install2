<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Form;

use Laminas\Form\Element\Hidden;
use Laminas\Form\Element\Text;
use Laminas\Form\Fieldset;

class VideoSceneFieldsetForm extends Fieldset
{
    protected $pano_id;

    public function __construct()
    {
        parent::__construct('panos_fs');

        $this->add(new Hidden('language_id'));
        $this->add(new Hidden('language'));

        $name = new Text('name');
        $name->setLabel(_('Name') . ' <span>*</span>');
        $name->setLabelOptions(['disable_html_escape' => true]);
        $name->setAttributes(['placeholder' => _('Scene name'), 'class' => 'form-control text-input input', 'id' => '', 'data-required' => 1]);
        $this->add($name);
    }

}




