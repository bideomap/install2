<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

/**
 * Class ACL defines roles of users in the system and is used mainly to prevent editors from doing unauthorized tasks
 *
 * @package Application\Model
 */
class ACL
{

    /**
     * Checks if the user is allowed to perform given action
     *
     * @param $role
     * @param $module
     * @param $action
     *
     * @return bool
     */
    public static function isAllowed($role, $module, $action)
    {
        $acl['categories']['new'] = array('developer', 'admin');
        $acl['categories']['delete'] = array('developer', 'admin');

        $acl['pano']['new'] = array('developer', 'admin');
        $acl['pano']['delete'] = array('developer', 'admin');

        $acl['siteplans']['new'] = array('developer', 'admin');
        $acl['siteplans']['delete'] = array('developer', 'admin');

        $acl['media']['new'] = array('developer', 'admin', 'editor');
        $acl['media']['delete'] = array('developer', 'admin');

        $acl['site-plans']['new'] = array('developer', 'admin');
        $acl['site-plans']['delete'] = array('developer', 'admin');

        $acl['galleries']['new'] = array('developer', 'admin', 'editor');
        $acl['galleries']['delete'] = array('developer', 'admin', 'editor');

        $acl['administration']['new'] = array('developer', 'admin');
        $acl['administration']['delete'] = array('developer', 'admin');

        $acl['administration']['backup'] = array('developer');

        $acl['administration']['clone'] = array('developer');
        $acl['administration']['register'] = array('developer');
        $acl['administration']['unregister'] = array('developer');

        if (isset($acl[$module][$action])) {
            return in_array($role, $acl[$module][$action]);
        }

        return false;
    }
}
