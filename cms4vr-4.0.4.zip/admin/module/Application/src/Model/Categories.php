<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

class Categories extends MainModel
{
    public $id;
    public $position;
    public $starting_pano;
    public $facebook_id;
    public $twitter_id;

    public function exchangeArray($data)
    {
        $this->id = (isset($data['id'])) ? $data['id'] : null;
        $this->position = (isset($data['position'])) ? $data['position'] : null;
        $this->starting_pano = (isset($data['starting_pano'])) ? $data['starting_pano'] : null;
        $this->facebook_id = (isset($data['facebook_id'])) ? $data['facebook_id'] : null;
        $this->twitter_id = (isset($data['twitter_id'])) ? $data['twitter_id'] : null;
    }
}
