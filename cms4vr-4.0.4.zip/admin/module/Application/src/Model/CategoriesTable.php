<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

use Laminas\Db\Adapter\Adapter;
use Laminas\Db\ResultSet\ResultSet;
use Laminas\Db\Sql\Expression;
use Laminas\Db\Sql\Select;
use Laminas\Db\Sql\Sql;
use Laminas\Db\TableGateway\TableGateway;

/**
 * Class CategoriesTable
 *
 * @package Project\Model
 */
class CategoriesTable
{
    private $tableGateway;
    private $table = 'categories';

    /**
     * @param TableGateway $tableGateway
     */
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;

        $result = $this->tableGateway->getAdapter()->query(
            'PRAGMA table_info("categories")',
            Adapter::QUERY_MODE_EXECUTE
        )->toArray();

        $exists = false;

        foreach ($result as $item) {
            if ($item['name'] === 'hide') {
                $exists = true;
                break;
            }
        }

        if (!$exists) {
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `categories` ADD `hide` INTEGER',
                Adapter::QUERY_MODE_EXECUTE
            );
            $this->tableGateway->getAdapter()->query(
                'UPDATE `categories` SET `hide`=0',
                Adapter::QUERY_MODE_EXECUTE
            );
        }
    }

    /**
     * Get category by  ID
     *
     * @param $id
     *
     * @return array|\ArrayObject|null
     */
    public function getById($id)
    {
        return $this->tableGateway->select(['id' => $id])->current();
    }

    /**
     * Delete data by id
     *
     * @param $id
     *
     * @return array|\ArrayObject|null
     */
    public function deleteById($id)
    {
        return $this->tableGateway->delete(['id' => $id]);
    }

    /**
     * Get categories, optionally filtering it by list of allowed categories for editors
     *
     * @param $allowed_categories
     *
     * @return array|\ArrayObject|null
     */
    public function getCategories($allowed_categories = null)
    {
        $sql = new Sql($this->tableGateway->getAdapter());
        $select = $sql->select()->from($this->table);
        $select->join('category_phrases', 'categories.id = category_phrases.categories_id', ['name', 'description']);
        $select->join('languages', 'category_phrases.languages_id = languages.id', ['short']);
        $select->join('pano_category_connections', 'pano_category_connections.category_id = categories.id',
                      ['pano_count' => new Expression('COUNT(pano_category_connections.id)')], Select::JOIN_LEFT);

        if ($allowed_categories) {
            $select->where(['categories.id' => $allowed_categories]);
        }

        $select->group('category_phrases.id');
        $select->order('position ASC');
        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        $categories = [];

        foreach ($result as $category) {
            if (!isset($categories[$category['id']])) {
                $categories[$category['id']] =
                    [
                        'position'    => $category['position'],
                        'facebook_id' => $category['facebook_id'],
                        'twitter_id'  => $category['twitter_id'],
                        'pano_count'  => $category['pano_count'],
                        'hide'        => $category['hide'],
                    ];
                $categories[$category['id']]['name'][$category['short']] = $category['name'];
            } else {
                $categories[$category['id']]['name'][$category['short']] = $category['name'];
            }
        }

        return $categories;
    }

    /**
     * Get category by category ID
     *
     * @param $category_id
     *
     * @return array|\ArrayObject|null
     */
    public function getByCategoryId($category_id)
    {
        $sql = new Sql($this->tableGateway->getAdapter());
        $select = $sql->select()->from($this->table);
        $select->join('category_phrases', 'categories.id = category_phrases.categories_id', [
            'name',
            'description',
            'category_phrase_id' => 'id',
            'languages_id',
            'media_id'
        ]);

        $select->join('languages', 'category_phrases.languages_id = languages.id', [
            'short',
            'long'
        ]);

        $select->join('pano_category_connections', 'pano_category_connections.category_id = categories.id', [
            'connection_id' => 'id', 'pano_id'

        ], Select::JOIN_LEFT);

        $select->where(['categories.id' => $category_id]);
        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        $returnArray = [];
        foreach ($result as $key => $value) {

            //create array to populate
            $returnArray['category_fs'][$value['languages_id']] = array('name' => $value['name'],
                'description' => $value['description'],
                'category_phrase_id' => $value['category_phrase_id'],
                'language' => $value['short'],
                'language_id' => $value['languages_id'],
                'media_id' => $value['media_id']
            );

            $returnArray['facebook_id'] = $value['facebook_id'];
            $returnArray['twitter_id'] = $value['twitter_id'];
            $returnArray['id'] = $value['id'];
            $returnArray['starting_pano'] = $value['starting_pano'];
            $returnArray['panorama'][$value['pano_id']] = 1;
        }


        return $returnArray;
    }

    /**
     * Saves or updates category entry in the database
     *
     * @param Categories $category
     *
     * @return int || null
     */
    public function save(Categories $category)
    {
        if ((int)$category->id == 0) {
            $category->id = null;
            $this->tableGateway->insert($category->getArrayCopy());

            //return id
            $lastInsertedId = $this->tableGateway->getLastInsertValue();

            return $lastInsertedId;
        } else {

            $this->tableGateway->update(array_filter($category->getArrayCopy()), ['id' => $category->id]);

            return $category->id;
        }
    }

    /**
     * Updates category entry in the database
     *
     * @param int   $categoryId
     * @param array $categoryData
     *
     * @return int || null
     */
    public function update($categoryId, $categoryData)
    {
        if ($categoryId < 1) return false;

        $this->tableGateway->update($categoryData, ['id' => $categoryId]);

        return true;
    }

    /**
     * Gets list of categories and panos and returns a multidimensional array
     *
     * At each level (pano or category), names for given element are keyed with short language mark
     *
     * @param bool|true $onlyVisible
     *
     * @return array
     */
    public function getCategoriesWithPanos($onlyVisible = true)
    {
        $select = new Select();
        $select->from($this->table);
        $select->join('category_phrases', 'category_phrases.categories_id = categories.id',
                      ['cat_name' => 'name', 'categories_id', 'cat_description' => 'description', 'cat_media_id' => 'media_id']);
        $select->join(['cat_lang' => 'languages'], 'category_phrases.languages_id = cat_lang.id',
                      ['cat_short' => 'short']);
        $select->join('pano_category_connections', 'categories.id = pano_category_connections.category_id');
        $select->join('panos', 'panos.id = pano_category_connections.pano_id');
        $select->join('pano_phrases', 'pano_phrases.panos_id = panos.id', ['pano_name' => 'name', 'pano_media_id' => 'media_id']);
        $select->join(['pano_lang' => 'languages'], 'pano_phrases.languages_id = pano_lang.id',
                      ['pano_short' => 'short']);

        if ($onlyVisible) {
            $select->where(['panos.visible' => 1]);
        }

        $select->order(['categories.position', 'pano_category_connections.pano_position']);

        $sql = new Sql($this->tableGateway->getAdapter());
        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        $return = [];

        foreach ($result as $row) {

            // categories level
            if (!isset($return[$row['categories_id']])) {
                $return[$row['categories_id']] =
                    [
                        'facebook_id'   => $row['facebook_id'],
                        'twitter_id'    => $row['twitter_id'],
                        'starting_pano' => $row['starting_pano'],
                        'hide'       => $row['hide'],
                    ];
            }
            $return[$row['categories_id']]['phrases'][$row['cat_short']] =
                ['name' => $row['cat_name'], 'description' => $row['cat_description'], 'media_id' => $row['cat_media_id']];

            // panos level
            if (!isset($return[$row['categories_id']]['panos'][$row['pano_id']])) {
                $return[$row['categories_id']]['panos'][$row['pano_id']] =
                    ['lat' => $row['lat'], 'lng' => $row['lng'], 'visible' => $row['visible'] == 1 ? 'true' : 'false'];
            }
            $return[$row['categories_id']]['panos'][$row['pano_id']]['phrases'][$row['pano_short']] = ['name' => $row['pano_name'], 'media_id' => $row['pano_media_id']];
        }

        return $return;
    }

    /**
     * Returns numbers of categories for ordering purposes
     *
     * @return int
     */
    public function countCategories()
    {
        return $this->tableGateway->select()->count();
    }

    /**
     * Publishes or unpublishes given category in the project
     *
     * @param $id
     * @param $visible
     *
     * @return int
     */
    public function changeVisibility($id, $visible)
    {
        return $this->tableGateway->update(['hide' => $visible], ['id' => $id]);
    }
}
