<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

class CategoryPhrases extends MainModel
{
    public $id;
    public $categories_id;
    public $languages_id;
    public $name;
    public $description;
    public $media_id;

    public function exchangeArray($data)
    {

        $this->id = (isset($data['id'])) ? $data['id'] : null;
        $this->categories_id = (isset($data['categories_id'])) ? $data['categories_id'] : null;
        $this->languages_id = (isset($data['languages_id'])) ? $data['languages_id'] : null;
        $this->name = (isset($data['name'])) ? $data['name'] : null;
        $this->description = (isset($data['description'])) ? $data['description'] : null;
        $this->media_id = (isset($data['media_id'])) ? $data['media_id'] : null;

    }

}
