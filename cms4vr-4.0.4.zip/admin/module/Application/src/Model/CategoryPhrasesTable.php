<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;
use Laminas\Db\TableGateway\TableGateway;

/**
 * Class CategoryPhrasesTable
 *
 * @package Project\Model
 */
class CategoryPhrasesTable
{
    private $tableGateway;
    private $table = 'category_phrases';

    /**
     * @param TableGateway $tableGateway
     */
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    /**
     * Get category by  ID
     *
     * @param $id
     * @return array|\ArrayObject|null
     */
    public function getById($id)
    {
        return $this->tableGateway->select(array('id' => $id))->current();
    }

    /**
     * Get category phrases by project ID
     *
     * @param $project_id
     * @return array|\ArrayObject|null
     */
    public function getByCategoryId($project_id)
    {
        return $this->tableGateway->select(array('project_id' => $project_id));
    }

    /**
     * Saves or updates category phrase entry in the database
     *
     * @param CategoryPhrases $categoryPhrase
     *
     * @return int || null
     */
    public function save(CategoryPhrases $categoryPhrase)
    {
        if ((int)$categoryPhrase->id == 0) {
            $categoryPhrase->id = null;
            $this->tableGateway->insert($categoryPhrase->getArrayCopy());

            //return id
            $lastInsertedId = $this->tableGateway->getLastInsertValue();
            return $lastInsertedId;
        }

        $this->tableGateway->update($categoryPhrase->getArrayCopy(), array('id' => $categoryPhrase->id));
        return $categoryPhrase->id;
    }

    /**
     * Delete data by category id
     *
     * @param $category_id int
     * @return array|\ArrayObject|null
     */
    public function deleteByCategoryId($category_id)
    {
        return $this->tableGateway->delete(['categories_id' => $category_id]);
    }

    public function getByCategoryIdAndLanguageId($panoId, $languageId)
    {
        $panoId = (int) $panoId;
        $languageId = (int) $languageId;

        return $this->tableGateway->select(['categories_id' => $panoId, 'languages_id' => $languageId])->current();
    }


}
