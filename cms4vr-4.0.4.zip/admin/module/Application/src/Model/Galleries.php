<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

class Galleries extends MainModel
{
    public $id;
    public $position;
    public $name;

    public function exchangeArray($data)
    {
        $this->id = (isset($data['id'])) ? $data['id'] : null;
        $this->position = (isset($data['position'])) ? $data['position'] : null;
        $this->name = (isset($data['name'])) ? $data['name'] : null;
    }
}
