<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;
use Laminas\Db\ResultSet\ResultSet;
use Laminas\Db\Sql\Predicate\Expression;
use Laminas\Db\Sql\Select;
use Laminas\Db\Sql\Sql;
use Laminas\Db\TableGateway\TableGateway;

/**
 * Class GalleriesTable
 *
 * @package Project\Model
 */
class GalleriesTable
{
    private $tableGateway;
    private $table = 'galleries';

    /**
     * @param TableGateway $tableGateway
     */
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    /**
     * Get gallery by  ID
     *
     * @param $id
     * @return array|\ArrayObject|null
     */
    public function getById($id)
    {
        return $this->tableGateway->select(array('id' => $id))->current();
    }

    /**
     * Get gallery by ID
     *
     * @return array|\ArrayObject|null
     */
    public function getLastGalleryId()
    {
        $select = new Select();
        $select->from($this->table);
        $select->columns(array('max_id' => new Expression('MAX(id)')));

        $sql = new Sql($this->tableGateway->getAdapter());
        $statement = $sql->prepareStatementForSqlObject($select);

        $result = $statement->execute()->current();

        //if there is no galleries set max_id to 0
        $maxGalleryId = 0;

        if(is_numeric($result['max_id'])){
            $maxGalleryId = $result['max_id'];
        }

        return $maxGalleryId;
    }

    /**
     * Saves or updates gallery entry in the database
     *
     * @param Galleries $gallery
     *
     * @return int || null
     */
    public function save(Galleries $gallery)
    {
        if ((int)$gallery->id == 0) {
            $gallery->id = null;
            $this->tableGateway->insert($gallery->getArrayCopy());

            //return id
            $lastInsertedId = $this->tableGateway->getLastInsertValue();
            return $lastInsertedId;
        } else {

            $this->tableGateway->update($gallery->getArrayCopy(), array('id' => $gallery->id));
            return $gallery->id;
        }
    }

    /**
     * Get galleries list with number of media
     *
     * @return array | null
     */
    public function getGalleriesList()
    {
        $sql = new Sql($this->tableGateway->getAdapter());

        $galleries_media = new Select();
        $galleries_media->from('media_galleries_connections');
        $galleries_media->columns(['count' => new Expression('count(media_galleries_connections.id)')]);
        $galleries_media->where('media_galleries_connections.gallery_id = galleries.id');

        $galleries = new Select();
        $galleries->from($this->table);
        $galleries->columns(array('id', 'name', 'position', 'media_count' => $galleries_media));
        $galleries->join('gallery_phrases', 'gallery_phrases.galleries_id = galleries.id', ['phraseName' => 'name'], Select::JOIN_LEFT);
        $galleries->join('languages', 'languages.id = gallery_phrases.languages_id', ['short'], Select::JOIN_LEFT);
        $galleries->order('galleries.position');

        $statement = $sql->prepareStatementForSqlObject($galleries);

        $result = $statement->execute();

        $return = [];
        foreach($result as $gallery){
            if (!isset($return[$gallery['id']])) {
                $return[$gallery['id']] =
                    [
                        'position'    => $gallery['position'],
                        'media_count' => $gallery['media_count']
                    ];
                $return[$gallery['id']]['name'][$gallery['short']] = $gallery['phraseName'];
            } else {
                $return[$gallery['id']]['name'][$gallery['short']] = $gallery['phraseName'];
            }
        }

        return $return;
    }

    /**
     * Get galleries list with specific media
     *
     * @return array | null
     */
    public function getGalleriesListWithMedia()
    {
        $sql = new Sql($this->tableGateway->getAdapter());

        $galleries = new Select();
        $galleries->from($this->table);
        $galleries->columns(array('id', 'name', 'position'));
        $galleries->join('gallery_phrases', 'gallery_phrases.galleries_id = galleries.id', ['phraseName' => 'name'], Select::JOIN_LEFT);
        $galleries->join('languages', 'languages.id = gallery_phrases.languages_id', ['short'], Select::JOIN_LEFT);
        $galleries->join('media_galleries_connections', 'media_galleries_connections.gallery_id = galleries.id', [], Select::JOIN_LEFT);
        $galleries->join('media', 'media.id = media_galleries_connections.media_id', ['type', 'resource', 'mediaId' => 'id'], Select::JOIN_LEFT);
        $galleries->order('galleries.position, media_galleries_connections.position');

        $statement = $sql->prepareStatementForSqlObject($galleries);

        $result = $statement->execute();

        $return = [];
        foreach($result as $gallery){
            if (!isset($return[$gallery['id']])) {
                $return[$gallery['id']] =
                    [
                        'position'    => $gallery['position']
                    ];
                $return[$gallery['id']]['media'] = [];
                $return[$gallery['id']]['name'][$gallery['short']] = $gallery['phraseName'];
            } else {
                $return[$gallery['id']]['name'][$gallery['short']] = $gallery['phraseName'];
            }

            if ($gallery['mediaId']) {
                $return[$gallery['id']]['media'][$gallery['mediaId']] = [
                    'id' => $gallery['mediaId'],
                    'type' => $gallery['type'],
                    'resource' => $gallery['resource']
                ];
            }
        }

        return $return;
    }

    public function getByGalleryId($galleryId)
    {
        $sql = new Sql($this->tableGateway->getAdapter());
        $select = $sql->select()->from($this->table);
        $select->join('gallery_phrases', 'gallery_phrases.galleries_id = galleries.id', [
            'name',
            'gallery_phrase_id' => 'id',
            'languages_id',
        ]);

        $select->join('languages', 'gallery_phrases.languages_id = languages.id', [
            'short',
            'long'
        ]);

        $select->where(['galleries.id' => $galleryId]);
        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        $returnArray = [];
        foreach ($result as $key => $value) {

            //create array to populate
            $returnArray['gallery_fs'][$value['languages_id']] = [
                'name'              => $value['name'],
                'gallery_phrase_id' => $value['gallery_phrase_id'],
                'language'          => $value['short'],
                'language_id'       => $value['languages_id']
            ];

            $returnArray['id'] = $value['id'];
        }


        return $returnArray;
    }

    /**
     * Delete by gallery id
     *
     * @param $id
     * @return array|\ArrayObject|null
     */
    public function deleteById($id)
    {
        return $this->tableGateway->delete(array('id' => $id));
    }

    /**
     * Updates gallery entry in the database
     *
     * @param int $imageId
     * @param array $imageData
     *
     * @return int || null
     */
    public function update($imageId, $imageData)
    {
        if($imageId < 1) return false;

        $this->tableGateway->update($imageData, array('id' => $imageId));
        return true;
    }

}
