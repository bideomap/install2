<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

class GalleryPhrases extends MainModel
{
    public $id;
    public $galleries_id;
    public $languages_id;
    public $name;

    public function exchangeArray($data)
    {

        $this->id = (isset($data['id'])) ? $data['id'] : null;
        $this->galleries_id = (isset($data['galleries_id'])) ? $data['galleries_id'] : null;
        $this->languages_id = (isset($data['languages_id'])) ? $data['languages_id'] : null;
        $this->name = (isset($data['name'])) ? $data['name'] : null;

    }
}
