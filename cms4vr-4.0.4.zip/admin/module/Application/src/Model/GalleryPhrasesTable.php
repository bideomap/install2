<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;
use Laminas\Db\TableGateway\TableGateway;

/**
 * Class GalleryPhrasesTable
 *
 * @package Application\Model
 */
class GalleryPhrasesTable
{
    private $tableGateway;
    private $table = 'gallery_phrases';

    /**
     * @param TableGateway $tableGateway
     */
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    /**
     * Get gallery by ID
     *
     * @param $id
     * @return array|\ArrayObject|null
     */
    public function getById($id)
    {
        return $this->tableGateway->select(array('id' => $id))->current();
    }

    /**
     * Saves or updates gallery phrase entry in the database
     *
     * @param GalleryPhrases $galleryPhrase
     *
     * @return int | null
     *
     */
    public function save(GalleryPhrases $galleryPhrase)
    {
        if ((int)$galleryPhrase->id == 0) {
            $galleryPhrase->id = null;
            $this->tableGateway->insert($galleryPhrase->getArrayCopy());

            //return id
            $lastInsertedId = $this->tableGateway->getLastInsertValue();
            return $lastInsertedId;
        } else {
            $this->tableGateway->update($galleryPhrase->getArrayCopy(), array('id' => $galleryPhrase->id));
            return $galleryPhrase->id;
        }
    }

    /**
     * Delete data by gallery id
     *
     * @param $galleriy_id
     *
     * @return array|\ArrayObject|null
     */
    public function deleteByGalleryId($galleriy_id)
    {
        return $this->tableGateway->delete(['galleries_id' => $galleriy_id]);
    }
}
