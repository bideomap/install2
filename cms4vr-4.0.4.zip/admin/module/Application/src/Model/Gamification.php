<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

class Gamification extends MainModel
{
    public $id;
    public $name;
    public $hide;

    public function exchangeArray($data)
    {
        $this->id = (isset($data['id'])) ? (int)$data['id'] : null;
        $this->name = (isset($data['name'])) ? $data['name'] : null;
        $this->hide = (isset($data['hide'])) ? $data['hide'] : null;
    }
}
