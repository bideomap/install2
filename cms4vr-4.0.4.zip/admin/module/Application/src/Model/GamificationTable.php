<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

use Laminas\Db\Adapter\Adapter;
use Laminas\Db\TableGateway\TableGateway;

/**
 * Class GamificationTable manages language signed to projects
 *
 * @package Project\Model
 */
class GamificationTable
{
    private $tableGateway;
    private $table = 'gamification';

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
        $result = $this->tableGateway->getAdapter()->query(
            'SELECT name FROM sqlite_master WHERE type="table" AND name="gamification"',
            Adapter::QUERY_MODE_EXECUTE
        )->toArray();

        if (!$result) {
            $this->tableGateway->getAdapter()->query(
                'CREATE TABLE "gamification" (
                    "id"    INTEGER,
                    "name"    TEXT,
                    "hide"    INTEGER,
                    PRIMARY KEY("id" AUTOINCREMENT))',
                Adapter::QUERY_MODE_EXECUTE
            );

            $this->tableGateway->getAdapter()->query(
                'INSERT INTO "gamification" ("id", "name", "hide") VALUES ("1", "Puzzle Cubic", "1")',
                Adapter::QUERY_MODE_EXECUTE
            );
        }
    }

    public function fetchAll()
    {
        return $this->tableGateway->select();
    }

    public function getById($id)
    {
        return $this->tableGateway->select(['id' => $id])->current();
    }

    public function save(Gamification $gamification)
    {

        if ((int)$gamification->id == 0) {

            $gamification->id = null;

            $this->tableGateway->insert($gamification->getArrayCopy());

            //return id
            return $this->tableGateway->getLastInsertValue();
        }
            $this->tableGateway->update(array_filter($gamification->getArrayCopy()), ['id' => $gamification->id]);

            return true;
    }

    /**
     * Publishes or unpublishes given language in the project
     *
     * @param $id int
     * @param $hidden bool
     *
     * @return int
     */
    public function changeVisibility($id, $hidden)
    {

        return $this->tableGateway->update(['hide' => $hidden], ['id' => $id]);
    }
}
