<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

class Languages extends MainModel
{
    public $id;
    public $short;
    public $long;
    public $position;
    public $voice;
    public $public;

    public function exchangeArray($data)
    {
        $this->id = (isset($data['id'])) ? (int)$data['id'] : null;
        $this->short = (isset($data['short'])) ? $data['short'] : null;
        $this->long = (isset($data['long'])) ? $data['long'] : null;
        $this->position = (isset($data['position'])) ? $data['position'] : null;
        $this->voice = (isset($data['voice'])) ? $data['voice'] : null;
        $this->public = (isset($data['public'])) ? $data['public'] : null;
    }
}
