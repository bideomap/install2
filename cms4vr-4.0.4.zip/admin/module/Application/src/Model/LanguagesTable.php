<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

use Laminas\Db\Sql\Select;
use Laminas\Db\Sql\Sql;
use Laminas\Db\TableGateway\TableGateway;

/**
 * Class LanguageTable manages language signed to projects
 *
 * @package Project\Model
 */
class LanguagesTable
{
    private $tableGateway;
    private $table = 'languages';

    /**
     * @param TableGateway $tableGateway
     */
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    /**
     * Get language by its ID
     *
     * @param $id
     *
     * @return array|\ArrayObject|null
     */
    public function getById($id)
    {
        return $this->tableGateway->select(['id' => $id])->current();
    }

    /**
     * Returns language rows
     *
     * @param $public      bool return only public (published) languages
     *
     * @return \Laminas\Db\ResultSet\ResultSet
     */
    public function getLanguages($public = true)
    {
        if ($public) {
            return $this->tableGateway->select(function (Select $select) {
                $select->where(['public' => 1])->order('position ASC');
            });
        } else {
            return $this->tableGateway->select(function (Select $select) {
                $select->order('position ASC');
            });
        }
    }

    /**
     * Returns language row based on the project id and short name
     *
     * @param $projects_id int
     *
     * @param $shortName
     *
     * @return array|\ArrayObject|null
     */
    public function getLanguageByProjectIdAndShortName($projects_id, $shortName)
    {
        return $this->tableGateway->select(['projects_id' => $projects_id, 'short' => $shortName])->current();
    }

    public function getLanguageByShortName($shortName)
    {
        return $this->tableGateway->select(['short' => $shortName])->current();
    }

    /**
     * Saves or updates language entry in the database
     *
     * @param Languages $language
     *
     * @return int || null
     */
    public function save(Languages $language)
    {

        if ((int)$language->id == 0) {

            $language->id = null;

            $this->tableGateway->insert($language->getArrayCopy());

            //return id
            $lastInsertedId = $this->tableGateway->getLastInsertValue();

            return $lastInsertedId;
        } else {
            $this->tableGateway->update(array_filter($language->getArrayCopy()), ['id' => $language->id]);

            return true;
        }
    }

    /**
     * Publishes or unpublishes given language in the project
     *
     * @param $id
     * @param $public
     *
     * @return int
     */
    public function changeVisibility($id, $public)
    {

        return $this->tableGateway->update(['public' => $public], ['id' => $id]);
    }

    /**
     * Delete language by its ID
     *
     * @param $id
     *
     * @return array|\ArrayObject|null
     */
    public function deleteById($id)
    {
        return $this->tableGateway->delete(['id' => $id]);
    }

    public function getByShort($short)
    {
        return $this->tableGateway->select(['short' => $short])->current();
    }

    /**
     * Copies required phrases on a database level
     *
     * (title/description of the project, panos, categories and names of site plans and galleries)
     *
     * @param $from
     * @param $to
     */
    public function copyLanguagePhrases($from, $to)
    {

        $fromShort = $this->getById($from)->short;
        $toShort = $this->getById($to)->short;

        $sql = new Sql($this->tableGateway->getAdapter());

        $select = $sql->select()->from('settings')->where(['key' => 'project_lang_settings']);
        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute()->current();
        $projectLangSettings = json_decode($result['value'], true);
        $projectLangSettings[$toShort] = $projectLangSettings[$fromShort];

        $update = $sql->update('settings')->set(['value' => json_encode($projectLangSettings)])->where(['key' => 'project_lang_settings']);
        $statement = $sql->prepareStatementForSqlObject($update);
        $statement->execute();

        $phrasesTables = ['pano_phrases', 'category_phrases', 'site_plans_phrases', 'gallery_phrases'];

        foreach ($phrasesTables as $phrasesTable) {
            $select = $sql->select()->from($phrasesTable)->where(['languages_id' => $from]);
            $statement = $sql->prepareStatementForSqlObject($select);
            $result = $statement->execute();

            foreach ($result as $item) {
                $item['id'] = null;
                $item['languages_id'] = $to;
                $insert = $sql->insert($phrasesTable)->values($item);
                $insertStatement = $sql->prepareStatementForSqlObject($insert);
                $insertStatement->execute();
            }
        }
    }

    /**
     * Updates language entry in the database
     *
     * @param int   $languageId
     * @param array $languageData
     *
     * @return int || null
     */
    public function update($languageId, $languageData)
    {
        if ($languageId < 1) return false;

        $this->tableGateway->update($languageData, ['id' => $languageId]);

        return true;
    }
}
