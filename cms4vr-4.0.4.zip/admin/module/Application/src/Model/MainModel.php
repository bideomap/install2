<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;


class MainModel
{
    public function getArrayCopy()
    {
        $values = get_object_vars($this);
        $values = array_map(function($value) {
            return $value === "" ? null : $value;
        }, $values);
        return $values;
    }
}
