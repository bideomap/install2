<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

class Media extends MainModel
{
    public $id;
    public $type;
    public $resource;
    public $date_uploaded;
    public $original_name;

    public function exchangeArray($data)
    {
        $this->id = (isset($data['id'])) ? $data['id'] : null;
        $this->type = (isset($data['type'])) ? $data['type'] : null;
        $this->resource = (isset($data['resource'])) ? $data['resource'] : null;
        $this->date_uploaded = (isset($data['date_uploaded'])) ? $data['date_uploaded'] : null;
        $this->original_name = (isset($data['original_name'])) ? $data['original_name'] : null;
    }
}
