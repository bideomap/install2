<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

class MediaGalleriesConnections extends MainModel
{
    public $id;
    public $media_id;
    public $gallery_id;
    public $position;

    public function exchangeArray($data)
    {
        $this->id = (isset($data['id'])) ? $data['id'] : null;
        $this->media_id = (isset($data['media_id'])) ? $data['media_id'] : null;
        $this->gallery_id = (isset($data['gallery_id'])) ? $data['gallery_id'] : null;
        $this->position = (isset($data['position'])) ? $data['position'] : null;
    }
}
