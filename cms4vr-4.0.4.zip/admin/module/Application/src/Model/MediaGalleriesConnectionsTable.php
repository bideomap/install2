<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

use Laminas\Db\Sql\Select;
use Laminas\Db\Sql\Sql;
use Laminas\Db\TableGateway\TableGateway;

/**
 * Class MediaGalleriesConnectionsTable
 *
 * @package Application\Model
 */
class MediaGalleriesConnectionsTable
{
    private $tableGateway;
    private $table = 'media_galleries_connections';

    /**
     * @param TableGateway $tableGateway
     */
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    /**
     * Get connection by its ID
     *
     * @param $id
     *
     * @return array|\ArrayObject|null
     */
    public function getById($id)
    {
        return $this->tableGateway->select(['id' => $id])->current();
    }


    /**
     * Saves or updates connection entry in the database
     *
     * @param MediaGalleriesConnections $connection
     *
     * @return int || null
     */
    public function save(MediaGalleriesConnections $connection)
    {
        if ((int)$connection->id == 0) {
            $connection->id = null;
            $this->tableGateway->insert($connection->getArrayCopy());

            //return id
            $lastInsertedId = $this->tableGateway->getLastInsertValue();

            return $lastInsertedId;
        } else {
            $this->tableGateway->update($connection->getArrayCopy(), ['id' => $connection->id]);

            return true;
        }
    }

    public function saveConnections($galleryId, $connections)
    {
        $this->clearConnectionsByGalleryId($galleryId);

        $position = 0;

        foreach ($connections as $connectionId) {
            $this->tableGateway->insert(['gallery_id' => $galleryId, 'media_id' => $connectionId, 'position' => $position]);
            $position++;
        }
    }

    /**
     * Updates position of media elements in the gallery
     *
     * @param $connectionId
     * @param $position
     */
    public function updatePosition($connectionId, $position)
    {
        $this->tableGateway->update(['position' => $position], ['id' => $connectionId]);
    }

    /**
     * Retrieves list of connections between given gallery and media resources
     *
     * @param $galleriesId
     *
     * @return \Laminas\Db\ResultSet\ResultSet
     */
    public function getConnectionsByGallery($galleriesId)
    {
        $sql = new Sql($this->tableGateway->getAdapter());

        $select = new Select();
        $select->from($this->table);
        $select->columns(array('media_id', 'position', 'connectionId' => 'id'));
        $select->join('media', 'media.id = media_galleries_connections.media_id', ['*']);
        $select->where(['gallery_id' => $galleriesId]);
        $select->order('media_galleries_connections.position');

        $statement = $sql->prepareStatementForSqlObject($select);

        $result = $statement->execute();

        return $result;
    }

    /**
     * Clear connections by gallery id
     * @param       $galleryId
     * @return bool
     */
    public function clearConnectionsByGalleryId($galleryId)
    {
        $this->tableGateway->delete(['gallery_id' => $galleryId]);
    }

}
