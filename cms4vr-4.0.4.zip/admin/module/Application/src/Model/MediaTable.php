<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;
use Laminas\Db\ResultSet\ResultSet;
use Laminas\Db\Sql\Predicate\Expression;
use Laminas\Db\Sql\Predicate\Like;
use Laminas\Db\Sql\Predicate\PredicateSet;
use Laminas\Db\Sql\Select;
use Laminas\Db\Sql\Sql;
use Laminas\Db\Sql\Where;
use Laminas\Db\TableGateway\TableGateway;

/**
 * Class MediaTable
 *
 * @package Application\Model
 */
class MediaTable
{
    private $tableGateway;
    private $table = 'media';

    /**
     * @param TableGateway $tableGateway
     */
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    /**
     * Get media by ID
     *
     * @param $id
     * @return array|\ArrayObject|null
     */
    public function getById($id)
    {
        return $this->tableGateway->select(array('id' => $id))->current();
    }

    /**
     * Get media by resource
     *
     * @param $id
     * @return array|\ArrayObject|null
     */
    public function getByresource($resource)
    {
        return $this->tableGateway->select(array('resource' => $resource))->current();
    }

    /**
     * Saves or updates media entry in the database
     *
     * @param Media $media
     * @return int | null
     *
     */
    public function save(Media $media)
    {
        if ((int)$media->id == 0) {
            $media->id = null;
            $this->tableGateway->insert($media->getArrayCopy());

            //return id
            $lastInsertedId = $this->tableGateway->getLastInsertValue();
            return $lastInsertedId;
        } else {

            $this->tableGateway->update($media->getArrayCopy(), array('id' => $media->id));
            return $media->id;
        }
    }

    /**
     * Get media, optionally filtering by type
     *
     * @param array $type
     * @return array|null
     */
    public function getMedia($type = [], $extensions = [])
    {
        $sql = new Sql($this->tableGateway->getAdapter());

        $select = new Select();
        $select->from($this->table);

        if ($type) {
            $select->where(['type' => $type]);
        }

        if ($extensions) {
            $predicateSet = new PredicateSet();
            foreach ($extensions as $extension) {
                $extension = preg_replace("/[^a-zA-Z0-9]+/", '', $extension);
                $predicateSet->addPredicate(new Like('original_name', '%.' . $extension), PredicateSet::COMBINED_BY_OR);
            }
            $select->where->addPredicate($predicateSet);
        }

        $select->order('date_uploaded DESC');

        $statement = $sql->prepareStatementForSqlObject($select);

        return $statement->execute();
    }

    /**
     * Delete by media id
     *
     * @param $id
     * @return int
     */
    public function deleteById($id)
    {
        return $this->tableGateway->delete(array('id' => $id));
    }
}
