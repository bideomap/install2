<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

class PanoCategoryConnections extends MainModel
{
    public $id;
    public $pano_id;
    public $category_id;
    public $pano_position;


    public function exchangeArray($data)
    {
        $this->id = (isset($data['id'])) ? $data['id'] : null;
        $this->pano_id = (isset($data['pano_id'])) ? $data['pano_id'] : null;
        $this->category_id = (isset($data['category_id'])) ? $data['category_id'] : null;
        $this->pano_position = (isset($data['pano_position'])) ? $data['pano_position'] : null;
    }
}
