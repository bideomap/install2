<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

use Laminas\Db\Sql\Select;
use Laminas\Db\Sql\Sql;
use Laminas\Db\TableGateway\TableGateway;

/**
 * Class PanoCategoryConnectionsTable
 *
 * @package Project\Model
 */
class PanoCategoryConnectionsTable
{
    private $tableGateway;
    private $table = 'pano_category_connections';

    /**
     * @param TableGateway $tableGateway
     */
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    /**
     * Get connection by its ID
     *
     * @param $id
     *
     * @return array|\ArrayObject|null
     */
    public function getById($id)
    {
        return $this->tableGateway->select(['id' => $id])->current();
    }


    /**
     * Saves or updates connection entry in the database
     *
     * @param PanoCategoryConnections $connection
     *
     * @return int || null
     */
    public function save(PanoCategoryConnections $connection)
    {
        if ((int)$connection->id == 0) {
            $connection->id = null;
            $this->tableGateway->insert($connection->getArrayCopy());

            //return id
            $lastInsertedId = $this->tableGateway->getLastInsertValue();

            return $lastInsertedId;
        } else {
            $this->tableGateway->update($connection->getArrayCopy(), ['id' => $connection->id]);

            return true;
        }
    }

    /**
     * Retrieves list of connections between given pano and existing categories
     *
     * @param $pano_id
     *
     * @return \Laminas\Db\ResultSet\ResultSet
     */
    public function getConnectionsByPano($pano_id)
    {
        return $this->tableGateway->select(['pano_id' => $pano_id]);
    }

    /**
     * Clear connections by category id
     * @param       $categoryId
     * @return bool
     */
    public function clearConnectionsByCategoryId($categoryId)
    {
        $this->tableGateway->delete(['category_id' => $categoryId]);
    }

    /**
     * Get connections by category id
     * @param       $categoryId
     * @return array
     */
    public function getConnectionsByCategoryId($categoryId)
    {
        $result = $this->tableGateway->select(['category_id' => $categoryId]);
        $return = [];
        foreach ($result as $item) {
            $return[$item->pano_id] = $item->pano_position;
        }
        return $return;
    }

    /**
     * Updates position of panoramas within category
     *
     * @param $panoId
     * @param $categoryId
     * @param $position
     *
     * @return int
     */
    public function updatePosition($panoId, $categoryId, $position)
    {
        return $this->tableGateway->update(['pano_position' => $position], ['pano_id' => $panoId, 'category_id' => $categoryId]);
    }
}
