<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

class PanoPhrases extends MainModel
{
    public $id;
    public $panos_id;
    public $languages_id;
    public $media_id;
    public $name;
    public $description;
    public $gallery_name;
    public $gallery_description;

    public function exchangeArray($data)
    {

        $this->id = (isset($data['id'])) ? $data['id'] : null;
        $this->panos_id = (isset($data['panos_id'])) ? $data['panos_id'] : null;
        $this->languages_id = (isset($data['languages_id'])) ? $data['languages_id'] : null;
        $this->media_id = (isset($data['media_id'])) ? $data['media_id'] : null;
        $this->name = (isset($data['name'])) ? $data['name'] : null;
        $this->description = (isset($data['description'])) ? $data['description'] : null;
        $this->gallery_name = (isset($data['gallery_name'])) ? $data['gallery_name'] : null;
        $this->gallery_description = (isset($data['gallery_description'])) ? $data['gallery_description'] : null;

    }
}
