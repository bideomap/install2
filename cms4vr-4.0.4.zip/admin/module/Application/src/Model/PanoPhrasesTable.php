<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;
use Laminas\Db\TableGateway\TableGateway;

/**
 * Class PanoPhrasesTable
 *
 * @package Project\Model
 */
class PanoPhrasesTable
{
    private $tableGateway;
    private $table = 'pano_phrases';

    /**
     * @param TableGateway $tableGateway
     */
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    /**
     * Get pano phrase by  ID
     *
     * @param $id
     * @return array|\ArrayObject|null
     */
    public function getById($id)
    {
        return $this->tableGateway->select(array('id' => $id))->current();
    }

    /**
     * Get pano phrases by project ID
     *
     * @param $project_id
     * @return array|\ArrayObject|null
     */
    public function getByCategoryId($project_id)
    {
        return $this->tableGateway->select(array('project_id' => $project_id));
    }

    /**
     * Saves or updates category phrase entry in the database
     *
     * @param PanoPhrases $panoPhrase
     *
     * @return int || null
     */
    public function save(PanoPhrases $panoPhrase)
    {
        if ((int)$panoPhrase->id == 0) {
            $panoPhrase->id = null;
            $this->tableGateway->insert($panoPhrase->getArrayCopy());

            //return id
            return $this->tableGateway->getLastInsertValue();
        }

        $this->tableGateway->update($panoPhrase->getArrayCopy(), array('id' => $panoPhrase->id));
        return $panoPhrase->id;
    }

    /**
     * Gets all phrases assigned to the requested pano
     *
     * @param $pano_id
     *
     * @return \Laminas\Db\ResultSet\ResultSet
     */
    public function getPhrasesForPano($pano_id)
    {
        return $this->tableGateway->select(['panos_id' => $pano_id]);
    }

    public function getByPanoIdAndLanguageId($panoId, $languageId)
    {
        $panoId = (int) $panoId;
        $languageId = (int) $languageId;

        return $this->tableGateway->select(['panos_id' => $panoId, 'languages_id' => $languageId])->current();
    }

}
