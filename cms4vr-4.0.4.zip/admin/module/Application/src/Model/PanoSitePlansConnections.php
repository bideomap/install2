<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

/**
 * Class PanoSitePlansConnections represents linkages between site plans and pano
 *
 * Coordinates are stored in coordinates field, and these are comma-separated entries specifying marker position (x,y)
 * and site plan background offset (also x,y)
 *
 * @package Application\Model
 */
class PanoSitePlansConnections extends MainModel
{

    public $id;
    public $panos_id;
    public $site_plans_id;
    public $coordinates;

    public function exchangeArray($data)
    {
        $this->id = (isset($data['id'])) ? $data['id'] : null;
        $this->panos_id = (isset($data['panos_id'])) ? $data['panos_id'] : null;
        $this->site_plans_id = (isset($data['site_plans_id'])) ? $data['site_plans_id'] : null;
        $this->coordinates = (isset($data['coordinates'])) ? $data['coordinates'] : null;
    }
}
