<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;


use Laminas\Db\TableGateway\TableGateway;

/**
 * Class PanoSitePlansConnectionsTable provides functionalities to manage linkages between panos and site plans saved in
 * the database
 *
 * @see     PanoSitePlansConnections
 *
 * @package Project\Model
 */
class PanoSitePlansConnectionsTable
{
    private $tableGateway;
    private $table = 'pano_site_plans_connections';

    /**
     * @param TableGateway $tableGateway
     */
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    /**
     * Saves PoiPhrase instance in the database
     *
     * @param PanoSitePlansConnections $connection
     *
     * @return int
     *
     */
    public function save(PanoSitePlansConnections $connection)
    {
        if ((int)$connection->id == 0) {
            $connection->id = null;
            $this->tableGateway->insert($connection->getArrayCopy());

            //return id
            $lastInsertedId = $this->tableGateway->getLastInsertValue();

            return $lastInsertedId;
        } else {
            $this->tableGateway->update(array_filter($connection->getArrayCopy()), ['id' => $connection->id]);

            return $connection->id;
        }
    }

    /**
     * Deletes any linkage between pano and site plan based on pano ID
     *
     * @param $panosId
     *
     * @return int
     */
    public function deleteByPanosId($panosId)
    {
        return $this->tableGateway->delete(['panos_id' => $panosId]);
    }

    /**
     * Deletes specific connection based on the ID provided
     *
     * @param $connectionId
     *
     * @return int
     */
    public function deleteById($connectionId)
    {
        return $this->tableGateway->delete(['id' => $connectionId]);
    }

    /**
     * Deletes any linkage between pano and site plan based on site plan ID
     *
     * @param $sitePlanId
     *
     * @return int
     */
    public function deleteBySitePlanId($sitePlanId)
    {
        return $this->tableGateway->delete(['site_plans_id' => $sitePlanId]);
    }

    /**
     * Selects current linkage between pano and site plan based on pano ID
     *
     * @param $panosId
     *
     * @return array|\ArrayObject|null
     */
    public function getByPanosId($panosId)
    {
        return $this->tableGateway->select(['panos_id' => $panosId])->current();
    }

    /**
     * Retrieves list of connections for given site plan
     *
     * @param $sitePlanId
     *
     * @return \Laminas\Db\ResultSet\ResultSet
     */
    public function getConnectionsBySitePlan($sitePlanId)
    {
        return $this->tableGateway->select(['site_plans_id' => $sitePlanId]);
    }
}
