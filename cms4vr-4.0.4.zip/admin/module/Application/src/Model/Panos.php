<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

class Panos extends MainModel
{

    const PROCESSING_PENDING = 0;
    const PROCESSING = 1;
    const PROCESSING_DONE = 2;

    public $id;
    public $building_id;
    public $position;
    public $lat;
    public $lng;
    public $north;
    public $start_view;
    public $visible;
    public $processed;
    public $galleries_id;
    public $scene_data;
    public $altitude;
    public $rendermode;
    public $background;
    public $scale;
    public $offset;
    public $subdiv;
    public $depthmap_visible;
    public $dollhouse_visible;
    public $prealign_x;
    public $prealign_y;
    public $prealign_z;
    public $ox;
    public $oy;
    public $oz;
    public $type;
    public $media_id;

    public function exchangeArray($data)
    {
        $this->id = (isset($data['id'])) ? $data['id'] : null;
        $this->building_id = (isset($data['building_id'])) ? $data['building_id'] : null;
        $this->position = (isset($data['position'])) ? $data['position'] : null;
        $this->lat = (isset($data['lat'])) ? $data['lat'] : null;
        $this->lng = (isset($data['lng'])) ? $data['lng'] : null;
        $this->north = (isset($data['north'])) ? $data['north'] : null;
        $this->start_view = (isset($data['start_view'])) ? $data['start_view'] : null;
        $this->visible = (isset($data['visible'])) ? $data['visible'] : null;
        $this->processed = (isset($data['processed'])) ? $data['processed'] : null;
        $this->galleries_id = (isset($data['galleries_id'])) ? $data['galleries_id'] : null;
        $this->scene_data = (isset($data['scene_data'])) ? $data['scene_data'] : null;
        $this->altitude = (isset($data['altitude'])) ? $data['altitude'] : null;
        $this->rendermode = (isset($data['rendermode'])) ? $data['rendermode'] : null;
        $this->background = (isset($data['background'])) ? $data['background'] : null;
        $this->scale = (isset($data['scale'])) ? $data['scale'] : '100';
        $this->offset = (isset($data['offset'])) ? $data['offset'] : '0';
        $this->subdiv = (isset($data['subdiv'])) ? $data['subdiv'] : null;
        $this->depthmap_visible = (isset($data['depthmap_visible'])) ? $data['depthmap_visible'] : null;
        $this->dollhouse_visible = (isset($data['dollhouse_visible'])) ? $data['dollhouse_visible'] : null;
        $this->prealign_x = (isset($data['prealign_x'])) ? $data['prealign_x'] : null;
        $this->prealign_y = (isset($data['prealign_y'])) ? $data['prealign_y'] : null;
        $this->prealign_z = (isset($data['prealign_z'])) ? $data['prealign_z'] : null;
        $this->ox = (isset($data['ox'])) ? $data['ox'] : null;
        $this->oy = (isset($data['oy'])) ? $data['oy'] : null;
        $this->oz = (isset($data['oz'])) ? $data['oz'] : null;
        $this->type = (isset($data['type'])) ? $data['type'] : null;
        $this->media_id = (isset($data['media_id'])) ? $data['media_id'] : null;
    }

}
