<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

use RuntimeException;
use Laminas\Db\Adapter\Adapter;
use Laminas\Db\Sql\Expression;
use Laminas\Db\Sql\Predicate\Operator;
use Laminas\Db\Sql\Predicate\PredicateSet;
use Laminas\Db\Sql\Select;
use Laminas\Db\Sql\Sql;
use Laminas\Db\TableGateway\TableGateway;

class PanosTable
{
    private $tableGateway;
    private $table = 'panos';

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;

        $result = $this->tableGateway->getAdapter()->query(
            'PRAGMA table_info("panos")',
            Adapter::QUERY_MODE_EXECUTE
        )->toArray();

        $exists = false;

        foreach ($result as $item) {
            if ($item['name'] === 'altitude') {
                $exists = true;
                break;
            }
        }

        if (!$exists) {
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `panos` ADD `altitude` TEXT',
                Adapter::QUERY_MODE_EXECUTE
            );
        }

        $exists = false;

        foreach ($result as $item) {
            if ($item['name'] === 'rendermode') {
                $exists = true;
                break;
            }
        }

        if (!$exists) {
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `panos` ADD `rendermode` VARCHAR',
                Adapter::QUERY_MODE_EXECUTE
            );
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `panos` ADD `background` VARCHAR',
                Adapter::QUERY_MODE_EXECUTE
            );
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `panos` ADD `scale` VARCHAR',
                Adapter::QUERY_MODE_EXECUTE
            );
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `panos` ADD `offset` VARCHAR',
                Adapter::QUERY_MODE_EXECUTE
            );
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `panos` ADD `subdiv` VARCHAR',
                Adapter::QUERY_MODE_EXECUTE
            );
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `panos` ADD `depthmap_visible` VARCHAR',
                Adapter::QUERY_MODE_EXECUTE
            );
        }

        $exists = false;

        foreach ($result as $item) {
            if ($item['name'] === 'prealign_x') {
                $exists = true;
                break;
            }
        }

        if (!$exists) {
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `panos` ADD `dollhouse_visible` VARCHAR',
                Adapter::QUERY_MODE_EXECUTE
            );
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `panos` ADD `prealign_x` VARCHAR',
                Adapter::QUERY_MODE_EXECUTE
            );
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `panos` ADD `prealign_y` VARCHAR',
                Adapter::QUERY_MODE_EXECUTE
            );
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `panos` ADD `prealign_z` VARCHAR',
                Adapter::QUERY_MODE_EXECUTE
            );
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `panos` ADD `ox` VARCHAR',
                Adapter::QUERY_MODE_EXECUTE
            );
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `panos` ADD `oy` VARCHAR',
                Adapter::QUERY_MODE_EXECUTE
            );
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `panos` ADD `oz` VARCHAR',
                Adapter::QUERY_MODE_EXECUTE
            );
        }

        $exists = false;

        foreach ($result as $item) {
            if ($item['name'] === 'type') {
                $exists = true;
                break;
            }
        }

        if (!$exists) {
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `panos` ADD `type` VARCHAR DEFAULT "pano"',
                Adapter::QUERY_MODE_EXECUTE
            );

            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `panos` ADD `media_id` VARCHAR',
                Adapter::QUERY_MODE_EXECUTE
            );
        }
    }

    public function fetchAll()
    {
        return $this->tableGateway->select();
    }

    public function getPano($id)
    {
        $id = (int) $id;
        $rowset = $this->tableGateway->select(['id' => $id]);
        $row = $rowset->current();
        if (! $row) {
            throw new RuntimeException(sprintf(
                'Could not find row with identifier %d',
                $id
            ));
        }

        return $row;
    }

    /**
     * Saves or updates pano entry in the database
     *
     * @param Panos $pano
     *
     * @return int
     */
    public function save(Panos $pano)
    {
        if ($pano->id == null) {
            $this->tableGateway->insert($pano->getArrayCopy());

            //return id
            $lastInsertedId = $this->tableGateway->getLastInsertValue();

            return $lastInsertedId;
        } else {
            $pano->galleries_id = $pano->galleries_id == 0 ? new Expression('null') : $pano->galleries_id;
            $pano->lat = $pano->lat == '' ? new Expression('null') : $pano->lat;
            $pano->lng = $pano->lng == '' ? new Expression('null') : $pano->lng;
            $pano->altitude = $pano->altitude == '' ? new Expression('null') : $pano->altitude;
            $pano->rendermode = $pano->rendermode == '' ? new Expression('null') : $pano->rendermode;
            $pano->background = $pano->background == '' ? new Expression('null') : $pano->background;
            $pano->scale = $pano->scale == '' ? new Expression('null') : $pano->scale;
            $pano->offset = $pano->offset == '' ? new Expression('null') : $pano->offset;
            $pano->subdiv = $pano->subdiv == '' ? new Expression('null') : $pano->subdiv;
            $pano->depthmap_visible = $pano->depthmap_visible == '' || $pano->depthmap_visible == 0 ? new Expression('null') : $pano->depthmap_visible;
            $pano->dollhouse_visible = $pano->dollhouse_visible == '' || $pano->dollhouse_visible == 0 ? new Expression('null') : $pano->dollhouse_visible;
            $pano->prealign_x = $pano->prealign_x == '' ? 0 : $pano->prealign_x;
            $pano->prealign_y = $pano->prealign_y == '' ? 0 : $pano->prealign_y;
            $pano->prealign_z = $pano->prealign_z == '' ? 0 : $pano->prealign_z;
            $pano->ox = $pano->ox == '' ? 0 : $pano->ox;
            $pano->oy = $pano->oy == '' ? 0 : $pano->oy;
            $pano->oz = $pano->oz == '' ? 0 : $pano->oz;
            $this->tableGateway->update(array_filter($pano->getArrayCopy(), function($var){return $var !== null;}), ['id' => $pano->id]);

            return $pano->id;
        }
    }

    /**
     * Updates field that specifies panorama conversion process
     *
     * 0 - processing pending
     * 1 - currently processing
     * 2 - processing finished
     *
     * @param $id
     * @param $status
     *
     * @return bool
     */
    public function changeProcessingStatus($id, $status)
    {
        $result = $this->tableGateway->update(['processed' => $status], ['id' => $id]);

        return $result ? true : false;
    }

    /**
     * Removes given panorama from the database
     *
     * @param $id
     *
     * @return bool
     */
    public function deletePano($id)
    {
        return $this->tableGateway->delete(['id' => (int) $id]);
    }

    /**
     * Get pano list with extra data, returning an array keyed with pano id.
     *
     * The example of output is as follows:
     *
     *  array
     *      'position' => 5
     *      'visible' => 0
     *      'processed' => 0
     *      'galleries_id' => null
     *      'vgalleries_id' => null
     *      'poi_count' => 0
     *      'name' =>
     *          array
     *              'fr' => 'fr1'
     *              'dk' => 'dk1'
     *              'fi' => 'fi1'
     *
     * @param        $category_id int | bool
     *
     * @param string $langKey
     *
     * @param bool $allowedCategories
     * @return array|\ArrayObject|null
     */
    public function getPanoList($category_id = false, $langKey = 'langShort', $allowedCategories = false)
    {
        $select_poi = new Select();
        $select_poi->from(['poi' => 'poi']);
        $select_poi->columns(['count' => new Expression('count(poi.id)')]);
        $select_poi->where('poi.panos_id = panos.id');

        $select = new Select();
        $select->from($this->table);
        $select->columns([
            'pid'       => 'id',
            'position',
            'visible',
            'processed',
            'galleries_id',
            'poi_count' => $select_poi
        ]);
        $select->join('pano_phrases', 'panos.id = pano_phrases.panos_id', ['name', 'languages_id'], Select::JOIN_LEFT);
        $select->join('languages', 'languages.id = pano_phrases.languages_id', ['short'], Select::JOIN_LEFT);

        if ($category_id) {
            $select->join('pano_category_connections', 'panos.id = pano_category_connections.pano_id');
            $select->where(['pano_category_connections.category_id' => $category_id]);
            $select->order('pano_position');
        }

        if ($allowedCategories !== false) {
            if (empty($allowedCategories)) {
                $allowedCategories = [0];
            }
            $select->join(['pcc' => 'pano_category_connections'], 'panos.id = pcc.pano_id');
            $select->where(['pcc.category_id' => $allowedCategories]);
        }

        $sql = new Sql($this->tableGateway->getAdapter());
        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        $panos = [];

        $prevPanoId = 0;

        foreach ($result as $pano) {

            if ($prevPanoId != $pano['pid']) {
                $panos[$pano['pid']] =
                    [
                        'position'      => $pano['position'],
                        'visible'       => $pano['visible'],
                        'processed'     => $pano['processed'],
                        'galleries_id'  => $pano['galleries_id'],
                        'poi_count'     => $pano['poi_count']
                    ];
                if ($langKey == 'langShort') {
                    $panos[$pano['pid']]['name'][$pano['short']] = $pano['name'];
                } else {
                    $panos[$pano['pid']]['name'][$pano['languages_id']] = $pano['name'];
                }
            } else {
                if ($langKey == 'langShort') {
                    $panos[$pano['pid']]['name'][$pano['short']] = $pano['name'];
                } else {
                    $panos[$pano['pid']]['name'][$pano['languages_id']] = $pano['name'];
                }
            }
            $prevPanoId = $pano['pid'];
        }

        return $panos;
    }

    /**
     * Returns number of all panoramas in the system
     *
     * @return int
     */
    public function countPanos()
    {
        return $this->tableGateway->select()->count();
    }

    /**
     * Publishes or unpublishes given pano in the project
     *
     * @param $id
     * @param $visible
     *
     * @return int
     */
    public function changeVisibility($id, $visible)
    {
        return $this->tableGateway->update(['visible' => $visible], ['id' => $id]);
    }

    /**
     * Sets Start view for specific panorama
     * @param $id
     * @param $startView
     *
     * @return int
     */
    public function setPanoStartView($id, $startView)
    {
        return $this->tableGateway->update(['start_view' => $startView], ['id' => $id]);
    }

    /**
     * Sets North for specific panorama
     *
     * @param $id
     * @param $north
     *
     * @return int
     */
    public function setPanoNorth($id, $north)
    {
        return $this->tableGateway->update(['north' => $north], ['id' => $id]);
    }

    /**
     * Returns connection rows
     *
     * @param bool $orderByName
     * @return array|\ArrayObject|null
     */
    public function getConnections($orderByName = false)
    {
        $sql = new Sql($this->tableGateway->getAdapter());

        $select = $sql->select()->from('settings')->join('languages', 'languages.short = settings.value')->where(['key' => 'default_language'])->limit(1);
        $statement = $sql->prepareStatementForSqlObject($select);
        $defaultLangId = (int)$statement->execute()->current()['id'];

        $select = $sql->select()->from($this->table);
        $select->columns(['id']);
        $select->join('pano_category_connections', 'panos.id = pano_category_connections.pano_id',
            ['connection_id' => 'id', 'category_id'], Select::JOIN_LEFT);
        $select->join('pano_phrases', 'pano_phrases.panos_id = panos.id',
            ['name'], Select::JOIN_LEFT);
        $select->where(['panos.processed' => Panos::PROCESSING_DONE]);
        $select->where(['pano_phrases.languages_id' => $defaultLangId]);

        if ($orderByName) {
            $select->order('pano_phrases.name');
        } else {
            $select->order('pano_category_connections.pano_position ASC');
        }

        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        $returnArray = [];
        foreach($result as $key => $value){
            if(!isset($returnArray[$value['id']])){
                $returnArray[$value['id']] = $value;
                $returnArray[$value['id']]['connections'][$value['category_id']] = ['connection_id' => $value['connection_id']];
            } else {
                $returnArray[$value['id']]['connections'][$value['category_id']] = ['connection_id' => $value['connection_id']];
            }

        }

        return $returnArray;
    }

    /**
     * Stores scene data generated by krpano for future use
     *
     * @param $id
     * @param $sceneData
     * @return mixed
     */
    public function saveSceneData($id, $sceneData)
    {
        return $this->tableGateway->update(['scene_data' => $sceneData], ['id' => $id]);
    }

    public function getPanosWithPoi($onlyVisible = true, $langLimit = false)
    {
        $sql = new Sql($this->tableGateway->getAdapter());
        $select = $sql->select()->from($this->table);
        $select->columns(['*', 'panoId' => 'id']);
        $select->join('poi', 'poi.panos_id = panos.id', ['*', 'poiId' => 'id', 'poiName' => 'name'], Select::JOIN_LEFT);
        $select->join('poi_phrases', 'poi_phrases.poi_id = poi.id', ['*', 'poiPhraseName' => 'name', 'poiParams' => 'params'], Select::JOIN_LEFT);
        $select->join('languages', 'poi_phrases.languages_id = languages.id', ['poiLang' => 'short'], Select::JOIN_LEFT);
        $select->join('pano_phrases', 'pano_phrases.panos_id = panos.id', ['*', 'panoName' => 'name', 'panoDescription' => 'description'], Select::JOIN_LEFT);
        $select->join(['languages2' => 'languages'], 'pano_phrases.languages_id = languages2.id', ['panoLang' => 'short'], Select::JOIN_LEFT);

        if ($onlyVisible) {
            $select->where(['panos.visible' => 1]);
        }

        if ($langLimit) {
            $select->where->and->nest()->equalTo('languages.short', $langLimit)->or->isNull('languages.short')->unnest();
            $select->where(['languages2.short' => $langLimit]);
        }

        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        $panosWithPoi = [];

        foreach ($result as $row) {
            if (!isset($panosWithPoi[$row['panoId']])) {
                $panosWithPoi[$row['panoId']]['panoDetails'] = [
                    'name' => 'p' . $row['panoId'],
                    'lat' => $row['lat'],
                    'lng' => $row['lng'],
                    'altitude' => $row['altitude'],
                    'north' => $row['north'],
                    'start_view' => $row['start_view'],
                    'galleries_id' => $row['galleries_id'],
                    'visible' => $row['visible'],
                    'scene_data' => $row['scene_data']
                ];
                $panosWithPoi[$row['panoId']]['poi'] = [];
                $panosWithPoi[$row['panoId']]['panoDetails']['phrases'] = [];
            }
            // add pano languages
            if (isset($row['panoLang'])) {
                if (!isset($panosWithPoi[$row['panoId']]['panoDetails']['phrases'][$row['panoLang']])) {
                    $panosWithPoi[$row['panoId']]['panoDetails']['phrases'][$row['panoLang']] = [];
                }
                $panosWithPoi[$row['panoId']]['panoDetails']['phrases'][$row['panoLang']]['name'] = $row['panoName'];
                $panosWithPoi[$row['panoId']]['panoDetails']['phrases'][$row['panoLang']]['description'] = $row['panoDescription'];
                $panosWithPoi[$row['panoId']]['panoDetails']['phrases'][$row['panoLang']]['media_id'] = $row['media_id'];
            }
            if (!isset($panosWithPoi[$row['panoId']]['poi'][$row['poiId']]) && $row['poiId']) {
                $panosWithPoi[$row['panoId']]['poi'][$row['poiId']] = [];
                $panosWithPoi[$row['panoId']]['poi'][$row['poiId']]['name'] = $row['poiName'];
                $panosWithPoi[$row['panoId']]['poi'][$row['poiId']]['type'] = $row['type'];
                $panosWithPoi[$row['panoId']]['poi'][$row['poiId']]['ath'] = $row['ath'];
                $panosWithPoi[$row['panoId']]['poi'][$row['poiId']]['atv'] = $row['atv'];
                $panosWithPoi[$row['panoId']]['poi'][$row['poiId']]['settings'] = $row['settings'];
                $panosWithPoi[$row['panoId']]['poi'][$row['poiId']]['depth'] = $row['depth'];
                $panosWithPoi[$row['panoId']]['poi'][$row['poiId']]['phrases'] = [];
            }
            // add POI languages
            if (isset($row['poiLang'])) {
                $panosWithPoi[$row['panoId']]['poi'][$row['poiId']]['phrases'][$row['poiLang']] = [];
                $panosWithPoi[$row['panoId']]['poi'][$row['poiId']]['phrases'][$row['poiLang']]['name'] = $row['poiPhraseName'];
                $panosWithPoi[$row['panoId']]['poi'][$row['poiId']]['phrases'][$row['poiLang']]['params'] = $row['poiParams'];
            }
        }

        return $panosWithPoi;
    }

    /**
     * Updates lat, lng and north values
     *
     * @param $panosId
     * @param $coords
     */
    public function updatePanoCoords($panosId, $coords)
    {
        if (trim($coords['north']) == '') {
            $coords['north'] = '0.00001';
        }

        $this->tableGateway->update(array_filter($coords), ['id' => $panosId]);
    }

    /**
     * Gets IDs of visible panoramas
     *
     * @return array
     */
    public function getPublishedPanos()
    {
        $panos = $this->tableGateway->select(['visible' => 1]);
        $panosIds = [];
        foreach ($panos as $pano) {
            $panosIds[] = $pano->id;
        }
        return $panosIds;
    }

    public function updateVideoSceneMediaId($panosId, $mediaId, $type)
    {
        $currentPano = $this->getPano($panosId);
        $currentPano->media_id = $mediaId;
        $currentPano->scene_data = str_replace(['flat', 'spherical'], [$type, $type], $currentPano->scene_data);
        $this->save($currentPano);
    }
}
