<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

/**
 * Class Poi is a representation of POIs stored in the database
 *
 * All POIs share some of the parameters (atv, ath), and are differentiated by 'type' field denoting parameters stored
 * in poi_phrases table
 *
 * @see     PoiPhrasesTable
 *
 * @package Application\Model
 */
class Poi extends MainModel
{

    const POI_INFO = 'info';
    const POI_AUDIO = 'audio';
    const POI_VIDEO = 'video';
    const POI_PANO = 'pano';
    const POI_POPUP = 'popup';
    const POI_LINK = 'link';
    const POI_DOWNLOAD = 'download';
    const POI_LABEL = 'label';
    const POI_PDF = 'pdf';
    const POI_PHOTO = 'photo';
    const POI_USER = 'user';
    const POI_GALLERY = 'gallery';
    const POI_FORM = 'form';
    const POI_OBJECT3D = 'object3d';

    public $id;
    public $panos_id;
    public $name;
    public $atv;
    public $ath;
    public $type;
    public $settings;
    public $depth;

    public function exchangeArray($data)
    {
        $this->id = (isset($data['id'])) ? $data['id'] : null;
        $this->panos_id = (isset($data['panos_id'])) ? $data['panos_id'] : null;
        $this->name = (isset($data['name'])) ? $data['name'] : null;
        $this->atv = (isset($data['atv'])) ? $data['atv'] : null;
        $this->ath = (isset($data['ath'])) ? $data['ath'] : null;
        $this->type = (isset($data['type'])) ? $data['type'] : null;
        $this->settings = (isset($data['settings'])) ? $data['settings'] : null;
        $this->depth = (isset($data['depth'])) ? $data['depth'] : null;
    }
}
