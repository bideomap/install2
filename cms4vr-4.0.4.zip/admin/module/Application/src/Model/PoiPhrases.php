<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

/**
 * Class PoiPhrases represents POI phrases stored in the database
 *
 * Each phrase contains language specific params that are JSON-encoded in the database
 *
 * @package Application\Model
 */
class PoiPhrases extends MainModel
{

    public $id;
    public $poi_id;
    public $languages_id;
    public $name;
    public $params;

    public function exchangeArray($data)
    {
        $this->id = (isset($data['id'])) ? $data['id'] : null;
        $this->poi_id = (isset($data['poi_id'])) ? $data['poi_id'] : null;
        $this->languages_id = (isset($data['languages_id'])) ? $data['languages_id'] : null;
        $this->name = (isset($data['name'])) ? $data['name'] : null;
        $this->params = (isset($data['params'])) ? $data['params'] : null;
    }
}
