<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;


use Laminas\Db\TableGateway\TableGateway;

/**
 * Class PoiPhrasesTable provides functionalities to manage POI phrases saved in the database
 *
 * Some of the functionality regarding POI phrases are stored within PoiTable class - like retrieving data from DB
 *
 * @see     PoiTable
 *
 * @package Project\Model
 */
class PoiPhrasesTable
{
    private $tableGateway;
    private $table = 'poi_phrases';

    /**
     * @param TableGateway $tableGateway
     */
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    /**
     * Saves PoiPhrase instance in the database
     *
     * @param PoiPhrases $poiPhrase
     *
     * @return int
     */
    public function save(PoiPhrases $poiPhrase)
    {
        if ((int)$poiPhrase->id == 0) {
            $poiPhrase->id = null;
            $this->tableGateway->insert($poiPhrase->getArrayCopy());

            //return id
            $lastInsertedId = $this->tableGateway->getLastInsertValue();

            return $lastInsertedId;
        } else {
            $this->tableGateway->update($poiPhrase->getArrayCopy(), ['id' => $poiPhrase->id]);

            return $poiPhrase->id;
        }
    }

}
