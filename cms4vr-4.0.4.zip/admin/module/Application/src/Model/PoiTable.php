<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;


use Laminas\Db\Adapter\Adapter;
use Laminas\Db\Sql\Expression;
use Laminas\Db\Sql\Predicate\Like;
use Laminas\Db\Sql\Select;
use Laminas\Db\Sql\Sql;
use Laminas\Db\TableGateway\TableGateway;
use Laminas\Json\Json;

/**
 * Class PoiTable manages POIs stored in the database
 *
 * This class also works on poi_phrases table, especially when pulling information out of the database
 *
 * @see     PoiPhrasesTable
 *
 * @package Project\Model
 */
class PoiTable
{
    private $tableGateway;
    private $table = 'poi';

    /**
     * @param TableGateway $tableGateway
     */
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;

        $result = $this->tableGateway->getAdapter()->query(
            'PRAGMA table_info("poi")',
            Adapter::QUERY_MODE_EXECUTE
        )->toArray();

        $exists = false;

        foreach ($result as $item) {
            if ($item['name'] === 'depth') {
                $exists = true;
                break;
            }
        }

        if (!$exists) {
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `poi` ADD `depth` VARCHAR',
                Adapter::QUERY_MODE_EXECUTE
            );
        }
    }

    /**
     * Saves basic POI information in the database
     *
     * @param Poi $poi
     *
     * @return int
     */
    public function save(Poi $poi)
    {
        if ((int)$poi->id == 0) {
            $poi->id = null;
            $this->tableGateway->insert($poi->getArrayCopy());

            //return id
            $lastInsertedId = $this->tableGateway->getLastInsertValue();

            return $lastInsertedId;
        } else {
            $this->tableGateway->update(array_filter($poi->getArrayCopy()), ['id' => $poi->id]);

            return $poi->id;
        }
    }

    /**
     * Saves POI using name provided - either creates a new entry, or updates an existing one
     *
     * @param Poi $poi
     */
    public function savePoiByName(Poi $poi)
    {
        // check if POI exists
        $currentPoi = $this->tableGateway->select(['name' => $poi->name])->current();

        /*if ($poi->settings == Json::encode([])) {
            $poi->settings = new Expression('null');
        }*/

        // update or insert
        if ($currentPoi) {
            $this->tableGateway->update(array_filter($poi->getArrayCopy()), ['id' => $currentPoi->id]);
        } else {
            $poi->id = null;
            $this->tableGateway->insert($poi->getArrayCopy());
        }
    }

    /**
     * Retrieves list of POIs pinned to the requested pano, taking into account names in different languages
     *
     * @param $pano_id
     *
     * @return array
     */
    public function getPoiByPanoId($pano_id)
    {
        $sql = new Sql($this->tableGateway->getAdapter());
        $select = $sql->select()->from($this->table);
        $select->join('poi_phrases', 'poi.id = poi_phrases.poi_id', ['name', 'params', 'languages_id']);
        $select->join('languages', 'poi_phrases.languages_id = languages.id', ['short']);
        $select->where(['poi.panos_id' => $pano_id]);
        $select->group('poi_phrases.id');
        $select->order('position ASC');
        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        $pois = [];

        foreach ($result as $poi) {
            if (!isset($pois[$poi['type']][$poi['id']])) {
                $pois[$poi['type']][$poi['id']] =
                    [
                        //'id'    => $poi['id'],
                        'ath'    => $poi['ath'],
                        'atv'    => $poi['atv'],
                        'type'   => $poi['type'],
                        'settings' => $poi['settings'],
                    ];
                $pois[$poi['type']][$poi['id']]['phrases'][] = ['short' => $poi['short'], 'languages_id' => $poi['languages_id'], 'name' => $poi['name'], 'params' => $poi['params']];
            } else {
                $pois[$poi['type']][$poi['id']]['phrases'][] = ['short' => $poi['short'], 'languages_id' => $poi['languages_id'], 'name' => $poi['name'], 'params' => $poi['params']];
            }
        }

        return $pois;
    }

    /**
     * Retrieves full set of POI-related information for editing or displaying purposes
     *
     * This method returns language-aware entries keyed either by language ID (int) or language code (string)
     *
     * @deprecated To be verified
     * @see getPoiByName
     *
     * @param int    $id
     * @param string $langKey
     *
     * @return array
     */
    public function getPoiById($id, $langKey = 'langShort')
    {
        $sql = new Sql($this->tableGateway->getAdapter());
        $select = $sql->select()->from($this->table);
        $select->join('poi_phrases', 'poi.id = poi_phrases.poi_id',
                      ['name', 'params', 'languages_id', 'poi_phrases_id' => 'id']);
        $select->join('languages', 'poi_phrases.languages_id = languages.id', ['short']);
        $select->where(['poi.id' => $id]);
        $select->group('poi_phrases.id');
        $select->order('position ASC');
        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        $pois = [];

        foreach ($result as $poi) {
            if (!isset($pois[$poi['id']])) {
                $pois[$poi['id']] =
                    [
                        'id'   => $poi['id'],
                        'ath'  => $poi['ath'],
                        'atv'  => $poi['atv'],
                        'type' => $poi['type'],
                        'settings' => $poi['settings'],
                    ];

                // key names either by short lang name or by languages_id
                if ($langKey == 'langShort') {
                    $pois[$poi['id']]['phrases'][$poi['short']] =
                        ['id' => $poi['poi_phrases_id'], 'name' => $poi['name'], 'params' => $poi['params']];
                } else {
                    $pois[$poi['id']]['phrases'][$poi['languages_id']] =
                        ['id' => $poi['poi_phrases_id'], 'name' => $poi['name'], 'params' => $poi['params']];
                }

            } else {
                // key names either by short lang name or by languages_id
                if ($langKey == 'langShort') {
                    $pois[$poi['id']]['phrases'][$poi['short']] =
                        ['id' => $poi['poi_phrases_id'], 'name' => $poi['name'], 'params' => $poi['params']];
                } else {
                    $pois[$poi['id']]['phrases'][$poi['languages_id']] =
                        ['id' => $poi['poi_phrases_id'], 'name' => $poi['name'], 'params' => $poi['params']];
                }
            }
        }

        return $pois;
    }

    /**
     * Retrieves full set of POI-related information for editing or displaying purposes
     *
     * This method returns language-aware entries keyed either by language ID (int) or language code (string)
     *
     * @param string    $poiName
     * @param string $langKey
     *
     * @return array
     */
    public function getPoiByName($poiName, $langKey = 'langShort')
    {
        $sql = new Sql($this->tableGateway->getAdapter());
        $select = $sql->select()->from($this->table);
        $select->join('poi_phrases', 'poi.id = poi_phrases.poi_id',
            ['name', 'params', 'languages_id', 'poi_phrases_id' => 'id'], Select::JOIN_LEFT);
        $select->join('languages', 'poi_phrases.languages_id = languages.id', ['short'], Select::JOIN_LEFT);
        $select->where(['poi.name' => $poiName]);
        $select->group('poi_phrases.id');
        $select->order('position ASC');
        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        $pois = [];

        foreach ($result as $poi) {
            if (!isset($pois[$poi['id']])) {
                $pois[$poi['id']] =
                    [
                        'id'   => $poi['id'],
                        'ath'  => $poi['ath'],
                        'atv'  => $poi['atv'],
                        'type' => $poi['type'],
                        'settings' => $poi['settings'],
                    ];

                // key names either by short lang name or by languages_id
                if ($langKey == 'langShort') {
                    $pois[$poi['id']]['phrases'][$poi['short']] =
                        ['id' => $poi['poi_phrases_id'], 'name' => $poi['name'], 'params' => $poi['params']];
                } else {
                    $pois[$poi['id']]['phrases'][$poi['languages_id']] =
                        ['id' => $poi['poi_phrases_id'], 'name' => $poi['name'], 'params' => $poi['params']];
                }

            } else {
                // key names either by short lang name or by languages_id
                if ($langKey == 'langShort') {
                    $pois[$poi['id']]['phrases'][$poi['short']] =
                        ['id' => $poi['poi_phrases_id'], 'name' => $poi['name'], 'params' => $poi['params']];
                } else {
                    $pois[$poi['id']]['phrases'][$poi['languages_id']] =
                        ['id' => $poi['poi_phrases_id'], 'name' => $poi['name'], 'params' => $poi['params']];
                }
            }
        }

        return $pois;
    }

    /**
     * Deletes given POI
     *
     * @param $poi_id
     * @param $panos_id
     * @param $type
     * @deprecated
     * @return int
     */
    public function deletePoi($poi_id, $panos_id, $type)
    {
        return $this->tableGateway->delete(['id' => $poi_id, 'panos_id' => $panos_id, 'type' => $type]);
    }

    /**
     * Deletes POI by name provided
     *
     * @param $poiName
     * @return int
     */
    public function deletePoiByName($poiName)
    {
        return $this->tableGateway->delete(['name' => $poiName]);
    }

    /**
     * Delete POI if media resource is deleted
     *
     * @param $mediaName
     * @param $mediaType
     */
    public function deletePoiByMedia($mediaName, $mediaType)
    {
        $this->tableGateway->delete(['type' => $mediaType, new Like('settings', $mediaName . '%')]);
    }
}
