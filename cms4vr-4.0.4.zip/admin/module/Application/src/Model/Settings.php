<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

/**
 * Class Settings stores various settings related to the project
 *
 * @package Application\Model
 */
class Settings extends MainModel
{
    public $id;
    public $key;
    public $value;

    public function exchangeArray($data)
    {
        $this->id = (isset($data['id'])) ? $data['id'] : null;
        $this->key = (isset($data['key'])) ? $data['key'] : null;
        $this->value = (isset($data['value'])) ? $data['value'] : null;
    }
}
