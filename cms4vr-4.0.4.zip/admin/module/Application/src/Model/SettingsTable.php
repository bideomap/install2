<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;


use Laminas\Db\TableGateway\TableGateway;

/**
 * Class SettingsTable performs CRUD operation on various project settings stored in the database
 *
 * @package Application\Model
 */
class SettingsTable
{
    private $tableGateway;
    private $table = 'settings';

    /**
     * @param TableGateway $tableGateway
     */
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    public function get($key)
    {
        $row = $this->tableGateway->select(['key' => $key])->current();

        return $row ? $row->value : null;
    }

    public function set($key, $value)
    {
        $exists = $this->get($key) !== null ? true : false;

        if ($exists) {
            $this->tableGateway->update(['value' => $value], ['key' => $key]);
        } else {
            $this->tableGateway->insert(['id' => null, 'value' => $value, 'key' => $key]);
        }
    }

    public function remove($key)
    {
        $this->tableGateway->delete(['key' => $key]);
    }

}
