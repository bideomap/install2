<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

class Shortlink extends MainModel
{
    public $id;
    public $link;
    public $params;

    public function exchangeArray($data)
    {
        $this->id = (isset($data['id'])) ? $data['id'] : null;
        $this->link = (isset($data['link'])) ? $data['link'] : null;
        $this->params = (isset($data['params'])) ? $data['params'] : null;
    }
}
