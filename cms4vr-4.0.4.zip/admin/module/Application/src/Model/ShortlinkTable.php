<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;


use Laminas\Db\TableGateway\TableGateway;

/**
 *
 *
 * @package Application\Model
 */
class ShortlinkTable
{
    private $tableGateway;
    private $table = 'shortlinks';

    /**
     * @param TableGateway $tableGateway
     */
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    public function save(Shortlink $shortlink)
    {
        if ((int)$shortlink->id == 0) {
            $shortlinkId = $this->tableGateway->insert($shortlink->getArrayCopy());
        } else {
            $this->tableGateway->update($shortlink->getArrayCopy(), ['id' => $shortlink->id]);
            $shortlinkId = $shortlink->id;
        }

        return $shortlinkId;
    }

    public function getByLink($link)
    {
        return $this->tableGateway->select(['link' => $link]);
    }

}
