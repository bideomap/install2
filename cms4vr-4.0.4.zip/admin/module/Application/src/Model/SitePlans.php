<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

/**
 * Class SitePlans is a representation of site plans present in the system
 *
 * @package Project\Model
 */
class SitePlans extends MainModel
{
    public $id;
    public $site_plans_categories_id;
    public $extension;

    public function exchangeArray($data)
    {
        $this->id = (isset($data['id'])) ? $data['id'] : null;
        $this->site_plans_categories_id = (isset($data['site_plans_categories_id'])) ? $data['site_plans_categories_id'] : null;
        $this->extension = (isset($data['extension'])) ? $data['extension'] : null;
    }
}
