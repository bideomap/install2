<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

/**
 * Class SitePlansPhrases is a representation of site plan phrases present in the system
 *
 * @package Project\Model
 */
class SitePlansPhrases extends MainModel
{
    public $id;
    public $site_plans_id;
    public $languages_id;
    public $name;

    public function exchangeArray($data)
    {
        $this->id = (isset($data['id'])) ? $data['id'] : null;
        $this->site_plans_id = (isset($data['site_plans_id'])) ? $data['site_plans_id'] : null;
        $this->languages_id = (isset($data['languages_id'])) ? $data['languages_id'] : null;
        $this->name = (isset($data['name'])) ? $data['name'] : null;
    }
}
