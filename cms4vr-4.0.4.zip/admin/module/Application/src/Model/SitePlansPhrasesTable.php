<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;
use Laminas\Db\TableGateway\TableGateway;

/**
 * Class CategoryPhrasesTable handles CRUD operations on site plan phrases
 *
 * @package Project\Model
 */
class SitePlansPhrasesTable
{
    private $tableGateway;
    private $table = 'site_plans_phrases';

    /**
     * @param TableGateway $tableGateway
     */
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    /**
     * Get site plan phrase by ID
     *
     * @param $id
     * @return array|\ArrayObject|null
     */
    public function getById($id)
    {
        return $this->tableGateway->select(array('id' => $id))->current();
    }

    /**
     * Saves or updates site plan phrase entry in the database
     *
     * @param SitePlansPhrases $planPhrase
     *
     * @return int|null
     *
     */
    public function save(SitePlansPhrases $planPhrase)
    {
        if ((int)$planPhrase->id == 0) {
            $planPhrase->id = null;
            $this->tableGateway->insert($planPhrase->getArrayCopy());

            //return id
            $lastInsertedId = $this->tableGateway->getLastInsertValue();
            return $lastInsertedId;
        } else {
            $this->tableGateway->update($planPhrase->getArrayCopy(), array('id' => $planPhrase->id));
            return $planPhrase->id;
        }
    }

}
