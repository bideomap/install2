<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

use Laminas\Db\Adapter\Adapter;
use Laminas\Db\ResultSet\ResultSet;
use Laminas\Db\Sql\Expression;
use Laminas\Db\Sql\Select;
use Laminas\Db\Sql\Sql;
use Laminas\Db\TableGateway\TableGateway;

/**
 * Class SitePlansTable handles CRUD operations on site plans
 *
 * @package Project\Model
 */
class SitePlansTable
{
    private $tableGateway;
    private $table = 'site_plans';

    /**
     * @param TableGateway $tableGateway
     */
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;

        $result = $this->tableGateway->getAdapter()->query(
            'PRAGMA table_info("site_plans")',
            Adapter::QUERY_MODE_EXECUTE
        )->toArray();

        $exists = false;

        foreach ($result as $item) {
            if ($item['name'] === 'extension') {
                $exists = true;
                break;
            }
        }

        if (!$exists) {
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `site_plans` ADD `extension` VARCHAR(255)',
                Adapter::QUERY_MODE_EXECUTE
            );
            $this->tableGateway->getAdapter()->query(
                'UPDATE `site_plans` SET `extension`="jpg"',
                Adapter::QUERY_MODE_EXECUTE
            );
        }

        $exists = false;

        foreach ($result as $item) {
            if ($item['name'] === 'scale') {
                $exists = true;
                break;
            }
        }

        if (!$exists) {
            $this->tableGateway->getAdapter()->query(
                'ALTER TABLE `site_plans` ADD `scale` VARCHAR(255)',
                Adapter::QUERY_MODE_EXECUTE
            );
            $this->tableGateway->getAdapter()->query(
                'UPDATE `site_plans` SET `scale`="false"',
                Adapter::QUERY_MODE_EXECUTE
            );
        }
    }

    /**
     * Get site plan by ID
     *
     * @param $id
     *
     * @return array|\ArrayObject|null
     */
    public function getById($id)
    {
        return $this->tableGateway->select(['id' => $id])->current();
    }

    /**
     * Delete site plan by id
     *
     * @param $id
     *
     * @return array|\ArrayObject|null
     */
    public function deleteById($id)
    {
        return $this->tableGateway->delete(['id' => $id]);
    }

    /**
     * Gets list of site plans with connections to specific panos
     *
     * @return array
     */
    public function getPlansWithConnections()
    {
        $sql = new Sql($this->tableGateway->getAdapter());
        $select = $sql->select()->from($this->table);
        $select->columns(['sitePlanId' => 'id', 'extension', 'scale']);
        $select->join('pano_site_plans_connections', 'pano_site_plans_connections.site_plans_id = site_plans.id', ['*', 'connectionId' => 'id']);
        $select->join('site_plans_phrases', 'site_plans_phrases.site_plans_id = site_plans.id', ['*', 'phraseName' => 'name'], Select::JOIN_LEFT);
        $select->join('languages', 'languages.id = site_plans_phrases.languages_id', ['*', 'phraseLang' => 'short']);

        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        $sitePlans = [];
        foreach ($result as $row) {
            if (!isset($sitePlans[$row['sitePlanId']])) {
                $sitePlans[$row['sitePlanId']] = [];
                $sitePlans[$row['sitePlanId']]['phrases'] = [];
                $sitePlans[$row['sitePlanId']]['connections'] = [];
                $sitePlans[$row['sitePlanId']]['extension'] = $row['extension'];
                $sitePlans[$row['sitePlanId']]['scale'] = $row['scale'];
            }
            if (!isset($sitePlans[$row['sitePlanId']]['connections'][$row['connectionId']])) {
                $sitePlans[$row['sitePlanId']]['connections'][$row['connectionId']] = [];
            }

            // add site plan languages
            if (isset($row['phraseLang'])) {
                if (!isset($sitePlans[$row['sitePlanId']]['phrases'][$row['phraseLang']])) {
                    $sitePlans[$row['sitePlanId']]['phrases'][$row['phraseLang']] = $row['phraseName'];
                }
            }

            $sitePlans[$row['sitePlanId']]['connections'][$row['connectionId']]['panos_id'] = $row['panos_id'];
            $coords = explode(',', $row['coordinates']);
            $sitePlans[$row['sitePlanId']]['connections'][$row['connectionId']]['x'] = $coords[0];
            $sitePlans[$row['sitePlanId']]['connections'][$row['connectionId']]['y'] = $coords[1];
        }

        return $sitePlans;
    }

    /**
     * Get site plans
     *
     * @return array|\ArrayObject|null
     *
     */
    public function getPlans()
    {

        $panoLinks = new Select();
        $panoLinks->from('pano_site_plans_connections');
        $panoLinks->columns(['count' => new Expression('count(pano_site_plans_connections.id)')]);
        $panoLinks->where('pano_site_plans_connections.site_plans_id = site_plans.id');

        $sql = new Sql($this->tableGateway->getAdapter());
        $select = $sql->select()->from($this->table);
        $select->join('site_plans_phrases', 'site_plans_phrases.site_plans_id = site_plans.id', ['name'], Select::JOIN_LEFT);
        $select->join('languages', 'site_plans_phrases.languages_id = languages.id', ['short'], Select::JOIN_LEFT);
        $select->columns(['*', 'pano_count' => $panoLinks]);

        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        $plans = [];

        foreach ($result as $plan) {
            if (!isset($plans[$plan['id']])) {
                $plans[$plan['id']] = [];
                $plans[$plan['id']]['id'] = $plan['id'];
                $plans[$plan['id']]['extension'] = $plan['extension'];
                $plans[$plan['id']]['pano_count'] = $plan['pano_count'];
                $plans[$plan['id']]['name'] = [];
                $plans[$plan['id']]['name'][$plan['short']] = $plan['name'];
            } else {
                $plans[$plan['id']]['name'][$plan['short']] = $plan['name'];
            }
        }

        return $plans;
    }

    /**
     * Get site plan details with phrases in available languages
     *
     * @param $id
     *
     * @return array
     */
    public function getByIdWithLanguages($id)
    {
        $sql = new Sql($this->tableGateway->getAdapter());
        $select = $sql->select()->from($this->table);
        $select->join('site_plans_phrases',
                      'site_plans.id = site_plans_phrases.site_plans_id', [
                          'name',
                          'phrase_id' => 'id',
                          'languages_id',
                      ]);

        $select->join('languages', 'site_plans_phrases.languages_id = languages.id', [
            'short',
            'long'
        ]);

        $select->where(['site_plans.id' => $id]);
        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        $returnArray = [];
        foreach ($result as $key => $value) {

            //create array to populate
            $returnArray['site_plan_fs'][$value['languages_id']] = [
                'name'        => $value['name'],
                'id'          => $value['phrase_id'],
                'language'    => $value['short'],
                'language_id' => $value['languages_id']
            ];

            $returnArray['id'] = $value['id'];
            $returnArray['extension'] = $value['extension'];
        }

        return $returnArray;
    }

    /**
     * Saves site plan entry in the database
     *
     * @param SitePlans $sitePlan
     *
     * @return int|null
     *
     */
    public function save(SitePlans $sitePlan)
    {
        if ((int)$sitePlan->id == 0) {
            $sitePlan->id = null;
            $this->tableGateway->insert($sitePlan->getArrayCopy());

            //return id
            $lastInsertedId = $this->tableGateway->getLastInsertValue();

            return $lastInsertedId;
        } else {
            if (isset($sitePlan->extension)) {
                $this->tableGateway->update(['extension' => $sitePlan->extension], ['id' => $sitePlan->id]);
            }
            return $sitePlan->id;
        }
    }

    /**
     * Saves new scale for given site plan
     *
     * @param $sitePlanId
     * @param $scale
     */
    public function updateScale($sitePlanId, $scale)
    {
        $this->tableGateway->update(['scale' => (int)$scale], ['id' => $sitePlanId]);
    }

}
