<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

class Templates extends MainModel
{
    public $id;
    public $name;
    public $labels_used;

    public function exchangeArray($data)
    {
        $this->id = (isset($data['id'])) ? $data['id'] : null;
        $this->name = (isset($data['name'])) ? $data['name'] : null;
        $this->labels_used = (isset($data['labels_used'])) ? $data['labels_used'] : null;
    }

    public static function getTemplateSettingsMapping()
    {
        return array(
            'm_poi_settings' => array('name' => _('POI settings'), 'settings' => true, 'showHide' => false),
            'm_map' => array('name' => _('Map'), 'settings' => true, 'showHide' => true),
            'm_facebook' => array('name' => _('Facebook box'), 'settings' => true, 'showHide' => true),
            'm_analytics' => array('name' => _('Google Analytics'), 'settings' => true, 'showHide' => true),
            'm_logo' => array('name' => _('Client logo'), 'settings' => true, 'showHide' => true),
            'm_copyright' => array('name' => _('Copyright'), 'settings' => true, 'showHide' => true),
            'm_privacy' => array('name' => _('Privacy'), 'settings' => true, 'showHide' => true),
            'm_social' => array('name' => _('Social share'), 'settings' => false, 'showHide' => true),
            'm_stickers' => array('name' => _('Stickers'), 'settings' => true, 'showHide' => true),
            'm_infobox' => array('name' => _('Infobox on start'), 'settings' => false, 'showHide' => true),
            'm_keepview' => array('name' => _('KEEPVIEW - set start view settings will be ignored'), 'settings' => false, 'showHide' => true),
            'm_arrowmode' => array('name' => _('Floating POI style - panorama POI only'), 'settings' => false, 'showHide' => true),
            'm_radarmode' => array('name' => _('Radar'), 'settings' => false, 'showHide' => true),
            'm_floorplans' => array('name' => _('Floor Plans'), 'settings' => false, 'showHide' => true),
            'm_autotour' => array('name' => _('Autotour'), 'settings' => true, 'showHide' => true),
            'm_simple_content_menu' => array('name' => _('Simple content menu'), 'settings' => false, 'showHide' => true),
        );
    }

    /**
     * Function returns default xml template which is part of new project
     */
    public static function XmlTemplatesConfig()
    {
        return <<<EOF
<krpano>
    <skin logo="false" banner="false">
        <modules>
            <item name="map" visible="true" map_default_view="roadmap" map_default_zoom="12" map_default_lat="50.0424363" map_default_lng="22.0165942"/>
            <item name="analytics" visible="false" id=""/>
            <item name="users" visible="true"/>
            <item name="postcard" visible="true"/>
            <item name="search" visible="true"/>
            <item name="view_options" visible="true"/>
            <item name="home" visible="true"/>
            <item name="history" visible="true"/>
            <item name="login" visible="true"/>
            <item name="share" visible="false"/>
        </modules>
    </skin>
<data name="copyright"><![CDATA[<p></p>]]></data>
</krpano>
EOF;

    }

}
