<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

/**
 * Class User is a representation of all users in the system
 *
 * @see     UserTable
 *
 * @package Application\Model
 */
class User extends MainModel
{

    const TYPE_DEV = 'developer';
    const TYPE_ADMIN = 'admin';
    const TYPE_EDITOR = 'editor';

    public $id;
    public $display_name;
    public $login;
    public $password;
    public $mail;
    public $date_added;
    public $active;
    public $usertype;
    public $settings;
    public $language;
    public $token;
    public $token_created;

    public function exchangeArray($data)
    {
        $this->id = (isset($data['id'])) ? $data['id'] : null;
        $this->display_name = (isset($data['display_name'])) ? $data['display_name'] : null;
        $this->login = (isset($data['login'])) ? $data['login'] : null;
        $this->password = (isset($data['password'])) ? $data['password'] : null;
        $this->mail = (isset($data['mail'])) ? $data['mail'] : null;
        $this->date_added = (isset($data['date_added'])) ? $data['date_added'] : null;
        $this->active = (isset($data['active'])) ? $data['active'] : null;
        $this->usertype = (isset($data['usertype'])) ? $data['usertype'] : null;
        $this->settings = (isset($data['settings'])) ? $data['settings'] : null;
        $this->language = (isset($data['language'])) ? $data['language'] : null;
        $this->token = (isset($data['token'])) ? $data['token'] : null;
        $this->token_created = (isset($data['token_created'])) ? $data['token_created'] : null;
    }
}
