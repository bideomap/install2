<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;


use Laminas\Db\TableGateway\TableGateway;

/**
 * Class UserTable performs CRUD operation on users stored in the database
 *
 * @package Application\Model
 */
class UserTable
{
    private $tableGateway;
    private $table = 'users';

    /**
     * @param TableGateway $tableGateway
     */
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    public function save(User $user)
    {
        if ((int)$user->id == 0) {
            $user->id = null;
            $userId = $this->tableGateway->insert($user->getArrayCopy());
        } else {
            $userData = $user->getArrayCopy();
            // do not touch some fields
            if (!$userData['password']) {
                unset($userData['password']);
            }
            if (!$userData['mail']) {
                unset($userData['mail']);
            }
            if (!$userData['date_added']) {
                unset($userData['date_added']);
            }
            if (!$userData['usertype']) {
                unset($userData['usertype']);
            }
            if (!$userData['active']) {
                unset($userData['active']);
            }
            if (!$userData['token']) {
                unset($userData['token']);
            }
            if (!$userData['token_created']) {
                unset($userData['token_created']);
            }
            if (!$userData['language']) {
                unset($userData['language']);
            }
            if (!$userData['settings']) {
                unset($userData['settings']);
            }
            $this->tableGateway->update($userData, ['id' => $user->id]);
            $userId = $user->id;
        }

        return $userId;
    }

    public function getUserById($userId)
    {
        return $this->tableGateway->select(['id' => $userId])->current();
    }

    public function getUserByLogin($login)
    {
        return $this->tableGateway->select(['login' => $login])->current();
    }

    public function getUserByToken($token)
    {
        return $this->tableGateway->select(['token' => $token])->current();
    }

    public function getAllUsers()
    {
        return $this->tableGateway->select();
    }

    public function deleteById($userId)
    {
        $this->tableGateway->delete(['id' => $userId]);
    }

    public function setLangForUser($login, $language)
    {
        $this->tableGateway->update(['language' => $language], ['login' => $login]);
    }

}
