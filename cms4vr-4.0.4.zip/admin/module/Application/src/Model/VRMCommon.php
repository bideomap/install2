<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Model;

use Aws\Credentials\Credentials;
use Aws\Polly\PollyClient;

/**
 * Class VRMCommon delivers a set of useful static functions to be used in the application
 *
 * @package Application\Model
 */
class VRMCommon
{

    /**
     * Converts image to jpg format
     *
     * @param $input
     * @param $origExt
     */
    public static function convertToJpg($input, $origExt)
    {
        $in_ext = $origExt;

        $in_func = 'png';

        if ($in_ext == 'gif') {
            $in_func = 'gif';
        }

        $in_func = 'imagecreatefrom' . $in_func;

        $image = $in_func($input);
        $bg = imagecreatetruecolor(imagesx($image), imagesy($image));
        imagefill($bg, 0, 0, imagecolorallocate($bg, 255, 255, 255));
        imagealphablending($bg, true);
        imagecopy($bg, $image, 0, 0, 0, 0, imagesx($image), imagesy($image));
        imagedestroy($image);
        imagejpeg($bg, $input, IMG_QUALITY);
        imagedestroy($bg);
    }

    /**
     * Resizes the image according to parameters provided
     *
     * @param        $input
     * @param        $output
     * @param        $width
     * @param        $height
     * @param string $scale
     *
     * @return bool
     */
    public static function resizeImage($input, $output, $width, $height, $scale = 'contain')
    {
        if (!file_exists($input) || !$width || !$height)
            return false;

        $in_ext = explode('.', $input);
        $in_ext = strtolower(end($in_ext));
        $out_ext = explode('.', $output);
        $out_ext = strtolower(end($out_ext));

        $orientation = 0;
        if (extension_loaded('exif') && ($in_ext == 'jpg' || $in_ext == 'jpeg')) {
            $exifData = @exif_read_data($input);
            if (isset($exifData['Orientation'])) {
                $orientation = $exifData['Orientation'];
            }
        }

        if ($in_ext == 'jpg' || $in_ext == 'jpeg') $in_func = 'jpeg';
        else if ($in_ext == 'png') $in_func = 'png';
        else if ($in_ext == 'gif') $in_func = 'gif';
        $in_func = 'imagecreatefrom' . $in_func;

        if ($out_ext == 'jpg' || $out_ext == 'jpeg') $out_func = 'jpeg';
        else if ($out_ext == 'png') $out_func = 'png';
        else if ($out_ext == 'gif') $out_func = 'gif';
        $out_func = 'image' . $out_func;

        $in_im = $in_func($input);

        // orientation fix
        switch($orientation) {
            case 3:
                $in_im = imagerotate($in_im, 180, 0);
                break;
            case 6:
                $in_im = imagerotate($in_im, -90, 0);
                break;
            case 8:
                $in_im = imagerotate($in_im, 90, 0);
                break;
        }

        $in_w = imagesx($in_im);
        $in_h = imagesy($in_im);

        if ($scale == 'contain') {
            $s = $width / $in_w;
            $im_w = $in_w * $s;
            $im_h = $in_h * $s;
            if ($im_h > $height) {
                $s = $height / $im_h;
                $im_h = $s * $im_h;
                $im_w = $s * $im_w;
            }
            $out_h = $im_h;
            $out_w = $im_w;
            $start_h = 0;
            $start_w = 0;
            $end_h = $im_h;
            $end_w = $im_w;
        } else if ($scale == 'cover') {
            $s = $width / $in_w;
            $im_w = $in_w * $s;
            $im_h = $in_h * $s;
            if ($im_h < $height) {
                $s = $height / $im_h;
                $im_h = $s * $im_h;
                $im_w = $s * $im_w;
            }
            $out_h = $height;
            $out_w = $width;
            $start_h = ($height - $im_h) / 2;
            $start_w = ($width - $im_w) / 2;
        }

        $out_im = imagecreatetruecolor($out_w, $out_h);
        imagealphablending($out_im, false);
        imagesavealpha($out_im, true);
        $transparent = imagecolorallocatealpha($out_im, 255, 255, 255, 127);
        imagefilledrectangle($out_im, 0, 0, $out_w - 1, $out_h - 1, $transparent);
        imagecopyresampled($out_im, $in_im, $start_w, $start_h, 0, 0, $im_w, $im_h, $in_w, $in_h);

        if ($out_func == 'imagejpeg') {
            imagejpeg($out_im, $output, IMG_QUALITY);
        } else
            $out_func($out_im, $output);

        imagedestroy($out_im);
        imagedestroy($in_im);
    }

    public static function convertAudio($inputFile)
    {
        $fileName = pathinfo($inputFile, PATHINFO_FILENAME);
        $outputDir = dirname($inputFile) . DIRECTORY_SEPARATOR;
        shell_exec('ffmpeg -i ' . $inputFile . ' ' . $outputDir . $fileName . '.mp3');
        // shell_exec('ffmpeg -i ' . $inputFile . ' ' . $outputDir . $fileName . '.ogg');
    }

    /**
     * Generates a randomized token having the requested string lengtu
     *
     * @param int       $length
     * @param bool|true $special_chars
     *
     * @return string
     */
    public static function generateToken($length = 40, $special_chars = true)
    {
        $charmap = '1234567890qwertyuiopasdfghjklzxcvbnm1234567890QWERTYUIOPASDFGHJKLZXCVBNM';
        if ($special_chars)
            $charmap .= '-------_______';
        $charmap = str_split($charmap);
        $return = '';
        for ($i=0; $i<$length; $i++)
        {
            shuffle($charmap);
            $return .= $charmap[0];
        }
        return $return;
    }


    /**
     * Removes all files and folder in directory
     *
     * @param string $path
     * @param bool $keepParent
     *
     * @return bool
     */
    public static function removeDirectory($path, $keepParent = false) {
        $files = glob($path . '/*');
        foreach ($files as $file) {
            is_dir($file) ? self::removeDirectory($file) : unlink($file);
        }
        if (!$keepParent) {
            @rmdir($path);
        }

        return true;
    }

    public static function purgePanoDirectory($panoId) {
        $directory = __DIR__ . '/../../../../../panos/p' . $panoId . '.tiles';

        if (!is_dir($directory)) {
            return false;
        }

        $dirContents = array_diff(scandir($directory), ['..', '.']);
        foreach ($dirContents as $dirContent) {
            if (is_dir($directory . DIRECTORY_SEPARATOR . $dirContent)) {
                self::removeDirectory($directory . DIRECTORY_SEPARATOR . $dirContent);
            }
        }
        return true;
    }

    /**
     * Returns list of supported languages
     *
     * @return array
     */
    public static function getSystemLanguages()
    {
        return ['ad', 'am', 'ba', 'be', 'bg', 'ch', 'cy', 'cz', 'de', 'dk', 'ee', 'en', 'es', 'fi',
            'fr', 'gr', 'hr', 'hu', 'ie', 'is', 'it', 'jp', 'ko', 'la', 'li', 'lt', 'lu', 'mk', 'mt', 'nl', 'no', 'pl', 'pt',
            'ro', 'ru', 'se', 'si', 'sk', 'sm', 'tr', 'ua', 'va', 'vi', 'wf', 'zn'];
    }

    /**
     * Reads PHP's limits for file uploads
     *
     * @param $attr
     * @return int|string
     */
    public static function getIniBytes($attr)
    {
        $attr_value = trim(ini_get($attr));

        if ($attr_value != '') {
            $type_byte = strtolower($attr_value[strlen($attr_value) - 1]);
        } else {
            return (int)$attr_value;
        }

        $attr_value = (int)$attr_value;

        switch ($type_byte) {
            case 'g': $attr_value *= 1024*1024*1024; break;
            case 'm': $attr_value *= 1024*1024; break;
            case 'k': $attr_value *= 1024; break;
        }

        return (int)$attr_value;
    }

    /**
     * Gets current upload limit
     *
     * @return string
     */
    public static function getMaxUploadSize()
    {
        $limit = min(VRMCommon::getIniBytes('post_max_size'), VRMCommon::getIniBytes('upload_max_filesize'));
        return number_format($limit/(1024*1024), 2) . 'MB';
    }

    /**
     * Gets available languages in the system
     * @return array
     */
    public static function getAvailableLanguages()
    {
        $languages = [];
        $languagesDir = __DIR__  . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'language' . DIRECTORY_SEPARATOR;

        foreach(glob($languagesDir . '*.mo') as $lang) {
            $languages[] = str_replace('.mo', '', basename($lang));
        }

        return $languages;
    }

    /**
     * Breaks text into smaller pieces suitable for Amazon Polly
     *
     * @param $text
     * @param int $maxLength
     * @return mixed
     */
    public static function breakLongText($text, $maxLength = 1450)
    {
        $split[0] = '';

        // remove new lines if any and other entities
        $text = str_replace([PHP_EOL, "\r", "\n"], '', $text);
        $text = str_replace('&nbsp;', ' ', $text);

        if (mb_strlen($text) < $maxLength) {
            $split[0] = $text;
            return $split;
        }

        $sentences = preg_split('/(?<=[.?!])\s+(?=[a-z])/iu', $text);

        $block = 0;
        foreach ($sentences as $sentence) {
            if (mb_strlen($split[$block]) + mb_strlen($sentence) < $maxLength) {
                $split[$block] .= ' ' . $sentence;
            } else {
                $block += 1;
                $split[$block] = $sentence;
            }
        }

        return $split;
    }

    public static function copyDirectory($source, $destination)
    {
        if (!@mkdir($destination) && !is_dir($destination)) {
            throw new \RuntimeException(sprintf('Directory "%s" was not created', $destination));
        }
        foreach (
            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($source, \RecursiveDirectoryIterator::SKIP_DOTS),
                \RecursiveIteratorIterator::SELF_FIRST) as $item) {
            if ($item->isDir()) {
                mkdir($destination . DIRECTORY_SEPARATOR . $iterator->getSubPathName());
            } else {
                copy($item, $destination . DIRECTORY_SEPARATOR . $iterator->getSubPathName());
            }
        }
    }

    public static function utf8ForXml($in)
    {
        return preg_replace('/[^\x{0009}\x{000a}\x{000d}\x{0020}-\x{D7FF}\x{E000}-\x{FFFD}]+/u', '', $in);
    }

    public static function recurse_copy($src,$dst) {
        $dir = opendir($src);
        @mkdir($dst);
        while(false !== ( $file = readdir($dir)) ) {
            if (( $file !== '.' ) && ( $file !== '..' )) {
                if ( is_dir($src . '/' . $file) ) {
                    self::recurse_copy($src . '/' . $file,$dst . '/' . $file);
                }
                else {
                    copy($src . '/' . $file,$dst . '/' . $file);
                }
            }
        }
        closedir($dir);
    }
}
