<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application;

use Application\Controller\AuthController;
use Application\Controller\PanoController;
use Application\Factory\VRMTranslatorFactory;
use Application\Factory\XmlWriterFactory;
use Application\Model\SettingsTable;
use Application\Service\AuthManager;
use Laminas\Db\Adapter\AdapterInterface;
use Laminas\Db\ResultSet\ResultSet;
use Laminas\Db\TableGateway\TableGateway;
use Laminas\I18n\Translator\TranslatorInterface;
use Laminas\ModuleManager\Feature\ConfigProviderInterface;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\Mvc\MvcEvent;

class Module implements ConfigProviderInterface
{
    const VERSION = '3.0.3-dev';

    public function getConfig()
    {
        return include __DIR__ . '/../config/module.config.php';
    }

    public function getServiceConfig()
    {
        return [
            'factories' => [
                Model\XmlWriter::class => XmlWriterFactory::class,
                Model\PanosTable::class => function($container) {
                    $tableGateway = $container->get(Model\PanosTableGateway::class);
                    return new Model\PanosTable($tableGateway);
                },
                Model\PanosTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\Panos());
                    return new TableGateway('panos', $dbAdapter, null, $resultSetPrototype);
                },
                Model\PanoPhrasesTable::class => function($container) {
                    $tableGateway = $container->get(Model\PanoPhrasesTableGateway::class);
                    return new Model\PanoPhrasesTable($tableGateway);
                },
                Model\PanoPhrasesTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\PanoPhrases());
                    return new TableGateway('pano_phrases', $dbAdapter, null, $resultSetPrototype);
                },
                Model\LanguagesTable::class => function($container) {
                    $tableGateway = $container->get(Model\LanguagesTableGateway::class);
                    return new Model\LanguagesTable($tableGateway);
                },
                Model\LanguagesTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\Languages());
                    return new TableGateway('languages', $dbAdapter, null, $resultSetPrototype);
                },
                Model\CategoriesTable::class => function($container) {
                    $tableGateway = $container->get(Model\CategoriesTableGateway::class);
                    return new Model\CategoriesTable($tableGateway);
                },
                Model\CategoriesTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\Categories());
                    return new TableGateway('categories', $dbAdapter, null, $resultSetPrototype);
                },
                Model\CategoryPhrasesTable::class => function($container) {
                    $tableGateway = $container->get(Model\CategoryPhrasesTableGateway::class);
                    return new Model\CategoryPhrasesTable($tableGateway);
                },
                Model\CategoryPhrasesTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\CategoryPhrases());
                    return new TableGateway('category_phrases', $dbAdapter, null, $resultSetPrototype);
                },
                Model\GalleriesTable::class => function($container) {
                    $tableGateway = $container->get(Model\GalleriesTableGateway::class);
                    return new Model\GalleriesTable($tableGateway);
                },
                Model\GalleriesTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\Galleries());
                    return new TableGateway('galleries', $dbAdapter, null, $resultSetPrototype);
                },
                Model\GalleryPhrasesTable::class => function($container) {
                    $tableGateway = $container->get(Model\GalleryPhrasesTableGateway::class);
                    return new Model\GalleryPhrasesTable($tableGateway);
                },
                Model\GalleryPhrasesTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\GalleryPhrases());
                    return new TableGateway('gallery_phrases', $dbAdapter, null, $resultSetPrototype);
                },
                Model\MediaGalleriesConnectionsTable::class => function($container) {
                    $tableGateway = $container->get(Model\MediaGalleriesConnectionsTableGateway::class);
                    return new Model\MediaGalleriesConnectionsTable($tableGateway);
                },
                Model\MediaGalleriesConnectionsTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\MediaGalleriesConnections());
                    return new TableGateway('media_galleries_connections', $dbAdapter, null, $resultSetPrototype);
                },
                Model\PanoCategoryConnectionsTable::class => function($container) {
                    $tableGateway = $container->get(Model\PanoCategoryConnectionsTableGateway::class);
                    return new Model\PanoCategoryConnectionsTable($tableGateway);
                },
                Model\PanoCategoryConnectionsTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\PanoCategoryConnections());
                    return new TableGateway('pano_category_connections', $dbAdapter, null, $resultSetPrototype);
                },
                Model\PanoSitePlansConnectionsTable::class => function($container) {
                    $tableGateway = $container->get(Model\PanoSitePlansConnectionsTableGateway::class);
                    return new Model\PanoSitePlansConnectionsTable($tableGateway);
                },
                Model\PanoSitePlansConnectionsTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\PanoSitePlansConnections());
                    return new TableGateway('pano_site_plans_connections', $dbAdapter, null, $resultSetPrototype);
                },
                Model\SitePlansTable::class => function($container) {
                    $tableGateway = $container->get(Model\SitePlansTableGateway::class);
                    return new Model\SitePlansTable($tableGateway);
                },
                Model\SitePlansTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\SitePlans());
                    return new TableGateway('site_plans', $dbAdapter, null, $resultSetPrototype);
                },
                Model\SitePlansPhrasesTable::class => function($container) {
                    $tableGateway = $container->get(Model\SitePlansPhrasesTableGateway::class);
                    return new Model\SitePlansPhrasesTable($tableGateway);
                },
                Model\SitePlansPhrasesTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\SitePlansPhrases());
                    return new TableGateway('site_plans_phrases', $dbAdapter, null, $resultSetPrototype);
                },
                Model\PoiTable::class => function($container) {
                    $tableGateway = $container->get(Model\PoiTableGateway::class);
                    return new Model\PoiTable($tableGateway);
                },
                Model\PoiTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\Poi());
                    return new TableGateway('poi', $dbAdapter, null, $resultSetPrototype);
                },
                Model\PoiPhrasesTable::class => function($container) {
                    $tableGateway = $container->get(Model\PoiPhrasesTableGateway::class);
                    return new Model\PoiPhrasesTable($tableGateway);
                },
                Model\PoiPhrasesTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\PoiPhrases());
                    return new TableGateway('poi_phrases', $dbAdapter, null, $resultSetPrototype);
                },
                Model\MediaTable::class => function($container) {
                    $tableGateway = $container->get(Model\MediaTableGateway::class);
                    return new Model\MediaTable($tableGateway);
                },
                Model\MediaTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\Media());
                    return new TableGateway('media', $dbAdapter, null, $resultSetPrototype);
                },
                Model\SettingsTable::class => function($container) {
                    $tableGateway = $container->get(Model\SettingsTableGateway::class);
                    return new Model\SettingsTable($tableGateway);
                },
                Model\SettingsTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\Settings());
                    return new TableGateway('settings', $dbAdapter, null, $resultSetPrototype);
                },
                Model\UserTable::class => function($container) {
                    $tableGateway = $container->get(Model\UserTableGateway::class);
                    return new Model\UserTable($tableGateway);
                },
                Model\UserTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\User());
                    return new TableGateway('users', $dbAdapter, null, $resultSetPrototype);
                },
                Model\ShortlinkTable::class => function($container) {
                    $tableGateway = $container->get(Model\ShortlinkTableGateway::class);
                    return new Model\ShortlinkTable($tableGateway);
                },
                Model\ShortlinkTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\Shortlink());
                    return new TableGateway('shortlinks', $dbAdapter, null, $resultSetPrototype);
                },
                Model\GamificationTable::class => function($container) {
                    $tableGateway = $container->get(Model\GamificationTableGateway::class);
                    return new Model\GamificationTable($tableGateway);
                },
                Model\GamificationTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\Gamification());
                    return new TableGateway('gamification', $dbAdapter, null, $resultSetPrototype);
                },
            ],
            'delegators' => [
                TranslatorInterface::class => [
                    VRMTranslatorFactory::class
                ]
            ]
        ];
    }

    /*public function getControllerConfig()
    {
        return [
            'factories' => [
                Controller\PanoController::class => function($container) {
                    return new Controller\PanoController(
                        $container->get(Model\PanosTable::class)
                    );
                },
            ],
        ];
    }*/

    /**
     * This method is called once the MVC bootstrapping is complete and allows
     * to register event listeners.
     *
     * @param MvcEvent $event
     */
    public function onBootstrap(MvcEvent $event)
    {
        // Get event manager.
        $eventManager = $event->getApplication()->getEventManager();
        $sharedEventManager = $eventManager->getSharedManager();
        // Register the event listener method.
        $sharedEventManager->attach(AbstractActionController::class,
                                    MvcEvent::EVENT_DISPATCH, [$this, 'onDispatch'], 100);
    }

    /**
     * Event listener method for the 'Dispatch' event. We listen to the Dispatch
     * event to call the access filter. The access filter allows to determine if
     * the current visitor is allowed to see the page or not. If he/she
     * is not authenticated and is not allowed to see the page, we redirect the user
     * to the login page.
     *
     * @param MvcEvent $event
     *
     * @return
     */
    public function onDispatch(MvcEvent $event)
    {
        /*$servicemanager = $event->getApplication()->getServiceManager();
        $translator = $servicemanager->get(TranslatorInterface::class);
        $translator->setLocale('pl_PL');*/

        // Get controller and action to which the HTTP request was dispatched.
        $controller = $event->getTarget();
        $controllerName = $event->getRouteMatch()->getParam('controller', null);
        $actionName = $event->getRouteMatch()->getParam('action', null);

        // Convert dash-style action name to camel-case.
        $actionName = str_replace('-', '', lcfirst(ucwords($actionName, '-')));

        // Get the instance of AuthManager service.
        $authManager = $event->getApplication()->getServiceManager()->get(AuthManager::class);

        // Execute the access filter on every controller except AuthController
        // (to avoid infinite redirect).
        if ($controllerName!=AuthController::class &&
            !$authManager->filterAccess($controllerName, $actionName)) {

            // Remember the URL of the page the user tried to access. We will
            // redirect the user to that URL after successful login.
            $uri = $event->getApplication()->getRequest()->getUri();
            // Make the URL relative (remove scheme, user info, host name and port)
            // to avoid redirecting to other domain by a malicious user.
            $uri->setScheme(null)
                ->setHost(null)
                ->setPort(null)
                ->setUserInfo(null);
            $redirectUrl = $uri->toString();

            // Redirect the user to the "Login" page.
            return $controller->redirect()->toRoute('vrm', ['controller' => 'auth', 'action' => 'login', 'redirectUrl'=>$redirectUrl]);
        }

        $settingsTable = $event->getApplication()->getServiceManager()->get(SettingsTable::class);

        // SSL redirect
        if((!isset($_SERVER["HTTPS"]) || strtolower($_SERVER["HTTPS"]) !== "on") && $settingsTable->get('force_ssl') == 1 && !isset($_GET['no_ssl'])) {
            header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
            exit;
        }

        // check if version is not banned
        $cmsDevVersion = $settingsTable->get('cms_dev_version');
        if ($cmsDevVersion == 'banned' && !($controllerName == PanoController::class && $actionName == 'addProjectAjax')) {
            $controller->layout('layout/banned');
        }
    }
}
