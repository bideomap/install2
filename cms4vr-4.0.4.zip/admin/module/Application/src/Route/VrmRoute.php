<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Route;

use Application\Controller\IndexController;
use Traversable;
use \Laminas\Router\Exception;
use Laminas\Router\Http\TreeRouteStack;
use \Laminas\Stdlib\ArrayUtils;
use \Laminas\Stdlib\RequestInterface as Request;
use \Laminas\Router\Http\RouteInterface;
use \Laminas\Router\Http\RouteMatch;

/**
 * VRM route.
 */
class VrmRoute implements RouteInterface
{
    // Defaults.
    protected $defaults;

    // List of assembled parameters.
    protected $assembledParams = [];

    // Constructor.
    public function __construct(array $defaults = [])
    {
        $this->defaults = $defaults;
    }

    // Create a new route with given options.
    public static function factory($options = [])
    {
        if ($options instanceof Traversable) {
            $options = ArrayUtils::iteratorToArray($options);
        } elseif (!is_array($options)) {
            throw new Exception\InvalidArgumentException(__METHOD__ .
                ' expects an array or Traversable set of options');
        }

        if (!isset($options['defaults'])) {
            $options['defaults'] = [];
        }

        return new static(
            $options['defaults']);
    }

    // Match a given request.
    public function match(Request $request, $pathOffset = null)
    {

        // Ensure this route type is used in a HTTP request
        if (!method_exists($request, 'getUri')) {
            return null;
        }

        $action = isset($_GET['a']) ? $_GET['a'] : 'index';
        $controller = isset($_GET['c']) ? 'Application\Controller\\' . ucfirst($_GET['c']) . 'Controller' : IndexController::class;

        unset($_GET['a']);
        unset($_GET['c']);

        $params = $_GET;

        $rm =  new RouteMatch(
            array_merge($this->defaults, ['controller' => $controller, 'action' => $action],
                $params),
            1);
        $rm->setMatchedRouteName('vrm/vrm');

        return $rm;
    }

    // Assembles an URL by route params
    public function assemble(array $params = [], array $options = [])
    {
        $mergedParams = array_merge($this->defaults, $params);
        $this->assembledParams = [];

        $url = '';

        $newParams = [];
        if (isset($mergedParams['controller'])) {
            $newParams['c'] = $mergedParams['controller'];
        }
        if (isset($mergedParams['action'])) {
            $newParams['a'] = $mergedParams['action'];
        }

        unset($mergedParams['controller']);
        unset($mergedParams['action']);

        if (count($mergedParams)) {
            foreach ($mergedParams as $k => $v) {
                $newParams[$k] = $v;
            }
        }

        if (count($newParams)) {
            $url = '/?' . http_build_query($newParams);
        }

        return $url;
    }

    // Get a list of parameters used while assembling.
    public function getAssembledParams()
    {
        return $this->assembledParams;
    }
}
