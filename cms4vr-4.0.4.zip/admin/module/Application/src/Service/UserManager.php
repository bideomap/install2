<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Service;

use Application\Model\User;
use Application\Model\UserTable;
use Laminas\Crypt\Password\Bcrypt;
use Laminas\Math\Rand;

/**
 * This service is responsible for adding/editing users
 * and changing user password.
 */
class UserManager
{

    private $userTable;

    /**
     * Constructs the service.
     *
     * @param UserTable $userTable
     */
    public function __construct(UserTable $userTable)
    {
        $this->userTable = $userTable;
    }

    /**
     * This method adds a new user.
     */
    public function saveUser($data, $triggeringUser = false)
    {
        // Do not allow several users with the same email address.
        if((int)$data['id'] === 0 && $this->checkUserExists($data['login'])) {
            throw new \Exception("User with email address " . $data['login'] . " already exists");
        }

        // Create new User entity.
        $user = new User();
        $user->id = $data['id'];
        $user->login = $data['login'];
        $user->display_name = $data['display_name'];

        if (in_array($data['usertype'], [User::TYPE_ADMIN, User::TYPE_EDITOR, User::TYPE_DEV])) {
            $user->usertype = $data['usertype'];
        }

        // Encrypt password and store the password in encrypted state.
        if (isset($data['password']) && trim($data['password'])) {
            $bcrypt = new Bcrypt();
            $passwordHash = $bcrypt->create($data['password']);
            $user->password = $passwordHash;
        }

        $user->active = $data['active'] ? true : false;

        if (isset($data['allowed_categories']) && $data['usertype'] == User::TYPE_EDITOR) {
            $user->settings = json_encode(['allowed_categories' => $data['allowed_categories']]);
        } elseif (isset($data['new_pano']) && $data['usertype'] == User::TYPE_ADMIN && $triggeringUser == User::TYPE_DEV) {
            $user->settings = json_encode(['new_pano' => $data['new_pano']]);
        } else {
            $user->settings = null;
        }

        if (!$data['id']) {
            $currentDate = date('Y-m-d H:i:s');
            $user->date_added = $currentDate;
        }

        // Add the entity to the entity manager.
        $this->userTable->save($user);

        return $user;
    }

    /**
     * Checks whether an active user with given email address already exists in the database.
     */
    public function checkUserExists($email)
    {
        $user = $this->userTable->getUserByLogin($email);

        return $user !== null;
    }

    /**
     * Checks that the given password is correct.
     */
    public function validatePassword(User $user, $password)
    {
        $bcrypt = new Bcrypt();
        $passwordHash = $user->password;

        if ($bcrypt->verify($password, $passwordHash)) {
            return true;
        }

        return false;
    }

    /**
     * Generates a password reset token for the user. This token is then stored in database and
     * sent to the user's E-mail address. When the user clicks the link in E-mail message, he is
     * directed to the Set Password page.
     */
    public function generatePasswordResetToken($email)
    {
        // Generate a token.
        $token = Rand::getString(32, '0123456789abcdefghijklmnopqrstuvwxyz', true);
        $currentDate = date('Y-m-d H:i:s');

        $user = $this->userTable->getUserByLogin($email);

        if (!$user) {
            return false;
        }

        $user->token = $token;
        $user->token_created = $currentDate;

        $this->userTable->save($user);

        $subject = 'Password Reset';

        $httpHost = isset($_SERVER['HTTP_HOST'])?$_SERVER['HTTP_HOST']:'localhost';
        $isSSL = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != '' ? "https" : "http";
        $subdirPart = str_replace('/admin', '', dirname($_SERVER['PHP_SELF']));
        $passwordResetUrl = $isSSL . '://' . $httpHost . $subdirPart . '/admin/?c=auth&a=set-password&token=' . $token;

        $body = "Please follow the link below to reset your password:\n";
        $body .= "$passwordResetUrl\n";
        $body .= "If you haven't asked to reset your password, please ignore this message.\n";

        $headers = 'From: ' . PANEL_TYTUL . ' <noreply@' . $httpHost . ">\r\n" .
            'X-Mailer: ' . PANEL_TYTUL;

        // Send email to user.
        mail($user->login, $subject, $body, $headers);

        return true;
    }

    /**
     * Checks whether the given password reset token is a valid one.
     */
    public function validatePasswordResetToken($passwordResetToken)
    {
        $user = $this->userTable->getUserByToken($passwordResetToken);

        if($user==null) {
            return false;
        }

        $tokenCreationDate = $user->token_created;
        $tokenCreationDate = strtotime($tokenCreationDate);

        $currentDate = strtotime('now');

        if ($currentDate - $tokenCreationDate > 24*60*60) {
            return false; // expired
        }

        return true;
    }

    /**
     * This method sets new password by password reset token.
     */
    public function setNewPasswordByToken($passwordResetToken, $newPassword)
    {
        if (!$this->validatePasswordResetToken($passwordResetToken)) {
            return false;
        }

        $user = $this->userTable->getUserByToken($passwordResetToken);

        if ($user==null) {
            return false;
        }

        // Set new password for user
        $bcrypt = new Bcrypt();
        $passwordHash = $bcrypt->create($newPassword);
        $user->password = $passwordHash;

        // Remove password reset token
        $user->token = '-';
        $user->token_created = '0000-00-00 00:00:00';

        $this->userTable->save($user);

        return true;
    }
}

