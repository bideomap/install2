<?php

namespace Application\Service;

class XmlReaderService
{

    protected $xmlData;

    public function __construct($xmlData)
    {
        $this->xmlData = $xmlData;
    }

    /**
     * @return array
     */
    public function getScenes()
    {
        $xml = simplexml_load_string($this->xmlData);
        $scenes = [];

        $i = 0;
        foreach ($xml->scene as $scene) {
            $scenes[$i]['title'] = (string)$scene['title'];
            $scenes[$i]['name'] = (string)$scene['name'];
            $scenes[$i]['thumbnail'] = (string)$scene['thumburl'];
            $scenes[$i]['preview_url'] = (string)$scene->preview['url'];
            $scenes[$i]['lat'] = (string)$scene['lat'];
            $scenes[$i]['lng'] = (string)$scene['lng'];
            $scenes[$i]['heading'] = trim((string)$scene['heading']) === '' ? '0.00001' : trim((string)$scene['heading']);
            $scenes[$i]['dir'] = $this->getSceneDir((string)$scene['thumburl']);
            $scenes[$i]['xml'] = $scene->asXml();

            $i++;
        }

        return $scenes;
    }

    public function getScene($index)
    {
        return $this->getScenes()[$index] ?? null;
    }

    public function getSceneDir($thumbnailPath)
    {
        $thumbDirTree = explode('/', $thumbnailPath);

        return $thumbDirTree[1] ?? null;
    }
}
