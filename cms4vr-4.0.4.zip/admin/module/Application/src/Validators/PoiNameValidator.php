<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\Validators;

use Laminas\Validator\AbstractValidator;

/**
 * Class PoiNameValidator provides validation for POI names
 *
 * By design, at least one name in any language is required, and such condition triggers other relevant validations
 * through own fieldsets if needed
 *
 * @package Application\Validators
 */
class PoiNameValidator extends AbstractValidator
{
    const NAME_EMPTY = 'NAME_EMPTY';

    protected $messageTemplates = [
        self::NAME_EMPTY => 'NAME_EMPTY',
    ];

    public function __construct(array $options = [])
    {
        parent::__construct($options);
    }

    /**
     * Check if at least one name has been provided
     *
     * @param mixed $value
     * @param null  $context
     *
     * @return bool
     */
    public function isValid($value, $context = null)
    {
        foreach ($context['poi_fs'] as $lang => $field) {
            if (trim($field['name']) != '') {
                return true;
            }
        }
        $this->error(self::NAME_EMPTY);

        return false;
    }

}
