<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\View\Helper;

use Application\Model\SettingsTable;
use Laminas\View\Helper\AbstractHelper;

/**
 * Class UserInfo is a simple view helper to provide basic information about the user in view files
 *
 * @package Application\View\Helper
 */
class ProjectInfo extends AbstractHelper
{
    private $settingsTable;
    private $defaultLanguage;

    public function __construct(SettingsTable $settingsTable)
    {
        $this->settingsTable = $settingsTable;
        $this->defaultLanguage = $settingsTable->get('default_language');
    }

    public function getDefaultLanguage()
    {
        return $this->defaultLanguage;
    }
}
