<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

namespace Application\View\Helper;

use Application\Model\SettingsTable;
use Application\Model\UserTable;
use Laminas\Authentication\AuthenticationService;
use Laminas\View\Helper\AbstractHelper;

/**
 * Class UserInfo is a simple view helper to provide basic information about the user in view files
 *
 * @package Application\View\Helper
 */
class UserInfo extends AbstractHelper
{
    private $userTable;
    private $authenticationService;
    private $user;
    private $settingsTable;

    public function __construct(UserTable $userTable, AuthenticationService $authenticationService, SettingsTable $settingsTable)
    {
        $this->userTable = $userTable;
        $this->authenticationService = $authenticationService;
        $this->settingsTable = $settingsTable;
    }

    public function __invoke()
    {
        if (!$this->user) {
            $login = $this->authenticationService->getIdentity();
            $this->user = $this->userTable->getUserByLogin($login);
            $this->user->cmsDevVersion = $this->settingsTable->get('cms_dev_version');
            $this->user->settingsTable = $this->settingsTable;
        }

        return $this->user;
    }
}
