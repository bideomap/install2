var ico_list = [
    {
         
        name: "ab-testing",
        codepoint: "F001C",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "access-point",
        codepoint: "F002",
        aliases: [
            "wireless"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "access-point-network",
        codepoint: "F003",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "access-point-network-off",
        codepoint: "FBBD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "account",
        codepoint: "F004",
        aliases: [
            "person",
            "user"
        ],
        tags: [
            "Account \/ User",
            "Home Automation"
        ],
    },
    {
        
        name: "account-alert",
        codepoint: "F005",
        aliases: [
            "user-alert",
            "account-warning",
            "user-warning",
            "person-alert",
            "person-warning"
        ],
        tags: [
            "Account \/ User",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "account-alert-outline",
        codepoint: "FB2C",
        aliases: [
            "user-alert-outline",
            "account-warning-outline",
            "user-warning-outline",
            "person-warning-outline",
            "person-alert-outline"
        ],
        tags: [
            "Account \/ User",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "account-arrow-left",
        codepoint: "FB2D",
        aliases: [
            "user-arrow-left",
            "person-arrow-left"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-arrow-left-outline",
        codepoint: "FB2E",
        aliases: [
            "user-arrow-left-outline",
            "person-arrow-left-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-arrow-right",
        codepoint: "FB2F",
        aliases: [
            "user-arrow-right",
            "person-arrow-right"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-arrow-right-outline",
        codepoint: "FB30",
        aliases: [
            "user-arrow-right-outline",
            "person-arrow-right-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-badge",
        codepoint: "FD83",
        aliases: [
            "user-badge",
            "person-badge"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-badge-alert",
        codepoint: "FD84",
        aliases: [
            "user-badge-alert",
            "person-badge-alert",
            "account-badge-warning",
            "user-badge-warning",
            "person-badge-warning"
        ],
        tags: [
            "Account \/ User",
            "Alert \/ Error",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "account-badge-alert-outline",
        codepoint: "FD85",
        aliases: [
            "user-badge-alert-outline",
            "person-badge-alert-outline",
            "account-badge-warning-outline",
            "user-badge-warning-outline",
            "person-badge-warning-outline"
        ],
        tags: [
            "Account \/ User",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "account-badge-horizontal",
        codepoint: "FDF0",
        aliases: [],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-badge-horizontal-outline",
        codepoint: "FDF1",
        aliases: [],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-badge-outline",
        codepoint: "FD86",
        aliases: [
            "user-badge-outline",
            "person-badge-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-box",
        codepoint: "F006",
        aliases: [
            "selfie",
            "user-box",
            "person-box",
            "contact"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-box-multiple",
        codepoint: "F933",
        aliases: [
            "switch-account",
            "user-box-multiple",
            "account-boxes",
            "user-boxes",
            "person-box-multiple",
            "person-boxes"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-box-multiple-outline",
        codepoint: "F002C",
        aliases: [],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-box-outline",
        codepoint: "F007",
        aliases: [
            "selfie-outline",
            "user-box-outline",
            "portrait",
            "contact-outline",
            "person-box-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-card-details",
        codepoint: "F5D2",
        aliases: [
            "identification-card",
            "user-card-details",
            "id-card",
            "person-card-details",
            "drivers-license",
            "business-card"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-card-details-outline",
        codepoint: "FD87",
        aliases: [
            "identification-card-outline",
            "user-card-details-outline",
            "id-card-outline",
            "person-card-details-outline",
            "drivers-license-outline",
            "business-card-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-cash",
        codepoint: "F00C2",
        aliases: [],
        tags: [
            "Account \/ User",
            "Banking"
        ],
    },
    {
        
        name: "account-cash-outline",
        codepoint: "F00C3",
        aliases: [],
        tags: [
            "Account \/ User",
            "Banking"
        ],
    },
    {
        
        name: "account-check",
        codepoint: "F008",
        aliases: [
            "user-check",
            "account-tick",
            "user-tick",
            "person-check",
            "person-tick",
            "how-to-reg"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-check-outline",
        codepoint: "FBBE",
        aliases: [
            "account-tick-outline",
            "user-check-outline",
            "user-tick-outline",
            "person-check-outline",
            "person-tick-outline",
            "how-to-reg-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-child",
        codepoint: "FA88",
        aliases: [
            "user-child",
            "person-child",
            "guardian"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-child-circle",
        codepoint: "FA89",
        aliases: [
            "user-child-circle",
            "person-child-circle",
            "guardian-circle"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-child-outline",
        codepoint: "F00F3",
        aliases: [],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-circle",
        codepoint: "F009",
        aliases: [
            "user-circle",
            "person-circle"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-circle-outline",
        codepoint: "FB31",
        aliases: [
            "user-circle-outline",
            "person-circle-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-clock",
        codepoint: "FB32",
        aliases: [
            "user-clock",
            "account-pending",
            "person-clock"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-clock-outline",
        codepoint: "FB33",
        aliases: [
            "user-clock-outline",
            "account-pending-outline",
            "person-clock-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-convert",
        codepoint: "F00A",
        aliases: [
            "user-convert",
            "person-convert"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-details",
        codepoint: "F631",
        aliases: [
            "user-details",
            "person-details"
        ],
        tags: [
            "Account \/ User",
            "Settings"
        ],
    },
    {
        
        name: "account-edit",
        codepoint: "F6BB",
        aliases: [
            "user-edit",
            "person-edit"
        ],
        tags: [
            "Account \/ User",
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "account-edit-outline",
        codepoint: "F001D",
        aliases: [],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-group",
        codepoint: "F848",
        aliases: [
            "user-group",
            "users-group",
            "person-group",
            "people-group",
            "accounts-group"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-group-outline",
        codepoint: "FB34",
        aliases: [
            "user-group-outline",
            "users-group-outline",
            "person-group-outline",
            "people-group-outline",
            "accounts-group-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-heart",
        codepoint: "F898",
        aliases: [
            "user-heart",
            "person-heart"
        ],
        tags: [
            "Account \/ User",
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "account-heart-outline",
        codepoint: "FBBF",
        aliases: [
            "user-heart-outline",
            "person-heart-outline"
        ],
        tags: [
            "Account \/ User",
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "account-key",
        codepoint: "F00B",
        aliases: [
            "user-key",
            "person-key"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-key-outline",
        codepoint: "FBC0",
        aliases: [
            "user-key-outline",
            "person-key-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-lock",
        codepoint: "F0189",
        aliases: [
            "account-security",
            "account-secure"
        ],
        tags: [
            "Account \/ User",
            "Lock"
        ],
    },
    {
        
        name: "account-lock-outline",
        codepoint: "F018A",
        aliases: [
            "account-security-outline",
            "account-secure-outline"
        ],
        tags: [
            "Account \/ User",
            "Lock"
        ],
    },
    {
        
        name: "account-minus",
        codepoint: "F00D",
        aliases: [
            "user-minus",
            "person-minus"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-minus-outline",
        codepoint: "FAEB",
        aliases: [
            "user-minus-outline",
            "person-minus-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-multiple",
        codepoint: "F00E",
        aliases: [
            "people",
            "user-multiple",
            "group",
            "accounts",
            "users",
            "person-multiple"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-multiple-check",
        codepoint: "F8C4",
        aliases: [
            "user-multiple-check",
            "account-multiple-tick",
            "accounts-check",
            "accounts-tick",
            "users-check",
            "users-tick",
            "user-multiple-tick",
            "person-multiple-check",
            "person-multiple-tick",
            "people-check",
            "people-tick"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-multiple-check-outline",
        codepoint: "F0229",
        aliases: [],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-multiple-minus",
        codepoint: "F5D3",
        aliases: [
            "user-multiple-minus",
            "accounts-minus",
            "users-minus",
            "people-minus",
            "person-multiple-minus"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-multiple-minus-outline",
        codepoint: "FBC1",
        aliases: [
            "accounts-minus-outline",
            "people-minus-outline",
            "user-multiple-minus-outline",
            "users-minus-outline",
            "person-multiple-minus-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-multiple-outline",
        codepoint: "F00F",
        aliases: [
            "user-multiple-outline",
            "people-outline",
            "accounts-outline",
            "users-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-multiple-plus",
        codepoint: "F010",
        aliases: [
            "user-multiple-plus",
            "group-add",
            "accounts-plus",
            "users-plus",
            "person-multiple-plus",
            "people-plus",
            "person-multiple-add",
            "people-add",
            "account-multiple-add",
            "accounts-add",
            "user-multiple-add",
            "users-add"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-multiple-plus-outline",
        codepoint: "F7FF",
        aliases: [
            "group-add-outline",
            "user-multiple-plus-outline",
            "accounts-plus-outline",
            "users-plus-outline",
            "person-multiple-plus-outline",
            "people-plus-outline",
            "person-multiple-add-outline",
            "people-add-outline",
            "account-multiple-add-outline",
            "accounts-add-outline",
            "user-multiple-add-outline",
            "users-add-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-multiple-remove",
        codepoint: "F0235",
        aliases: [],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-multiple-remove-outline",
        codepoint: "F0236",
        aliases: [],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-network",
        codepoint: "F011",
        aliases: [
            "user-network",
            "person-network"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-network-outline",
        codepoint: "FBC2",
        aliases: [
            "user-network-outline",
            "person-network-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-off",
        codepoint: "F012",
        aliases: [
            "user-off",
            "person-off"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-off-outline",
        codepoint: "FBC3",
        aliases: [
            "user-off-outline",
            "person-off-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-outline",
        codepoint: "F013",
        aliases: [
            "user-outline",
            "perm-identity",
            "person-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-plus",
        codepoint: "F014",
        aliases: [
            "register",
            "user-plus",
            "person-add",
            "account-add",
            "person-plus",
            "user-add"
        ],
        tags: [
            "Account \/ User",
            "Home Automation"
        ],
    },
    {
        
        name: "account-plus-outline",
        codepoint: "F800",
        aliases: [
            "person-add-outline",
            "register-outline",
            "user-plus-outline",
            "account-add-outline",
            "person-plus-outline",
            "user-add-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-question",
        codepoint: "FB35",
        aliases: [
            "user-help",
            "account-question-mark",
            "account-help",
            "user-question",
            "person-question",
            "person-help"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-question-outline",
        codepoint: "FB36",
        aliases: [
            "account-question-mark-outline",
            "user-help-outline",
            "account-help-outline",
            "user-question-outline",
            "person-question-outline",
            "person-help-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-remove",
        codepoint: "F015",
        aliases: [
            "user-remove",
            "person-remove"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-remove-outline",
        codepoint: "FAEC",
        aliases: [
            "user-remove-outline",
            "person-remove-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-search",
        codepoint: "F016",
        aliases: [
            "user-search",
            "person-search"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-search-outline",
        codepoint: "F934",
        aliases: [
            "user-search-outline",
            "person-search-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-settings",
        codepoint: "F630",
        aliases: [
            "user-settings",
            "person-settings"
        ],
        tags: [
            "Account \/ User",
            "Settings"
        ],
    },
    {
        
        name: "account-settings-outline",
        codepoint: "F00F4",
        aliases: [],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-star",
        codepoint: "F017",
        aliases: [
            "user-star",
            "person-star"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-star-outline",
        codepoint: "FBC4",
        aliases: [
            "user-star-outline",
            "person-star-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-supervisor",
        codepoint: "FA8A",
        aliases: [
            "user-supervisor",
            "person-supervisor"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-supervisor-circle",
        codepoint: "FA8B",
        aliases: [
            "user-supervisor-circle",
            "person-supervisor-circle"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-supervisor-outline",
        codepoint: "F0158",
        aliases: [],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-switch",
        codepoint: "F019",
        aliases: [
            "user-switch",
            "accounts-switch",
            "users-switch",
            "person-switch",
            "people-switch"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-tie",
        codepoint: "FCBF",
        aliases: [
            "person-tie",
            "user-tie"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "account-tie-outline",
        codepoint: "F00F5",
        aliases: [],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "accusoft",
        codepoint: "F849",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "adchoices",
        codepoint: "FD1E",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "adjust",
        codepoint: "F01A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "adobe",
        codepoint: "F935",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "adobe-acrobat",
        codepoint: "FFBD",
        aliases: [
            "pdf"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "air-conditioner",
        codepoint: "F01B",
        aliases: [
            "ac-unit"
        ],
        tags: [
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "air-filter",
        codepoint: "FD1F",
        aliases: [
            "water-filter",
            "filter"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "air-horn",
        codepoint: "FD88",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "air-humidifier",
        codepoint: "F00C4",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "air-purifier",
        codepoint: "FD20",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "airbag",
        codepoint: "FBC5",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "airballoon",
        codepoint: "F01C",
        aliases: [
            "hot-air-balloon"
        ],
        tags: [
            "Transportation + Other",
            "Transportation + Flying"
        ],
    },
    {
        
        name: "airballoon-outline",
        codepoint: "F002D",
        aliases: [
            "hot-air-balloon-outline"
        ],
        tags: [
            "Transportation + Flying"
        ],
    },
    {
        
        name: "airplane",
        codepoint: "F01D",
        aliases: [
            "aeroplane",
            "airplanemode-active",
            "flight",
            "local-airport",
            "flight-mode",
            "plane"
        ],
        tags: [
            "Transportation + Flying",
            "Navigation"
        ],
    },
    {
        
        name: "airplane-landing",
        codepoint: "F5D4",
        aliases: [
            "aeroplane-landing",
            "flight-land",
            "plane-landing"
        ],
        tags: [
            "Transportation + Flying"
        ],
    },
    {
        
        name: "airplane-off",
        codepoint: "F01E",
        aliases: [
            "aeroplane-off",
            "airplanemode-inactive",
            "flight-mode-off",
            "plane-off"
        ],
        tags: [
            "Transportation + Flying"
        ],
    },
    {
        
        name: "airplane-takeoff",
        codepoint: "F5D5",
        aliases: [
            "aeroplane-takeoff",
            "flight-takeoff",
            "plane-takeoff",
            "airplane-take-off"
        ],
        tags: [
            "Transportation + Flying"
        ],
    },
    {
        
        name: "airplay",
        codepoint: "F01F",
        aliases: [
            "apple"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "airport",
        codepoint: "F84A",
        aliases: [],
        tags: [
            "Places",
            "Transportation + Flying"
        ],
    },
    {
        
        name: "alarm",
        codepoint: "F020",
        aliases: [
            "access-alarms",
            "alarm-clock"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "alarm-bell",
        codepoint: "F78D",
        aliases: [],
        tags: [
            "Notification"
        ],
    },
    {
        
        name: "alarm-check",
        codepoint: "F021",
        aliases: [
            "alarm-on",
            "alarm-tick",
            "alarm-clock-check",
            "alarm-clock-tick"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "alarm-light",
        codepoint: "F78E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "alarm-light-outline",
        codepoint: "FBC6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "alarm-multiple",
        codepoint: "F022",
        aliases: [
            "alarms",
            "alarm-clock-multiple",
            "alarm-clocks"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "alarm-note",
        codepoint: "FE8E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "alarm-note-off",
        codepoint: "FE8F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "alarm-off",
        codepoint: "F023",
        aliases: [
            "alarm-clock-off"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "alarm-plus",
        codepoint: "F024",
        aliases: [
            "add-alarm",
            "alarm-clock-plus",
            "alarm-clock-add",
            "alarm-add"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "alarm-snooze",
        codepoint: "F68D",
        aliases: [
            "alarm-clock-snooze"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "album",
        codepoint: "F025",
        aliases: [
            "vinyl",
            "record"
        ],
        tags: [
            "Audio",
            "Music"
        ],
    },
    {
        
        name: "alert",
        codepoint: "F026",
        aliases: [
            "warning",
            "report-problem"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "alert-box",
        codepoint: "F027",
        aliases: [
            "warning-box"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "alert-box-outline",
        codepoint: "FCC0",
        aliases: [
            "warning-box-outline"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "alert-circle",
        codepoint: "F028",
        aliases: [
            "warning-circle",
            "error"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "alert-circle-check",
        codepoint: "F0218",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "alert-circle-check-outline",
        codepoint: "F0219",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "alert-circle-outline",
        codepoint: "F5D6",
        aliases: [
            "warning-circle-outline",
            "error-outline",
            "git-issue"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "alert-decagram",
        codepoint: "F6BC",
        aliases: [
            "new-releases",
            "warning-decagram"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "alert-decagram-outline",
        codepoint: "FCC1",
        aliases: [
            "warning-decagram-outline"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "alert-octagon",
        codepoint: "F029",
        aliases: [
            "warning-octagon",
            "report"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "alert-octagon-outline",
        codepoint: "FCC2",
        aliases: [
            "warning-octagon-outline"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "alert-octagram",
        codepoint: "F766",
        aliases: [
            "warning-octagram"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "alert-octagram-outline",
        codepoint: "FCC3",
        aliases: [
            "warning-octagram-outline"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "alert-outline",
        codepoint: "F02A",
        aliases: [
            "warning-outline"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "alert-rhombus",
        codepoint: "F01F9",
        aliases: [],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "alert-rhombus-outline",
        codepoint: "F01FA",
        aliases: [],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "alien",
        codepoint: "F899",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "alien-outline",
        codepoint: "F00F6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "align-horizontal-center",
        codepoint: "F01EE",
        aliases: [
            "align-horizontal-centre"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "align-horizontal-left",
        codepoint: "F01ED",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "align-horizontal-right",
        codepoint: "F01EF",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "align-vertical-bottom",
        codepoint: "F01F0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "align-vertical-center",
        codepoint: "F01F1",
        aliases: [
            "align-vertical-centre"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "align-vertical-top",
        codepoint: "F01F2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "all-inclusive",
        codepoint: "F6BD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "alpha",
        codepoint: "F02B",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-a",
        codepoint: "0041",
        aliases: [
            "alphabet-a",
            "letter-a"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-a-box",
        codepoint: "FAED",
        aliases: [
            "alphabet-a-box",
            "letter-a-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-a-box-outline",
        codepoint: "FBC7",
        aliases: [
            "alphabet-a-box-outline",
            "letter-a-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-a-circle",
        codepoint: "FBC8",
        aliases: [
            "alphabet-a-circle",
            "letter-a-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-a-circle-outline",
        codepoint: "FBC9",
        aliases: [
            "alphabet-a-circle-outline",
            "letter-a-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-b",
        codepoint: "0042",
        aliases: [
            "alphabet-b",
            "letter-b"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-b-box",
        codepoint: "FAEE",
        aliases: [
            "alphabet-b-box",
            "letter-b-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-b-box-outline",
        codepoint: "FBCA",
        aliases: [
            "alphabet-b-box-outline",
            "letter-b-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-b-circle",
        codepoint: "FBCB",
        aliases: [
            "alphabet-b-circle",
            "letter-b-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-b-circle-outline",
        codepoint: "FBCC",
        aliases: [
            "alphabet-b-circle-outline",
            "letter-b-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-c",
        codepoint: "0043",
        aliases: [
            "alphabet-c",
            "letter-c"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-c-box",
        codepoint: "FAEF",
        aliases: [
            "alphabet-c-box",
            "letter-c-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-c-box-outline",
        codepoint: "FBCD",
        aliases: [
            "alphabet-c-box-outline",
            "letter-c-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-c-circle",
        codepoint: "FBCE",
        aliases: [
            "alphabet-c-circle",
            "letter-c-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-c-circle-outline",
        codepoint: "FBCF",
        aliases: [
            "alphabet-c-circle-outline",
            "letter-c-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-d",
        codepoint: "0044",
        aliases: [
            "alphabet-d",
            "letter-d",
            "drive"
        ],
        tags: [
            "Automotive",
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-d-box",
        codepoint: "FAF0",
        aliases: [
            "alphabet-d-box",
            "letter-d-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-d-box-outline",
        codepoint: "FBD0",
        aliases: [
            "alphabet-d-box-outline",
            "letter-d-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-d-circle",
        codepoint: "FBD1",
        aliases: [
            "alphabet-d-circle",
            "letter-d-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-d-circle-outline",
        codepoint: "FBD2",
        aliases: [
            "alphabet-d-circle-outline",
            "letter-d-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-e",
        codepoint: "0045",
        aliases: [
            "alphabet-e",
            "letter-e"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-e-box",
        codepoint: "FAF1",
        aliases: [
            "alphabet-e-box",
            "letter-e-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-e-box-outline",
        codepoint: "FBD3",
        aliases: [
            "alphabet-e-box-outline",
            "letter-e-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-e-circle",
        codepoint: "FBD4",
        aliases: [
            "alphabet-e-circle",
            "letter-e-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-e-circle-outline",
        codepoint: "FBD5",
        aliases: [
            "alphabet-e-circle-outline",
            "letter-e-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-f",
        codepoint: "0046",
        aliases: [
            "alphabet-f",
            "letter-f"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-f-box",
        codepoint: "FAF2",
        aliases: [
            "alphabet-f-box",
            "letter-f-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-f-box-outline",
        codepoint: "FBD6",
        aliases: [
            "alphabet-f-box-outline",
            "letter-f-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-f-circle",
        codepoint: "FBD7",
        aliases: [
            "alphabet-f-circle",
            "letter-f-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-f-circle-outline",
        codepoint: "FBD8",
        aliases: [
            "alphabet-f-circle-outline",
            "letter-f-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-g",
        codepoint: "0047",
        aliases: [
            "alphabet-g",
            "letter-g"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-g-box",
        codepoint: "FAF3",
        aliases: [
            "alphabet-g-box",
            "letter-g-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-g-box-outline",
        codepoint: "FBD9",
        aliases: [
            "alphabet-g-box-outline",
            "letter-g-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-g-circle",
        codepoint: "FBDA",
        aliases: [
            "alphabet-g-circle",
            "letter-g-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-g-circle-outline",
        codepoint: "FBDB",
        aliases: [
            "alphabet-g-circle-outline",
            "letter-g-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-h",
        codepoint: "0048",
        aliases: [
            "alphabet-h",
            "letter-h"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-h-box",
        codepoint: "FAF4",
        aliases: [
            "alphabet-h-box",
            "letter-h-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-h-box-outline",
        codepoint: "FBDC",
        aliases: [
            "alphabet-h-box-outline",
            "letter-h-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-h-circle",
        codepoint: "FBDD",
        aliases: [
            "alphabet-h-circle",
            "letter-h-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-h-circle-outline",
        codepoint: "FBDE",
        aliases: [
            "alphabet-h-circle-outline",
            "letter-h-circle-outline",
            "helipad"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-i",
        codepoint: "0049",
        aliases: [
            "alphabet-i",
            "letter-i",
            "roman-numeral-1"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-i-box",
        codepoint: "FAF5",
        aliases: [
            "alphabet-i-box",
            "letter-i-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-i-box-outline",
        codepoint: "FBDF",
        aliases: [
            "alphabet-i-box-outline",
            "letter-i-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-i-circle",
        codepoint: "FBE0",
        aliases: [
            "alphabet-i-circle",
            "letter-i-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-i-circle-outline",
        codepoint: "FBE1",
        aliases: [
            "alphabet-i-circle-outline",
            "letter-i-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-j",
        codepoint: "004A",
        aliases: [
            "alphabet-j",
            "letter-j"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-j-box",
        codepoint: "FAF6",
        aliases: [
            "alphabet-j-box",
            "letter-j-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-j-box-outline",
        codepoint: "FBE2",
        aliases: [
            "alphabet-j-box-outline",
            "letter-j-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-j-circle",
        codepoint: "FBE3",
        aliases: [
            "alphabet-j-circle",
            "letter-j-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-j-circle-outline",
        codepoint: "FBE4",
        aliases: [
            "alphabet-j-circle-outline",
            "letter-j-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-k",
        codepoint: "004B",
        aliases: [
            "alphabet-k",
            "letter-k"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-k-box",
        codepoint: "FAF7",
        aliases: [
            "alphabet-k-box",
            "letter-k-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-k-box-outline",
        codepoint: "FBE5",
        aliases: [
            "alphabet-k-box-outline",
            "letter-k-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-k-circle",
        codepoint: "FBE6",
        aliases: [
            "alphabet-k-circle",
            "letter-k-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-k-circle-outline",
        codepoint: "FBE7",
        aliases: [
            "alphabet-k-circle-outline",
            "letter-k-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-l",
        codepoint: "004C",
        aliases: [
            "alphabet-l",
            "letter-l"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-l-box",
        codepoint: "FAF8",
        aliases: [
            "alphabet-l-box",
            "letter-l-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-l-box-outline",
        codepoint: "FBE8",
        aliases: [
            "alphabet-l-box-outline",
            "letter-l-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-l-circle",
        codepoint: "FBE9",
        aliases: [
            "alphabet-l-circle",
            "letter-l-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-l-circle-outline",
        codepoint: "FBEA",
        aliases: [
            "alphabet-l-circle-outline",
            "letter-l-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-m",
        codepoint: "004D",
        aliases: [
            "alphabet-m",
            "letter-m"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-m-box",
        codepoint: "FAF9",
        aliases: [
            "alphabet-m-box",
            "letter-m-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-m-box-outline",
        codepoint: "FBEB",
        aliases: [
            "alphabet-m-box-outline",
            "letter-m-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-m-circle",
        codepoint: "FBEC",
        aliases: [
            "alphabet-m-circle",
            "letter-m-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-m-circle-outline",
        codepoint: "FBED",
        aliases: [
            "alphabet-m-circle-outline",
            "letter-m-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-n",
        codepoint: "004E",
        aliases: [
            "alphabet-n",
            "letter-n",
            "neutral"
        ],
        tags: [
            "Automotive",
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-n-box",
        codepoint: "FAFA",
        aliases: [
            "alphabet-n-box",
            "letter-n-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-n-box-outline",
        codepoint: "FBEE",
        aliases: [
            "alphabet-n-box-outline",
            "letter-n-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-n-circle",
        codepoint: "FBEF",
        aliases: [
            "alphabet-n-circle",
            "letter-n-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-n-circle-outline",
        codepoint: "FBF0",
        aliases: [
            "alphabet-n-circle-outline",
            "letter-n-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-o",
        codepoint: "004F",
        aliases: [
            "alphabet-o",
            "letter-o"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-o-box",
        codepoint: "FAFB",
        aliases: [
            "alphabet-o-box",
            "letter-o-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-o-box-outline",
        codepoint: "FBF1",
        aliases: [
            "alphabet-o-box-outline",
            "letter-o-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric",
            "Alpha \/ Numeric",
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-o-circle",
        codepoint: "FBF2",
        aliases: [
            "alphabet-o-circle",
            "letter-o-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-o-circle-outline",
        codepoint: "FBF3",
        aliases: [
            "alphabet-o-circle-outline",
            "letter-o-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-p",
        codepoint: "0050",
        aliases: [
            "alphabet-p",
            "letter-p",
            "park"
        ],
        tags: [
            "Automotive",
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-p-box",
        codepoint: "FAFC",
        aliases: [
            "alphabet-p-box",
            "letter-p-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-p-box-outline",
        codepoint: "FBF4",
        aliases: [
            "alphabet-p-box-outline",
            "letter-p-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-p-circle",
        codepoint: "FBF5",
        aliases: [
            "alphabet-p-circle",
            "letter-p-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-p-circle-outline",
        codepoint: "FBF6",
        aliases: [
            "alphabet-p-circle-outline",
            "letter-p-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-q",
        codepoint: "0051",
        aliases: [
            "alphabet-q",
            "letter-q"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-q-box",
        codepoint: "FAFD",
        aliases: [
            "alphabet-q-box",
            "letter-q-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-q-box-outline",
        codepoint: "FBF7",
        aliases: [
            "alphabet-q-box-outline",
            "letter-q-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-q-circle",
        codepoint: "FBF8",
        aliases: [
            "alphabet-q-circle",
            "letter-q-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-q-circle-outline",
        codepoint: "FBF9",
        aliases: [
            "alphabet-q-circle-outline",
            "letter-q-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-r",
        codepoint: "0052",
        aliases: [
            "alphabet-r",
            "letter-r",
            "reverse"
        ],
        tags: [
            "Automotive",
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-r-box",
        codepoint: "FAFE",
        aliases: [
            "alphabet-r-box",
            "letter-r-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-r-box-outline",
        codepoint: "FBFA",
        aliases: [
            "alphabet-r-box-outline",
            "letter-r-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-r-circle",
        codepoint: "FBFB",
        aliases: [
            "alphabet-r-circle",
            "letter-r-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-r-circle-outline",
        codepoint: "FBFC",
        aliases: [
            "alphabet-r-circle-outline",
            "letter-r-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-s",
        codepoint: "0053",
        aliases: [
            "alphabet-s",
            "letter-s"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-s-box",
        codepoint: "FAFF",
        aliases: [
            "alphabet-s-box",
            "letter-s-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-s-box-outline",
        codepoint: "FBFD",
        aliases: [
            "alphabet-s-box-outline",
            "letter-s-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-s-circle",
        codepoint: "FBFE",
        aliases: [
            "alphabet-s-circle",
            "letter-s-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-s-circle-outline",
        codepoint: "FBFF",
        aliases: [
            "alphabet-s-circle-outline",
            "letter-s-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-t",
        codepoint: "0054",
        aliases: [
            "alphabet-t",
            "letter-t"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-t-box",
        codepoint: "FB00",
        aliases: [
            "alphabet-t-box",
            "letter-t-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-t-box-outline",
        codepoint: "FC00",
        aliases: [
            "alphabet-t-box-outline",
            "letter-t-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-t-circle",
        codepoint: "FC01",
        aliases: [
            "alphabet-t-circle",
            "letter-t-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-t-circle-outline",
        codepoint: "FC02",
        aliases: [
            "alphabet-t-circle-outline",
            "letter-t-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-u",
        codepoint: "0055",
        aliases: [
            "alphabet-u",
            "letter-u"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-u-box",
        codepoint: "FB01",
        aliases: [
            "alphabet-u-box",
            "letter-u-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-u-box-outline",
        codepoint: "FC03",
        aliases: [
            "alphabet-u-box-outline",
            "letter-u-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-u-circle",
        codepoint: "FC04",
        aliases: [
            "alphabet-u-circle",
            "letter-u-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-u-circle-outline",
        codepoint: "FC05",
        aliases: [
            "alphabet-u-circle-outline",
            "letter-u-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-v",
        codepoint: "0056",
        aliases: [
            "alphabet-v",
            "letter-v",
            "roman-numeral-5"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-v-box",
        codepoint: "FB02",
        aliases: [
            "alphabet-v-box",
            "letter-v-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-v-box-outline",
        codepoint: "FC06",
        aliases: [
            "alphabet-v-box-outline",
            "letter-v-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-v-circle",
        codepoint: "FC07",
        aliases: [
            "alphabet-v-circle",
            "letter-v-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-v-circle-outline",
        codepoint: "FC08",
        aliases: [
            "alphabet-v-circle-outline",
            "letter-v-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-w",
        codepoint: "0057",
        aliases: [
            "alphabet-w",
            "letter-w"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-w-box",
        codepoint: "FB03",
        aliases: [
            "alphabet-w-box",
            "letter-w-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-w-box-outline",
        codepoint: "FC09",
        aliases: [
            "alphabet-w-box-outline",
            "letter-w-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-w-circle",
        codepoint: "FC0A",
        aliases: [
            "alphabet-w-circle",
            "letter-w-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-w-circle-outline",
        codepoint: "FC0B",
        aliases: [
            "alphabet-w-circle-outline",
            "letter-w-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-x",
        codepoint: "0058",
        aliases: [
            "alphabet-x",
            "letter-x",
            "roman-numeral-10"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-x-box",
        codepoint: "FB04",
        aliases: [
            "alphabet-x-box",
            "letter-x-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-x-box-outline",
        codepoint: "FC0C",
        aliases: [
            "alphabet-x-box-outline",
            "letter-x-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-x-circle",
        codepoint: "FC0D",
        aliases: [
            "alphabet-x-circle",
            "letter-x-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-x-circle-outline",
        codepoint: "FC0E",
        aliases: [
            "alphabet-x-circle-outline",
            "letter-x-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-y",
        codepoint: "0059",
        aliases: [
            "alphabet-y",
            "letter-y"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-y-box",
        codepoint: "FB05",
        aliases: [
            "alphabet-y-box",
            "letter-y-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-y-box-outline",
        codepoint: "FC0F",
        aliases: [
            "alphabet-y-box-outline",
            "letter-y-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-y-circle",
        codepoint: "FC10",
        aliases: [
            "alphabet-y-circle",
            "letter-y-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-y-circle-outline",
        codepoint: "FC11",
        aliases: [
            "alphabet-y-circle-outline",
            "letter-y-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-z",
        codepoint: "005A",
        aliases: [
            "alphabet-z",
            "letter-z"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-z-box",
        codepoint: "FB06",
        aliases: [
            "alphabet-z-box",
            "letter-z-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-z-box-outline",
        codepoint: "FC12",
        aliases: [
            "alphabet-z-box-outline",
            "letter-z-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-z-circle",
        codepoint: "FC13",
        aliases: [
            "alphabet-z-circle",
            "letter-z-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alpha-z-circle-outline",
        codepoint: "FC14",
        aliases: [
            "alphabet-z-circle-outline",
            "letter-z-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alphabetical",
        codepoint: "F02C",
        aliases: [
            "letters",
            "a-b-c",
            "abc"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alphabetical-off",
        codepoint: "F002E",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alphabetical-variant",
        codepoint: "F002F",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "alphabetical-variant-off",
        codepoint: "F0030",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "altimeter",
        codepoint: "F5D7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "amazon",
        codepoint: "F02D",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "amazon-alexa",
        codepoint: "F8C5",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "amazon-drive",
        codepoint: "F02E",
        aliases: [
            "amazon-clouddrive"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "ambulance",
        codepoint: "F02F",
        aliases: [],
        tags: [
            "Transportation + Road",
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "ammunition",
        codepoint: "FCC4",
        aliases: [
            "bullets"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "ampersand",
        codepoint: "FA8C",
        aliases: [
            "and"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "amplifier",
        codepoint: "F030",
        aliases: [],
        tags: [
            "Home Automation",
            "Music"
        ],
    },
    {
        
        name: "amplifier-off",
        codepoint: "F01E0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "anchor",
        codepoint: "F031",
        aliases: [],
        tags: [
            "Transportation + Water"
        ],
    },
    {
        
        name: "android",
        codepoint: "F032",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "android-auto",
        codepoint: "FA8D",
        aliases: [],
        tags: [
            "Automotive",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "android-debug-bridge",
        codepoint: "F033",
        aliases: [
            "adb"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "android-head",
        codepoint: "F78F",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "android-messages",
        codepoint: "FD21",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "android-studio",
        codepoint: "F034",
        aliases: [
            "math-compass-variant"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "angle-acute",
        codepoint: "F936",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "angle-obtuse",
        codepoint: "F937",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "angle-right",
        codepoint: "F938",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "angular",
        codepoint: "F6B1",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "angularjs",
        codepoint: "F6BE",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "animation",
        codepoint: "F5D8",
        aliases: [
            "auto-awesome-motion"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "animation-outline",
        codepoint: "FA8E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "animation-play",
        codepoint: "F939",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "animation-play-outline",
        codepoint: "FA8F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "ansible",
        codepoint: "F00C5",
        aliases: [],
        tags: [
            "Developer \/ Languages",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "antenna",
        codepoint: "F0144",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "anvil",
        codepoint: "F89A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "apache-kafka",
        codepoint: "F0031",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "api",
        codepoint: "F00C6",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "api-off",
        codepoint: "F0282",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "apple",
        codepoint: "F035",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "apple-finder",
        codepoint: "F036",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "apple-icloud",
        codepoint: "F038",
        aliases: [
            "apple-mobileme"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "apple-ios",
        codepoint: "F037",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "apple-keyboard-caps",
        codepoint: "F632",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "apple-keyboard-command",
        codepoint: "F633",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "apple-keyboard-control",
        codepoint: "F634",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "apple-keyboard-option",
        codepoint: "F635",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "apple-keyboard-shift",
        codepoint: "F636",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "apple-safari",
        codepoint: "F039",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "application",
        codepoint: "F614",
        aliases: [
            "web-asset"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "application-export",
        codepoint: "FD89",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "application-import",
        codepoint: "FD8A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "approximately-equal",
        codepoint: "FFBE",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "approximately-equal-box",
        codepoint: "FFBF",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "apps",
        codepoint: "F03B",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "apps-box",
        codepoint: "FD22",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "arch",
        codepoint: "F8C6",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "archive",
        codepoint: "F03C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "archive-outline",
        codepoint: "F0239",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "arm-flex",
        codepoint: "F008F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "arm-flex-outline",
        codepoint: "F0090",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "arrange-bring-forward",
        codepoint: "F03D",
        aliases: [],
        tags: [
            "Arrange",
            "Geographic Information System"
        ],
    },
    {
        
        name: "arrange-bring-to-front",
        codepoint: "F03E",
        aliases: [],
        tags: [
            "Arrange",
            "Geographic Information System"
        ],
    },
    {
        
        name: "arrange-send-backward",
        codepoint: "F03F",
        aliases: [],
        tags: [
            "Arrange",
            "Geographic Information System"
        ],
    },
    {
        
        name: "arrange-send-to-back",
        codepoint: "F040",
        aliases: [],
        tags: [
            "Arrange",
            "Geographic Information System"
        ],
    },
    {
        
        name: "arrow-all",
        codepoint: "F041",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-bottom-left",
        codepoint: "F042",
        aliases: [
            "arrow-down-left"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-bottom-left-bold-outline",
        codepoint: "F9B6",
        aliases: [
            "arrow-down-left-bold-outline"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-bottom-left-thick",
        codepoint: "F9B7",
        aliases: [
            "arrow-down-left-thick"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-bottom-right",
        codepoint: "F043",
        aliases: [
            "arrow-down-right"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-bottom-right-bold-outline",
        codepoint: "F9B8",
        aliases: [
            "arrow-down-right-bold-outline"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-bottom-right-thick",
        codepoint: "F9B9",
        aliases: [
            "arrow-down-right-thick"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-collapse",
        codepoint: "F615",
        aliases: [
            "arrow-compress"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-collapse-all",
        codepoint: "F044",
        aliases: [
            "arrow-compress-all"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-collapse-down",
        codepoint: "F791",
        aliases: [
            "arrow-compress-down"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-collapse-horizontal",
        codepoint: "F84B",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-collapse-left",
        codepoint: "F792",
        aliases: [
            "arrow-compress-left"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-collapse-right",
        codepoint: "F793",
        aliases: [
            "arrow-compress-right"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-collapse-up",
        codepoint: "F794",
        aliases: [
            "arrow-compress-up"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-collapse-vertical",
        codepoint: "F84C",
        aliases: [
            "compress"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-decision",
        codepoint: "F9BA",
        aliases: [
            "proxy"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "arrow-decision-auto",
        codepoint: "F9BB",
        aliases: [
            "proxy-auto"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "arrow-decision-auto-outline",
        codepoint: "F9BC",
        aliases: [
            "proxy-auto-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "arrow-decision-outline",
        codepoint: "F9BD",
        aliases: [
            "proxy-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "arrow-down",
        codepoint: "F045",
        aliases: [
            "arrow-downward",
            "arrow-bottom"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-down-bold",
        codepoint: "F72D",
        aliases: [
            "arrow-bottom-bold"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-down-bold-box",
        codepoint: "F72E",
        aliases: [
            "arrow-bottom-bold-box"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-down-bold-box-outline",
        codepoint: "F72F",
        aliases: [
            "arrow-bottom-bold-box-outline"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-down-bold-circle",
        codepoint: "F047",
        aliases: [
            "arrow-bottom-bold-circle"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-down-bold-circle-outline",
        codepoint: "F048",
        aliases: [
            "arrow-bottom-bold-circle-outline"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-down-bold-hexagon-outline",
        codepoint: "F049",
        aliases: [
            "arrow-bottom-bold-hexagon-outline"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-down-bold-outline",
        codepoint: "F9BE",
        aliases: [
            "arrow-bottom-bold-outline"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-down-box",
        codepoint: "F6BF",
        aliases: [
            "arrow-bottom-box"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-down-circle",
        codepoint: "FCB7",
        aliases: [
            "arrow-bottom-circle"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-down-circle-outline",
        codepoint: "FCB8",
        aliases: [
            "arrow-bottom-circle-outline"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-down-drop-circle",
        codepoint: "F04A",
        aliases: [
            "arrow-drop-down-circle",
            "arrow-bottom-drop-circle"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-down-drop-circle-outline",
        codepoint: "F04B",
        aliases: [
            "arrow-bottom-drop-circle-outline"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-down-thick",
        codepoint: "F046",
        aliases: [
            "arrow-bottom-thick"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-expand",
        codepoint: "F616",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-expand-all",
        codepoint: "F04C",
        aliases: [],
        tags: [
            "Arrow",
            "Geographic Information System"
        ],
    },
    {
        
        name: "arrow-expand-down",
        codepoint: "F795",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-expand-horizontal",
        codepoint: "F84D",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-expand-left",
        codepoint: "F796",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-expand-right",
        codepoint: "F797",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-expand-up",
        codepoint: "F798",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-expand-vertical",
        codepoint: "F84E",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-horizontal-lock",
        codepoint: "F0186",
        aliases: [
            "scroll-horizontal-lock"
        ],
        tags: [
            "Lock",
            "Arrow"
        ],
    },
    {
        
        name: "arrow-left",
        codepoint: "F04D",
        aliases: [
            "arrow-back"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-left-bold",
        codepoint: "F730",
        aliases: [],
        tags: [
            "Arrow",
            "Automotive"
        ],
    },
    {
        
        name: "arrow-left-bold-box",
        codepoint: "F731",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-left-bold-box-outline",
        codepoint: "F732",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-left-bold-circle",
        codepoint: "F04F",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-left-bold-circle-outline",
        codepoint: "F050",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-left-bold-hexagon-outline",
        codepoint: "F051",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-left-bold-outline",
        codepoint: "F9BF",
        aliases: [],
        tags: [
            "Arrow",
            "Automotive"
        ],
    },
    {
        
        name: "arrow-left-box",
        codepoint: "F6C0",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-left-circle",
        codepoint: "FCB9",
        aliases: [
            "arrow-back-circle"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-left-circle-outline",
        codepoint: "FCBA",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-left-drop-circle",
        codepoint: "F052",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-left-drop-circle-outline",
        codepoint: "F053",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-left-right",
        codepoint: "FE90",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-left-right-bold",
        codepoint: "FE91",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-left-right-bold-outline",
        codepoint: "F9C0",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-left-thick",
        codepoint: "F04E",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-right",
        codepoint: "F054",
        aliases: [
            "arrow-forward"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-right-bold",
        codepoint: "F733",
        aliases: [],
        tags: [
            "Arrow",
            "Automotive"
        ],
    },
    {
        
        name: "arrow-right-bold-box",
        codepoint: "F734",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-right-bold-box-outline",
        codepoint: "F735",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-right-bold-circle",
        codepoint: "F056",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-right-bold-circle-outline",
        codepoint: "F057",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-right-bold-hexagon-outline",
        codepoint: "F058",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-right-bold-outline",
        codepoint: "F9C1",
        aliases: [],
        tags: [
            "Arrow",
            "Automotive"
        ],
    },
    {
        
        name: "arrow-right-box",
        codepoint: "F6C1",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-right-circle",
        codepoint: "FCBB",
        aliases: [
            "arrow-forward-circle"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-right-circle-outline",
        codepoint: "FCBC",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-right-drop-circle",
        codepoint: "F059",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-right-drop-circle-outline",
        codepoint: "F05A",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-right-thick",
        codepoint: "F055",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-split-horizontal",
        codepoint: "F93A",
        aliases: [
            "resize-vertical",
            "resize"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-split-vertical",
        codepoint: "F93B",
        aliases: [
            "resize-horizontal",
            "resize"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-top-left",
        codepoint: "F05B",
        aliases: [
            "arrow-up-left"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-top-left-bold-outline",
        codepoint: "F9C2",
        aliases: [
            "arrow-up-left-bold-outline"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-top-left-bottom-right",
        codepoint: "FE92",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-top-left-bottom-right-bold",
        codepoint: "FE93",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-top-left-thick",
        codepoint: "F9C3",
        aliases: [
            "arrow-up-left-thick"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-top-right",
        codepoint: "F05C",
        aliases: [
            "arrow-up-right"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-top-right-bold-outline",
        codepoint: "F9C4",
        aliases: [
            "arrow-up-right-bold-outline"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-top-right-bottom-left",
        codepoint: "FE94",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-top-right-bottom-left-bold",
        codepoint: "FE95",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-top-right-thick",
        codepoint: "F9C5",
        aliases: [
            "arrow-up-right-thick"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-up",
        codepoint: "F05D",
        aliases: [
            "arrow-upward",
            "arrow-top"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-up-bold",
        codepoint: "F736",
        aliases: [
            "arrow-top-bold"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-up-bold-box",
        codepoint: "F737",
        aliases: [
            "arrow-top-bold-box"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-up-bold-box-outline",
        codepoint: "F738",
        aliases: [
            "arrow-top-bold-box-outline"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-up-bold-circle",
        codepoint: "F05F",
        aliases: [
            "arrow-top-bold-circle"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-up-bold-circle-outline",
        codepoint: "F060",
        aliases: [
            "arrow-top-bold-circle-outline"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-up-bold-hexagon-outline",
        codepoint: "F061",
        aliases: [
            "arrow-top-bold-hexagon-outline"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-up-bold-outline",
        codepoint: "F9C6",
        aliases: [
            "arrow-top-bold-outline"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-up-box",
        codepoint: "F6C2",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-up-circle",
        codepoint: "FCBD",
        aliases: [
            "arrow-top-circle"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-up-circle-outline",
        codepoint: "FCBE",
        aliases: [
            "arrow-top-circle-outline"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-up-down",
        codepoint: "FE96",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-up-down-bold",
        codepoint: "FE97",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-up-down-bold-outline",
        codepoint: "F9C7",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-up-drop-circle",
        codepoint: "F062",
        aliases: [
            "arrow-top-drop-circle"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-up-drop-circle-outline",
        codepoint: "F063",
        aliases: [
            "arrow-top-drop-circle-outline"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-up-thick",
        codepoint: "F05E",
        aliases: [
            "arrow-top-thick"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "arrow-vertical-lock",
        codepoint: "F0187",
        aliases: [
            "scroll-vertical-lock"
        ],
        tags: [
            "Lock",
            "Arrow"
        ],
    },
    {
        
        name: "artist",
        codepoint: "F802",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "artist-outline",
        codepoint: "FCC5",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "artstation",
        codepoint: "FB37",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "aspect-ratio",
        codepoint: "FA23",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "assistant",
        codepoint: "F064",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "asterisk",
        codepoint: "F6C3",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "at",
        codepoint: "F065",
        aliases: [
            "alternate-email"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "atlassian",
        codepoint: "F803",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "atm",
        codepoint: "FD23",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "atom",
        codepoint: "F767",
        aliases: [],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "atom-variant",
        codepoint: "FE98",
        aliases: [],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "attachment",
        codepoint: "F066",
        aliases: [
            "paperclip-horizontal"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "audio-video",
        codepoint: "F93C",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "audio-video-off",
        codepoint: "F01E1",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "audiobook",
        codepoint: "F067",
        aliases: [],
        tags: [
            "Audio"
        ],
    },
    {
        
        name: "augmented-reality",
        codepoint: "F84F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "auto-fix",
        codepoint: "F068",
        aliases: [
            "magic",
            "wand",
            "auto-fix-high"
        ],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "auto-upload",
        codepoint: "F069",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "autorenew",
        codepoint: "F06A",
        aliases: [
            "clockwise-arrows",
            "circular-arrows",
            "circle-arrows"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "av-timer",
        codepoint: "F06B",
        aliases: [],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "aws",
        codepoint: "FDF2",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "axe",
        codepoint: "F8C7",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "axis",
        codepoint: "FD24",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "axis-arrow",
        codepoint: "FD25",
        aliases: [
            "accelerometer",
            "gyro"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "axis-arrow-lock",
        codepoint: "FD26",
        aliases: [],
        tags: [
            "Lock",
            "Arrow"
        ],
    },
    {
        
        name: "axis-lock",
        codepoint: "FD27",
        aliases: [],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "axis-x-arrow",
        codepoint: "FD28",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "axis-x-arrow-lock",
        codepoint: "FD29",
        aliases: [],
        tags: [
            "Lock",
            "Arrow"
        ],
    },
    {
        
        name: "axis-x-rotate-clockwise",
        codepoint: "FD2A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "axis-x-rotate-counterclockwise",
        codepoint: "FD2B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "axis-x-y-arrow-lock",
        codepoint: "FD2C",
        aliases: [],
        tags: [
            "Lock",
            "Arrow"
        ],
    },
    {
        
        name: "axis-y-arrow",
        codepoint: "FD2D",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "axis-y-arrow-lock",
        codepoint: "FD2E",
        aliases: [],
        tags: [
            "Lock",
            "Arrow"
        ],
    },
    {
        
        name: "axis-y-rotate-clockwise",
        codepoint: "FD2F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "axis-y-rotate-counterclockwise",
        codepoint: "FD30",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "axis-z-arrow",
        codepoint: "FD31",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "axis-z-arrow-lock",
        codepoint: "FD32",
        aliases: [],
        tags: [
            "Lock",
            "Arrow"
        ],
    },
    {
        
        name: "axis-z-rotate-clockwise",
        codepoint: "FD33",
        aliases: [
            "vertical-rotate-clockwise"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "axis-z-rotate-counterclockwise",
        codepoint: "FD34",
        aliases: [
            "vertical-rotate-counterclockwise"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "azure",
        codepoint: "F804",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "azure-devops",
        codepoint: "F0091",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "babel",
        codepoint: "FA24",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "baby",
        codepoint: "F06C",
        aliases: [],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "baby-bottle",
        codepoint: "FF56",
        aliases: [],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "baby-bottle-outline",
        codepoint: "FF57",
        aliases: [],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "baby-carriage",
        codepoint: "F68E",
        aliases: [
            "child-friendly",
            "stroller",
            "pram",
            "buggy"
        ],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "baby-carriage-off",
        codepoint: "FFC0",
        aliases: [
            "child-friendly-off",
            "stroller-off",
            "pram-off",
            "buggy-off"
        ],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "baby-face",
        codepoint: "FE99",
        aliases: [],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "baby-face-outline",
        codepoint: "FE9A",
        aliases: [],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "backburger",
        codepoint: "F06D",
        aliases: [
            "hamburger-menu-back"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "backspace",
        codepoint: "F06E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "backspace-outline",
        codepoint: "FB38",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "backspace-reverse",
        codepoint: "FE9B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "backspace-reverse-outline",
        codepoint: "FE9C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "backup-restore",
        codepoint: "F06F",
        aliases: [
            "settings-backup-restore"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bacteria",
        codepoint: "FEF2",
        aliases: [],
        tags: [
            "Science",
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "bacteria-outline",
        codepoint: "FEF3",
        aliases: [],
        tags: [
            "Science",
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "badminton",
        codepoint: "F850",
        aliases: [
            "shuttlecock"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "bag-carry-on",
        codepoint: "FF58",
        aliases: [
            "carry-on-luggage"
        ],
        tags: [
            "Transportation + Flying"
        ],
    },
    {
        
        name: "bag-carry-on-check",
        codepoint: "FD41",
        aliases: [
            "carry-on-bag-tick",
            "carry-on-bag-check"
        ],
        tags: [
            "Transportation + Flying"
        ],
    },
    {
        
        name: "bag-carry-on-off",
        codepoint: "FF59",
        aliases: [
            "carry-on-luggage-off"
        ],
        tags: [
            "Transportation + Flying"
        ],
    },
    {
        
        name: "bag-checked",
        codepoint: "FF5A",
        aliases: [
            "luggage"
        ],
        tags: [
            "Transportation + Flying"
        ],
    },
    {
        
        name: "bag-personal",
        codepoint: "FDF3",
        aliases: [
            "backpack"
        ],
        tags: [
            "Transportation + Flying"
        ],
    },
    {
        
        name: "bag-personal-off",
        codepoint: "FDF4",
        aliases: [
            "backpack-off"
        ],
        tags: [
            "Transportation + Flying"
        ],
    },
    {
        
        name: "bag-personal-off-outline",
        codepoint: "FDF5",
        aliases: [
            "backpack-off-outline"
        ],
        tags: [
            "Transportation + Flying"
        ],
    },
    {
        
        name: "bag-personal-outline",
        codepoint: "FDF6",
        aliases: [
            "backpack-outline"
        ],
        tags: [
            "Transportation + Flying"
        ],
    },
    {
        
        name: "baguette",
        codepoint: "FF5B",
        aliases: [
            "bread",
            "bakery",
            "french-baguette",
            "loaf"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "balloon",
        codepoint: "FA25",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "ballot",
        codepoint: "F9C8",
        aliases: [
            "vote"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "ballot-outline",
        codepoint: "F9C9",
        aliases: [
            "vote-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "ballot-recount",
        codepoint: "FC15",
        aliases: [
            "vote-recount"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "ballot-recount-outline",
        codepoint: "FC16",
        aliases: [
            "vote-recount-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bandage",
        codepoint: "FD8B",
        aliases: [
            "band-aid",
            "plaster"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bandcamp",
        codepoint: "F674",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "bank",
        codepoint: "F070",
        aliases: [
            "account-balance",
            "museum"
        ],
        tags: [
            "Banking",
            "Places"
        ],
    },
    {
        
        name: "bank-minus",
        codepoint: "FD8C",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "bank-outline",
        codepoint: "FE9D",
        aliases: [
            "museum-outline"
        ],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "bank-plus",
        codepoint: "FD8D",
        aliases: [
            "bank-add"
        ],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "bank-remove",
        codepoint: "FD8E",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "bank-transfer",
        codepoint: "FA26",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "bank-transfer-in",
        codepoint: "FA27",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "bank-transfer-out",
        codepoint: "FA28",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "barcode",
        codepoint: "F071",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "barcode-off",
        codepoint: "F0261",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "barcode-scan",
        codepoint: "F072",
        aliases: [
            "barcode-scanner"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "barley",
        codepoint: "F073",
        aliases: [
            "grain",
            "wheat"
        ],
        tags: [
            "Agriculture",
            "Food \/ Drink"
        ],
    },
    {
        
        name: "barley-off",
        codepoint: "FB39",
        aliases: [
            "gluten-free",
            "grain-off",
            "wheat-off"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "barn",
        codepoint: "FB3A",
        aliases: [
            "farm"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "barrel",
        codepoint: "F074",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "baseball",
        codepoint: "F851",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "baseball-bat",
        codepoint: "F852",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "basecamp",
        codepoint: "F075",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "bash",
        codepoint: "F01AE",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "basket",
        codepoint: "F076",
        aliases: [
            "shopping-basket"
        ],
        tags: [
            "Shopping"
        ],
    },
    {
        
        name: "basket-fill",
        codepoint: "F077",
        aliases: [],
        tags: [
            "Shopping"
        ],
    },
    {
        
        name: "basket-outline",
        codepoint: "F01AC",
        aliases: [
            "shopping-basket-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "basket-unfill",
        codepoint: "F078",
        aliases: [],
        tags: [
            "Shopping"
        ],
    },
    {
        
        name: "basketball",
        codepoint: "F805",
        aliases: [
            "youtube-sports"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "basketball-hoop",
        codepoint: "FC17",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "basketball-hoop-outline",
        codepoint: "FC18",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "bat",
        codepoint: "FB3B",
        aliases: [],
        tags: [
            "Holiday"
        ],
    },
    {
        
        name: "battery",
        codepoint: "F079",
        aliases: [
            "battery-full",
            "battery-std",
            "battery-100"
        ],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-10",
        codepoint: "F07A",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-10-bluetooth",
        codepoint: "F93D",
        aliases: [],
        tags: [
            "Battery"
        ],
    },
    {
        
        name: "battery-20",
        codepoint: "F07B",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-20-bluetooth",
        codepoint: "F93E",
        aliases: [],
        tags: [
            "Battery"
        ],
    },
    {
        
        name: "battery-30",
        codepoint: "F07C",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-30-bluetooth",
        codepoint: "F93F",
        aliases: [],
        tags: [
            "Battery"
        ],
    },
    {
        
        name: "battery-40",
        codepoint: "F07D",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-40-bluetooth",
        codepoint: "F940",
        aliases: [],
        tags: [
            "Battery"
        ],
    },
    {
        
        name: "battery-50",
        codepoint: "F07E",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-50-bluetooth",
        codepoint: "F941",
        aliases: [],
        tags: [
            "Battery"
        ],
    },
    {
        
        name: "battery-60",
        codepoint: "F07F",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-60-bluetooth",
        codepoint: "F942",
        aliases: [],
        tags: [
            "Battery"
        ],
    },
    {
        
        name: "battery-70",
        codepoint: "F080",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-70-bluetooth",
        codepoint: "F943",
        aliases: [],
        tags: [
            "Battery"
        ],
    },
    {
        
        name: "battery-80",
        codepoint: "F081",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-80-bluetooth",
        codepoint: "F944",
        aliases: [],
        tags: [
            "Battery"
        ],
    },
    {
        
        name: "battery-90",
        codepoint: "F082",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-90-bluetooth",
        codepoint: "F945",
        aliases: [],
        tags: [
            "Battery"
        ],
    },
    {
        
        name: "battery-alert",
        codepoint: "F083",
        aliases: [
            "battery-warning"
        ],
        tags: [
            "Battery",
            "Home Automation",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "battery-alert-bluetooth",
        codepoint: "F946",
        aliases: [
            "battery-warning-bluetooth"
        ],
        tags: [
            "Alert \/ Error",
            "Battery"
        ],
    },
    {
        
        name: "battery-alert-variant",
        codepoint: "F00F7",
        aliases: [],
        tags: [
            "Battery",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "battery-alert-variant-outline",
        codepoint: "F00F8",
        aliases: [],
        tags: [
            "Battery",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "battery-bluetooth",
        codepoint: "F947",
        aliases: [
            "battery-bluetooth-100",
            "battery-bluetooth-full"
        ],
        tags: [
            "Battery"
        ],
    },
    {
        
        name: "battery-bluetooth-variant",
        codepoint: "F948",
        aliases: [],
        tags: [
            "Battery"
        ],
    },
    {
        
        name: "battery-charging",
        codepoint: "F084",
        aliases: [
            "battery-charging-full"
        ],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-charging-10",
        codepoint: "F89B",
        aliases: [],
        tags: [
            "Automotive",
            "Battery"
        ],
    },
    {
        
        name: "battery-charging-100",
        codepoint: "F085",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-charging-20",
        codepoint: "F086",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-charging-30",
        codepoint: "F087",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-charging-40",
        codepoint: "F088",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-charging-50",
        codepoint: "F89C",
        aliases: [],
        tags: [
            "Automotive",
            "Battery"
        ],
    },
    {
        
        name: "battery-charging-60",
        codepoint: "F089",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-charging-70",
        codepoint: "F89D",
        aliases: [],
        tags: [
            "Automotive",
            "Battery"
        ],
    },
    {
        
        name: "battery-charging-80",
        codepoint: "F08A",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-charging-90",
        codepoint: "F08B",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-charging-outline",
        codepoint: "F89E",
        aliases: [],
        tags: [
            "Automotive",
            "Battery"
        ],
    },
    {
        
        name: "battery-charging-wireless",
        codepoint: "F806",
        aliases: [
            "battery-charging-wireless-full",
            "battery-charging-wireless-100"
        ],
        tags: [
            "Battery",
            "Home Automation"
        ],
    },
    {
        
        name: "battery-charging-wireless-10",
        codepoint: "F807",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation"
        ],
    },
    {
        
        name: "battery-charging-wireless-20",
        codepoint: "F808",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation"
        ],
    },
    {
        
        name: "battery-charging-wireless-30",
        codepoint: "F809",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation"
        ],
    },
    {
        
        name: "battery-charging-wireless-40",
        codepoint: "F80A",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation"
        ],
    },
    {
        
        name: "battery-charging-wireless-50",
        codepoint: "F80B",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation"
        ],
    },
    {
        
        name: "battery-charging-wireless-60",
        codepoint: "F80C",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation"
        ],
    },
    {
        
        name: "battery-charging-wireless-70",
        codepoint: "F80D",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation"
        ],
    },
    {
        
        name: "battery-charging-wireless-80",
        codepoint: "F80E",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation"
        ],
    },
    {
        
        name: "battery-charging-wireless-90",
        codepoint: "F80F",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation"
        ],
    },
    {
        
        name: "battery-charging-wireless-alert",
        codepoint: "F810",
        aliases: [
            "battery-charging-wireless-warning"
        ],
        tags: [
            "Battery",
            "Home Automation",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "battery-charging-wireless-outline",
        codepoint: "F811",
        aliases: [
            "battery-charging-wireless-empty",
            "battery-charging-wireless-0"
        ],
        tags: [
            "Battery",
            "Home Automation"
        ],
    },
    {
        
        name: "battery-heart",
        codepoint: "F023A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "battery-heart-outline",
        codepoint: "F023B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "battery-heart-variant",
        codepoint: "F023C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "battery-minus",
        codepoint: "F08C",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation"
        ],
    },
    {
        
        name: "battery-negative",
        codepoint: "F08D",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation"
        ],
    },
    {
        
        name: "battery-outline",
        codepoint: "F08E",
        aliases: [
            "battery-0",
            "battery-empty"
        ],
        tags: [
            "Battery",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "battery-plus",
        codepoint: "F08F",
        aliases: [
            "battery-saver",
            "battery-add"
        ],
        tags: [
            "Battery",
            "Home Automation"
        ],
    },
    {
        
        name: "battery-positive",
        codepoint: "F090",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation"
        ],
    },
    {
        
        name: "battery-unknown",
        codepoint: "F091",
        aliases: [],
        tags: [
            "Battery",
            "Home Automation"
        ],
    },
    {
        
        name: "battery-unknown-bluetooth",
        codepoint: "F949",
        aliases: [],
        tags: [
            "Battery"
        ],
    },
    {
        
        name: "battlenet",
        codepoint: "FB3C",
        aliases: [
            "battle-net"
        ],
        tags: [
            "Brand \/ Logo",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "beach",
        codepoint: "F092",
        aliases: [
            "parasol"
        ],
        tags: [
            "Places"
        ],
    },
    {
        
        name: "beaker",
        codepoint: "FCC6",
        aliases: [],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "beaker-alert",
        codepoint: "F0254",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "beaker-alert-outline",
        codepoint: "F0255",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "beaker-check",
        codepoint: "F0256",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "beaker-check-outline",
        codepoint: "F0257",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "beaker-minus",
        codepoint: "F0258",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "beaker-minus-outline",
        codepoint: "F0259",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "beaker-outline",
        codepoint: "F68F",
        aliases: [],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "beaker-plus",
        codepoint: "F025A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "beaker-plus-outline",
        codepoint: "F025B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "beaker-question",
        codepoint: "F025C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "beaker-question-outline",
        codepoint: "F025D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "beaker-remove",
        codepoint: "F025E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "beaker-remove-outline",
        codepoint: "F025F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "beats",
        codepoint: "F097",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "bed-double",
        codepoint: "F0092",
        aliases: [],
        tags: [
            "Home Automation",
            "Holiday"
        ],
    },
    {
        
        name: "bed-double-outline",
        codepoint: "F0093",
        aliases: [],
        tags: [
            "Home Automation",
            "Holiday"
        ],
    },
    {
        
        name: "bed-empty",
        codepoint: "F89F",
        aliases: [],
        tags: [
            "Home Automation",
            "Holiday"
        ],
    },
    {
        
        name: "bed-king",
        codepoint: "F0094",
        aliases: [],
        tags: [
            "Home Automation",
            "Holiday"
        ],
    },
    {
        
        name: "bed-king-outline",
        codepoint: "F0095",
        aliases: [],
        tags: [
            "Home Automation",
            "Holiday"
        ],
    },
    {
        
        name: "bed-queen",
        codepoint: "F0096",
        aliases: [],
        tags: [
            "Home Automation",
            "Holiday"
        ],
    },
    {
        
        name: "bed-queen-outline",
        codepoint: "F0097",
        aliases: [],
        tags: [
            "Home Automation",
            "Holiday"
        ],
    },
    {
        
        name: "bed-single",
        codepoint: "F0098",
        aliases: [],
        tags: [
            "Home Automation",
            "Holiday"
        ],
    },
    {
        
        name: "bed-single-outline",
        codepoint: "F0099",
        aliases: [],
        tags: [
            "Home Automation",
            "Holiday"
        ],
    },
    {
        
        name: "bee",
        codepoint: "FFC1",
        aliases: [
            "fly",
            "insect"
        ],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "bee-flower",
        codepoint: "FFC2",
        aliases: [
            "fly-flower",
            "nature"
        ],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "beehive-outline",
        codepoint: "F00F9",
        aliases: [],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "beer",
        codepoint: "F098",
        aliases: [
            "pint",
            "pub",
            "bar"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "behance",
        codepoint: "F099",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "bell",
        codepoint: "F09A",
        aliases: [
            "notifications"
        ],
        tags: [
            "Notification",
            "Home Automation",
            "Music"
        ],
    },
    {
        
        name: "bell-alert",
        codepoint: "FD35",
        aliases: [
            "bell-warning"
        ],
        tags: [
            "Alert \/ Error",
            "Notification"
        ],
    },
    {
        
        name: "bell-alert-outline",
        codepoint: "FE9E",
        aliases: [],
        tags: [
            "Alert \/ Error",
            "Notification"
        ],
    },
    {
        
        name: "bell-check",
        codepoint: "F0210",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bell-check-outline",
        codepoint: "F0211",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bell-circle",
        codepoint: "FD36",
        aliases: [],
        tags: [
            "Notification"
        ],
    },
    {
        
        name: "bell-circle-outline",
        codepoint: "FD37",
        aliases: [],
        tags: [
            "Notification"
        ],
    },
    {
        
        name: "bell-off",
        codepoint: "F09B",
        aliases: [
            "notifications-off"
        ],
        tags: [
            "Notification"
        ],
    },
    {
        
        name: "bell-off-outline",
        codepoint: "FA90",
        aliases: [],
        tags: [
            "Notification"
        ],
    },
    {
        
        name: "bell-outline",
        codepoint: "F09C",
        aliases: [
            "notifications-none"
        ],
        tags: [
            "Notification",
            "Music"
        ],
    },
    {
        
        name: "bell-plus",
        codepoint: "F09D",
        aliases: [
            "add-alert",
            "bell-add"
        ],
        tags: [
            "Notification"
        ],
    },
    {
        
        name: "bell-plus-outline",
        codepoint: "FA91",
        aliases: [
            "bell-add-outline",
            "add-alert-outline"
        ],
        tags: [
            "Notification"
        ],
    },
    {
        
        name: "bell-ring",
        codepoint: "F09E",
        aliases: [
            "notifications-active"
        ],
        tags: [
            "Notification"
        ],
    },
    {
        
        name: "bell-ring-outline",
        codepoint: "F09F",
        aliases: [],
        tags: [
            "Notification"
        ],
    },
    {
        
        name: "bell-sleep",
        codepoint: "F0A0",
        aliases: [
            "notifications-paused"
        ],
        tags: [
            "Notification"
        ],
    },
    {
        
        name: "bell-sleep-outline",
        codepoint: "FA92",
        aliases: [],
        tags: [
            "Notification"
        ],
    },
    {
        
        name: "beta",
        codepoint: "F0A1",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "betamax",
        codepoint: "F9CA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "biathlon",
        codepoint: "FDF7",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "bible",
        codepoint: "F0A2",
        aliases: [],
        tags: [
            "Religion"
        ],
    },
    {
        
        name: "bicycle",
        codepoint: "F00C7",
        aliases: [
            "bike",
            "cycling"
        ],
        tags: [
            "Transportation + Other"
        ],
    },
    {
        
        name: "bicycle-basket",
        codepoint: "F0260",
        aliases: [
            "bike-basket"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bike",
        codepoint: "F0A3",
        aliases: [
            "bicycle",
            "cycling",
            "directions-bike"
        ],
        tags: [
            "Transportation + Other",
            "Sport"
        ],
    },
    {
        
        name: "bike-fast",
        codepoint: "F014A",
        aliases: [],
        tags: [
            "Transportation + Other"
        ],
    },
    {
        
        name: "billboard",
        codepoint: "F0032",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "billiards",
        codepoint: "FB3D",
        aliases: [
            "pool",
            "eight-ball"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "billiards-rack",
        codepoint: "FB3E",
        aliases: [
            "pool-table",
            "pool-rack",
            "snooker-rack",
            "pool-triangle",
            "billiards-triangle",
            "snooker-triangle"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "bing",
        codepoint: "F0A4",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "binoculars",
        codepoint: "F0A5",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bio",
        codepoint: "F0A6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "biohazard",
        codepoint: "F0A7",
        aliases: [],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "bitbucket",
        codepoint: "F0A8",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "bitcoin",
        codepoint: "F812",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Banking",
            "Currency"
        ],
    },
    {
        
        name: "black-mesa",
        codepoint: "F0A9",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "blackberry",
        codepoint: "F0AA",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "blender",
        codepoint: "FCC7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "blender-software",
        codepoint: "F0AB",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "blinds",
        codepoint: "F0AC",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "blinds-open",
        codepoint: "F0033",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "block-helper",
        codepoint: "F0AD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "blogger",
        codepoint: "F0AE",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "blood-bag",
        codepoint: "FCC8",
        aliases: [],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "bluetooth",
        codepoint: "F0AF",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bluetooth-audio",
        codepoint: "F0B0",
        aliases: [
            "bluetooth-searching"
        ],
        tags: [
            "Audio"
        ],
    },
    {
        
        name: "bluetooth-connect",
        codepoint: "F0B1",
        aliases: [
            "bluetooth-connected"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bluetooth-off",
        codepoint: "F0B2",
        aliases: [
            "bluetooth-disabled"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bluetooth-settings",
        codepoint: "F0B3",
        aliases: [
            "settings-bluetooth"
        ],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "bluetooth-transfer",
        codepoint: "F0B4",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "blur",
        codepoint: "F0B5",
        aliases: [
            "blur-on"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "blur-linear",
        codepoint: "F0B6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "blur-off",
        codepoint: "F0B7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "blur-radial",
        codepoint: "F0B8",
        aliases: [
            "blur-circular"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bolnisi-cross",
        codepoint: "FCC9",
        aliases: [],
        tags: [
            "Religion"
        ],
    },
    {
        
        name: "bolt",
        codepoint: "FD8F",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "bomb",
        codepoint: "F690",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "bomb-off",
        codepoint: "F6C4",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bone",
        codepoint: "F0B9",
        aliases: [],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "book",
        codepoint: "F0BA",
        aliases: [
            "git-repository"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-information-variant",
        codepoint: "F009A",
        aliases: [
            "encyclopedia"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-lock",
        codepoint: "F799",
        aliases: [
            "book-secure"
        ],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "book-lock-open",
        codepoint: "F79A",
        aliases: [
            "book-unsecure"
        ],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "book-minus",
        codepoint: "F5D9",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-minus-multiple",
        codepoint: "FA93",
        aliases: [
            "books-minus"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-multiple",
        codepoint: "F0BB",
        aliases: [
            "books"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-open",
        codepoint: "F0BD",
        aliases: [
            "chrome-reader-mode"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-open-outline",
        codepoint: "FB3F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-open-page-variant",
        codepoint: "F5DA",
        aliases: [
            "auto-stories"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-open-variant",
        codepoint: "F0BE",
        aliases: [
            "import-contacts"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-outline",
        codepoint: "FB40",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-play",
        codepoint: "FE9F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-play-outline",
        codepoint: "FEA0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-plus",
        codepoint: "F5DB",
        aliases: [
            "book-add"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-plus-multiple",
        codepoint: "FA94",
        aliases: [
            "books-plus",
            "book-multiple-add",
            "books-add"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-remove",
        codepoint: "FA96",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-remove-multiple",
        codepoint: "FA95",
        aliases: [
            "books-remove"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-search",
        codepoint: "FEA1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-search-outline",
        codepoint: "FEA2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-variant",
        codepoint: "F0BF",
        aliases: [
            "class"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "book-variant-multiple",
        codepoint: "F0BC",
        aliases: [
            "books-variant"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bookmark",
        codepoint: "F0C0",
        aliases: [
            "turned-in"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bookmark-check",
        codepoint: "F0C1",
        aliases: [
            "bookmark-tick"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bookmark-minus",
        codepoint: "F9CB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bookmark-minus-outline",
        codepoint: "F9CC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bookmark-multiple",
        codepoint: "FDF8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bookmark-multiple-outline",
        codepoint: "FDF9",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bookmark-music",
        codepoint: "F0C2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bookmark-off",
        codepoint: "F9CD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bookmark-off-outline",
        codepoint: "F9CE",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bookmark-outline",
        codepoint: "F0C3",
        aliases: [
            "bookmark-border",
            "turned-in-not"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bookmark-plus",
        codepoint: "F0C5",
        aliases: [
            "bookmark-add"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bookmark-plus-outline",
        codepoint: "F0C4",
        aliases: [
            "bookmark-add-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bookmark-remove",
        codepoint: "F0C6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "boom-gate",
        codepoint: "FEA3",
        aliases: [
            "boom-arm",
            "boom-barrier",
            "arm-barrier",
            "barrier",
            "automatic-gate"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "boom-gate-alert",
        codepoint: "FEA4",
        aliases: [
            "boom-arm-alert",
            "boom-barrier-alert",
            "arm-barrier-alert",
            "barrier-alert",
            "automatic-gate-alert"
        ],
        tags: [
            "Alert \/ Error",
            "Transportation + Road"
        ],
    },
    {
        
        name: "boom-gate-alert-outline",
        codepoint: "FEA5",
        aliases: [
            "boom-arm-alert-outline",
            "boom-barrier-alert-outline",
            "arm-barrier-alert-outline",
            "barrier-alert-outline",
            "automatic-gate-alert-outline"
        ],
        tags: [
            "Alert \/ Error",
            "Transportation + Road"
        ],
    },
    {
        
        name: "boom-gate-down",
        codepoint: "FEA6",
        aliases: [
            "boom-arm-down",
            "boom-barrier-down",
            "arm-barrier-down",
            "barrier-down",
            "automatic-gate-down"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "boom-gate-down-outline",
        codepoint: "FEA7",
        aliases: [
            "boom-arm-down-outline",
            "boom-barrier-down-outline",
            "arm-barrier-down-outline",
            "barrier-down-outline",
            "automatic-gate-down-outline"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "boom-gate-outline",
        codepoint: "FEA8",
        aliases: [
            "boom-arm-outline",
            "boom-barrier-outline",
            "arm-barrier-outline",
            "barrier-outline",
            "automatic-gate-outline"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "boom-gate-up",
        codepoint: "FEA9",
        aliases: [
            "boom-arm-up",
            "boom-barrier-up",
            "arm-barrier-up",
            "barrier-up",
            "automatic-gate-up"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "boom-gate-up-outline",
        codepoint: "FEAA",
        aliases: [
            "boom-arm-up-outline",
            "boom-barrier-up-outline",
            "arm-barrier-up-outline",
            "barrier-up-outline",
            "automatic-gate-up-outline"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "boombox",
        codepoint: "F5DC",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "boomerang",
        codepoint: "F00FA",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "bootstrap",
        codepoint: "F6C5",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "border-all",
        codepoint: "F0C7",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "border-all-variant",
        codepoint: "F8A0",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "border-bottom",
        codepoint: "F0C8",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "border-bottom-variant",
        codepoint: "F8A1",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format",
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "border-color",
        codepoint: "F0C9",
        aliases: [
            "border-colour"
        ],
        tags: [
            "Color",
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "border-horizontal",
        codepoint: "F0CA",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "border-inside",
        codepoint: "F0CB",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "border-left",
        codepoint: "F0CC",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "border-left-variant",
        codepoint: "F8A2",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "border-none",
        codepoint: "F0CD",
        aliases: [
            "border-clear"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "border-none-variant",
        codepoint: "F8A3",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "border-outside",
        codepoint: "F0CE",
        aliases: [
            "border-outer"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "border-right",
        codepoint: "F0CF",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "border-right-variant",
        codepoint: "F8A4",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "border-style",
        codepoint: "F0D0",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "border-top",
        codepoint: "F0D1",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "border-top-variant",
        codepoint: "F8A5",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "border-vertical",
        codepoint: "F0D2",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "bottle-soda",
        codepoint: "F009B",
        aliases: [
            "bottle-coke",
            "bottle-pop"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "bottle-soda-classic",
        codepoint: "F009C",
        aliases: [
            "bottle-coke-classic",
            "bottle-pop-classic"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "bottle-soda-outline",
        codepoint: "F009D",
        aliases: [
            "bottle-coke-outline",
            "bottle-pop-outline"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "bottle-tonic",
        codepoint: "F0159",
        aliases: [
            "flask"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bottle-tonic-outline",
        codepoint: "F015A",
        aliases: [
            "flask-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bottle-tonic-plus",
        codepoint: "F015B",
        aliases: [
            "health-potion"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "bottle-tonic-plus-outline",
        codepoint: "F015C",
        aliases: [
            "health-potion-outline"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "bottle-tonic-skull",
        codepoint: "F015D",
        aliases: [
            "poison",
            "moonshine"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "bottle-tonic-skull-outline",
        codepoint: "F015E",
        aliases: [
            "poison-outline",
            "moonshine-outline"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "bottle-wine",
        codepoint: "F853",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "bow-tie",
        codepoint: "F677",
        aliases: [],
        tags: [
            "Clothing"
        ],
    },
    {
        
        name: "bowl",
        codepoint: "F617",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "bowling",
        codepoint: "F0D3",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "box",
        codepoint: "F0D4",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "box-cutter",
        codepoint: "F0D5",
        aliases: [
            "stanley-knife"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "box-shadow",
        codepoint: "F637",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "boxing-glove",
        codepoint: "FB41",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "braille",
        codepoint: "F9CF",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "brain",
        codepoint: "F9D0",
        aliases: [],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "bread-slice",
        codepoint: "FCCA",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "bread-slice-outline",
        codepoint: "FCCB",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "bridge",
        codepoint: "F618",
        aliases: [],
        tags: [
            "Places"
        ],
    },
    {
        
        name: "briefcase",
        codepoint: "F0D6",
        aliases: [
            "work"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "briefcase-account",
        codepoint: "FCCC",
        aliases: [
            "briefcase-person",
            "briefcase-user"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "briefcase-account-outline",
        codepoint: "FCCD",
        aliases: [
            "briefcase-person-outline",
            "briefcase-user-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "briefcase-check",
        codepoint: "F0D7",
        aliases: [
            "briefcase-tick"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "briefcase-clock",
        codepoint: "F00FB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "briefcase-clock-outline",
        codepoint: "F00FC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "briefcase-download",
        codepoint: "F0D8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "briefcase-download-outline",
        codepoint: "FC19",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "briefcase-edit",
        codepoint: "FA97",
        aliases: [],
        tags: [
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "briefcase-edit-outline",
        codepoint: "FC1A",
        aliases: [],
        tags: [
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "briefcase-minus",
        codepoint: "FA29",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "briefcase-minus-outline",
        codepoint: "FC1B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "briefcase-outline",
        codepoint: "F813",
        aliases: [
            "work-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "briefcase-plus",
        codepoint: "FA2A",
        aliases: [
            "briefcase-add"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "briefcase-plus-outline",
        codepoint: "FC1C",
        aliases: [
            "briefcase-add-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "briefcase-remove",
        codepoint: "FA2B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "briefcase-remove-outline",
        codepoint: "FC1D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "briefcase-search",
        codepoint: "FA2C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "briefcase-search-outline",
        codepoint: "FC1E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "briefcase-upload",
        codepoint: "F0D9",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "briefcase-upload-outline",
        codepoint: "FC1F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "brightness-1",
        codepoint: "F0DA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "brightness-2",
        codepoint: "F0DB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "brightness-3",
        codepoint: "F0DC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "brightness-4",
        codepoint: "F0DD",
        aliases: [
            "theme-light-dark"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "brightness-5",
        codepoint: "F0DE",
        aliases: [
            "brightness-low"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "brightness-6",
        codepoint: "F0DF",
        aliases: [
            "brightness-medium",
            "theme-light-dark"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "brightness-7",
        codepoint: "F0E0",
        aliases: [
            "brightness-high"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "brightness-auto",
        codepoint: "F0E1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "brightness-percent",
        codepoint: "FCCE",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "broom",
        codepoint: "F0E2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "brush",
        codepoint: "F0E3",
        aliases: [
            "paintbrush"
        ],
        tags: [
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "buddhism",
        codepoint: "F94A",
        aliases: [
            "dharmachakra",
            "dharma-wheel",
            "religion-buddhist"
        ],
        tags: [
            "Religion"
        ],
    },
    {
        
        name: "buffer",
        codepoint: "F619",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "bug",
        codepoint: "F0E4",
        aliases: [
            "bug-report"
        ],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "bug-check",
        codepoint: "FA2D",
        aliases: [
            "bug-tick"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bug-check-outline",
        codepoint: "FA2E",
        aliases: [
            "bug-tick-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bug-outline",
        codepoint: "FA2F",
        aliases: [],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "bugle",
        codepoint: "FD90",
        aliases: [
            "car-horn"
        ],
        tags: [
            "Automotive",
            "Music"
        ],
    },
    {
        
        name: "bulldozer",
        codepoint: "FB07",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "bullet",
        codepoint: "FCCF",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bulletin-board",
        codepoint: "F0E5",
        aliases: [
            "notice-board"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bullhorn",
        codepoint: "F0E6",
        aliases: [
            "announcement",
            "megaphone"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bullhorn-outline",
        codepoint: "FB08",
        aliases: [
            "announcement-outline",
            "megaphone-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bullseye",
        codepoint: "F5DD",
        aliases: [
            "target"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "bullseye-arrow",
        codepoint: "F8C8",
        aliases: [
            "target-arrow"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "bus",
        codepoint: "F0E7",
        aliases: [
            "directions-bus"
        ],
        tags: [
            "Navigation",
            "Transportation + Road"
        ],
    },
    {
        
        name: "bus-alert",
        codepoint: "FA98",
        aliases: [
            "bus-warning"
        ],
        tags: [
            "Alert \/ Error",
            "Transportation + Road"
        ],
    },
    {
        
        name: "bus-articulated-end",
        codepoint: "F79B",
        aliases: [],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "bus-articulated-front",
        codepoint: "F79C",
        aliases: [],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "bus-clock",
        codepoint: "F8C9",
        aliases: [
            "departure-board"
        ],
        tags: [
            "Date \/ Time",
            "Transportation + Road"
        ],
    },
    {
        
        name: "bus-double-decker",
        codepoint: "F79D",
        aliases: [],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "bus-marker",
        codepoint: "F023D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "bus-multiple",
        codepoint: "FF5C",
        aliases: [
            "fleet"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "bus-school",
        codepoint: "F79E",
        aliases: [],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "bus-side",
        codepoint: "F79F",
        aliases: [],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "bus-stop",
        codepoint: "F0034",
        aliases: [],
        tags: [
            "Transportation + Road",
            "Navigation"
        ],
    },
    {
        
        name: "bus-stop-covered",
        codepoint: "F0035",
        aliases: [],
        tags: [
            "Transportation + Road",
            "Navigation"
        ],
    },
    {
        
        name: "bus-stop-uncovered",
        codepoint: "F0036",
        aliases: [],
        tags: [
            "Transportation + Road",
            "Navigation"
        ],
    },
    {
        
        name: "cached",
        codepoint: "F0E8",
        aliases: [
            "counterclockwise-arrows",
            "circular-arrows",
            "circle-arrows"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "cactus",
        codepoint: "FD91",
        aliases: [],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "cake",
        codepoint: "F0E9",
        aliases: [],
        tags: [
            "Holiday",
            "Food \/ Drink"
        ],
    },
    {
        
        name: "cake-layered",
        codepoint: "F0EA",
        aliases: [],
        tags: [
            "Holiday",
            "Food \/ Drink"
        ],
    },
    {
        
        name: "cake-variant",
        codepoint: "F0EB",
        aliases: [],
        tags: [
            "Holiday",
            "Food \/ Drink"
        ],
    },
    {
        
        name: "calculator",
        codepoint: "F0EC",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "calculator-variant",
        codepoint: "FA99",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "calendar",
        codepoint: "F0ED",
        aliases: [
            "event",
            "insert-invitation"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-account",
        codepoint: "FEF4",
        aliases: [],
        tags: [
            "Date \/ Time",
            "Account \/ User"
        ],
    },
    {
        
        name: "calendar-account-outline",
        codepoint: "FEF5",
        aliases: [],
        tags: [
            "Date \/ Time",
            "Account \/ User"
        ],
    },
    {
        
        name: "calendar-alert",
        codepoint: "FA30",
        aliases: [
            "event-alert",
            "calendar-warning"
        ],
        tags: [
            "Date \/ Time",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "calendar-arrow-left",
        codepoint: "F015F",
        aliases: [
            "reschedule"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-arrow-right",
        codepoint: "F0160",
        aliases: [
            "reschedule"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-blank",
        codepoint: "F0EE",
        aliases: [
            "calendar-today"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-blank-multiple",
        codepoint: "F009E",
        aliases: [],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-blank-outline",
        codepoint: "FB42",
        aliases: [
            "event-blank-outline"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-check",
        codepoint: "F0EF",
        aliases: [
            "event-available",
            "calendar-task",
            "calendar-tick",
            "event-tick",
            "event-check"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-check-outline",
        codepoint: "FC20",
        aliases: [
            "event-available-outline",
            "event-check-outline",
            "event-tick-outline",
            "calendar-task-outline",
            "calendar-tick-outline"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-clock",
        codepoint: "F0F0",
        aliases: [
            "event-clock",
            "event-time",
            "calendar-time"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-edit",
        codepoint: "F8A6",
        aliases: [
            "event-edit"
        ],
        tags: [
            "Date \/ Time",
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "calendar-export",
        codepoint: "FB09",
        aliases: [],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-heart",
        codepoint: "F9D1",
        aliases: [
            "event-heart"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-import",
        codepoint: "FB0A",
        aliases: [],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-minus",
        codepoint: "FD38",
        aliases: [
            "event-minus"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-month",
        codepoint: "FDFA",
        aliases: [],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-month-outline",
        codepoint: "FDFB",
        aliases: [],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-multiple",
        codepoint: "F0F1",
        aliases: [
            "event-multiple",
            "calendars",
            "events"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-multiple-check",
        codepoint: "F0F2",
        aliases: [
            "event-multiple-check",
            "calendar-multiple-tick",
            "calendars-check",
            "calendars-tick",
            "event-multiple-tick",
            "events-check",
            "events-tick"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-multiselect",
        codepoint: "FA31",
        aliases: [],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-outline",
        codepoint: "FB43",
        aliases: [
            "event-outline"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-plus",
        codepoint: "F0F3",
        aliases: [
            "event-plus",
            "calendar-add",
            "event-add"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-question",
        codepoint: "F691",
        aliases: [
            "calendar-rsvp",
            "event-question"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-range",
        codepoint: "F678",
        aliases: [
            "date-range",
            "calendar-week",
            "event-range"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-range-outline",
        codepoint: "FB44",
        aliases: [
            "event-range-outline"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-remove",
        codepoint: "F0F4",
        aliases: [
            "event-busy",
            "event-remove"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-remove-outline",
        codepoint: "FC21",
        aliases: [
            "event-busy-outline",
            "event-remove-outline"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-repeat",
        codepoint: "FEAB",
        aliases: [
            "calendar-sync"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-repeat-outline",
        codepoint: "FEAC",
        aliases: [
            "calendar-sync-outline"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-search",
        codepoint: "F94B",
        aliases: [
            "event-search"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-star",
        codepoint: "F9D2",
        aliases: [
            "event-star"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-text",
        codepoint: "F0F5",
        aliases: [
            "event-note",
            "event-text"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-text-outline",
        codepoint: "FC22",
        aliases: [
            "event-text-outline",
            "event-note-outline"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-today",
        codepoint: "F0F6",
        aliases: [
            "calendar-day"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-week",
        codepoint: "FA32",
        aliases: [
            "event-week"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-week-begin",
        codepoint: "FA33",
        aliases: [
            "event-week-begin"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-weekend",
        codepoint: "FEF6",
        aliases: [],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "calendar-weekend-outline",
        codepoint: "FEF7",
        aliases: [],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "call-made",
        codepoint: "F0F7",
        aliases: [],
        tags: [
            "Cellphone \/ Phone",
            "Arrow"
        ],
    },
    {
        
        name: "call-merge",
        codepoint: "F0F8",
        aliases: [
            "merge-type"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Arrow"
        ],
    },
    {
        
        name: "call-missed",
        codepoint: "F0F9",
        aliases: [],
        tags: [
            "Cellphone \/ Phone",
            "Arrow"
        ],
    },
    {
        
        name: "call-received",
        codepoint: "F0FA",
        aliases: [],
        tags: [
            "Cellphone \/ Phone",
            "Arrow"
        ],
    },
    {
        
        name: "call-split",
        codepoint: "F0FB",
        aliases: [],
        tags: [
            "Cellphone \/ Phone",
            "Arrow"
        ],
    },
    {
        
        name: "camcorder",
        codepoint: "F0FC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "camcorder-box",
        codepoint: "F0FD",
        aliases: [],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "camcorder-box-off",
        codepoint: "F0FE",
        aliases: [],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "camcorder-off",
        codepoint: "F0FF",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "camera",
        codepoint: "F100",
        aliases: [
            "photography",
            "camera-alt",
            "local-see",
            "photo-camera"
        ],
        tags: [
            "Photography",
            "Home Automation"
        ],
    },
    {
        
        name: "camera-account",
        codepoint: "F8CA",
        aliases: [
            "camera-user"
        ],
        tags: [
            "Account \/ User",
            "Photography"
        ],
    },
    {
        
        name: "camera-burst",
        codepoint: "F692",
        aliases: [
            "burst-mode"
        ],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-control",
        codepoint: "FB45",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-enhance",
        codepoint: "F101",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-enhance-outline",
        codepoint: "FB46",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-front",
        codepoint: "F102",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-front-variant",
        codepoint: "F103",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-gopro",
        codepoint: "F7A0",
        aliases: [],
        tags: [
            "Photography",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "camera-image",
        codepoint: "F8CB",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-iris",
        codepoint: "F104",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-metering-center",
        codepoint: "F7A1",
        aliases: [
            "camera-metering-centre"
        ],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-metering-matrix",
        codepoint: "F7A2",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-metering-partial",
        codepoint: "F7A3",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-metering-spot",
        codepoint: "F7A4",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-off",
        codepoint: "F5DF",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-outline",
        codepoint: "FD39",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-party-mode",
        codepoint: "F105",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-plus",
        codepoint: "FEF8",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-plus-outline",
        codepoint: "FEF9",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-rear",
        codepoint: "F106",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-rear-variant",
        codepoint: "F107",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-retake",
        codepoint: "FDFC",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-retake-outline",
        codepoint: "FDFD",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-switch",
        codepoint: "F108",
        aliases: [
            "switch-camera"
        ],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-timer",
        codepoint: "F109",
        aliases: [],
        tags: [
            "Date \/ Time",
            "Photography"
        ],
    },
    {
        
        name: "camera-wireless",
        codepoint: "FD92",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "camera-wireless-outline",
        codepoint: "FD93",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "campfire",
        codepoint: "FEFA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "cancel",
        codepoint: "F739",
        aliases: [
            "prohibited",
            "ban",
            "do-not-disturb-alt",
            "denied",
            "block",
            "forbid"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "candle",
        codepoint: "F5E2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "candycane",
        codepoint: "F10A",
        aliases: [],
        tags: [
            "Holiday",
            "Food \/ Drink"
        ],
    },
    {
        
        name: "cannabis",
        codepoint: "F7A5",
        aliases: [],
        tags: [
            "Nature",
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "caps-lock",
        codepoint: "FA9A",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "car",
        codepoint: "F10B",
        aliases: [
            "directions-car",
            "drive-eta",
            "time-to-leave"
        ],
        tags: [
            "Transportation + Road",
            "Navigation",
            "Automotive"
        ],
    },
    {
        
        name: "car-2-plus",
        codepoint: "F0037",
        aliases: [
            "hov-lane",
            "high-occupancy-vehicle-lane",
            "carpool-lane"
        ],
        tags: [
            "Transportation + Road",
            "Automotive"
        ],
    },
    {
        
        name: "car-3-plus",
        codepoint: "F0038",
        aliases: [
            "hov-lane",
            "high-occupancy-vehicle-lane",
            "carpool-lane"
        ],
        tags: [
            "Transportation + Road",
            "Automotive"
        ],
    },
    {
        
        name: "car-back",
        codepoint: "FDFE",
        aliases: [],
        tags: [
            "Automotive",
            "Transportation + Road"
        ],
    },
    {
        
        name: "car-battery",
        codepoint: "F10C",
        aliases: [],
        tags: [
            "Battery",
            "Automotive"
        ],
    },
    {
        
        name: "car-brake-abs",
        codepoint: "FC23",
        aliases: [
            "anti-lock-brake-system",
            "anti-lock-braking-system"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-brake-alert",
        codepoint: "FC24",
        aliases: [
            "car-parking-brake",
            "car-handbrake",
            "car-hand-brake",
            "car-emergency-brake",
            "car-brake-warning"
        ],
        tags: [
            "Automotive",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "car-brake-hold",
        codepoint: "FD3A",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-brake-parking",
        codepoint: "FD3B",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-brake-retarder",
        codepoint: "F0039",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-child-seat",
        codepoint: "FFC3",
        aliases: [],
        tags: [
            "Automotive",
            "People \/ Family"
        ],
    },
    {
        
        name: "car-clutch",
        codepoint: "F003A",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-connected",
        codepoint: "F10D",
        aliases: [],
        tags: [
            "Transportation + Road",
            "Automotive"
        ],
    },
    {
        
        name: "car-convertible",
        codepoint: "F7A6",
        aliases: [],
        tags: [
            "Transportation + Road",
            "Automotive"
        ],
    },
    {
        
        name: "car-coolant-level",
        codepoint: "F003B",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-cruise-control",
        codepoint: "FD3C",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-defrost-front",
        codepoint: "FD3D",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-defrost-rear",
        codepoint: "FD3E",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-door",
        codepoint: "FB47",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-door-lock",
        codepoint: "F00C8",
        aliases: [],
        tags: [
            "Automotive",
            "Lock"
        ],
    },
    {
        
        name: "car-electric",
        codepoint: "FB48",
        aliases: [],
        tags: [
            "Transportation + Road",
            "Automotive"
        ],
    },
    {
        
        name: "car-esp",
        codepoint: "FC25",
        aliases: [
            "electronic-stability-program"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-estate",
        codepoint: "F7A7",
        aliases: [],
        tags: [
            "Transportation + Road",
            "Automotive"
        ],
    },
    {
        
        name: "car-hatchback",
        codepoint: "F7A8",
        aliases: [],
        tags: [
            "Transportation + Road",
            "Automotive"
        ],
    },
    {
        
        name: "car-info",
        codepoint: "F01E9",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-key",
        codepoint: "FB49",
        aliases: [
            "car-rental",
            "rent-a-car"
        ],
        tags: [
            "Transportation + Road",
            "Automotive"
        ],
    },
    {
        
        name: "car-light-dimmed",
        codepoint: "FC26",
        aliases: [
            "head-light-dimmed",
            "low-beam"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-light-fog",
        codepoint: "FC27",
        aliases: [
            "head-light-fog"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-light-high",
        codepoint: "FC28",
        aliases: [
            "head-light-high",
            "high-beam"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-limousine",
        codepoint: "F8CC",
        aliases: [],
        tags: [
            "Transportation + Road",
            "Automotive"
        ],
    },
    {
        
        name: "car-multiple",
        codepoint: "FB4A",
        aliases: [],
        tags: [
            "Transportation + Road",
            "Automotive"
        ],
    },
    {
        
        name: "car-off",
        codepoint: "FDFF",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-parking-lights",
        codepoint: "FD3F",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-pickup",
        codepoint: "F7A9",
        aliases: [],
        tags: [
            "Transportation + Road",
            "Automotive"
        ],
    },
    {
        
        name: "car-seat",
        codepoint: "FFC4",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-seat-cooler",
        codepoint: "FFC5",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-seat-heater",
        codepoint: "FFC6",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-shift-pattern",
        codepoint: "FF5D",
        aliases: [
            "car-transmission",
            "car-manual-transmission"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-side",
        codepoint: "F7AA",
        aliases: [
            "car-saloon"
        ],
        tags: [
            "Transportation + Road",
            "Automotive"
        ],
    },
    {
        
        name: "car-sports",
        codepoint: "F7AB",
        aliases: [],
        tags: [
            "Transportation + Road",
            "Sport",
            "Automotive"
        ],
    },
    {
        
        name: "car-tire-alert",
        codepoint: "FC29",
        aliases: [
            "car-tyre-alert",
            "car-tyre-warning",
            "car-tire-warning"
        ],
        tags: [
            "Automotive",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "car-traction-control",
        codepoint: "FD40",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-turbocharger",
        codepoint: "F003C",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-wash",
        codepoint: "F10E",
        aliases: [
            "local-car-wash"
        ],
        tags: [
            "Transportation + Road",
            "Places",
            "Automotive"
        ],
    },
    {
        
        name: "car-windshield",
        codepoint: "F003D",
        aliases: [
            "car-front-glass"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "car-windshield-outline",
        codepoint: "F003E",
        aliases: [
            "car-front-glass-outline"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "caravan",
        codepoint: "F7AC",
        aliases: [],
        tags: [
            "Transportation + Road",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "card",
        codepoint: "FB4B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "card-bulleted",
        codepoint: "FB4C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "card-bulleted-off",
        codepoint: "FB4D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "card-bulleted-off-outline",
        codepoint: "FB4E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "card-bulleted-outline",
        codepoint: "FB4F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "card-bulleted-settings",
        codepoint: "FB50",
        aliases: [],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "card-bulleted-settings-outline",
        codepoint: "FB51",
        aliases: [],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "card-outline",
        codepoint: "FB52",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "card-plus",
        codepoint: "F022A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "card-plus-outline",
        codepoint: "F022B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "card-search",
        codepoint: "F009F",
        aliases: [
            "pageview"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "card-search-outline",
        codepoint: "F00A0",
        aliases: [
            "pageview-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "card-text",
        codepoint: "FB53",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "card-text-outline",
        codepoint: "FB54",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "cards",
        codepoint: "F638",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "cards-club",
        codepoint: "F8CD",
        aliases: [
            "suit-clubs"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "cards-diamond",
        codepoint: "F8CE",
        aliases: [
            "suit-diamonds",
            "hov-lane",
            "high-occupancy-vehicle-lane",
            "carpool-lane"
        ],
        tags: [
            "Gaming \/ RPG",
            "Transportation + Road"
        ],
    },
    {
        
        name: "cards-diamond-outline",
        codepoint: "F003F",
        aliases: [
            "hov-lane-outline",
            "high-occupancy-vehicle-lane-outline",
            "carpool-lane-outline"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "cards-heart",
        codepoint: "F8CF",
        aliases: [
            "suit-hearts"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "cards-outline",
        codepoint: "F639",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "cards-playing-outline",
        codepoint: "F63A",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "cards-spade",
        codepoint: "F8D0",
        aliases: [
            "suit-spades"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "cards-variant",
        codepoint: "F6C6",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "carrot",
        codepoint: "F10F",
        aliases: [],
        tags: [
            "Agriculture",
            "Food \/ Drink"
        ],
    },
    {
        
        name: "cart",
        codepoint: "F110",
        aliases: [
            "trolley",
            "local-grocery-store",
            "shopping-cart"
        ],
        tags: [
            "Shopping"
        ],
    },
    {
        
        name: "cart-arrow-down",
        codepoint: "FD42",
        aliases: [
            "shopping-cart-arrow-down",
            "trolley-arrow-down"
        ],
        tags: [
            "Shopping"
        ],
    },
    {
        
        name: "cart-arrow-right",
        codepoint: "FC2A",
        aliases: [
            "trolley-arrow-right",
            "shopping-cart-arrow-right"
        ],
        tags: [
            "Shopping"
        ],
    },
    {
        
        name: "cart-arrow-up",
        codepoint: "FD43",
        aliases: [
            "shopping-cart-arrow-up",
            "trolley-arrow-up"
        ],
        tags: [
            "Shopping"
        ],
    },
    {
        
        name: "cart-minus",
        codepoint: "FD44",
        aliases: [
            "shopping-cart-minus",
            "trolley-minus"
        ],
        tags: [
            "Shopping"
        ],
    },
    {
        
        name: "cart-off",
        codepoint: "F66B",
        aliases: [
            "trolley-off",
            "remove-shopping-cart",
            "shopping-cart-off"
        ],
        tags: [
            "Shopping"
        ],
    },
    {
        
        name: "cart-outline",
        codepoint: "F111",
        aliases: [
            "trolley-outline",
            "shopping-cart-outline"
        ],
        tags: [
            "Shopping"
        ],
    },
    {
        
        name: "cart-plus",
        codepoint: "F112",
        aliases: [
            "trolley-plus",
            "add-shopping-cart",
            "shopping-cart-plus",
            "cart-add",
            "trolley-add",
            "shopping-cart-add"
        ],
        tags: [
            "Shopping"
        ],
    },
    {
        
        name: "cart-remove",
        codepoint: "FD45",
        aliases: [
            "trolley-remove",
            "shopping-cart-remove"
        ],
        tags: [
            "Shopping"
        ],
    },
    {
        
        name: "case-sensitive-alt",
        codepoint: "F113",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "cash",
        codepoint: "F114",
        aliases: [
            "money"
        ],
        tags: [
            "Currency",
            "Banking",
            "Shopping"
        ],
    },
    {
        
        name: "cash-100",
        codepoint: "F115",
        aliases: [
            "money-100"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "cash-marker",
        codepoint: "FD94",
        aliases: [
            "cod",
            "cash-on-delivery"
        ],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "cash-multiple",
        codepoint: "F116",
        aliases: [
            "money"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "cash-refund",
        codepoint: "FA9B",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "cash-register",
        codepoint: "FCD0",
        aliases: [
            "till"
        ],
        tags: [
            "Shopping"
        ],
    },
    {
        
        name: "cash-usd",
        codepoint: "F01A1",
        aliases: [
            "local-atm",
            "money-usd"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "cash-usd-outline",
        codepoint: "F117",
        aliases: [
            "local-atm",
            "money-usd"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "cassette",
        codepoint: "F9D3",
        aliases: [
            "tape"
        ],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "cast",
        codepoint: "F118",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "cast-audio",
        codepoint: "F0040",
        aliases: [
            "cast-speaker"
        ],
        tags: [
            "Audio"
        ],
    },
    {
        
        name: "cast-connected",
        codepoint: "F119",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "cast-education",
        codepoint: "FE6D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "cast-off",
        codepoint: "F789",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "castle",
        codepoint: "F11A",
        aliases: [],
        tags: [
            "Places"
        ],
    },
    {
        
        name: "cat",
        codepoint: "F11B",
        aliases: [],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "cctv",
        codepoint: "F7AD",
        aliases: [
            "closed-circuit-television",
            "security-camera"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "ceiling-light",
        codepoint: "F768",
        aliases: [
            "ceiling-lamp"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "cellphone",
        codepoint: "F11C",
        aliases: [
            "mobile-phone",
            "smartphone",
            "stay-current-portrait",
            "stay-primary-portrait"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-android",
        codepoint: "F11D",
        aliases: [
            "mobile-phone-android",
            "smartphone-android"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-arrow-down",
        codepoint: "F9D4",
        aliases: [
            "cellphone-system-update",
            "mobile-phone-arrow-down",
            "smartphone-arrow-down"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-basic",
        codepoint: "F11E",
        aliases: [
            "mobile-phone-basic"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-dock",
        codepoint: "F11F",
        aliases: [
            "mobile-phone-dock",
            "smartphone-dock"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-erase",
        codepoint: "F94C",
        aliases: [
            "phonelink-erase",
            "mobile-phone-erase",
            "smartphone-erase"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-information",
        codepoint: "FF5E",
        aliases: [
            "mobile-phone-information",
            "smartphone-information"
        ],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "cellphone-iphone",
        codepoint: "F120",
        aliases: [
            "mobile-phone-iphone",
            "smartphone-iphone"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-key",
        codepoint: "F94D",
        aliases: [
            "mobile-phone-key",
            "smartphone-key"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-link",
        codepoint: "F121",
        aliases: [
            "mobile-phone-link",
            "smartphone-link",
            "devices"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-link-off",
        codepoint: "F122",
        aliases: [
            "mobile-phone-link-off",
            "smartphone-link-off",
            "phonelink-off"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-lock",
        codepoint: "F94E",
        aliases: [
            "phonelink-lock",
            "mobile-phone-lock",
            "smartphone-lock"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Lock",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-message",
        codepoint: "F8D2",
        aliases: [
            "mobile-phone-message",
            "smartphone-message"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-message-off",
        codepoint: "F00FD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "cellphone-nfc",
        codepoint: "FEAD",
        aliases: [],
        tags: [
            "Automotive",
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-off",
        codepoint: "F94F",
        aliases: [
            "mobile-phone-off",
            "smartphone-off",
            "mobile-off"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-play",
        codepoint: "F0041",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "cellphone-screenshot",
        codepoint: "FA34",
        aliases: [],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-settings",
        codepoint: "F123",
        aliases: [
            "mobile-phone-settings",
            "smartphone-settings",
            "settings-cell"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Settings",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-settings-variant",
        codepoint: "F950",
        aliases: [
            "phonelink-setup",
            "mobile-phone-settings-variant",
            "smartphone-settings-variant"
        ],
        tags: [
            "Settings",
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-sound",
        codepoint: "F951",
        aliases: [
            "phonelink-ring",
            "mobile-phone-sound",
            "smartphone-sound"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-text",
        codepoint: "F8D1",
        aliases: [
            "mobile-phone-text",
            "smartphone-text"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "cellphone-wireless",
        codepoint: "F814",
        aliases: [
            "mobile-phone-wireless",
            "smartphone-wireless"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "celtic-cross",
        codepoint: "FCD1",
        aliases: [],
        tags: [
            "Religion"
        ],
    },
    {
        
        name: "centos",
        codepoint: "F0145",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "certificate",
        codepoint: "F124",
        aliases: [
            "diploma",
            "seal"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "certificate-outline",
        codepoint: "F01B3",
        aliases: [
            "diploma-outline",
            "seal-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "chair-rolling",
        codepoint: "FFBA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "chair-school",
        codepoint: "F125",
        aliases: [
            "desk"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "charity",
        codepoint: "FC2B",
        aliases: [
            "super-chat-for-good"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "chart-arc",
        codepoint: "F126",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-areaspline",
        codepoint: "F127",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-areaspline-variant",
        codepoint: "FEAE",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-bar",
        codepoint: "F128",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-bar-stacked",
        codepoint: "F769",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-bell-curve",
        codepoint: "FC2C",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-bell-curve-cumulative",
        codepoint: "FFC7",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-bubble",
        codepoint: "F5E3",
        aliases: [
            "bubble-chart"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-donut",
        codepoint: "F7AE",
        aliases: [
            "chart-doughnut",
            "data-usage"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-donut-variant",
        codepoint: "F7AF",
        aliases: [
            "chart-doughnut-variant"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-gantt",
        codepoint: "F66C",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-histogram",
        codepoint: "F129",
        aliases: [],
        tags: [
            "Math",
            "Math"
        ],
    },
    {
        
        name: "chart-line",
        codepoint: "F12A",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-line-stacked",
        codepoint: "F76A",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-line-variant",
        codepoint: "F7B0",
        aliases: [
            "show-chart"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-multiline",
        codepoint: "F8D3",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-multiple",
        codepoint: "F023E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "chart-pie",
        codepoint: "F12B",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-scatter-plot",
        codepoint: "FEAF",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-scatter-plot-hexbin",
        codepoint: "F66D",
        aliases: [
            "chart-scatterplot-hexbin"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-snakey",
        codepoint: "F020A",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-snakey-variant",
        codepoint: "F020B",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-timeline",
        codepoint: "F66E",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-timeline-variant",
        codepoint: "FEB0",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chart-tree",
        codepoint: "FEB1",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "chat",
        codepoint: "FB55",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "chat-alert",
        codepoint: "FB56",
        aliases: [
            "chat-warning"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "chat-outline",
        codepoint: "FEFB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "chat-processing",
        codepoint: "FB57",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "check",
        codepoint: "F12C",
        aliases: [
            "tick",
            "done"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "check-all",
        codepoint: "F12D",
        aliases: [
            "tick-all",
            "done-all",
            "check-multiple",
            "checks",
            "ticks"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "check-bold",
        codepoint: "FE6E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "check-box-multiple-outline",
        codepoint: "FC2D",
        aliases: [
            "check-boxes-outline",
            "tick-box-multiple-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "check-box-outline",
        codepoint: "FC2E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "check-circle",
        codepoint: "F5E0",
        aliases: [
            "tick-circle"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "check-circle-outline",
        codepoint: "F5E1",
        aliases: [
            "tick-circle-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "check-decagram",
        codepoint: "F790",
        aliases: [
            "verified",
            "decagram-check",
            "approve",
            "approval",
            "tick-decagram"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "check-network",
        codepoint: "FC2F",
        aliases: [
            "tick-network"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "check-network-outline",
        codepoint: "FC30",
        aliases: [
            "tick-network-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "check-outline",
        codepoint: "F854",
        aliases: [
            "done-outline",
            "tick-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "check-underline",
        codepoint: "FE70",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "check-underline-circle",
        codepoint: "FE71",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "check-underline-circle-outline",
        codepoint: "FE72",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "checkbook",
        codepoint: "FA9C",
        aliases: [
            "chequebook",
            "cheque-book"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "checkbox-blank",
        codepoint: "F12E",
        aliases: [],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "checkbox-blank-circle",
        codepoint: "F12F",
        aliases: [],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "checkbox-blank-circle-outline",
        codepoint: "F130",
        aliases: [],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "checkbox-blank-outline",
        codepoint: "F131",
        aliases: [
            "check-box-outline-blank"
        ],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "checkbox-intermediate",
        codepoint: "F855",
        aliases: [],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "checkbox-marked",
        codepoint: "F132",
        aliases: [
            "check-box"
        ],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "checkbox-marked-circle",
        codepoint: "F133",
        aliases: [],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "checkbox-marked-circle-outline",
        codepoint: "F134",
        aliases: [],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "checkbox-marked-outline",
        codepoint: "F135",
        aliases: [],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "checkbox-multiple-blank",
        codepoint: "F136",
        aliases: [
            "checkboxes-blank"
        ],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "checkbox-multiple-blank-circle",
        codepoint: "F63B",
        aliases: [
            "checkboxes-blank-circle"
        ],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "checkbox-multiple-blank-circle-outline",
        codepoint: "F63C",
        aliases: [
            "checkboxes-blank-circle-outline"
        ],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "checkbox-multiple-blank-outline",
        codepoint: "F137",
        aliases: [
            "checkboxes-blank-outline"
        ],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "checkbox-multiple-marked",
        codepoint: "F138",
        aliases: [
            "checkboxes-marked"
        ],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "checkbox-multiple-marked-circle",
        codepoint: "F63D",
        aliases: [
            "checkboxes-marked-circle"
        ],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "checkbox-multiple-marked-circle-outline",
        codepoint: "F63E",
        aliases: [
            "checkboxes-marked-circle-outline"
        ],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "checkbox-multiple-marked-outline",
        codepoint: "F139",
        aliases: [
            "checkboxes-marked-outline"
        ],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "checkerboard",
        codepoint: "F13A",
        aliases: [
            "raster"
        ],
        tags: [
            "Gaming \/ RPG",
            "Geographic Information System"
        ],
    },
    {
        
        name: "checkerboard-minus",
        codepoint: "F022D",
        aliases: [
            "raster-minus"
        ],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "checkerboard-plus",
        codepoint: "F022C",
        aliases: [
            "raster-plus"
        ],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "checkerboard-remove",
        codepoint: "F022E",
        aliases: [
            "raster-remove"
        ],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "chef-hat",
        codepoint: "FB58",
        aliases: [
            "toque",
            "cook"
        ],
        tags: [
            "Clothing"
        ],
    },
    {
        
        name: "chemical-weapon",
        codepoint: "F13B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "chess-bishop",
        codepoint: "F85B",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "chess-king",
        codepoint: "F856",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "chess-knight",
        codepoint: "F857",
        aliases: [
            "chess-horse"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "chess-pawn",
        codepoint: "F858",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "chess-queen",
        codepoint: "F859",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "chess-rook",
        codepoint: "F85A",
        aliases: [
            "chess-castle"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "chevron-double-down",
        codepoint: "F13C",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-double-left",
        codepoint: "F13D",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-double-right",
        codepoint: "F13E",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-double-up",
        codepoint: "F13F",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-down",
        codepoint: "F140",
        aliases: [
            "expand-more",
            "keyboard-arrow-down"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-down-box",
        codepoint: "F9D5",
        aliases: [],
        tags: [
            "Form",
            "Arrow"
        ],
    },
    {
        
        name: "chevron-down-box-outline",
        codepoint: "F9D6",
        aliases: [],
        tags: [
            "Form",
            "Arrow"
        ],
    },
    {
        
        name: "chevron-down-circle",
        codepoint: "FB0B",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-down-circle-outline",
        codepoint: "FB0C",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-left",
        codepoint: "F141",
        aliases: [
            "keyboard-arrow-left",
            "navigate-before"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-left-box",
        codepoint: "F9D7",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-left-box-outline",
        codepoint: "F9D8",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-left-circle",
        codepoint: "FB0D",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-left-circle-outline",
        codepoint: "FB0E",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-right",
        codepoint: "F142",
        aliases: [
            "keyboard-arrow-right",
            "navigate-next"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-right-box",
        codepoint: "F9D9",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-right-box-outline",
        codepoint: "F9DA",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-right-circle",
        codepoint: "FB0F",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-right-circle-outline",
        codepoint: "FB10",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-triple-down",
        codepoint: "FD95",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "chevron-triple-left",
        codepoint: "FD96",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "chevron-triple-right",
        codepoint: "FD97",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "chevron-triple-up",
        codepoint: "FD98",
        aliases: [
            "rank"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "chevron-up",
        codepoint: "F143",
        aliases: [
            "expand-less",
            "keyboard-arrow-up",
            "caret"
        ],
        tags: [
            "Arrow",
            "Math"
        ],
    },
    {
        
        name: "chevron-up-box",
        codepoint: "F9DB",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-up-box-outline",
        codepoint: "F9DC",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-up-circle",
        codepoint: "FB11",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chevron-up-circle-outline",
        codepoint: "FB12",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "chili-hot",
        codepoint: "F7B1",
        aliases: [
            "chilli-hot",
            "pepper",
            "spicy"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "chili-medium",
        codepoint: "F7B2",
        aliases: [
            "chilli-medium",
            "pepper",
            "spicy"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "chili-mild",
        codepoint: "F7B3",
        aliases: [
            "chilli-mild",
            "pepper",
            "spicy"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "chip",
        codepoint: "F61A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "christianity",
        codepoint: "F952",
        aliases: [
            "religion-christian",
            "cross"
        ],
        tags: [
            "Religion"
        ],
    },
    {
        
        name: "christianity-outline",
        codepoint: "FCD2",
        aliases: [
            "religion-christian-outline",
            "cross-outline"
        ],
        tags: [
            "Religion"
        ],
    },
    {
        
        name: "church",
        codepoint: "F144",
        aliases: [],
        tags: [
            "Religion",
            "Places"
        ],
    },
    {
        
        name: "cigar",
        codepoint: "F01B4",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "circle",
        codepoint: "F764",
        aliases: [
            "lens"
        ],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "circle-double",
        codepoint: "FEB2",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "circle-edit-outline",
        codepoint: "F8D4",
        aliases: [],
        tags: [
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "circle-expand",
        codepoint: "FEB3",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "circle-medium",
        codepoint: "F9DD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "circle-off-outline",
        codepoint: "F00FE",
        aliases: [
            "null-off"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "circle-outline",
        codepoint: "F765",
        aliases: [
            "null"
        ],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "circle-slice-1",
        codepoint: "FA9D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "circle-slice-2",
        codepoint: "FA9E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "circle-slice-3",
        codepoint: "FA9F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "circle-slice-4",
        codepoint: "FAA0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "circle-slice-5",
        codepoint: "FAA1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "circle-slice-6",
        codepoint: "FAA2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "circle-slice-7",
        codepoint: "FAA3",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "circle-slice-8",
        codepoint: "FAA4",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "circle-small",
        codepoint: "F9DE",
        aliases: [
            "bullet",
            "multiplication"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "circular-saw",
        codepoint: "FE73",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "cisco-webex",
        codepoint: "F145",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "city",
        codepoint: "F146",
        aliases: [
            "location-city"
        ],
        tags: [
            "Places"
        ],
    },
    {
        
        name: "city-variant",
        codepoint: "FA35",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "city-variant-outline",
        codepoint: "FA36",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard",
        codepoint: "F147",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-account",
        codepoint: "F148",
        aliases: [
            "clipboard-user",
            "assignment-ind",
            "clipboard-person"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "clipboard-account-outline",
        codepoint: "FC31",
        aliases: [
            "clipboard-user-outline",
            "clipboard-person-outline",
            "assignment-ind-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "clipboard-alert",
        codepoint: "F149",
        aliases: [
            "clipboard-warning",
            "assignment-late"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "clipboard-alert-outline",
        codepoint: "FCD3",
        aliases: [
            "clipboard-warning-outline"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "clipboard-arrow-down",
        codepoint: "F14A",
        aliases: [
            "assignment-returned",
            "clipboard-arrow-bottom"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-arrow-down-outline",
        codepoint: "FC32",
        aliases: [
            "assignment-returned-outline",
            "clipboard-arrow-bottom-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-arrow-left",
        codepoint: "F14B",
        aliases: [
            "assignment-return"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-arrow-left-outline",
        codepoint: "FCD4",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-arrow-right",
        codepoint: "FCD5",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-arrow-right-outline",
        codepoint: "FCD6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-arrow-up",
        codepoint: "FC33",
        aliases: [
            "clipboard-arrow-top"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-arrow-up-outline",
        codepoint: "FC34",
        aliases: [
            "clipboard-arrow-top-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-check",
        codepoint: "F14C",
        aliases: [
            "assignment-turned-in",
            "clipboard-tick"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-check-outline",
        codepoint: "F8A7",
        aliases: [
            "clipboard-tick-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-flow",
        codepoint: "F6C7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-flow-outline",
        codepoint: "F0142",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-list",
        codepoint: "F00FF",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-list-outline",
        codepoint: "F0100",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-outline",
        codepoint: "F14D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-play",
        codepoint: "FC35",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-play-outline",
        codepoint: "FC36",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-plus",
        codepoint: "F750",
        aliases: [
            "clipboard-add"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-pulse",
        codepoint: "F85C",
        aliases: [
            "clipboard-vitals"
        ],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "clipboard-pulse-outline",
        codepoint: "F85D",
        aliases: [
            "clipboard-vitals-outline"
        ],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "clipboard-text",
        codepoint: "F14E",
        aliases: [
            "assignment"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-text-outline",
        codepoint: "FA37",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-text-play",
        codepoint: "FC37",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clipboard-text-play-outline",
        codepoint: "FC38",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clippy",
        codepoint: "F14F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clock",
        codepoint: "F953",
        aliases: [
            "watch-later"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "clock-alert",
        codepoint: "F954",
        aliases: [
            "clock-warning"
        ],
        tags: [
            "Date \/ Time",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "clock-alert-outline",
        codepoint: "F5CE",
        aliases: [
            "clock-warning"
        ],
        tags: [
            "Date \/ Time",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "clock-check",
        codepoint: "FFC8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clock-check-outline",
        codepoint: "FFC9",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "clock-digital",
        codepoint: "FEB4",
        aliases: [],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "clock-end",
        codepoint: "F151",
        aliases: [],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "clock-fast",
        codepoint: "F152",
        aliases: [],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "clock-in",
        codepoint: "F153",
        aliases: [],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "clock-out",
        codepoint: "F154",
        aliases: [],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "clock-outline",
        codepoint: "F150",
        aliases: [
            "access-time",
            "query-builder",
            "schedule"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "clock-start",
        codepoint: "F155",
        aliases: [],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "close",
        codepoint: "F156",
        aliases: [
            "clear",
            "multiply"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "close-box",
        codepoint: "F157",
        aliases: [
            "multiply-box"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "close-box-multiple",
        codepoint: "FC39",
        aliases: [
            "close-boxes",
            "library-remove",
            "library-close"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "close-box-multiple-outline",
        codepoint: "FC3A",
        aliases: [
            "close-boxes-outline",
            "library-remove-outline",
            "library-close-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "close-box-outline",
        codepoint: "F158",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "close-circle",
        codepoint: "F159",
        aliases: [
            "remove-circle",
            "cancel",
            "multiply-circle"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "close-circle-outline",
        codepoint: "F15A",
        aliases: [
            "highlight-off"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "close-network",
        codepoint: "F15B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "close-network-outline",
        codepoint: "FC3B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "close-octagon",
        codepoint: "F15C",
        aliases: [
            "dangerous",
            "multiply-octagon"
        ],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "close-octagon-outline",
        codepoint: "F15D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "close-outline",
        codepoint: "F6C8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1-299" ],
    },
    {
        
        name: "closed-caption",
        codepoint: "F15E",
        aliases: [
            "cc"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "closed-caption-outline",
        codepoint: "FD99",
        aliases: [
            "cc-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cloud",
        codepoint: "F15F",
        aliases: [
            "wb-cloudy"
        ],
        tags: [
            "Cloud",
            "Weather"
        ],
    },
    {
        
        name: "cloud-alert",
        codepoint: "F9DF",
        aliases: [
            "cloud-warning"
        ],
        tags: [
            "Alert \/ Error",
            "Cloud",
            "Weather"
        ],
    },
    {
        
        name: "cloud-braces",
        codepoint: "F7B4",
        aliases: [
            "cloud-json"
        ],
        tags: [
            "Cloud"
        ],
    },
    {
        
        name: "cloud-check",
        codepoint: "F160",
        aliases: [
            "cloud-done",
            "cloud-tick"
        ],
        tags: [
            "Cloud"
        ],
    },
    {
        
        name: "cloud-circle",
        codepoint: "F161",
        aliases: [],
        tags: [
            "Cloud"
        ],
    },
    {
        
        name: "cloud-download",
        codepoint: "F162",
        aliases: [],
        tags: [
            "Cloud"
        ],
    },
    {
        
        name: "cloud-download-outline",
        codepoint: "FB59",
        aliases: [],
        tags: [
            "Cloud"
        ],
    },
    {
        
        name: "cloud-lock",
        codepoint: "F021C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cloud-lock-outline",
        codepoint: "F021D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cloud-off-outline",
        codepoint: "F164",
        aliases: [],
        tags: [
            "Cloud"
        ],
    },
    {
        
        name: "cloud-outline",
        codepoint: "F163",
        aliases: [
            "cloud-queue"
        ],
        tags: [
            "Cloud",
            "Weather"
        ],
    },
    {
        
        name: "cloud-print",
        codepoint: "F165",
        aliases: [],
        tags: [
            "Cloud",
            "Printer",
            "Home Automation"
        ],
    },
    {
        
        name: "cloud-print-outline",
        codepoint: "F166",
        aliases: [],
        tags: [
            "Cloud",
            "Printer",
            "Home Automation"
        ],
    },
    {
        
        name: "cloud-question",
        codepoint: "FA38",
        aliases: [],
        tags: [
            "Cloud"
        ],
    },
    {
        
        name: "cloud-search",
        codepoint: "F955",
        aliases: [],
        tags: [
            "Cloud"
        ],
    },
    {
        
        name: "cloud-search-outline",
        codepoint: "F956",
        aliases: [],
        tags: [
            "Cloud"
        ],
    },
    {
        
        name: "cloud-sync",
        codepoint: "F63F",
        aliases: [],
        tags: [
            "Cloud"
        ],
    },
    {
        
        name: "cloud-tags",
        codepoint: "F7B5",
        aliases: [
            "cloud-xml"
        ],
        tags: [
            "Cloud"
        ],
    },
    {
        
        name: "cloud-upload",
        codepoint: "F167",
        aliases: [
            "backup"
        ],
        tags: [
            "Cloud"
        ],
    },
    {
        
        name: "cloud-upload-outline",
        codepoint: "FB5A",
        aliases: [
            "backup-outline"
        ],
        tags: [
            "Cloud"
        ],
    },
    {
        
        name: "clover",
        codepoint: "F815",
        aliases: [
            "luck"
        ],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "coach-lamp",
        codepoint: "F0042",
        aliases: [
            "coach-light",
            "carriage-lamp",
            "carriage-light"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "coat-rack",
        codepoint: "F00C9",
        aliases: [],
        tags: [
            "Home Automation",
            "Clothing"
        ],
    },
    {
        
        name: "code-array",
        codepoint: "F168",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "code-braces",
        codepoint: "F169",
        aliases: [
            "set"
        ],
        tags: [
            "Developer \/ Languages",
            "Math"
        ],
    },
    {
        
        name: "code-braces-box",
        codepoint: "F0101",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "code-brackets",
        codepoint: "F16A",
        aliases: [
            "square-brackets"
        ],
        tags: [
            "Developer \/ Languages",
            "Math"
        ],
    },
    {
        
        name: "code-equal",
        codepoint: "F16B",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "code-greater-than",
        codepoint: "F16C",
        aliases: [],
        tags: [
            "Developer \/ Languages",
            "Math"
        ],
    },
    {
        
        name: "code-greater-than-or-equal",
        codepoint: "F16D",
        aliases: [],
        tags: [
            "Developer \/ Languages",
            "Math"
        ],
    },
    {
        
        name: "code-less-than",
        codepoint: "F16E",
        aliases: [],
        tags: [
            "Developer \/ Languages",
            "Math"
        ],
    },
    {
        
        name: "code-less-than-or-equal",
        codepoint: "F16F",
        aliases: [],
        tags: [
            "Developer \/ Languages",
            "Math"
        ],
    },
    {
        
        name: "code-not-equal",
        codepoint: "F170",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "code-not-equal-variant",
        codepoint: "F171",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "code-parentheses",
        codepoint: "F172",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "code-parentheses-box",
        codepoint: "F0102",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "code-string",
        codepoint: "F173",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "code-tags",
        codepoint: "F174",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "code-tags-check",
        codepoint: "F693",
        aliases: [
            "code-tags-tick"
        ],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "codepen",
        codepoint: "F175",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "coffee",
        codepoint: "F176",
        aliases: [
            "tea",
            "cup",
            "free-breakfast",
            "local-cafe"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "coffee-maker",
        codepoint: "F00CA",
        aliases: [
            "espresso-maker",
            "coffee-machine",
            "espresso-machine"
        ],
        tags: [
            "Home Automation",
            "Food \/ Drink"
        ],
    },
    {
        
        name: "coffee-off",
        codepoint: "FFCA",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "coffee-off-outline",
        codepoint: "FFCB",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "coffee-outline",
        codepoint: "F6C9",
        aliases: [
            "tea-outline",
            "cup-outline"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "coffee-to-go",
        codepoint: "F177",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "coffin",
        codepoint: "FB5B",
        aliases: [],
        tags: [
            "Holiday"
        ],
    },
    {
        
        name: "cog-clockwise",
        codepoint: "F0208",
        aliases: [],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "cog-counterclockwise",
        codepoint: "F0209",
        aliases: [],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "cogs",
        codepoint: "F8D5",
        aliases: [
            "manufacturing"
        ],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "coin",
        codepoint: "F0196",
        aliases: [],
        tags: [
            "Banking",
            "Currency"
        ],
    },
    {
        
        name: "coin-outline",
        codepoint: "F178",
        aliases: [
            "currency-usd-circle-outline"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "coins",
        codepoint: "F694",
        aliases: [
            "toll"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "collage",
        codepoint: "F640",
        aliases: [
            "auto-awesome-mosaic"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "collapse-all",
        codepoint: "FAA5",
        aliases: [
            "animation-minus"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "collapse-all-outline",
        codepoint: "FAA6",
        aliases: [
            "animation-minus-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "color-helper",
        codepoint: "F179",
        aliases: [
            "colour-helper"
        ],
        tags: [
            "Text \/ Content \/ Format",
            "Color"
        ],
    },
    {
        
        name: "comma",
        codepoint: "FE74",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comma-box",
        codepoint: "FE75",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comma-box-outline",
        codepoint: "FE76",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comma-circle",
        codepoint: "FE77",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comma-circle-outline",
        codepoint: "FE78",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment",
        codepoint: "F17A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-account",
        codepoint: "F17B",
        aliases: [
            "comment-user",
            "comment-person"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "comment-account-outline",
        codepoint: "F17C",
        aliases: [
            "comment-user-outline",
            "comment-person-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "comment-alert",
        codepoint: "F17D",
        aliases: [
            "comment-warning"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "comment-alert-outline",
        codepoint: "F17E",
        aliases: [
            "comment-warning-outline"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "comment-arrow-left",
        codepoint: "F9E0",
        aliases: [
            "comment-previous"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-arrow-left-outline",
        codepoint: "F9E1",
        aliases: [
            "comment-previous-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-arrow-right",
        codepoint: "F9E2",
        aliases: [
            "comment-next"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-arrow-right-outline",
        codepoint: "F9E3",
        aliases: [
            "comment-next-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-check",
        codepoint: "F17F",
        aliases: [
            "comment-tick"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-check-outline",
        codepoint: "F180",
        aliases: [
            "comment-tick-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-edit",
        codepoint: "F01EA",
        aliases: [],
        tags: [
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "comment-eye",
        codepoint: "FA39",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-eye-outline",
        codepoint: "FA3A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-multiple",
        codepoint: "F85E",
        aliases: [
            "comments"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-multiple-outline",
        codepoint: "F181",
        aliases: [
            "comments-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-outline",
        codepoint: "F182",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-plus",
        codepoint: "F9E4",
        aliases: [
            "comment-add"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-plus-outline",
        codepoint: "F183",
        aliases: [
            "comment-add-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-processing",
        codepoint: "F184",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-processing-outline",
        codepoint: "F185",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-question",
        codepoint: "F816",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-question-outline",
        codepoint: "F186",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-quote",
        codepoint: "F0043",
        aliases: [
            "feedback"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-quote-outline",
        codepoint: "F0044",
        aliases: [
            "feedback-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-remove",
        codepoint: "F5DE",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-remove-outline",
        codepoint: "F187",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-search",
        codepoint: "FA3B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-search-outline",
        codepoint: "FA3C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-text",
        codepoint: "F188",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-text-multiple",
        codepoint: "F85F",
        aliases: [
            "comments-text"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-text-multiple-outline",
        codepoint: "F860",
        aliases: [
            "comments-text-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "comment-text-outline",
        codepoint: "F189",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "compare",
        codepoint: "F18A",
        aliases: [
            "theme-light-dark"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "compass",
        codepoint: "F18B",
        aliases: [
            "explore"
        ],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "compass-off",
        codepoint: "FB5C",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "compass-off-outline",
        codepoint: "FB5D",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "compass-outline",
        codepoint: "F18C",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "concourse-ci",
        codepoint: "F00CB",
        aliases: [],
        tags: [
            "Developer \/ Languages",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "console",
        codepoint: "F18D",
        aliases: [
            "terminal"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "console-line",
        codepoint: "F7B6",
        aliases: [
            "terminal-line"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "console-network",
        codepoint: "F8A8",
        aliases: [
            "terminal-network"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "console-network-outline",
        codepoint: "FC3C",
        aliases: [
            "terminal-network-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "consolidate",
        codepoint: "F0103",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "contact-mail",
        codepoint: "F18E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "contact-mail-outline",
        codepoint: "FEB5",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "contact-phone",
        codepoint: "FEB6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "contact-phone-outline",
        codepoint: "FEB7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "contactless-payment",
        codepoint: "FD46",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "contacts",
        codepoint: "F6CA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "contain",
        codepoint: "FA3D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "contain-end",
        codepoint: "FA3E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "contain-start",
        codepoint: "FA3F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "content-copy",
        codepoint: "F18F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "content-cut",
        codepoint: "F190",
        aliases: [
            "scissors",
            "clip"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "content-duplicate",
        codepoint: "F191",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "content-paste",
        codepoint: "F192",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "content-save",
        codepoint: "F193",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "content-save-alert",
        codepoint: "FF5F",
        aliases: [],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "content-save-alert-outline",
        codepoint: "FF60",
        aliases: [],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "content-save-all",
        codepoint: "F194",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "content-save-all-outline",
        codepoint: "FF61",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "content-save-edit",
        codepoint: "FCD7",
        aliases: [],
        tags: [
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "content-save-edit-outline",
        codepoint: "FCD8",
        aliases: [],
        tags: [
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "content-save-move",
        codepoint: "FE79",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "content-save-move-outline",
        codepoint: "FE7A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "content-save-outline",
        codepoint: "F817",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "content-save-settings",
        codepoint: "F61B",
        aliases: [],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "content-save-settings-outline",
        codepoint: "FB13",
        aliases: [],
        tags: [
            "Settings",
            "Settings"
        ],
    },
    {
        
        name: "contrast",
        codepoint: "F195",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "contrast-box",
        codepoint: "F196",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "contrast-circle",
        codepoint: "F197",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "controller-classic",
        codepoint: "FB5E",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "controller-classic-outline",
        codepoint: "FB5F",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "cookie",
        codepoint: "F198",
        aliases: [
            "biscuit"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "coolant-temperature",
        codepoint: "F3C8",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "copyright",
        codepoint: "F5E6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cordova",
        codepoint: "F957",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "corn",
        codepoint: "F7B7",
        aliases: [],
        tags: [
            "Agriculture",
            "Food \/ Drink"
        ],
    },
    {
        
        name: "counter",
        codepoint: "F199",
        aliases: [
            "score",
            "numbers",
            "odometer"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "cow",
        codepoint: "F19A",
        aliases: [],
        tags: [
            "Animal",
            "Agriculture"
        ],
    },
    {
        
        name: "cowboy",
        codepoint: "FEB8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cpu-32-bit",
        codepoint: "FEFC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cpu-64-bit",
        codepoint: "FEFD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "crane",
        codepoint: "F861",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "creation",
        codepoint: "F1C9",
        aliases: [
            "auto-awesome"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "creative-commons",
        codepoint: "FD47",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "credit-card",
        codepoint: "F0010",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-clock",
        codepoint: "FEFE",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-clock-outline",
        codepoint: "FFBC",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-marker",
        codepoint: "F6A7",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-marker-outline",
        codepoint: "FD9A",
        aliases: [
            "cod",
            "payment-on-delivery"
        ],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-minus",
        codepoint: "FFCC",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-minus-outline",
        codepoint: "FFCD",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-multiple",
        codepoint: "F0011",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-multiple-outline",
        codepoint: "F19C",
        aliases: [
            "credit-cards"
        ],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-off",
        codepoint: "F0012",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-off-outline",
        codepoint: "F5E4",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-outline",
        codepoint: "F19B",
        aliases: [
            "payment"
        ],
        tags: [
            "Shopping",
            "Banking",
            "Currency"
        ],
    },
    {
        
        name: "credit-card-plus",
        codepoint: "F0013",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-plus-outline",
        codepoint: "F675",
        aliases: [
            "credit-card-add"
        ],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-refund",
        codepoint: "F0014",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-refund-outline",
        codepoint: "FAA7",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-remove",
        codepoint: "FFCE",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-remove-outline",
        codepoint: "FFCF",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-scan",
        codepoint: "F0015",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-scan-outline",
        codepoint: "F19D",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-settings",
        codepoint: "F0016",
        aliases: [],
        tags: [
            "Banking",
            "Settings"
        ],
    },
    {
        
        name: "credit-card-settings-outline",
        codepoint: "F8D6",
        aliases: [
            "payment-settings"
        ],
        tags: [
            "Banking",
            "Settings"
        ],
    },
    {
        
        name: "credit-card-wireless",
        codepoint: "F801",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "credit-card-wireless-outline",
        codepoint: "FD48",
        aliases: [
            "credit-card-contactless"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "cricket",
        codepoint: "FD49",
        aliases: [
            "cricket-bat"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "crop",
        codepoint: "F19E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "crop-free",
        codepoint: "F19F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "crop-landscape",
        codepoint: "F1A0",
        aliases: [
            "crop-5-4"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "crop-portrait",
        codepoint: "F1A1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "crop-rotate",
        codepoint: "F695",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "crop-square",
        codepoint: "F1A2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "crosshairs",
        codepoint: "F1A3",
        aliases: [
            "gps-not-fixed",
            "location-searching"
        ],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "crosshairs-gps",
        codepoint: "F1A4",
        aliases: [
            "gps-fixed",
            "my-location"
        ],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "crosshairs-off",
        codepoint: "FF62",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "crosshairs-question",
        codepoint: "F0161",
        aliases: [
            "crosshairs-unknown",
            "gps-unknown"
        ],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "crown",
        codepoint: "F1A5",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "crown-outline",
        codepoint: "F01FB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cryengine",
        codepoint: "F958",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "crystal-ball",
        codepoint: "FB14",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "cube",
        codepoint: "F1A6",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "cube-outline",
        codepoint: "F1A7",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "cube-scan",
        codepoint: "FB60",
        aliases: [
            "view-in-ar",
            "view-in-augmented-reality"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cube-send",
        codepoint: "F1A8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cube-unfolded",
        codepoint: "F1A9",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cup",
        codepoint: "F1AA",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "cup-off",
        codepoint: "F5E5",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "cup-water",
        codepoint: "F1AB",
        aliases: [
            "local-drink"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "cupboard",
        codepoint: "FF63",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "cupboard-outline",
        codepoint: "FF64",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "cupcake",
        codepoint: "F959",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "curling",
        codepoint: "F862",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "currency-bdt",
        codepoint: "F863",
        aliases: [
            "taka",
            "bangladeshi-taka"
        ],
        tags: [
            "Banking",
            "Currency"
        ],
    },
    {
        
        name: "currency-brl",
        codepoint: "FB61",
        aliases: [
            "brazilian-real"
        ],
        tags: [
            "Banking",
            "Currency"
        ],
    },
    {
        
        name: "currency-btc",
        codepoint: "F1AC",
        aliases: [
            "bitcoin"
        ],
        tags: [
            "Currency",
            "Brand \/ Logo",
            "Banking"
        ],
    },
    {
        
        name: "currency-cny",
        codepoint: "F7B9",
        aliases: [
            "yuan",
            "renminbi"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "currency-eth",
        codepoint: "F7BA",
        aliases: [
            "ethereum",
            "xi"
        ],
        tags: [
            "Currency",
            "Brand \/ Logo",
            "Banking"
        ],
    },
    {
        
        name: "currency-eur",
        codepoint: "F1AD",
        aliases: [
            "euro",
            "euro-symbol"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "currency-gbp",
        codepoint: "F1AE",
        aliases: [
            "pound",
            "sterling"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "currency-ils",
        codepoint: "FC3D",
        aliases: [],
        tags: [
            "Banking",
            "Currency"
        ],
    },
    {
        
        name: "currency-inr",
        codepoint: "F1AF",
        aliases: [
            "rupee"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "currency-jpy",
        codepoint: "F7BB",
        aliases: [
            "yen"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "currency-krw",
        codepoint: "F7BC",
        aliases: [
            "won"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "currency-kzt",
        codepoint: "F864",
        aliases: [
            "kazakhstani-tenge"
        ],
        tags: [
            "Banking",
            "Currency"
        ],
    },
    {
        
        name: "currency-ngn",
        codepoint: "F1B0",
        aliases: [
            "naira"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "currency-php",
        codepoint: "F9E5",
        aliases: [
            "philippine-peso"
        ],
        tags: [
            "Banking",
            "Currency"
        ],
    },
    {
        
        name: "currency-rial",
        codepoint: "FEB9",
        aliases: [
            "currency-riyal",
            "currency-irr",
            "currency-omr",
            "currency-yer",
            "currency-sar"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "currency-rub",
        codepoint: "F1B1",
        aliases: [
            "ruble"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "currency-sign",
        codepoint: "F7BD",
        aliases: [
            "currency-scarab"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "currency-try",
        codepoint: "F1B2",
        aliases: [
            "lira"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "currency-twd",
        codepoint: "F7BE",
        aliases: [
            "new-taiwan-dollar"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "currency-usd",
        codepoint: "F1B3",
        aliases: [
            "attach-money",
            "dollar"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "currency-usd-off",
        codepoint: "F679",
        aliases: [
            "money-off",
            "dollar-off"
        ],
        tags: [
            "Currency",
            "Banking"
        ],
    },
    {
        
        name: "current-ac",
        codepoint: "F95A",
        aliases: [
            "alternating-current",
            "sine-wave",
            "wave",
            "analog"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "current-dc",
        codepoint: "F95B",
        aliases: [
            "direct-current"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cursor-default",
        codepoint: "F1B4",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cursor-default-click",
        codepoint: "FCD9",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cursor-default-click-outline",
        codepoint: "FCDA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cursor-default-gesture",
        codepoint: "F0152",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cursor-default-gesture-outline",
        codepoint: "F0153",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cursor-default-outline",
        codepoint: "F1B5",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cursor-move",
        codepoint: "F1B6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cursor-pointer",
        codepoint: "F1B7",
        aliases: [
            "cursor-hand"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "cursor-text",
        codepoint: "F5E7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "database",
        codepoint: "F1B8",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "database-check",
        codepoint: "FAA8",
        aliases: [
            "database-tick"
        ],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "database-edit",
        codepoint: "FB62",
        aliases: [],
        tags: [
            "Edit \/ Modify",
            "Geographic Information System"
        ],
    },
    {
        
        name: "database-export",
        codepoint: "F95D",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "database-import",
        codepoint: "F95C",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "database-lock",
        codepoint: "FAA9",
        aliases: [],
        tags: [
            "Lock",
            "Geographic Information System"
        ],
    },
    {
        
        name: "database-minus",
        codepoint: "F1B9",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "database-plus",
        codepoint: "F1BA",
        aliases: [
            "database-add"
        ],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "database-refresh",
        codepoint: "FCDB",
        aliases: [
            "database-sync"
        ],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "database-remove",
        codepoint: "FCDC",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "database-search",
        codepoint: "F865",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "database-settings",
        codepoint: "FCDD",
        aliases: [],
        tags: [
            "Settings",
            "Geographic Information System"
        ],
    },
    {
        
        name: "death-star",
        codepoint: "F8D7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "death-star-variant",
        codepoint: "F8D8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "deathly-hallows",
        codepoint: "FB63",
        aliases: [
            "harry-potter"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "debian",
        codepoint: "F8D9",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "debug-step-into",
        codepoint: "F1BB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "debug-step-out",
        codepoint: "F1BC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "debug-step-over",
        codepoint: "F1BD",
        aliases: [
            "skip",
            "jump"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "decagram",
        codepoint: "F76B",
        aliases: [
            "starburst"
        ],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "decagram-outline",
        codepoint: "F76C",
        aliases: [
            "starburst-outline"
        ],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "decimal",
        codepoint: "F00CC",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "decimal-comma",
        codepoint: "F00CD",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "decimal-comma-decrease",
        codepoint: "F00CE",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "decimal-comma-increase",
        codepoint: "F00CF",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "decimal-decrease",
        codepoint: "F1BE",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "decimal-increase",
        codepoint: "F1BF",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "delete",
        codepoint: "F1C0",
        aliases: [
            "trash",
            "bin",
            "rubbish",
            "garbage",
            "rubbish-bin",
            "trash-can",
            "garbage-can"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "delete-alert",
        codepoint: "F00D0",
        aliases: [],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "delete-alert-outline",
        codepoint: "F00D1",
        aliases: [],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "delete-circle",
        codepoint: "F682",
        aliases: [
            "trash-circle",
            "bin-circle",
            "garbage-can-circle",
            "garbage-circle",
            "rubbish-bin-circle",
            "rubbish-circle",
            "trash-can-circle"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "delete-circle-outline",
        codepoint: "FB64",
        aliases: [
            "bin-circle-outline",
            "garbage-can-circle-outline",
            "garbage-circle-outline",
            "rubbish-bin-circle-outline",
            "rubbish-circle-outline",
            "trash-can-circle-outline",
            "trash-circle-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "delete-empty",
        codepoint: "F6CB",
        aliases: [
            "trash-empty",
            "bin-empty",
            "rubbish-empty",
            "rubbish-bin-empty",
            "trash-can-empty",
            "garbage-empty",
            "garbage-can-empty"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "delete-empty-outline",
        codepoint: "FEBA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "delete-forever",
        codepoint: "F5E8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "delete-forever-outline",
        codepoint: "FB65",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "delete-off",
        codepoint: "F00D2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "delete-off-outline",
        codepoint: "F00D3",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "delete-outline",
        codepoint: "F9E6",
        aliases: [
            "garbage-outline",
            "bin-outline",
            "rubbish-outline",
            "garbage-can-outline",
            "rubbish-bin-outline",
            "trash-outline",
            "trash-can-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "delete-restore",
        codepoint: "F818",
        aliases: [
            "trash-restore",
            "bin-restore",
            "restore-from-trash"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "delete-sweep",
        codepoint: "F5E9",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "delete-sweep-outline",
        codepoint: "FC3E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "delete-variant",
        codepoint: "F1C1",
        aliases: [
            "trash-variant",
            "bin-variant"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "delta",
        codepoint: "F1C2",
        aliases: [
            "change-history"
        ],
        tags: [
            "Math",
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "desk",
        codepoint: "F0264",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "desk-lamp",
        codepoint: "F95E",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "deskphone",
        codepoint: "F1C3",
        aliases: [],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "desktop-classic",
        codepoint: "F7BF",
        aliases: [
            "computer-classic"
        ],
        tags: [
            "Device \/ Tech",
            "Home Automation"
        ],
    },
    {
        
        name: "desktop-mac",
        codepoint: "F1C4",
        aliases: [],
        tags: [
            "Device \/ Tech",
            "Home Automation"
        ],
    },
    {
        
        name: "desktop-mac-dashboard",
        codepoint: "F9E7",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "desktop-tower",
        codepoint: "F1C5",
        aliases: [],
        tags: [
            "Device \/ Tech",
            "Home Automation"
        ],
    },
    {
        
        name: "desktop-tower-monitor",
        codepoint: "FAAA",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "details",
        codepoint: "F1C6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "dev-to",
        codepoint: "FD4A",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "developer-board",
        codepoint: "F696",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "deviantart",
        codepoint: "F1C7",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "devices",
        codepoint: "FFD0",
        aliases: [
            "monitor",
            "watch",
            "smartwatch",
            "smartphone",
            "cellphone",
            "television"
        ],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "diabetes",
        codepoint: "F0151",
        aliases: [
            "hand-blood"
        ],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "dialpad",
        codepoint: "F61C",
        aliases: [
            "keypad"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "diameter",
        codepoint: "FC3F",
        aliases: [
            "circle-diameter",
            "sphere-diameter"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "diameter-outline",
        codepoint: "FC40",
        aliases: [
            "circle-diameter-outline",
            "sphere-diameter-outline"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "diameter-variant",
        codepoint: "FC41",
        aliases: [
            "circle-diameter-variant",
            "sphere-diameter-variant"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "diamond",
        codepoint: "FB66",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "diamond-outline",
        codepoint: "FB67",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "diamond-stone",
        codepoint: "F1C8",
        aliases: [
            "jewel"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "dice-1",
        codepoint: "F1CA",
        aliases: [
            "die-1",
            "dice-one"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-1-outline",
        codepoint: "F0175",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-2",
        codepoint: "F1CB",
        aliases: [
            "die-2",
            "dice-two"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-2-outline",
        codepoint: "F0176",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-3",
        codepoint: "F1CC",
        aliases: [
            "die-3",
            "dice-three"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-3-outline",
        codepoint: "F0177",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-4",
        codepoint: "F1CD",
        aliases: [
            "die-4",
            "dice-four"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-4-outline",
        codepoint: "F0178",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-5",
        codepoint: "F1CE",
        aliases: [
            "die-5",
            "dice-five"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-5-outline",
        codepoint: "F0179",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-6",
        codepoint: "F1CF",
        aliases: [
            "die-6",
            "dice-six"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-6-outline",
        codepoint: "F017A",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-d10",
        codepoint: "F017E",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-d10-outline",
        codepoint: "F76E",
        aliases: [
            "die-d10"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-d12",
        codepoint: "F017F",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-d12-outline",
        codepoint: "F866",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-d20",
        codepoint: "F0180",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-d20-outline",
        codepoint: "F5EA",
        aliases: [
            "die-d20"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-d4",
        codepoint: "F017B",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-d4-outline",
        codepoint: "F5EB",
        aliases: [
            "die-d4"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-d6",
        codepoint: "F017C",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-d6-outline",
        codepoint: "F5EC",
        aliases: [
            "die-d6"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-d8",
        codepoint: "F017D",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-d8-outline",
        codepoint: "F5ED",
        aliases: [
            "die-d8"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-multiple",
        codepoint: "F76D",
        aliases: [
            "die-multiple"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dice-multiple-outline",
        codepoint: "F0181",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dictionary",
        codepoint: "F61D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "digital-ocean",
        codepoint: "F0262",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "dip-switch",
        codepoint: "F7C0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "directions",
        codepoint: "F1D0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "directions-fork",
        codepoint: "F641",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "disc",
        codepoint: "F5EE",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "disc-alert",
        codepoint: "F1D1",
        aliases: [
            "disc-full",
            "disc-warning"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "disc-player",
        codepoint: "F95F",
        aliases: [],
        tags: [
            "Home Automation",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "discord",
        codepoint: "F66F",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "dishwasher",
        codepoint: "FAAB",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "dishwasher-alert",
        codepoint: "F01E3",
        aliases: [],
        tags: [
            "Home Automation",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "dishwasher-off",
        codepoint: "F01E4",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "disqus",
        codepoint: "F1D2",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "disqus-outline",
        codepoint: "F1D3",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "distribute-horizontal-center",
        codepoint: "F01F4",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "distribute-horizontal-left",
        codepoint: "F01F3",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "distribute-horizontal-right",
        codepoint: "F01F5",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "distribute-vertical-bottom",
        codepoint: "F01F6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "distribute-vertical-center",
        codepoint: "F01F7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "distribute-vertical-top",
        codepoint: "F01F8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "diving-flippers",
        codepoint: "FD9B",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "diving-helmet",
        codepoint: "FD9C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "diving-scuba",
        codepoint: "FD9D",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "diving-scuba-flag",
        codepoint: "FD9E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "diving-scuba-tank",
        codepoint: "FD9F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "diving-scuba-tank-multiple",
        codepoint: "FDA0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "diving-snorkel",
        codepoint: "FDA1",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "division",
        codepoint: "F1D4",
        aliases: [
            "obelus"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "division-box",
        codepoint: "F1D5",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "dlna",
        codepoint: "FA40",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "dna",
        codepoint: "F683",
        aliases: [
            "helix"
        ],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "dns",
        codepoint: "F1D6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "dns-outline",
        codepoint: "FB68",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "do-not-disturb",
        codepoint: "F697",
        aliases: [
            "no-entry"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "do-not-disturb-off",
        codepoint: "F698",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "dock-bottom",
        codepoint: "F00D4",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "dock-left",
        codepoint: "F00D5",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "dock-right",
        codepoint: "F00D6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "dock-window",
        codepoint: "F00D7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "docker",
        codepoint: "F867",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "doctor",
        codepoint: "FA41",
        aliases: [],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "dog",
        codepoint: "FA42",
        aliases: [],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "dog-service",
        codepoint: "FAAC",
        aliases: [
            "guide-dog"
        ],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "dog-side",
        codepoint: "FA43",
        aliases: [],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "dolby",
        codepoint: "F6B2",
        aliases: [],
        tags: [
            "Audio",
            "Brand \/ Logo",
            "Home Automation"
        ],
    },
    {
        
        name: "dolly",
        codepoint: "FEBB",
        aliases: [
            "hand-truck",
            "trolley"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "domain",
        codepoint: "F1D7",
        aliases: [
            "building",
            "company",
            "business"
        ],
        tags: [
            "Places"
        ],
    },
    {
        
        name: "domain-off",
        codepoint: "FD4B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "domain-plus",
        codepoint: "F00D8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "domain-remove",
        codepoint: "F00D9",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "domino-mask",
        codepoint: "F0045",
        aliases: [
            "robber-mask"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "donkey",
        codepoint: "F7C1",
        aliases: [],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "door",
        codepoint: "F819",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "door-closed",
        codepoint: "F81A",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "door-closed-lock",
        codepoint: "F00DA",
        aliases: [],
        tags: [
            "Home Automation",
            "Lock"
        ],
    },
    {
        
        name: "door-open",
        codepoint: "F81B",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "doorbell-video",
        codepoint: "F868",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "dot-net",
        codepoint: "FAAD",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "dots-horizontal",
        codepoint: "F1D8",
        aliases: [
            "more",
            "ellipsis-horizontal",
            "more-horiz",
            "menu"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "dots-horizontal-circle",
        codepoint: "F7C2",
        aliases: [
            "ellipsis-horizontal-circle",
            "more-circle",
            "menu"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "dots-horizontal-circle-outline",
        codepoint: "FB69",
        aliases: [
            "ellipsis-horizontal-circle-outline",
            "more-circle-outline",
            "menu"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "dots-vertical",
        codepoint: "F1D9",
        aliases: [
            "ellipsis-vertical",
            "more-vert",
            "menu"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "dots-vertical-circle",
        codepoint: "F7C3",
        aliases: [
            "ellipsis-vertical-circle",
            "menu"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "dots-vertical-circle-outline",
        codepoint: "FB6A",
        aliases: [
            "ellipsis-vertical-circle-outline",
            "menu"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "douban",
        codepoint: "F699",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "download",
        codepoint: "F1DA",
        aliases: [
            "file-download",
            "get-app"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "download-multiple",
        codepoint: "F9E8",
        aliases: [
            "downloads"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "download-network",
        codepoint: "F6F3",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "download-network-outline",
        codepoint: "FC42",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "download-off",
        codepoint: "F00DB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "download-off-outline",
        codepoint: "F00DC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "download-outline",
        codepoint: "FB6B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "drag",
        codepoint: "F1DB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "drag-horizontal",
        codepoint: "F1DC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "drag-variant",
        codepoint: "FB6C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "drag-vertical",
        codepoint: "F1DD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "drama-masks",
        codepoint: "FCDE",
        aliases: [
            "comedy",
            "tragedy",
            "theatre"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "draw",
        codepoint: "FF66",
        aliases: [
            "sign",
            "signature"
        ],
        tags: [
            "Drawing \/ Art",
            "Form"
        ],
    },
    {
        
        name: "drawing",
        codepoint: "F1DE",
        aliases: [],
        tags: [
            "Drawing \/ Art",
            "Shape"
        ],
    },
    {
        
        name: "drawing-box",
        codepoint: "F1DF",
        aliases: [],
        tags: [
            "Drawing \/ Art",
            "Shape"
        ],
    },
    {
        
        name: "dresser",
        codepoint: "FF67",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "dresser-outline",
        codepoint: "FF68",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "dribbble",
        codepoint: "F1E0",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "dribbble-box",
        codepoint: "F1E1",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "drone",
        codepoint: "F1E2",
        aliases: [],
        tags: [
            "Transportation + Flying"
        ],
    },
    {
        
        name: "dropbox",
        codepoint: "F1E3",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "drupal",
        codepoint: "F1E4",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "duck",
        codepoint: "F1E5",
        aliases: [],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "dumbbell",
        codepoint: "F1E6",
        aliases: [
            "weights",
            "fitness-center"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "dump-truck",
        codepoint: "FC43",
        aliases: [
            "tipper-lorry"
        ],
        tags: [
            "Transportation + Road",
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "ear-hearing",
        codepoint: "F7C4",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "ear-hearing-off",
        codepoint: "FA44",
        aliases: [
            "hearing-impaired"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "earth",
        codepoint: "F1E7",
        aliases: [
            "globe",
            "public",
            "planet"
        ],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "earth-box",
        codepoint: "F6CC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "earth-box-off",
        codepoint: "F6CD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "earth-off",
        codepoint: "F1E8",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "edge",
        codepoint: "F1E9",
        aliases: [
            "microsoft-edge"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "edge-legacy",
        codepoint: "F027B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "egg",
        codepoint: "FAAE",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "egg-easter",
        codepoint: "FAAF",
        aliases: [],
        tags: [
            "Holiday"
        ],
    },
    {
        
        name: "eight-track",
        codepoint: "F9E9",
        aliases: [
            "8-track"
        ],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "eject",
        codepoint: "F1EA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "eject-outline",
        codepoint: "FB6D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "electric-switch",
        codepoint: "FEBC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "electric-switch-closed",
        codepoint: "F0104",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "electron-framework",
        codepoint: "F0046",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "elephant",
        codepoint: "F7C5",
        aliases: [],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "elevation-decline",
        codepoint: "F1EB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "elevation-rise",
        codepoint: "F1EC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "elevator",
        codepoint: "F1ED",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "ellipse",
        codepoint: "FEBD",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "ellipse-outline",
        codepoint: "FEBE",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "email",
        codepoint: "F1EE",
        aliases: [
            "local-post-office",
            "mail",
            "markunread",
            "envelope"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-alert",
        codepoint: "F6CE",
        aliases: [
            "email-warning",
            "envelope-alert",
            "envelope-warning"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "email-box",
        codepoint: "FCDF",
        aliases: [
            "envelope-box"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-check",
        codepoint: "FAB0",
        aliases: [
            "email-tick"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-check-outline",
        codepoint: "FAB1",
        aliases: [
            "email-tick-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-edit",
        codepoint: "FF00",
        aliases: [],
        tags: [
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "email-edit-outline",
        codepoint: "FF01",
        aliases: [],
        tags: [
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "email-lock",
        codepoint: "F1F1",
        aliases: [
            "envelope-secure",
            "email-secure",
            "envelope-lock"
        ],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "email-mark-as-unread",
        codepoint: "FB6E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-minus",
        codepoint: "FF02",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-minus-outline",
        codepoint: "FF03",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-multiple",
        codepoint: "FF04",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-multiple-outline",
        codepoint: "FF05",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-newsletter",
        codepoint: "FFD1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-open",
        codepoint: "F1EF",
        aliases: [
            "drafts",
            "envelope-open"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-open-multiple",
        codepoint: "FF06",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-open-multiple-outline",
        codepoint: "FF07",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-open-outline",
        codepoint: "F5EF",
        aliases: [
            "envelope-open-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-outline",
        codepoint: "F1F0",
        aliases: [
            "mail-outline",
            "envelope-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-plus",
        codepoint: "F9EA",
        aliases: [
            "email-add",
            "envelope-add",
            "envelope-plus"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-plus-outline",
        codepoint: "F9EB",
        aliases: [
            "email-add-outline",
            "envelope-add-outline",
            "envelope-plus-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-receive",
        codepoint: "F0105",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-receive-outline",
        codepoint: "F0106",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-search",
        codepoint: "F960",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-search-outline",
        codepoint: "F961",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-send",
        codepoint: "F0107",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-send-outline",
        codepoint: "F0108",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "email-variant",
        codepoint: "F5F0",
        aliases: [
            "envelope-variant"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "ember",
        codepoint: "FB15",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "emby",
        codepoint: "F6B3",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "emoticon",
        codepoint: "FC44",
        aliases: [
            "smiley"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-angry",
        codepoint: "FC45",
        aliases: [
            "smiley-angry"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-angry-outline",
        codepoint: "FC46",
        aliases: [
            "smiley-angry-outline"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-confused",
        codepoint: "F0109",
        aliases: [],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-confused-outline",
        codepoint: "F010A",
        aliases: [],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-cool",
        codepoint: "FC47",
        aliases: [
            "smiley-cool"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-cool-outline",
        codepoint: "F1F3",
        aliases: [
            "smiley-cool-outline"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-cry",
        codepoint: "FC48",
        aliases: [
            "smiley-cry"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-cry-outline",
        codepoint: "FC49",
        aliases: [
            "smiley-cry-outline"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-dead",
        codepoint: "FC4A",
        aliases: [
            "smiley-dead"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-dead-outline",
        codepoint: "F69A",
        aliases: [
            "smiley-dead-outline"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-devil",
        codepoint: "FC4B",
        aliases: [
            "smiley-devil"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-devil-outline",
        codepoint: "F1F4",
        aliases: [
            "smiley-devil-outline"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-excited",
        codepoint: "FC4C",
        aliases: [
            "smiley-excited"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-excited-outline",
        codepoint: "F69B",
        aliases: [
            "smiley-excited-outline"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-frown",
        codepoint: "FF69",
        aliases: [],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-frown-outline",
        codepoint: "FF6A",
        aliases: [],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-happy",
        codepoint: "FC4D",
        aliases: [
            "smiley-happy"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-happy-outline",
        codepoint: "F1F5",
        aliases: [
            "smiley-happy-outline"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-kiss",
        codepoint: "FC4E",
        aliases: [
            "smiley-kiss"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-kiss-outline",
        codepoint: "FC4F",
        aliases: [
            "smiley-kiss-outline"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-lol",
        codepoint: "F023F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "emoticon-lol-outline",
        codepoint: "F0240",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "emoticon-neutral",
        codepoint: "FC50",
        aliases: [
            "smiley-neutral"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-neutral-outline",
        codepoint: "F1F6",
        aliases: [
            "smiley-neutral-outline"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-outline",
        codepoint: "F1F2",
        aliases: [
            "insert-emoticon",
            "mood",
            "sentiment-very-satisfied",
            "tag-faces",
            "smiley-outline"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-poop",
        codepoint: "F1F7",
        aliases: [
            "smiley-poop"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-poop-outline",
        codepoint: "FC51",
        aliases: [],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-sad",
        codepoint: "FC52",
        aliases: [
            "smiley-sad"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-sad-outline",
        codepoint: "F1F8",
        aliases: [
            "smiley-sad-outline"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-tongue",
        codepoint: "F1F9",
        aliases: [
            "smiley-tongue"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-tongue-outline",
        codepoint: "FC53",
        aliases: [
            "smiley-tongue-outline"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-wink",
        codepoint: "FC54",
        aliases: [
            "smiley-wink"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "emoticon-wink-outline",
        codepoint: "FC55",
        aliases: [
            "smiley-wink-outline"
        ],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "engine",
        codepoint: "F1FA",
        aliases: [
            "motor"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "engine-off",
        codepoint: "FA45",
        aliases: [
            "motor-off"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "engine-off-outline",
        codepoint: "FA46",
        aliases: [
            "motor-off-outline"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "engine-outline",
        codepoint: "F1FB",
        aliases: [
            "motor-outline"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "epsilon",
        codepoint: "F010B",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "equal",
        codepoint: "F1FC",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "equal-box",
        codepoint: "F1FD",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "equalizer",
        codepoint: "FEBF",
        aliases: [],
        tags: [
            "Audio"
        ],
    },
    {
        
        name: "equalizer-outline",
        codepoint: "FEC0",
        aliases: [],
        tags: [
            "Audio"
        ],
    },
    {
        
        name: "eraser",
        codepoint: "F1FE",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "eraser-variant",
        codepoint: "F642",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "escalator",
        codepoint: "F1FF",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "eslint",
        codepoint: "FC56",
        aliases: [],
        tags: [
            "Developer \/ Languages",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "et",
        codepoint: "FAB2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "ethereum",
        codepoint: "F869",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "ethernet",
        codepoint: "F200",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "ethernet-cable",
        codepoint: "F201",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "ethernet-cable-off",
        codepoint: "F202",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "etsy",
        codepoint: "F203",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "ev-station",
        codepoint: "F5F1",
        aliases: [
            "charging-station"
        ],
        tags: [
            "Places",
            "Automotive"
        ],
    },
    {
        
        name: "eventbrite",
        codepoint: "F7C6",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "evernote",
        codepoint: "F204",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "excavator",
        codepoint: "F0047",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "exclamation",
        codepoint: "F205",
        aliases: [
            "factorial"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "exclamation-thick",
        codepoint: "F0263",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "exit-run",
        codepoint: "FA47",
        aliases: [
            "emergency-exit"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "exit-to-app",
        codepoint: "F206",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "expand-all",
        codepoint: "FAB3",
        aliases: [
            "animation-plus"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "expand-all-outline",
        codepoint: "FAB4",
        aliases: [
            "animation-plus-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "expansion-card",
        codepoint: "F8AD",
        aliases: [
            "gpu",
            "graphics-processing-unit",
            "nic",
            "network-interface-card"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "expansion-card-variant",
        codepoint: "FFD2",
        aliases: [
            "graphics-processing-unit",
            "gpu",
            "network-interface-card",
            "nice"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "exponent",
        codepoint: "F962",
        aliases: [
            "power"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "exponent-box",
        codepoint: "F963",
        aliases: [
            "power-box"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "export",
        codepoint: "F207",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "export-variant",
        codepoint: "FB6F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "eye",
        codepoint: "F208",
        aliases: [
            "show",
            "visibility",
            "remove-red-eye"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "eye-check",
        codepoint: "FCE0",
        aliases: [
            "eye-tick"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "eye-check-outline",
        codepoint: "FCE1",
        aliases: [
            "eye-tick-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "eye-circle",
        codepoint: "FB70",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "eye-circle-outline",
        codepoint: "FB71",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "eye-minus",
        codepoint: "F0048",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "eye-minus-outline",
        codepoint: "F0049",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "eye-off",
        codepoint: "F209",
        aliases: [
            "hide",
            "visibility-off"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "eye-off-outline",
        codepoint: "F6D0",
        aliases: [
            "hide-outline",
            "visibility-off-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "eye-outline",
        codepoint: "F6CF",
        aliases: [
            "show-outline",
            "visibility-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "eye-plus",
        codepoint: "F86A",
        aliases: [
            "eye-add"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "eye-plus-outline",
        codepoint: "F86B",
        aliases: [
            "eye-add-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "eye-settings",
        codepoint: "F86C",
        aliases: [],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "eye-settings-outline",
        codepoint: "F86D",
        aliases: [],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "eyedropper",
        codepoint: "F20A",
        aliases: [
            "pipette"
        ],
        tags: [
            "Color"
        ],
    },
    {
        
        name: "eyedropper-variant",
        codepoint: "F20B",
        aliases: [
            "colorize",
            "colourise",
            "pipette-variant"
        ],
        tags: [
            "Color"
        ],
    },
    {
        
        name: "face",
        codepoint: "F643",
        aliases: [],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "face-agent",
        codepoint: "FD4C",
        aliases: [
            "customer-service",
            "support"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "face-outline",
        codepoint: "FB72",
        aliases: [],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "face-profile",
        codepoint: "F644",
        aliases: [],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "face-profile-woman",
        codepoint: "F00A1",
        aliases: [],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "face-recognition",
        codepoint: "FC57",
        aliases: [
            "facial-recognition",
            "scan"
        ],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "face-woman",
        codepoint: "F00A2",
        aliases: [],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "face-woman-outline",
        codepoint: "F00A3",
        aliases: [],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "facebook",
        codepoint: "F20C",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Social Media"
        ],
    },
    {
        
        name: "facebook-box",
        codepoint: "F20D",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Social Media"
        ],
    },
    {
        
        name: "facebook-messenger",
        codepoint: "F20E",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Social Media"
        ],
    },
    {
        
        name: "facebook-workplace",
        codepoint: "FB16",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Social Media"
        ],
    },
    {
        
        name: "factory",
        codepoint: "F20F",
        aliases: [
            "industrial"
        ],
        tags: [
            "Places"
        ],
    },
    {
        
        name: "fan",
        codepoint: "F210",
        aliases: [],
        tags: [
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "fan-off",
        codepoint: "F81C",
        aliases: [],
        tags: [
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "fast-forward",
        codepoint: "F211",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "fast-forward-10",
        codepoint: "FD4D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "fast-forward-30",
        codepoint: "FCE2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "fast-forward-5",
        codepoint: "F0223",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "fast-forward-outline",
        codepoint: "F6D1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "fax",
        codepoint: "F212",
        aliases: [],
        tags: [
            "Printer",
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "feather",
        codepoint: "F6D2",
        aliases: [
            "quill"
        ],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "feature-search",
        codepoint: "FA48",
        aliases: [
            "box",
            "box-search"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "feature-search-outline",
        codepoint: "FA49",
        aliases: [
            "box",
            "box-outline",
            "box-search-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "fedora",
        codepoint: "F8DA",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "ferris-wheel",
        codepoint: "FEC1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "ferry",
        codepoint: "F213",
        aliases: [
            "cargo-ship",
            "boat",
            "ship",
            "directions-boat",
            "directions-ferry"
        ],
        tags: [
            "Transportation + Water",
            "Navigation"
        ],
    },
    {
        
        name: "file",
        codepoint: "F214",
        aliases: [
            "insert-drive-file",
            "draft",
            "paper"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-account",
        codepoint: "F73A",
        aliases: [
            "file-user",
            "resume"
        ],
        tags: [
            "Account \/ User",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-account-outline",
        codepoint: "F004A",
        aliases: [],
        tags: [
            "Files \/ Folders",
            "Account \/ User"
        ],
    },
    {
        
        name: "file-alert",
        codepoint: "FA4A",
        aliases: [
            "file-warning"
        ],
        tags: [
            "Files \/ Folders",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "file-alert-outline",
        codepoint: "FA4B",
        aliases: [
            "file-warning-outline"
        ],
        tags: [
            "Files \/ Folders",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "file-cabinet",
        codepoint: "FAB5",
        aliases: [
            "filing-cabinet"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-cad",
        codepoint: "FF08",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-cad-box",
        codepoint: "FF09",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-cancel",
        codepoint: "FDA2",
        aliases: [
            "ban",
            "forbid"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-cancel-outline",
        codepoint: "FDA3",
        aliases: [
            "ban",
            "forbid"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-certificate",
        codepoint: "F01B1",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-certificate-outline",
        codepoint: "F01B2",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-chart",
        codepoint: "F215",
        aliases: [
            "file-report"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-chart-outline",
        codepoint: "F004B",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-check",
        codepoint: "F216",
        aliases: [
            "file-tick"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-check-outline",
        codepoint: "FE7B",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-cloud",
        codepoint: "F217",
        aliases: [],
        tags: [
            "Cloud",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-cloud-outline",
        codepoint: "F004C",
        aliases: [],
        tags: [
            "Files \/ Folders",
            "Cloud"
        ],
    },
    {
        
        name: "file-code",
        codepoint: "F22E",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-code-outline",
        codepoint: "F004D",
        aliases: [],
        tags: [
            "Files \/ Folders",
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "file-compare",
        codepoint: "F8A9",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-delimited",
        codepoint: "F218",
        aliases: [
            "file-csv"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-delimited-outline",
        codepoint: "FEC2",
        aliases: [
            "file-csv-outline"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-document",
        codepoint: "F219",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-document-box",
        codepoint: "F21A",
        aliases: [
            "drive-document"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-document-box-check",
        codepoint: "FEC3",
        aliases: [
            "file-document-box-tick"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-document-box-check-outline",
        codepoint: "FEC4",
        aliases: [
            "file-document-box-tick-outline"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-document-box-minus",
        codepoint: "FEC5",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-document-box-minus-outline",
        codepoint: "FEC6",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-document-box-multiple",
        codepoint: "FAB6",
        aliases: [
            "file-document-boxes"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-document-box-multiple-outline",
        codepoint: "FAB7",
        aliases: [
            "file-document-boxes-outline"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-document-box-outline",
        codepoint: "F9EC",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-document-box-plus",
        codepoint: "FEC7",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-document-box-plus-outline",
        codepoint: "FEC8",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-document-box-remove",
        codepoint: "FEC9",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-document-box-remove-outline",
        codepoint: "FECA",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-document-box-search",
        codepoint: "FECB",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-document-box-search-outline",
        codepoint: "FECC",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-document-edit",
        codepoint: "FDA4",
        aliases: [
            "contract"
        ],
        tags: [
            "Edit \/ Modify",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-document-edit-outline",
        codepoint: "FDA5",
        aliases: [
            "contract-outline"
        ],
        tags: [
            "Edit \/ Modify",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-document-outline",
        codepoint: "F9ED",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-download",
        codepoint: "F964",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-download-outline",
        codepoint: "F965",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-edit",
        codepoint: "F0212",
        aliases: [],
        tags: [
            "Edit \/ Modify",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-edit-outline",
        codepoint: "F0213",
        aliases: [],
        tags: [
            "Edit \/ Modify",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-excel",
        codepoint: "F21B",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-excel-box",
        codepoint: "F21C",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-excel-box-outline",
        codepoint: "F004E",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-excel-outline",
        codepoint: "F004F",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-export",
        codepoint: "F21D",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-export-outline",
        codepoint: "F0050",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-eye",
        codepoint: "FDA6",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-eye-outline",
        codepoint: "FDA7",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-find",
        codepoint: "F21E",
        aliases: [
            "print-preview",
            "find-in-page"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-find-outline",
        codepoint: "FB73",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-hidden",
        codepoint: "F613",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-image",
        codepoint: "F21F",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-image-outline",
        codepoint: "FECD",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-import",
        codepoint: "F220",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-import-outline",
        codepoint: "F0051",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-key",
        codepoint: "F01AF",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-key-outline",
        codepoint: "F01B0",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-link",
        codepoint: "F01A2",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-link-outline",
        codepoint: "F01A3",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-lock",
        codepoint: "F221",
        aliases: [],
        tags: [
            "Lock",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-lock-outline",
        codepoint: "F0052",
        aliases: [],
        tags: [
            "Files \/ Folders",
            "Lock"
        ],
    },
    {
        
        name: "file-move",
        codepoint: "FAB8",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-move-outline",
        codepoint: "F0053",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-multiple",
        codepoint: "F222",
        aliases: [
            "files"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-multiple-outline",
        codepoint: "F0054",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-music",
        codepoint: "F223",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-music-outline",
        codepoint: "FE7C",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-outline",
        codepoint: "F224",
        aliases: [
            "paper-outline"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-pdf",
        codepoint: "F225",
        aliases: [
            "file-acrobat"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-pdf-box",
        codepoint: "F226",
        aliases: [
            "file-acrobat-box"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-pdf-box-outline",
        codepoint: "FFD3",
        aliases: [
            "file-acrobat-box-outline"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-pdf-outline",
        codepoint: "FE7D",
        aliases: [
            "file-acrobat-outline"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-percent",
        codepoint: "F81D",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-percent-outline",
        codepoint: "F0055",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-phone",
        codepoint: "F01A4",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-phone-outline",
        codepoint: "F01A5",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-plus",
        codepoint: "F751",
        aliases: [
            "note-add"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-plus-outline",
        codepoint: "FF0A",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-powerpoint",
        codepoint: "F227",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-powerpoint-box",
        codepoint: "F228",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-powerpoint-box-outline",
        codepoint: "F0056",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-powerpoint-outline",
        codepoint: "F0057",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-presentation-box",
        codepoint: "F229",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-question",
        codepoint: "F86E",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-question-outline",
        codepoint: "F0058",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-remove",
        codepoint: "FB74",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-remove-outline",
        codepoint: "F0059",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-replace",
        codepoint: "FB17",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-replace-outline",
        codepoint: "FB18",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-restore",
        codepoint: "F670",
        aliases: [
            "restore-page"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-restore-outline",
        codepoint: "F005A",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-search",
        codepoint: "FC58",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-search-outline",
        codepoint: "FC59",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-send",
        codepoint: "F22A",
        aliases: [
            "file-move"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-send-outline",
        codepoint: "F005B",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-settings",
        codepoint: "F00A4",
        aliases: [],
        tags: [
            "Settings",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-settings-outline",
        codepoint: "F00A5",
        aliases: [],
        tags: [
            "Settings",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-settings-variant",
        codepoint: "F00A6",
        aliases: [
            "file-settings-cog"
        ],
        tags: [
            "Settings",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-settings-variant-outline",
        codepoint: "F00A7",
        aliases: [
            "file-settings-cog-outline"
        ],
        tags: [
            "Settings",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-star",
        codepoint: "F005C",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-star-outline",
        codepoint: "F005D",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-swap",
        codepoint: "FFD4",
        aliases: [
            "file-transfer"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-swap-outline",
        codepoint: "FFD5",
        aliases: [
            "file-transfer-outline"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-sync",
        codepoint: "F0241",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "file-sync-outline",
        codepoint: "F0242",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "file-table",
        codepoint: "FC5A",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-table-box",
        codepoint: "F010C",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-table-box-multiple",
        codepoint: "F010D",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-table-box-multiple-outline",
        codepoint: "F010E",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-table-box-outline",
        codepoint: "F010F",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-table-outline",
        codepoint: "FC5B",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-tree",
        codepoint: "F645",
        aliases: [
            "subtasks"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-undo",
        codepoint: "F8DB",
        aliases: [
            "file-revert",
            "file-discard"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-undo-outline",
        codepoint: "F005E",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-upload",
        codepoint: "FA4C",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-upload-outline",
        codepoint: "FA4D",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-video",
        codepoint: "F22B",
        aliases: [],
        tags: [
            "Video \/ Movie",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-video-outline",
        codepoint: "FE10",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-word",
        codepoint: "F22C",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-word-box",
        codepoint: "F22D",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-word-box-outline",
        codepoint: "F005F",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "file-word-outline",
        codepoint: "F0060",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "film",
        codepoint: "F22F",
        aliases: [
            "camera-roll"
        ],
        tags: [
            "Photography",
            "Video \/ Movie"
        ],
    },
    {
        
        name: "filmstrip",
        codepoint: "F230",
        aliases: [
            "local-movies",
            "theaters"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "filmstrip-off",
        codepoint: "F231",
        aliases: [],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "filter",
        codepoint: "F232",
        aliases: [
            "funnel"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "filter-menu",
        codepoint: "F0110",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "filter-menu-outline",
        codepoint: "F0111",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "filter-minus",
        codepoint: "FF0B",
        aliases: [
            "funnel-minus"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "filter-minus-outline",
        codepoint: "FF0C",
        aliases: [
            "funnel-minus-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "filter-outline",
        codepoint: "F233",
        aliases: [
            "funnel-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "filter-plus",
        codepoint: "FF0D",
        aliases: [
            "funnel-plus"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "filter-plus-outline",
        codepoint: "FF0E",
        aliases: [
            "funnel-plus-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "filter-remove",
        codepoint: "F234",
        aliases: [
            "funnel-remove"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "filter-remove-outline",
        codepoint: "F235",
        aliases: [
            "funnel-remove-outline"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "filter-variant",
        codepoint: "F236",
        aliases: [
            "filter-list"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "filter-variant-minus",
        codepoint: "F013D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "filter-variant-plus",
        codepoint: "F013E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "filter-variant-remove",
        codepoint: "F0061",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "finance",
        codepoint: "F81E",
        aliases: [
            "chart-finance"
        ],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "find-replace",
        codepoint: "F6D3",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "fingerprint",
        codepoint: "F237",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "fingerprint-off",
        codepoint: "FECE",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "fire",
        codepoint: "F238",
        aliases: [
            "whatshot",
            "flame"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "fire-extinguisher",
        codepoint: "FF0F",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "fire-hydrant",
        codepoint: "F0162",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "fire-hydrant-alert",
        codepoint: "F0163",
        aliases: [],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "fire-hydrant-off",
        codepoint: "F0164",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "fire-truck",
        codepoint: "F8AA",
        aliases: [
            "fire-engine"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "firebase",
        codepoint: "F966",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "firefox",
        codepoint: "F239",
        aliases: [
            "mozilla-firefox"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "fireplace",
        codepoint: "FE11",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "fireplace-off",
        codepoint: "FE12",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "firework",
        codepoint: "FE13",
        aliases: [
            "bottle-rocket"
        ],
        tags: [
            "Holiday"
        ],
    },
    {
        
        name: "fish",
        codepoint: "F23A",
        aliases: [],
        tags: [
            "Animal",
            "Food \/ Drink"
        ],
    },
    {
        
        name: "fishbowl",
        codepoint: "FF10",
        aliases: [
            "aquarium"
        ],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "fishbowl-outline",
        codepoint: "FF11",
        aliases: [
            "aquarium-outline"
        ],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "fit-to-page",
        codepoint: "FF12",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format",
            "Arrow"
        ],
    },
    {
        
        name: "fit-to-page-outline",
        codepoint: "FF13",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format",
            "Arrow"
        ],
    },
    {
        
        name: "flag",
        codepoint: "F23B",
        aliases: [
            "assistant-photo"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flag-checkered",
        codepoint: "F23C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flag-minus",
        codepoint: "FB75",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flag-minus-outline",
        codepoint: "F00DD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flag-outline",
        codepoint: "F23D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flag-plus",
        codepoint: "FB76",
        aliases: [
            "flag-add"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flag-plus-outline",
        codepoint: "F00DE",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flag-remove",
        codepoint: "FB77",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flag-remove-outline",
        codepoint: "F00DF",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flag-triangle",
        codepoint: "F23F",
        aliases: [
            "milestone"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flag-variant",
        codepoint: "F240",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flag-variant-outline",
        codepoint: "F23E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flare",
        codepoint: "FD4E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flash",
        codepoint: "F241",
        aliases: [
            "lightning-bolt",
            "flash-on",
            "electricity"
        ],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "flash-alert",
        codepoint: "FF14",
        aliases: [
            "lightning-alert",
            "storm-advisory"
        ],
        tags: [
            "Weather",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "flash-alert-outline",
        codepoint: "FF15",
        aliases: [
            "lightning-alert-outline",
            "storm-advisory-outline"
        ],
        tags: [
            "Weather",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "flash-auto",
        codepoint: "F242",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flash-circle",
        codepoint: "F81F",
        aliases: [
            "amp",
            "offline-bolt",
            "lightning-bolt-circle"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flash-off",
        codepoint: "F243",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flash-outline",
        codepoint: "F6D4",
        aliases: [
            "lightning-bolt-outline"
        ],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "flash-red-eye",
        codepoint: "F67A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flashlight",
        codepoint: "F244",
        aliases: [
            "torch"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flashlight-off",
        codepoint: "F245",
        aliases: [
            "torch-off"
        ],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flask",
        codepoint: "F093",
        aliases: [],
        tags: [
            "Science",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "flask-empty",
        codepoint: "F094",
        aliases: [],
        tags: [
            "Science",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "flask-empty-minus",
        codepoint: "F0265",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flask-empty-minus-outline",
        codepoint: "F0266",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flask-empty-outline",
        codepoint: "F095",
        aliases: [],
        tags: [
            "Science",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "flask-empty-plus",
        codepoint: "F0267",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flask-empty-plus-outline",
        codepoint: "F0268",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flask-empty-remove",
        codepoint: "F0269",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flask-empty-remove-outline",
        codepoint: "F026A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flask-minus",
        codepoint: "F026B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flask-minus-outline",
        codepoint: "F026C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flask-outline",
        codepoint: "F096",
        aliases: [],
        tags: [
            "Science",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "flask-plus",
        codepoint: "F026D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flask-plus-outline",
        codepoint: "F026E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flask-remove",
        codepoint: "F026F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flask-remove-outline",
        codepoint: "F0270",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flask-round-bottom",
        codepoint: "F0276",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flask-round-bottom-empty",
        codepoint: "F0277",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flask-round-bottom-empty-outline",
        codepoint: "F0278",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 300-599" ],
    },
    {
        
        name: "flask-round-bottom-outline",
        codepoint: "F0279",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "flattr",
        codepoint: "F246",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "flickr",
        codepoint: "FCE3",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "flip-horizontal",
        codepoint: "F0112",
        aliases: [],
        tags: [
            "Arrange"
        ],
    },
    {
        
        name: "flip-to-back",
        codepoint: "F247",
        aliases: [],
        tags: [
            "Arrange"
        ],
    },
    {
        
        name: "flip-to-front",
        codepoint: "F248",
        aliases: [],
        tags: [
            "Arrange"
        ],
    },
    {
        
        name: "flip-vertical",
        codepoint: "F0113",
        aliases: [],
        tags: [
            "Arrange"
        ],
    },
    {
        
        name: "floor-lamp",
        codepoint: "F8DC",
        aliases: [
            "floor-light"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "floor-lamp-dual",
        codepoint: "F0062",
        aliases: [
            "floor-light-dual"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "floor-lamp-variant",
        codepoint: "F0063",
        aliases: [
            "floor-light-variant"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "floor-plan",
        codepoint: "F820",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "floppy",
        codepoint: "F249",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "floppy-variant",
        codepoint: "F9EE",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "flower",
        codepoint: "F24A",
        aliases: [
            "local-florist",
            "plant"
        ],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "flower-outline",
        codepoint: "F9EF",
        aliases: [
            "local-florist-outline",
            "plant"
        ],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "flower-poppy",
        codepoint: "FCE4",
        aliases: [
            "plant"
        ],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "flower-tulip",
        codepoint: "F9F0",
        aliases: [
            "plant"
        ],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "flower-tulip-outline",
        codepoint: "F9F1",
        aliases: [
            "plant"
        ],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "focus-auto",
        codepoint: "FF6B",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "focus-field",
        codepoint: "FF6C",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "focus-field-horizontal",
        codepoint: "FF6D",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "focus-field-vertical",
        codepoint: "FF6E",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "folder",
        codepoint: "F24B",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-account",
        codepoint: "F24C",
        aliases: [
            "folder-user",
            "folder-shared"
        ],
        tags: [
            "Account \/ User",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-account-outline",
        codepoint: "FB78",
        aliases: [
            "folder-user-outline",
            "folder-shared-outline"
        ],
        tags: [
            "Files \/ Folders",
            "Account \/ User"
        ],
    },
    {
        
        name: "folder-alert",
        codepoint: "FDA8",
        aliases: [
            "folder-warning"
        ],
        tags: [
            "Files \/ Folders",
            "Alert \/ Error",
            "Alert \/ Error",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "folder-alert-outline",
        codepoint: "FDA9",
        aliases: [
            "folder-warning-outline"
        ],
        tags: [
            "Files \/ Folders",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "folder-clock",
        codepoint: "FAB9",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-clock-outline",
        codepoint: "FABA",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-download",
        codepoint: "F24D",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-download-outline",
        codepoint: "F0114",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-edit",
        codepoint: "F8DD",
        aliases: [],
        tags: [
            "Files \/ Folders",
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "folder-edit-outline",
        codepoint: "FDAA",
        aliases: [],
        tags: [
            "Edit \/ Modify",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-google-drive",
        codepoint: "F24E",
        aliases: [
            "folder-mydrive"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-heart",
        codepoint: "F0115",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-heart-outline",
        codepoint: "F0116",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-home",
        codepoint: "F00E0",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-home-outline",
        codepoint: "F00E1",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-image",
        codepoint: "F24F",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-information",
        codepoint: "F00E2",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-information-outline",
        codepoint: "F00E3",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-key",
        codepoint: "F8AB",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-key-network",
        codepoint: "F8AC",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-key-network-outline",
        codepoint: "FC5C",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-key-outline",
        codepoint: "F0117",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-lock",
        codepoint: "F250",
        aliases: [],
        tags: [
            "Lock",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-lock-open",
        codepoint: "F251",
        aliases: [],
        tags: [
            "Lock",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-move",
        codepoint: "F252",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-move-outline",
        codepoint: "F0271",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "folder-multiple",
        codepoint: "F253",
        aliases: [
            "folders"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-multiple-image",
        codepoint: "F254",
        aliases: [
            "perm-media",
            "folders-image"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-multiple-outline",
        codepoint: "F255",
        aliases: [
            "folders-outline"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-network",
        codepoint: "F86F",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-network-outline",
        codepoint: "FC5D",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-open",
        codepoint: "F76F",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-open-outline",
        codepoint: "FDAB",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-outline",
        codepoint: "F256",
        aliases: [
            "folder-open"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-plus",
        codepoint: "F257",
        aliases: [
            "create-new-folder",
            "folder-add"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-plus-outline",
        codepoint: "FB79",
        aliases: [
            "create-new-folder-outline",
            "folder-add-outline"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-pound",
        codepoint: "FCE5",
        aliases: [
            "folder-hash"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-pound-outline",
        codepoint: "FCE6",
        aliases: [
            "folder-hash-outline"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-remove",
        codepoint: "F258",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-remove-outline",
        codepoint: "FB7A",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-search",
        codepoint: "F967",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-search-outline",
        codepoint: "F968",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-settings",
        codepoint: "F00A8",
        aliases: [],
        tags: [
            "Settings",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-settings-outline",
        codepoint: "F00A9",
        aliases: [],
        tags: [
            "Settings",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-settings-variant",
        codepoint: "F00AA",
        aliases: [
            "folder-cog"
        ],
        tags: [
            "Settings",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-settings-variant-outline",
        codepoint: "F00AB",
        aliases: [
            "folder-cog-outline"
        ],
        tags: [
            "Settings",
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-star",
        codepoint: "F69C",
        aliases: [
            "folder-special"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-star-outline",
        codepoint: "FB7B",
        aliases: [
            "folder-special-outline"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-swap",
        codepoint: "FFD6",
        aliases: [
            "folder-transfer"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-swap-outline",
        codepoint: "FFD7",
        aliases: [
            "folder-transfer-outline"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-sync",
        codepoint: "FCE7",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-sync-outline",
        codepoint: "FCE8",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-text",
        codepoint: "FC5E",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-text-outline",
        codepoint: "FC5F",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-upload",
        codepoint: "F259",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-upload-outline",
        codepoint: "F0118",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-zip",
        codepoint: "F6EA",
        aliases: [
            "compressed-folder"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "folder-zip-outline",
        codepoint: "F7B8",
        aliases: [
            "compressed-folder-outline"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "font-awesome",
        codepoint: "F03A",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "food",
        codepoint: "F25A",
        aliases: [
            "fast-food"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "food-apple",
        codepoint: "F25B",
        aliases: [],
        tags: [
            "Food \/ Drink",
            "Food \/ Drink"
        ],
    },
    {
        
        name: "food-apple-outline",
        codepoint: "FC60",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "food-croissant",
        codepoint: "F7C7",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "food-fork-drink",
        codepoint: "F5F2",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "food-off",
        codepoint: "F5F3",
        aliases: [
            "fast-food-off"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "food-variant",
        codepoint: "F25C",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "foot-print",
        codepoint: "FF6F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "football",
        codepoint: "F25D",
        aliases: [
            "football-american"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "football-australian",
        codepoint: "F25E",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "football-helmet",
        codepoint: "F25F",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "forklift",
        codepoint: "F7C8",
        aliases: [],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "format-align-bottom",
        codepoint: "F752",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-align-center",
        codepoint: "F260",
        aliases: [
            "format-align-centre"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-align-justify",
        codepoint: "F261",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-align-left",
        codepoint: "F262",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-align-middle",
        codepoint: "F753",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-align-right",
        codepoint: "F263",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-align-top",
        codepoint: "F754",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-annotation-minus",
        codepoint: "FABB",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-annotation-plus",
        codepoint: "F646",
        aliases: [
            "format-annotation-add"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-bold",
        codepoint: "F264",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-clear",
        codepoint: "F265",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-color-fill",
        codepoint: "F266",
        aliases: [
            "format-colour-fill",
            "paint",
            "paint-bucket"
        ],
        tags: [
            "Text \/ Content \/ Format",
            "Color"
        ],
    },
    {
        
        name: "format-color-highlight",
        codepoint: "FE14",
        aliases: [
            "format-colour-highlight"
        ],
        tags: [
            "Color",
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-color-text",
        codepoint: "F69D",
        aliases: [
            "format-colour-text"
        ],
        tags: [
            "Text \/ Content \/ Format",
            "Color"
        ],
    },
    {
        
        name: "format-columns",
        codepoint: "F8DE",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-float-center",
        codepoint: "F267",
        aliases: [
            "format-float-centre"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-float-left",
        codepoint: "F268",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-float-none",
        codepoint: "F269",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-float-right",
        codepoint: "F26A",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-font",
        codepoint: "F6D5",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-font-size-decrease",
        codepoint: "F9F2",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-font-size-increase",
        codepoint: "F9F3",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-header-1",
        codepoint: "F26B",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-header-2",
        codepoint: "F26C",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-header-3",
        codepoint: "F26D",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-header-4",
        codepoint: "F26E",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-header-5",
        codepoint: "F26F",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-header-6",
        codepoint: "F270",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-header-decrease",
        codepoint: "F271",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-header-equal",
        codepoint: "F272",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-header-increase",
        codepoint: "F273",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-header-pound",
        codepoint: "F274",
        aliases: [
            "format-header-hash"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-horizontal-align-center",
        codepoint: "F61E",
        aliases: [
            "format-horizontal-align-centre"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-horizontal-align-left",
        codepoint: "F61F",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-horizontal-align-right",
        codepoint: "F620",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-indent-decrease",
        codepoint: "F275",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-indent-increase",
        codepoint: "F276",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-italic",
        codepoint: "F277",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-letter-case",
        codepoint: "FB19",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-letter-case-lower",
        codepoint: "FB1A",
        aliases: [
            "format-lowercase"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-letter-case-upper",
        codepoint: "FB1B",
        aliases: [
            "format-uppercase"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-letter-ends-with",
        codepoint: "FFD8",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-letter-matches",
        codepoint: "FFD9",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-letter-starts-with",
        codepoint: "FFDA",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-line-spacing",
        codepoint: "F278",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-line-style",
        codepoint: "F5C8",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format",
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "format-line-weight",
        codepoint: "F5C9",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format",
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "format-list-bulleted",
        codepoint: "F279",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-list-bulleted-square",
        codepoint: "FDAC",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-list-bulleted-triangle",
        codepoint: "FECF",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-list-bulleted-type",
        codepoint: "F27A",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-list-checkbox",
        codepoint: "F969",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-list-checks",
        codepoint: "F755",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-list-numbered",
        codepoint: "F27B",
        aliases: [
            "format-list-numbers"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-list-numbered-rtl",
        codepoint: "FCE9",
        aliases: [
            "format-list-numbered-right-to-left"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-overline",
        codepoint: "FED0",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-page-break",
        codepoint: "F6D6",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-paint",
        codepoint: "F27C",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format",
            "Color",
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "format-paragraph",
        codepoint: "F27D",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-pilcrow",
        codepoint: "F6D7",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-quote-close",
        codepoint: "F27E",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-quote-close-outline",
        codepoint: "F01D3",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-quote-open",
        codepoint: "F756",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-quote-open-outline",
        codepoint: "F01D2",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-rotate-90",
        codepoint: "F6A9",
        aliases: [
            "rotate-90-degrees-ccw",
            "format-rotate-ninety"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-section",
        codepoint: "F69E",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-size",
        codepoint: "F27F",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-strikethrough",
        codepoint: "F280",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-strikethrough-variant",
        codepoint: "F281",
        aliases: [
            "strikethrough-s"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-subscript",
        codepoint: "F282",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-superscript",
        codepoint: "F283",
        aliases: [
            "exponent"
        ],
        tags: [
            "Text \/ Content \/ Format",
            "Math"
        ],
    },
    {
        
        name: "format-text",
        codepoint: "F284",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-text-rotation-angle-down",
        codepoint: "FFDB",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-text-rotation-angle-up",
        codepoint: "FFDC",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-text-rotation-down",
        codepoint: "FD4F",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-text-rotation-down-vertical",
        codepoint: "FFDD",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-text-rotation-none",
        codepoint: "FD50",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-text-rotation-up",
        codepoint: "FFDE",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-text-rotation-vertical",
        codepoint: "FFDF",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-text-variant",
        codepoint: "FE15",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-text-wrapping-clip",
        codepoint: "FCEA",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-text-wrapping-overflow",
        codepoint: "FCEB",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-text-wrapping-wrap",
        codepoint: "FCEC",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-textbox",
        codepoint: "FCED",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-textdirection-l-to-r",
        codepoint: "F285",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-textdirection-r-to-l",
        codepoint: "F286",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-title",
        codepoint: "F5F4",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-underline",
        codepoint: "F287",
        aliases: [
            "format-underlined"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-vertical-align-bottom",
        codepoint: "F621",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-vertical-align-center",
        codepoint: "F622",
        aliases: [
            "format-vertical-align-centre"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-vertical-align-top",
        codepoint: "F623",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-wrap-inline",
        codepoint: "F288",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-wrap-square",
        codepoint: "F289",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-wrap-tight",
        codepoint: "F28A",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "format-wrap-top-bottom",
        codepoint: "F28B",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "forum",
        codepoint: "F28C",
        aliases: [
            "message-group",
            "question-answer",
            "chat"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "forum-outline",
        codepoint: "F821",
        aliases: [
            "chat-outline"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "forward",
        codepoint: "F28D",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "forwardburger",
        codepoint: "FD51",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "fountain",
        codepoint: "F96A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "fountain-pen",
        codepoint: "FCEE",
        aliases: [],
        tags: [
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "fountain-pen-tip",
        codepoint: "FCEF",
        aliases: [],
        tags: [
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "foursquare",
        codepoint: "F28E",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "freebsd",
        codepoint: "F8DF",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "frequently-asked-questions",
        codepoint: "FED1",
        aliases: [
            "faq"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "fridge",
        codepoint: "F290",
        aliases: [
            "fridge-filled",
            "refrigerator"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "fridge-alert",
        codepoint: "F01DC",
        aliases: [],
        tags: [
            "Home Automation",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "fridge-alert-outline",
        codepoint: "F01DD",
        aliases: [],
        tags: [
            "Home Automation",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "fridge-bottom",
        codepoint: "F292",
        aliases: [
            "fridge-filled-top",
            "refrigerator-bottom"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "fridge-off",
        codepoint: "F01DA",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "fridge-off-outline",
        codepoint: "F01DB",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "fridge-outline",
        codepoint: "F28F",
        aliases: [
            "kitchen",
            "refrigerator-outline"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "fridge-top",
        codepoint: "F291",
        aliases: [
            "fridge-filled-bottom",
            "refrigerator-top"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "fruit-cherries",
        codepoint: "F0064",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "fruit-citrus",
        codepoint: "F0065",
        aliases: [
            "fruit-lemon",
            "fruit-lime"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "fruit-grapes",
        codepoint: "F0066",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "fruit-grapes-outline",
        codepoint: "F0067",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "fruit-pineapple",
        codepoint: "F0068",
        aliases: [
            "fruit-ananas"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "fruit-watermelon",
        codepoint: "F0069",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "fuel",
        codepoint: "F7C9",
        aliases: [
            "petrol",
            "gasoline"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "fullscreen",
        codepoint: "F293",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "fullscreen-exit",
        codepoint: "F294",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "function",
        codepoint: "F295",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "function-variant",
        codepoint: "F870",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "furigana-horizontal",
        codepoint: "F00AC",
        aliases: [
            "ruby-horizontal"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "furigana-vertical",
        codepoint: "F00AD",
        aliases: [
            "ruby-vertical"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "fuse",
        codepoint: "FC61",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "fuse-blade",
        codepoint: "FC62",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "gamepad",
        codepoint: "F296",
        aliases: [
            "games"
        ],
        tags: [
            "Home Automation",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-circle",
        codepoint: "FE16",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-circle-down",
        codepoint: "FE17",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-circle-left",
        codepoint: "FE18",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-circle-outline",
        codepoint: "FE19",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-circle-right",
        codepoint: "FE1A",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-circle-up",
        codepoint: "FE1B",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-down",
        codepoint: "FE1C",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-left",
        codepoint: "FE1D",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-right",
        codepoint: "FE1E",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-round",
        codepoint: "FE1F",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-round-down",
        codepoint: "FE7E",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-round-left",
        codepoint: "FE7F",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-round-outline",
        codepoint: "FE80",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-round-right",
        codepoint: "FE81",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-round-up",
        codepoint: "FE82",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-square",
        codepoint: "FED2",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-square-outline",
        codepoint: "FED3",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-up",
        codepoint: "FE83",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-variant",
        codepoint: "F297",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamepad-variant-outline",
        codepoint: "FED4",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gamma",
        codepoint: "F0119",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "gantry-crane",
        codepoint: "FDAD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "garage",
        codepoint: "F6D8",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "garage-alert",
        codepoint: "F871",
        aliases: [
            "garage-warning"
        ],
        tags: [
            "Home Automation",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "garage-open",
        codepoint: "F6D9",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "gas-cylinder",
        codepoint: "F647",
        aliases: [
            "tank",
            "oxygen-tank"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gas-station",
        codepoint: "F298",
        aliases: [
            "gas-pump",
            "petrol-pump",
            "petrol-station",
            "local-gas-station",
            "fuel-station",
            "fuel-pump"
        ],
        tags: [
            "Places",
            "Automotive"
        ],
    },
    {
        
        name: "gas-station-outline",
        codepoint: "FED5",
        aliases: [
            "gas-pump-outline",
            "petrol-pump-outline",
            "petrol-station-outline",
            "fuel-station-outline",
            "fuel-pump-outline"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gate",
        codepoint: "F299",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "gate-and",
        codepoint: "F8E0",
        aliases: [
            "logic-gate-and"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gate-arrow-right",
        codepoint: "F0194",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "gate-nand",
        codepoint: "F8E1",
        aliases: [
            "logic-gate-nand"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gate-nor",
        codepoint: "F8E2",
        aliases: [
            "logic-gate-nor"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gate-not",
        codepoint: "F8E3",
        aliases: [
            "logic-gate-not"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gate-open",
        codepoint: "F0195",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "gate-or",
        codepoint: "F8E4",
        aliases: [
            "logic-gate-or"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gate-xnor",
        codepoint: "F8E5",
        aliases: [
            "logic-gate-xnor"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gate-xor",
        codepoint: "F8E6",
        aliases: [
            "logic-gate-xor"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gatsby",
        codepoint: "FE84",
        aliases: [],
        tags: [
            "Developer \/ Languages",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "gauge",
        codepoint: "F29A",
        aliases: [
            "swap-driving-apps-wheel",
            "barometer"
        ],
        tags: [
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "gauge-empty",
        codepoint: "F872",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "gauge-full",
        codepoint: "F873",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "gauge-low",
        codepoint: "F874",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "gavel",
        codepoint: "F29B",
        aliases: [
            "court-hammer"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gender-female",
        codepoint: "F29C",
        aliases: [
            "venus"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gender-male",
        codepoint: "F29D",
        aliases: [
            "mars"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gender-male-female",
        codepoint: "F29E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gender-male-female-variant",
        codepoint: "F016A",
        aliases: [
            "mercury"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gender-non-binary",
        codepoint: "F016B",
        aliases: [
            "gender-enby"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gender-transgender",
        codepoint: "F29F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gentoo",
        codepoint: "F8E7",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "gesture",
        codepoint: "F7CA",
        aliases: [
            "freehand-line"
        ],
        tags: [
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "gesture-double-tap",
        codepoint: "F73B",
        aliases: [
            "interaction-double-tap",
            "hand-double-tap"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gesture-pinch",
        codepoint: "FABC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gesture-spread",
        codepoint: "FABD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gesture-swipe",
        codepoint: "FD52",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gesture-swipe-down",
        codepoint: "F73C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gesture-swipe-horizontal",
        codepoint: "FABE",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gesture-swipe-left",
        codepoint: "F73D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gesture-swipe-right",
        codepoint: "F73E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gesture-swipe-up",
        codepoint: "F73F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gesture-swipe-vertical",
        codepoint: "FABF",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gesture-tap",
        codepoint: "F740",
        aliases: [
            "interaction-tap",
            "hand-tap"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gesture-tap-hold",
        codepoint: "FD53",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gesture-two-double-tap",
        codepoint: "F741",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gesture-two-tap",
        codepoint: "F742",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "ghost",
        codepoint: "F2A0",
        aliases: [
            "inky",
            "blinky",
            "pinky",
            "clyde"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "ghost-off",
        codepoint: "F9F4",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gif",
        codepoint: "FD54",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gift",
        codepoint: "FE85",
        aliases: [],
        tags: [
            "Holiday"
        ],
    },
    {
        
        name: "gift-outline",
        codepoint: "F2A1",
        aliases: [
            "donate",
            "present"
        ],
        tags: [
            "Shopping",
            "Holiday"
        ],
    },
    {
        
        name: "git",
        codepoint: "F2A2",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "github-box",
        codepoint: "F2A3",
        aliases: [],
        tags: [
            "Developer \/ Languages",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "github-circle",
        codepoint: "F2A4",
        aliases: [],
        tags: [
            "Developer \/ Languages",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "github-face",
        codepoint: "F6DA",
        aliases: [],
        tags: [
            "Developer \/ Languages",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "gitlab",
        codepoint: "FB7C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "glass-cocktail",
        codepoint: "F356",
        aliases: [
            "local-bar",
            "cocktail",
            "martini"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "glass-flute",
        codepoint: "F2A5",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "glass-mug",
        codepoint: "F2A6",
        aliases: [
            "pub",
            "bar",
            "beer"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "glass-mug-variant",
        codepoint: "F0141",
        aliases: [
            "pub",
            "bar",
            "beer",
            "drink"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "glass-stange",
        codepoint: "F2A7",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "glass-tulip",
        codepoint: "F2A8",
        aliases: [
            "bar"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "glass-wine",
        codepoint: "F875",
        aliases: [
            "bar"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "glassdoor",
        codepoint: "F2A9",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "glasses",
        codepoint: "F2AA",
        aliases: [],
        tags: [
            "Clothing"
        ],
    },
    {
        
        name: "globe-model",
        codepoint: "F8E8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gmail",
        codepoint: "F2AB",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "gnome",
        codepoint: "F2AC",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "go-kart",
        codepoint: "FD55",
        aliases: [
            "cart"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "go-kart-track",
        codepoint: "FD56",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "gog",
        codepoint: "FB7D",
        aliases: [
            "gog-com"
        ],
        tags: [
            "Brand \/ Logo",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "gold",
        codepoint: "F027A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "golf",
        codepoint: "F822",
        aliases: [
            "golf-course"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "golf-cart",
        codepoint: "F01CF",
        aliases: [],
        tags: [
            "Sport",
            "Transportation + Other"
        ],
    },
    {
        
        name: "golf-tee",
        codepoint: "F00AE",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "gondola",
        codepoint: "F685",
        aliases: [
            "cable-car"
        ],
        tags: [
            "Transportation + Other"
        ],
    },
    {
        
        name: "goodreads",
        codepoint: "FD57",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "google",
        codepoint: "F2AD",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "google-adwords",
        codepoint: "FC63",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "google-analytics",
        codepoint: "F7CB",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "google-assistant",
        codepoint: "F7CC",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "google-cardboard",
        codepoint: "F2AE",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "google-chrome",
        codepoint: "F2AF",
        aliases: [
            "chromecast"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "google-circles",
        codepoint: "F2B0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "google-circles-communities",
        codepoint: "F2B1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "google-circles-extended",
        codepoint: "F2B2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "google-circles-group",
        codepoint: "F2B3",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "google-classroom",
        codepoint: "F2C0",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "google-cloud",
        codepoint: "F0221",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "google-controller",
        codepoint: "F2B4",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "google-controller-off",
        codepoint: "F2B5",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "google-drive",
        codepoint: "F2B6",
        aliases: [
            "attach-drive"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "google-earth",
        codepoint: "F2B7",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "google-fit",
        codepoint: "F96B",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "google-glass",
        codepoint: "F2B8",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "google-hangouts",
        codepoint: "F2C9",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "google-home",
        codepoint: "F823",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "google-keep",
        codepoint: "F6DB",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "google-lens",
        codepoint: "F9F5",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "google-maps",
        codepoint: "F5F5",
        aliases: [],
        tags: [
            "Navigation",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "google-my-business",
        codepoint: "F006A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "google-nearby",
        codepoint: "F2B9",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "google-pages",
        codepoint: "F2BA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "google-photos",
        codepoint: "F6DC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "google-physical-web",
        codepoint: "F2BB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "google-play",
        codepoint: "F2BC",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "google-plus",
        codepoint: "F2BD",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Social Media"
        ],
    },
    {
        
        name: "google-plus-box",
        codepoint: "F2BE",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Social Media"
        ],
    },
    {
        
        name: "google-podcast",
        codepoint: "FED6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "google-spreadsheet",
        codepoint: "F9F6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "google-street-view",
        codepoint: "FC64",
        aliases: [
            "pegman"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "google-translate",
        codepoint: "F2BF",
        aliases: [
            "g-translate"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "gradient",
        codepoint: "F69F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "grain",
        codepoint: "FD58",
        aliases: [],
        tags: [
            "Photography",
            "Video \/ Movie"
        ],
    },
    {
        
        name: "graph",
        codepoint: "F006B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "graph-outline",
        codepoint: "F006C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "graphql",
        codepoint: "F876",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "grave-stone",
        codepoint: "FB7E",
        aliases: [
            "headstone",
            "tombstone",
            "cemetery",
            "graveyard"
        ],
        tags: [
            "Holiday"
        ],
    },
    {
        
        name: "grease-pencil",
        codepoint: "F648",
        aliases: [],
        tags: [
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "greater-than",
        codepoint: "F96C",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "greater-than-or-equal",
        codepoint: "F96D",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "grid",
        codepoint: "F2C1",
        aliases: [
            "grid-on"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "grid-large",
        codepoint: "F757",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "grid-off",
        codepoint: "F2C2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "grill",
        codepoint: "FE86",
        aliases: [
            "bbq",
            "barbecue",
            "charcoal"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "grill-outline",
        codepoint: "F01B5",
        aliases: [
            "barbecue-outline",
            "bbq-outline",
            "charcoal-outline"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "group",
        codepoint: "F2C3",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "guitar-acoustic",
        codepoint: "F770",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "guitar-electric",
        codepoint: "F2C4",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "guitar-pick",
        codepoint: "F2C5",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "guitar-pick-outline",
        codepoint: "F2C6",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "guy-fawkes-mask",
        codepoint: "F824",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hackernews",
        codepoint: "F624",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "hail",
        codepoint: "FAC0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hair-dryer",
        codepoint: "F011A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hair-dryer-outline",
        codepoint: "F011B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "halloween",
        codepoint: "FB7F",
        aliases: [
            "pumpkin-face",
            "pumpkin-carved",
            "jack-o-lantern"
        ],
        tags: [
            "Holiday"
        ],
    },
    {
        
        name: "hamburger",
        codepoint: "F684",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "hammer",
        codepoint: "F8E9",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "hand",
        codepoint: "FA4E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hand-heart",
        codepoint: "F011C",
        aliases: [
            "volunteer",
            "love",
            "hope"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hand-left",
        codepoint: "FE87",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hand-okay",
        codepoint: "FA4F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hand-peace",
        codepoint: "FA50",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hand-peace-variant",
        codepoint: "FA51",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hand-pointing-down",
        codepoint: "FA52",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hand-pointing-left",
        codepoint: "FA53",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hand-pointing-right",
        codepoint: "F2C7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hand-pointing-up",
        codepoint: "FA54",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hand-right",
        codepoint: "FE88",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hand-saw",
        codepoint: "FE89",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "handball",
        codepoint: "FF70",
        aliases: [
            "volleyball"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "handcuffs",
        codepoint: "F0169",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "handshake",
        codepoint: "F0243",
        aliases: [
            "business",
            "deal",
            "help"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hanger",
        codepoint: "F2C8",
        aliases: [
            "coat-hanger",
            "clothes-hanger"
        ],
        tags: [
            "Clothing"
        ],
    },
    {
        
        name: "hard-hat",
        codepoint: "F96E",
        aliases: [
            "helmet"
        ],
        tags: [
            "Hardware \/ Tools",
            "Clothing"
        ],
    },
    {
        
        name: "harddisk",
        codepoint: "F2CA",
        aliases: [
            "hdd"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "harddisk-plus",
        codepoint: "F006D",
        aliases: [
            "hdd-plus"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "harddisk-remove",
        codepoint: "F006E",
        aliases: [
            "hdd-remove"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hat-fedora",
        codepoint: "FB80",
        aliases: [],
        tags: [
            "Clothing"
        ],
    },
    {
        
        name: "hazard-lights",
        codepoint: "FC65",
        aliases: [
            "warning-lights"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "hdr",
        codepoint: "FD59",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hdr-off",
        codepoint: "FD5A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "headphones",
        codepoint: "F2CB",
        aliases: [
            "headset"
        ],
        tags: [
            "Audio",
            "Device \/ Tech",
            "Music"
        ],
    },
    {
        
        name: "headphones-bluetooth",
        codepoint: "F96F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "headphones-box",
        codepoint: "F2CC",
        aliases: [],
        tags: [
            "Audio",
            "Music"
        ],
    },
    {
        
        name: "headphones-off",
        codepoint: "F7CD",
        aliases: [],
        tags: [
            "Audio",
            "Device \/ Tech",
            "Music"
        ],
    },
    {
        
        name: "headphones-settings",
        codepoint: "F2CD",
        aliases: [],
        tags: [
            "Audio",
            "Settings"
        ],
    },
    {
        
        name: "headset",
        codepoint: "F2CE",
        aliases: [
            "headset-mic"
        ],
        tags: [
            "Audio",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "headset-dock",
        codepoint: "F2CF",
        aliases: [],
        tags: [
            "Audio"
        ],
    },
    {
        
        name: "headset-off",
        codepoint: "F2D0",
        aliases: [],
        tags: [
            "Audio",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "heart",
        codepoint: "F2D1",
        aliases: [
            "favorite",
            "favourite"
        ],
        tags: [
            "Shape",
            "Gaming \/ RPG",
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "heart-box",
        codepoint: "F2D2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "heart-box-outline",
        codepoint: "F2D3",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "heart-broken",
        codepoint: "F2D4",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "heart-broken-outline",
        codepoint: "FCF0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "heart-circle",
        codepoint: "F970",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "heart-circle-outline",
        codepoint: "F971",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "heart-flash",
        codepoint: "FF16",
        aliases: [
            "aed",
            "defibrillator"
        ],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "heart-half",
        codepoint: "F6DE",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "heart-half-full",
        codepoint: "F6DD",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "heart-half-outline",
        codepoint: "F6DF",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "heart-multiple",
        codepoint: "FA55",
        aliases: [
            "hearts"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "heart-multiple-outline",
        codepoint: "FA56",
        aliases: [
            "hearts-outline"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "heart-off",
        codepoint: "F758",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "heart-outline",
        codepoint: "F2D5",
        aliases: [
            "favorite-border",
            "favourite-border",
            "favorite-outline",
            "favourite-outline"
        ],
        tags: [
            "Shape",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "heart-pulse",
        codepoint: "F5F6",
        aliases: [
            "heart-vitals"
        ],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "helicopter",
        codepoint: "FAC1",
        aliases: [],
        tags: [
            "Transportation + Flying"
        ],
    },
    {
        
        name: "help",
        codepoint: "F2D6",
        aliases: [
            "question-mark"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "help-box",
        codepoint: "F78A",
        aliases: [
            "question-mark-box"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "help-circle",
        codepoint: "F2D7",
        aliases: [
            "question-mark-circle"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "help-circle-outline",
        codepoint: "F625",
        aliases: [
            "help-outline",
            "question-mark-circle-outline"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "help-network",
        codepoint: "F6F4",
        aliases: [
            "question-network"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "help-network-outline",
        codepoint: "FC66",
        aliases: [
            "question-network-outline"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "help-rhombus",
        codepoint: "FB81",
        aliases: [
            "question-mark-rhombus"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "help-rhombus-outline",
        codepoint: "FB82",
        aliases: [
            "question-mark-rhombus-outline"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hexagon",
        codepoint: "F2D8",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "hexagon-multiple",
        codepoint: "F6E0",
        aliases: [
            "hexagons"
        ],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "hexagon-multiple-outline",
        codepoint: "F011D",
        aliases: [],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "hexagon-outline",
        codepoint: "F2D9",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "hexagon-slice-1",
        codepoint: "FAC2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hexagon-slice-2",
        codepoint: "FAC3",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hexagon-slice-3",
        codepoint: "FAC4",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hexagon-slice-4",
        codepoint: "FAC5",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hexagon-slice-5",
        codepoint: "FAC6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hexagon-slice-6",
        codepoint: "FAC7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hexagram",
        codepoint: "FAC8",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "hexagram-outline",
        codepoint: "FAC9",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "high-definition",
        codepoint: "F7CE",
        aliases: [
            "hd"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "high-definition-box",
        codepoint: "F877",
        aliases: [
            "hd-box",
            "hd"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "highway",
        codepoint: "F5F7",
        aliases: [
            "autobahn",
            "motorway"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "hiking",
        codepoint: "FD5B",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "hinduism",
        codepoint: "F972",
        aliases: [
            "religion-hindu",
            "om"
        ],
        tags: [
            "Religion"
        ],
    },
    {
        
        name: "history",
        codepoint: "F2DA",
        aliases: [
            "recent",
            "latest",
            "clock-arrow",
            "counterclockwise",
            "restore-clock"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hockey-puck",
        codepoint: "F878",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "hockey-sticks",
        codepoint: "F879",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "hololens",
        codepoint: "F2DB",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "home",
        codepoint: "F2DC",
        aliases: [
            "house"
        ],
        tags: [
            "Home Automation",
            "Places"
        ],
    },
    {
        
        name: "home-account",
        codepoint: "F825",
        aliases: [
            "home-user"
        ],
        tags: [
            "Account \/ User",
            "Home Automation"
        ],
    },
    {
        
        name: "home-alert",
        codepoint: "F87A",
        aliases: [
            "home-warning"
        ],
        tags: [
            "Home Automation",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "home-analytics",
        codepoint: "FED7",
        aliases: [
            "chart-home",
            "home-chart"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-assistant",
        codepoint: "F7CF",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Home Automation"
        ],
    },
    {
        
        name: "home-automation",
        codepoint: "F7D0",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-circle",
        codepoint: "F7D1",
        aliases: [
            "house-circle"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-circle-outline",
        codepoint: "F006F",
        aliases: [
            "house-circle-outline"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-city",
        codepoint: "FCF1",
        aliases: [
            "house-city"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "home-city-outline",
        codepoint: "FCF2",
        aliases: [
            "house-city-outline"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "home-currency-usd",
        codepoint: "F8AE",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "home-edit",
        codepoint: "F0184",
        aliases: [],
        tags: [
            "Home Automation",
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "home-edit-outline",
        codepoint: "F0185",
        aliases: [],
        tags: [
            "Home Automation",
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "home-export-outline",
        codepoint: "FFB8",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-flood",
        codepoint: "FF17",
        aliases: [],
        tags: [
            "Weather",
            "Home Automation"
        ],
    },
    {
        
        name: "home-floor-0",
        codepoint: "FDAE",
        aliases: [
            "house-floor-0",
            "home-floor-zero",
            "house-floor-zero"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-floor-1",
        codepoint: "FD5C",
        aliases: [
            "house-floor-1",
            "home-floor-one",
            "house-floor-one",
            "home-floor-first",
            "house-floor-first"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-floor-2",
        codepoint: "FD5D",
        aliases: [
            "house-floor-2",
            "home-floor-two",
            "house-floor-two",
            "home-floor-second",
            "house-floor-second"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-floor-3",
        codepoint: "FD5E",
        aliases: [
            "house-floor-3",
            "home-floor-three",
            "house-floor-three",
            "home-floor-third",
            "house-floor-third"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-floor-a",
        codepoint: "FD5F",
        aliases: [
            "home-floor-attic",
            "house-floor-a",
            "house-floor-attic"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-floor-b",
        codepoint: "FD60",
        aliases: [
            "home-floor-basement",
            "house-floor-b",
            "house-floor-basement"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-floor-g",
        codepoint: "FD61",
        aliases: [
            "home-floor-ground",
            "house-floor-g",
            "house-floor-ground"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-floor-l",
        codepoint: "FD62",
        aliases: [
            "home-floor-loft",
            "home-floor-lower",
            "house-floor-l",
            "house-floor-loft",
            "house-floor-lower"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-floor-negative-1",
        codepoint: "FDAF",
        aliases: [
            "house-floor-negative-1",
            "home-floor-negative-one",
            "home-floor-minus-1",
            "home-floor-minus-one",
            "house-floor-negative-one",
            "house-floor-minus-1",
            "house-floor-minus-one"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-group",
        codepoint: "FDB0",
        aliases: [
            "house-group",
            "neighbourhood",
            "estate",
            "housing-estate"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-heart",
        codepoint: "F826",
        aliases: [
            "family"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-import-outline",
        codepoint: "FFB9",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-lightbulb",
        codepoint: "F027C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "home-lightbulb-outline",
        codepoint: "F027D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "home-lock",
        codepoint: "F8EA",
        aliases: [],
        tags: [
            "Home Automation",
            "Lock"
        ],
    },
    {
        
        name: "home-lock-open",
        codepoint: "F8EB",
        aliases: [],
        tags: [
            "Home Automation",
            "Lock"
        ],
    },
    {
        
        name: "home-map-marker",
        codepoint: "F5F8",
        aliases: [
            "house-map-marker"
        ],
        tags: [
            "Home Automation",
            "Navigation"
        ],
    },
    {
        
        name: "home-minus",
        codepoint: "F973",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-modern",
        codepoint: "F2DD",
        aliases: [
            "house-modern"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-outline",
        codepoint: "F6A0",
        aliases: [
            "house-outline"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-plus",
        codepoint: "F974",
        aliases: [
            "home-add"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-remove",
        codepoint: "F0272",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "home-roof",
        codepoint: "F0156",
        aliases: [
            "home-chimney"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-thermometer",
        codepoint: "FF71",
        aliases: [
            "home-climate",
            "home-temperature"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-thermometer-outline",
        codepoint: "FF72",
        aliases: [
            "home-climate-outline",
            "home-temperature-outline"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-variant",
        codepoint: "F2DE",
        aliases: [
            "house-variant"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "home-variant-outline",
        codepoint: "FB83",
        aliases: [
            "house-variant-outline"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "hook",
        codepoint: "F6E1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hook-off",
        codepoint: "F6E2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hops",
        codepoint: "F2DF",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "horizontal-rotate-clockwise",
        codepoint: "F011E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "horizontal-rotate-counterclockwise",
        codepoint: "F011F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "horseshoe",
        codepoint: "FA57",
        aliases: [
            "luck"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "hospital",
        codepoint: "F0017",
        aliases: [
            "swiss-cross"
        ],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "hospital-box",
        codepoint: "F2E0",
        aliases: [
            "local-hospital",
            "swiss-cross-box"
        ],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "hospital-box-outline",
        codepoint: "F0018",
        aliases: [
            "swiss-cross-box-outline"
        ],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "hospital-building",
        codepoint: "F2E1",
        aliases: [],
        tags: [
            "Places",
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "hospital-marker",
        codepoint: "F2E2",
        aliases: [],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "hot-tub",
        codepoint: "F827",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hotel",
        codepoint: "F2E3",
        aliases: [
            "bed",
            "local-hotel"
        ],
        tags: [
            "Home Automation",
            "Holiday"
        ],
    },
    {
        
        name: "houzz",
        codepoint: "F2E4",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "houzz-box",
        codepoint: "F2E5",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "hubspot",
        codepoint: "FCF3",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "hulu",
        codepoint: "F828",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "human",
        codepoint: "F2E6",
        aliases: [
            "accessibility"
        ],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "human-child",
        codepoint: "F2E7",
        aliases: [],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "human-female",
        codepoint: "F649",
        aliases: [
            "woman"
        ],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "human-female-boy",
        codepoint: "FA58",
        aliases: [
            "mother",
            "mom",
            "woman-child",
            "mum"
        ],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "human-female-female",
        codepoint: "FA59",
        aliases: [
            "woman-woman",
            "women"
        ],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "human-female-girl",
        codepoint: "FA5A",
        aliases: [
            "mother",
            "mom",
            "woman-child",
            "mum"
        ],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "human-greeting",
        codepoint: "F64A",
        aliases: [],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "human-handsdown",
        codepoint: "F64B",
        aliases: [],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "human-handsup",
        codepoint: "F64C",
        aliases: [],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "human-male",
        codepoint: "F64D",
        aliases: [
            "man"
        ],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "human-male-boy",
        codepoint: "FA5B",
        aliases: [
            "father",
            "dad",
            "man-child"
        ],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "human-male-female",
        codepoint: "F2E8",
        aliases: [
            "wc",
            "man-woman"
        ],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "human-male-girl",
        codepoint: "FA5C",
        aliases: [
            "father",
            "dad",
            "man-child"
        ],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "human-male-height",
        codepoint: "FF18",
        aliases: [],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "human-male-height-variant",
        codepoint: "FF19",
        aliases: [],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "human-male-male",
        codepoint: "FA5D",
        aliases: [
            "man-man",
            "men"
        ],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "human-pregnant",
        codepoint: "F5CF",
        aliases: [
            "pregnant-woman"
        ],
        tags: [
            "People \/ Family"
        ],
    },
    {
        
        name: "humble-bundle",
        codepoint: "F743",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "ice-cream",
        codepoint: "F829",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "ice-pop",
        codepoint: "FF1A",
        aliases: [
            "popsicle"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "id-card",
        codepoint: "FFE0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "identifier",
        codepoint: "FF1B",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "iframe",
        codepoint: "FC67",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "iframe-array",
        codepoint: "F0120",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "iframe-array-outline",
        codepoint: "F0121",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "iframe-braces",
        codepoint: "F0122",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "iframe-braces-outline",
        codepoint: "F0123",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "iframe-outline",
        codepoint: "FC68",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "iframe-parentheses",
        codepoint: "F0124",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "iframe-parentheses-outline",
        codepoint: "F0125",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "iframe-variable",
        codepoint: "F0126",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "iframe-variable-outline",
        codepoint: "F0127",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "image",
        codepoint: "F2E9",
        aliases: [
            "insert-photo"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "image-album",
        codepoint: "F2EA",
        aliases: [
            "photo-album"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "image-area",
        codepoint: "F2EB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "image-area-close",
        codepoint: "F2EC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "image-auto-adjust",
        codepoint: "FFE1",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "image-broken",
        codepoint: "F2ED",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "image-broken-variant",
        codepoint: "F2EE",
        aliases: [
            "broken-image"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "image-edit",
        codepoint: "F020E",
        aliases: [],
        tags: [
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "image-edit-outline",
        codepoint: "F020F",
        aliases: [],
        tags: [
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "image-filter",
        codepoint: "F2EF",
        aliases: [
            "image-multiple-outline",
            "images-outline"
        ],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "image-filter-black-white",
        codepoint: "F2F0",
        aliases: [
            "filter-b-and-w"
        ],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "image-filter-center-focus",
        codepoint: "F2F1",
        aliases: [
            "image-filter-centre-focus"
        ],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "image-filter-center-focus-strong",
        codepoint: "FF1C",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "image-filter-center-focus-strong-outline",
        codepoint: "FF1D",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "image-filter-center-focus-weak",
        codepoint: "F2F2",
        aliases: [
            "image-filter-centre-focus-weak"
        ],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "image-filter-drama",
        codepoint: "F2F3",
        aliases: [],
        tags: [
            "Photography",
            "Nature"
        ],
    },
    {
        
        name: "image-filter-frames",
        codepoint: "F2F4",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "image-filter-hdr",
        codepoint: "F2F5",
        aliases: [
            "mountain",
            "landscape"
        ],
        tags: [
            "Photography",
            "Nature"
        ],
    },
    {
        
        name: "image-filter-none",
        codepoint: "F2F6",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "image-filter-tilt-shift",
        codepoint: "F2F7",
        aliases: [],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "image-filter-vintage",
        codepoint: "F2F8",
        aliases: [],
        tags: [
            "Photography",
            "Nature"
        ],
    },
    {
        
        name: "image-frame",
        codepoint: "FE8A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "image-move",
        codepoint: "F9F7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "image-multiple",
        codepoint: "F2F9",
        aliases: [
            "collections",
            "photo-library",
            "images"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "image-off",
        codepoint: "F82A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "image-off-outline",
        codepoint: "F01FC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "image-outline",
        codepoint: "F975",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "image-plus",
        codepoint: "F87B",
        aliases: [
            "image-add"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "image-search",
        codepoint: "F976",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "image-search-outline",
        codepoint: "F977",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "image-size-select-actual",
        codepoint: "FC69",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "image-size-select-large",
        codepoint: "FC6A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "image-size-select-small",
        codepoint: "FC6B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "import",
        codepoint: "F2FA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "inbox",
        codepoint: "F686",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "inbox-arrow-down",
        codepoint: "F2FB",
        aliases: [
            "move-to-inbox"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "inbox-arrow-up",
        codepoint: "F3D1",
        aliases: [
            "move-from-inbox"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "inbox-multiple",
        codepoint: "F8AF",
        aliases: [
            "inboxes"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "inbox-multiple-outline",
        codepoint: "FB84",
        aliases: [
            "inboxes-outline"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "incognito",
        codepoint: "F5F9",
        aliases: [
            "anonymous"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "infinity",
        codepoint: "F6E3",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "information",
        codepoint: "F2FC",
        aliases: [
            "about",
            "information-circle",
            "info-circle",
            "about-circle"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "information-outline",
        codepoint: "F2FD",
        aliases: [
            "info-outline",
            "about-outline",
            "information-circle-outline",
            "info-circle-outline",
            "about-circle-outline"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "information-variant",
        codepoint: "F64E",
        aliases: [
            "info-variant",
            "about-variant"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "instagram",
        codepoint: "F2FE",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "instapaper",
        codepoint: "F2FF",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "instrument-triangle",
        codepoint: "F0070",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "internet-explorer",
        codepoint: "F300",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "invert-colors",
        codepoint: "F301",
        aliases: [
            "invert-colours"
        ],
        tags: [
            "Color"
        ],
    },
    {
        
        name: "invert-colors-off",
        codepoint: "FE8B",
        aliases: [
            "invert-colours-off"
        ],
        tags: [
            "Color"
        ],
    },
    {
        
        name: "ip",
        codepoint: "FA5E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "ip-network",
        codepoint: "FA5F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "ip-network-outline",
        codepoint: "FC6C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "ipod",
        codepoint: "FC6D",
        aliases: [
            "apple-ipod"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "islam",
        codepoint: "F978",
        aliases: [
            "religion-islamic",
            "star-and-crescent",
            "religion-muslim"
        ],
        tags: [
            "Religion"
        ],
    },
    {
        
        name: "island",
        codepoint: "F0071",
        aliases: [],
        tags: [
            "Places"
        ],
    },
    {
        
        name: "itunes",
        codepoint: "F676",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "iv-bag",
        codepoint: "F00E4",
        aliases: [],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "jabber",
        codepoint: "FDB1",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "jeepney",
        codepoint: "F302",
        aliases: [],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "jellyfish",
        codepoint: "FF1E",
        aliases: [],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "jellyfish-outline",
        codepoint: "FF1F",
        aliases: [],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "jira",
        codepoint: "F303",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "jquery",
        codepoint: "F87C",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "jsfiddle",
        codepoint: "F304",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "json",
        codepoint: "F626",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "judaism",
        codepoint: "F979",
        aliases: [
            "jewish",
            "religion-judaic",
            "star-of-david",
            "magen-david"
        ],
        tags: [
            "Religion"
        ],
    },
    {
        
        name: "kabaddi",
        codepoint: "FD63",
        aliases: [
            "wrestling"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "karate",
        codepoint: "F82B",
        aliases: [
            "martial-arts",
            "kickboxing"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "keg",
        codepoint: "F305",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "kettle",
        codepoint: "F5FA",
        aliases: [
            "tea-kettle",
            "kettle-full",
            "tea-kettle-full"
        ],
        tags: [
            "Home Automation",
            "Food \/ Drink"
        ],
    },
    {
        
        name: "kettle-outline",
        codepoint: "FF73",
        aliases: [
            "tea-kettle-outline",
            "kettle-empty",
            "tea-kettle-empty"
        ],
        tags: [
            "Food \/ Drink",
            "Home Automation"
        ],
    },
    {
        
        name: "key",
        codepoint: "F306",
        aliases: [
            "vpn-key"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "key-change",
        codepoint: "F307",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "key-link",
        codepoint: "F01CA",
        aliases: [
            "foreign-key",
            "sql-foreign-key"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "key-minus",
        codepoint: "F308",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "key-outline",
        codepoint: "FDB2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "key-plus",
        codepoint: "F309",
        aliases: [
            "key-add"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "key-remove",
        codepoint: "F30A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "key-star",
        codepoint: "F01C9",
        aliases: [
            "primary-key",
            "sql-primary-key"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "key-variant",
        codepoint: "F30B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "key-wireless",
        codepoint: "FFE2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "keyboard",
        codepoint: "F30C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "keyboard-backspace",
        codepoint: "F30D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "keyboard-caps",
        codepoint: "F30E",
        aliases: [
            "keyboard-capslock"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "keyboard-close",
        codepoint: "F30F",
        aliases: [
            "keyboard-hide"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "keyboard-off",
        codepoint: "F310",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "keyboard-off-outline",
        codepoint: "FE8C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "keyboard-outline",
        codepoint: "F97A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "keyboard-return",
        codepoint: "F311",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "keyboard-settings",
        codepoint: "F9F8",
        aliases: [],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "keyboard-settings-outline",
        codepoint: "F9F9",
        aliases: [],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "keyboard-space",
        codepoint: "F0072",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "keyboard-tab",
        codepoint: "F312",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "keyboard-variant",
        codepoint: "F313",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "khanda",
        codepoint: "F0128",
        aliases: [
            "sikh"
        ],
        tags: [
            "Religion"
        ],
    },
    {
        
        name: "kickstarter",
        codepoint: "F744",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "knife",
        codepoint: "F9FA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "knife-military",
        codepoint: "F9FB",
        aliases: [
            "dagger"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "kodi",
        codepoint: "F314",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "kotlin",
        codepoint: "F0244",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "kubernetes",
        codepoint: "F0129",
        aliases: [],
        tags: [
            "Developer \/ Languages",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "label",
        codepoint: "F315",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "label-off",
        codepoint: "FACA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "label-off-outline",
        codepoint: "FACB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "label-outline",
        codepoint: "F316",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "label-variant",
        codepoint: "FACC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "label-variant-outline",
        codepoint: "FACD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "ladybug",
        codepoint: "F82C",
        aliases: [
            "bugfood",
            "ladybird"
        ],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "lambda",
        codepoint: "F627",
        aliases: [],
        tags: [
            "Gaming \/ RPG",
            "Math"
        ],
    },
    {
        
        name: "lamp",
        codepoint: "F6B4",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "lan",
        codepoint: "F317",
        aliases: [
            "local-area-network"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lan-connect",
        codepoint: "F318",
        aliases: [
            "local-area-network-connect"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lan-disconnect",
        codepoint: "F319",
        aliases: [
            "local-area-network-disconnect"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lan-pending",
        codepoint: "F31A",
        aliases: [
            "local-area-network-pending"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "language-c",
        codepoint: "F671",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "language-cpp",
        codepoint: "F672",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "language-csharp",
        codepoint: "F31B",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "language-css3",
        codepoint: "F31C",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "language-fortran",
        codepoint: "F0245",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "language-go",
        codepoint: "F7D2",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "language-haskell",
        codepoint: "FC6E",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "language-html5",
        codepoint: "F31D",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "language-java",
        codepoint: "FB1C",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "language-javascript",
        codepoint: "F31E",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "language-lua",
        codepoint: "F8B0",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "language-php",
        codepoint: "F31F",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "language-python",
        codepoint: "F320",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "language-python-text",
        codepoint: "F321",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "language-r",
        codepoint: "F7D3",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "language-ruby-on-rails",
        codepoint: "FACE",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "language-swift",
        codepoint: "F6E4",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "language-typescript",
        codepoint: "F6E5",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "laptop",
        codepoint: "F322",
        aliases: [
            "computer"
        ],
        tags: [
            "Device \/ Tech",
            "Home Automation"
        ],
    },
    {
        
        name: "laptop-chromebook",
        codepoint: "F323",
        aliases: [],
        tags: [
            "Device \/ Tech",
            "Home Automation"
        ],
    },
    {
        
        name: "laptop-mac",
        codepoint: "F324",
        aliases: [],
        tags: [
            "Device \/ Tech",
            "Home Automation"
        ],
    },
    {
        
        name: "laptop-off",
        codepoint: "F6E6",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "laptop-windows",
        codepoint: "F325",
        aliases: [],
        tags: [
            "Device \/ Tech",
            "Home Automation"
        ],
    },
    {
        
        name: "laravel",
        codepoint: "FACF",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lasso",
        codepoint: "FF20",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lastfm",
        codepoint: "F326",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "lastpass",
        codepoint: "F446",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "latitude",
        codepoint: "FF74",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "launch",
        codepoint: "F327",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lava-lamp",
        codepoint: "F7D4",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "layers",
        codepoint: "F328",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "layers-minus",
        codepoint: "FE8D",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "layers-off",
        codepoint: "F329",
        aliases: [
            "layers-clear"
        ],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "layers-off-outline",
        codepoint: "F9FC",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "layers-outline",
        codepoint: "F9FD",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "layers-plus",
        codepoint: "FE30",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "layers-remove",
        codepoint: "FE31",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "layers-search",
        codepoint: "F0231",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "layers-search-outline",
        codepoint: "F0232",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "layers-triple",
        codepoint: "FF75",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "layers-triple-outline",
        codepoint: "FF76",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lead-pencil",
        codepoint: "F64F",
        aliases: [],
        tags: [
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "leaf",
        codepoint: "F32A",
        aliases: [],
        tags: [
            "Nature",
            "Food \/ Drink"
        ],
    },
    {
        
        name: "leaf-maple",
        codepoint: "FC6F",
        aliases: [],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "leak",
        codepoint: "FDB3",
        aliases: [
            "proximity-sensor"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "leak-off",
        codepoint: "FDB4",
        aliases: [
            "proximity-sensor-off"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "led-off",
        codepoint: "F32B",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "led-on",
        codepoint: "F32C",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "led-outline",
        codepoint: "F32D",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "led-strip",
        codepoint: "F7D5",
        aliases: [
            "light-strip"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "led-strip-variant",
        codepoint: "F0073",
        aliases: [
            "light-strip-variant"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "led-variant-off",
        codepoint: "F32E",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "led-variant-on",
        codepoint: "F32F",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "led-variant-outline",
        codepoint: "F330",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "leek",
        codepoint: "F01A8",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "less-than",
        codepoint: "F97B",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "less-than-or-equal",
        codepoint: "F97C",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "library",
        codepoint: "F331",
        aliases: [
            "local-library"
        ],
        tags: [
            "Places"
        ],
    },
    {
        
        name: "library-books",
        codepoint: "F332",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "library-movie",
        codepoint: "FCF4",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "library-music",
        codepoint: "F333",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "library-music-outline",
        codepoint: "FF21",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "library-shelves",
        codepoint: "FB85",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "library-video",
        codepoint: "FCF5",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "license",
        codepoint: "FFE3",
        aliases: [
            "ribbon",
            "prize",
            "award",
            "seal"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lifebuoy",
        codepoint: "F87D",
        aliases: [
            "life-preserver",
            "support",
            "help"
        ],
        tags: [
            "Transportation + Water"
        ],
    },
    {
        
        name: "light-switch",
        codepoint: "F97D",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "lightbulb",
        codepoint: "F335",
        aliases: [
            "idea",
            "bulb"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "lightbulb-cfl",
        codepoint: "F0233",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lightbulb-cfl-off",
        codepoint: "F0234",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lightbulb-group",
        codepoint: "F027E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lightbulb-group-outline",
        codepoint: "F027F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lightbulb-multiple",
        codepoint: "F0280",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lightbulb-multiple-outline",
        codepoint: "F0281",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lightbulb-off",
        codepoint: "FE32",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lightbulb-off-outline",
        codepoint: "FE33",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lightbulb-on",
        codepoint: "F6E7",
        aliases: [
            "idea",
            "bulb-on"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "lightbulb-on-outline",
        codepoint: "F6E8",
        aliases: [
            "idea",
            "bulb-on-outline"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "lightbulb-outline",
        codepoint: "F336",
        aliases: [
            "idea",
            "bulb-outline"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "lighthouse",
        codepoint: "F9FE",
        aliases: [
            "beacon"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lighthouse-on",
        codepoint: "F9FF",
        aliases: [
            "beacon"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "link",
        codepoint: "F337",
        aliases: [
            "insert-link"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "link-box",
        codepoint: "FCF6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "link-box-outline",
        codepoint: "FCF7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "link-box-variant",
        codepoint: "FCF8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "link-box-variant-outline",
        codepoint: "FCF9",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "link-lock",
        codepoint: "F00E5",
        aliases: [
            "block-chain"
        ],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "link-off",
        codepoint: "F338",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "link-plus",
        codepoint: "FC70",
        aliases: [
            "link-add"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "link-variant",
        codepoint: "F339",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "link-variant-minus",
        codepoint: "F012A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "link-variant-off",
        codepoint: "F33A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "link-variant-plus",
        codepoint: "F012B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "link-variant-remove",
        codepoint: "F012C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "linkedin",
        codepoint: "F33B",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Social Media"
        ],
    },
    {
        
        name: "linkedin-box",
        codepoint: "F33C",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Social Media"
        ],
    },
    {
        
        name: "linux",
        codepoint: "F33D",
        aliases: [
            "tux"
        ],
        tags: [
            "Animal",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "linux-mint",
        codepoint: "F8EC",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "litecoin",
        codepoint: "FA60",
        aliases: [],
        tags: [
            "Banking",
            "Brand \/ Logo",
            "Currency"
        ],
    },
    {
        
        name: "loading",
        codepoint: "F771",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "location-enter",
        codepoint: "FFE4",
        aliases: [
            "presence-enter"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "location-exit",
        codepoint: "FFE5",
        aliases: [
            "presence-exit"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "lock",
        codepoint: "F33E",
        aliases: [
            "https"
        ],
        tags: [
            "Lock",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "lock-alert",
        codepoint: "F8ED",
        aliases: [
            "lock-warning"
        ],
        tags: [
            "Lock",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "lock-clock",
        codepoint: "F97E",
        aliases: [
            "confidential-mode"
        ],
        tags: [
            "Lock",
            "Date \/ Time"
        ],
    },
    {
        
        name: "lock-open",
        codepoint: "F33F",
        aliases: [],
        tags: [
            "Lock",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "lock-open-outline",
        codepoint: "F340",
        aliases: [],
        tags: [
            "Lock",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "lock-open-variant",
        codepoint: "FFE6",
        aliases: [],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "lock-open-variant-outline",
        codepoint: "FFE7",
        aliases: [],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "lock-outline",
        codepoint: "F341",
        aliases: [],
        tags: [
            "Lock",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "lock-pattern",
        codepoint: "F6E9",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lock-plus",
        codepoint: "F5FB",
        aliases: [
            "enhanced-encryption",
            "lock-add"
        ],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "lock-question",
        codepoint: "F8EE",
        aliases: [
            "forgot-password"
        ],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "lock-reset",
        codepoint: "F772",
        aliases: [
            "password-reset"
        ],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "lock-smart",
        codepoint: "F8B1",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "locker",
        codepoint: "F7D6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "locker-multiple",
        codepoint: "F7D7",
        aliases: [
            "lockers"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "login",
        codepoint: "F342",
        aliases: [
            "log-in",
            "sign-in"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "login-variant",
        codepoint: "F5FC",
        aliases: [
            "log-in-variant",
            "sign-in-variant"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "logout",
        codepoint: "F343",
        aliases: [
            "log-out",
            "sign-out"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "logout-variant",
        codepoint: "F5FD",
        aliases: [
            "log-out-variant",
            "sign-out-variant"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "longitude",
        codepoint: "FF77",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "looks",
        codepoint: "F344",
        aliases: [
            "rainbow"
        ],
        tags: [
            "Weather",
            "Color"
        ],
    },
    {
        
        name: "loupe",
        codepoint: "F345",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "lumx",
        codepoint: "F346",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "lungs",
        codepoint: "F00AF",
        aliases: [],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "lyft",
        codepoint: "FB1D",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "magnet",
        codepoint: "F347",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "magnet-on",
        codepoint: "F348",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "magnify",
        codepoint: "F349",
        aliases: [
            "search"
        ],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "magnify-close",
        codepoint: "F97F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "magnify-minus",
        codepoint: "F34A",
        aliases: [
            "zoom-out",
            "search-minus"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "magnify-minus-cursor",
        codepoint: "FA61",
        aliases: [
            "zoom-out-cursor"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "magnify-minus-outline",
        codepoint: "F6EB",
        aliases: [
            "zoom-out-outline",
            "search-minus-outline"
        ],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "magnify-plus",
        codepoint: "F34B",
        aliases: [
            "zoom-in",
            "magnify-add",
            "search-plus",
            "search-add"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "magnify-plus-cursor",
        codepoint: "FA62",
        aliases: [
            "zoom-in-cursor",
            "magnify-add-cursor"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "magnify-plus-outline",
        codepoint: "F6EC",
        aliases: [
            "zoom-in-outline",
            "magnify-add-outline",
            "search-plus-outline",
            "search-add-outline"
        ],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "magnify-remove-cursor",
        codepoint: "F0237",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "magnify-remove-outline",
        codepoint: "F0238",
        aliases: [],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "mail",
        codepoint: "FED8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "mail-ru",
        codepoint: "F34C",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "mailbox",
        codepoint: "F6ED",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "mailbox-open",
        codepoint: "FD64",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "mailbox-open-outline",
        codepoint: "FD65",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "mailbox-open-up",
        codepoint: "FD66",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "mailbox-open-up-outline",
        codepoint: "FD67",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "mailbox-outline",
        codepoint: "FD68",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "mailbox-up",
        codepoint: "FD69",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "mailbox-up-outline",
        codepoint: "FD6A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "map",
        codepoint: "F34D",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-check",
        codepoint: "FED9",
        aliases: [
            "map-tick"
        ],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-check-outline",
        codepoint: "FEDA",
        aliases: [
            "map-tick-outline"
        ],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-clock",
        codepoint: "FCFA",
        aliases: [
            "timezone"
        ],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-clock-outline",
        codepoint: "FCFB",
        aliases: [
            "timezone-outline"
        ],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-legend",
        codepoint: "FA00",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-marker",
        codepoint: "F34E",
        aliases: [
            "location",
            "address-marker",
            "location-on",
            "place",
            "room"
        ],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-marker-alert",
        codepoint: "FF22",
        aliases: [],
        tags: [
            "Navigation",
            "Alert \/ Error",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-marker-alert-outline",
        codepoint: "FF23",
        aliases: [],
        tags: [
            "Navigation",
            "Alert \/ Error",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-marker-check",
        codepoint: "FC71",
        aliases: [
            "map-marker-tick",
            "where-to-vote"
        ],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-marker-circle",
        codepoint: "F34F",
        aliases: [
            "explore-nearby"
        ],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-marker-distance",
        codepoint: "F8EF",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-marker-down",
        codepoint: "F012D",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-marker-minus",
        codepoint: "F650",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-marker-multiple",
        codepoint: "F350",
        aliases: [
            "map-markers"
        ],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-marker-off",
        codepoint: "F351",
        aliases: [
            "location-off"
        ],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-marker-outline",
        codepoint: "F7D8",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-marker-path",
        codepoint: "FCFC",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-marker-plus",
        codepoint: "F651",
        aliases: [
            "add-location"
        ],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-marker-question",
        codepoint: "FF24",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-marker-question-outline",
        codepoint: "FF25",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-marker-radius",
        codepoint: "F352",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-marker-remove",
        codepoint: "FF26",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-marker-remove-variant",
        codepoint: "FF27",
        aliases: [],
        tags: [
            "Navigation"
        ],
    },
    {
        
        name: "map-marker-up",
        codepoint: "F012E",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-minus",
        codepoint: "F980",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-outline",
        codepoint: "F981",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-plus",
        codepoint: "F982",
        aliases: [
            "map-add"
        ],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-search",
        codepoint: "F983",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "map-search-outline",
        codepoint: "F984",
        aliases: [],
        tags: [
            "Navigation",
            "Geographic Information System"
        ],
    },
    {
        
        name: "mapbox",
        codepoint: "FB86",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "margin",
        codepoint: "F353",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "markdown",
        codepoint: "F354",
        aliases: [],
        tags: [
            "Developer \/ Languages",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "markdown-outline",
        codepoint: "FF78",
        aliases: [],
        tags: [
            "Developer \/ Languages",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "marker",
        codepoint: "F652",
        aliases: [
            "highlighter"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "marker-cancel",
        codepoint: "FDB5",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "marker-check",
        codepoint: "F355",
        aliases: [
            "beenhere",
            "marker-tick"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "mastodon",
        codepoint: "FAD0",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "mastodon-variant",
        codepoint: "FAD1",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "material-design",
        codepoint: "F985",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "material-ui",
        codepoint: "F357",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "math-compass",
        codepoint: "F358",
        aliases: [
            "maths-compass"
        ],
        tags: [
            "Math",
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "math-cos",
        codepoint: "FC72",
        aliases: [
            "math-cosine",
            "maths-cos"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "math-integral",
        codepoint: "FFE8",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "math-integral-box",
        codepoint: "FFE9",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "math-log",
        codepoint: "F00B0",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "math-norm",
        codepoint: "FFEA",
        aliases: [
            "code-or",
            "parallel"
        ],
        tags: [
            "Math",
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "math-norm-box",
        codepoint: "FFEB",
        aliases: [
            "code-or-box",
            "parallel-box"
        ],
        tags: [
            "Math",
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "math-sin",
        codepoint: "FC73",
        aliases: [
            "math-sine",
            "maths-sin"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "math-tan",
        codepoint: "FC74",
        aliases: [
            "math-tangent",
            "maths-tan"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "matrix",
        codepoint: "F628",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "maxcdn",
        codepoint: "F359",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "medal",
        codepoint: "F986",
        aliases: [],
        tags: [
            "Gaming \/ RPG",
            "Sport"
        ],
    },
    {
        
        name: "medical-bag",
        codepoint: "F6EE",
        aliases: [
            "first-aid-kit"
        ],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "meditation",
        codepoint: "F01A6",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "medium",
        codepoint: "F35A",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "meetup",
        codepoint: "FAD2",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "memory",
        codepoint: "F35B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "menu",
        codepoint: "F35C",
        aliases: [
            "hamburger-menu"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "menu-down",
        codepoint: "F35D",
        aliases: [
            "arrow-drop-down"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "menu-down-outline",
        codepoint: "F6B5",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "menu-left",
        codepoint: "F35E",
        aliases: [
            "arrow-left"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "menu-left-outline",
        codepoint: "FA01",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "menu-open",
        codepoint: "FB87",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "menu-right",
        codepoint: "F35F",
        aliases: [
            "arrow-right"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "menu-right-outline",
        codepoint: "FA02",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "menu-swap",
        codepoint: "FA63",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "menu-swap-outline",
        codepoint: "FA64",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "menu-up",
        codepoint: "F360",
        aliases: [
            "arrow-drop-up"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "menu-up-outline",
        codepoint: "F6B6",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "merge",
        codepoint: "FF79",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message",
        codepoint: "F361",
        aliases: [
            "chat-bubble"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-alert",
        codepoint: "F362",
        aliases: [
            "feedback",
            "message-warning",
            "announcement",
            "sms-failed"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "message-alert-outline",
        codepoint: "FA03",
        aliases: [
            "announcement-outline",
            "feedback-outline",
            "message-warning-outline",
            "sms-failed-outline"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "message-bulleted",
        codepoint: "F6A1",
        aliases: [
            "speaker-notes"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-bulleted-off",
        codepoint: "F6A2",
        aliases: [
            "speaker-notes-off"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-draw",
        codepoint: "F363",
        aliases: [
            "rate-review"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-image",
        codepoint: "F364",
        aliases: [
            "mms"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-image-outline",
        codepoint: "F0197",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-lock",
        codepoint: "FFEC",
        aliases: [
            "message-secure"
        ],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "message-lock-outline",
        codepoint: "F0198",
        aliases: [],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "message-minus",
        codepoint: "F0199",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-minus-outline",
        codepoint: "F019A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-outline",
        codepoint: "F365",
        aliases: [
            "chat-bubble-outline"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-plus",
        codepoint: "F653",
        aliases: [
            "message-add"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-plus-outline",
        codepoint: "F00E6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-processing",
        codepoint: "F366",
        aliases: [
            "sms",
            "textsms"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-processing-outline",
        codepoint: "F019B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-reply",
        codepoint: "F367",
        aliases: [
            "mode-comment"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-reply-text",
        codepoint: "F368",
        aliases: [
            "comment",
            "insert-comment"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-settings",
        codepoint: "F6EF",
        aliases: [],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "message-settings-outline",
        codepoint: "F019C",
        aliases: [],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "message-settings-variant",
        codepoint: "F6F0",
        aliases: [],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "message-settings-variant-outline",
        codepoint: "F019D",
        aliases: [],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "message-text",
        codepoint: "F369",
        aliases: [
            "chat"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-text-clock",
        codepoint: "F019E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-text-clock-outline",
        codepoint: "F019F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-text-lock",
        codepoint: "FFED",
        aliases: [
            "message-text-secure"
        ],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "message-text-lock-outline",
        codepoint: "F01A0",
        aliases: [],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "message-text-outline",
        codepoint: "F36A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "message-video",
        codepoint: "F36B",
        aliases: [
            "voice-chat"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "meteor",
        codepoint: "F629",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "metronome",
        codepoint: "F7D9",
        aliases: [
            "tempo",
            "bpm",
            "beats-per-minute"
        ],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "metronome-tick",
        codepoint: "F7DA",
        aliases: [
            "tempo-tick",
            "bpm-tick",
            "beats-per-minute-tick"
        ],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "micro-sd",
        codepoint: "F7DB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "microphone",
        codepoint: "F36C",
        aliases: [
            "keyboard-voice"
        ],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "microphone-minus",
        codepoint: "F8B2",
        aliases: [
            "microphone-remove"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "microphone-off",
        codepoint: "F36D",
        aliases: [
            "mic-off"
        ],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "microphone-outline",
        codepoint: "F36E",
        aliases: [
            "mic-none"
        ],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "microphone-plus",
        codepoint: "F8B3",
        aliases: [
            "microphone-add"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "microphone-settings",
        codepoint: "F36F",
        aliases: [
            "settings-voice"
        ],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "microphone-variant",
        codepoint: "F370",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "microphone-variant-off",
        codepoint: "F371",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "microscope",
        codepoint: "F654",
        aliases: [],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "microsoft",
        codepoint: "F372",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "microsoft-dynamics",
        codepoint: "F987",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "microwave",
        codepoint: "FC75",
        aliases: [
            "microwave-oven"
        ],
        tags: [
            "Home Automation",
            "Food \/ Drink"
        ],
    },
    {
        
        name: "middleware",
        codepoint: "FF7A",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "middleware-outline",
        codepoint: "FF7B",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "midi",
        codepoint: "F8F0",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Music"
        ],
    },
    {
        
        name: "midi-port",
        codepoint: "F8F1",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "mine",
        codepoint: "FDB6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "minecraft",
        codepoint: "F373",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "mini-sd",
        codepoint: "FA04",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "minidisc",
        codepoint: "FA05",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "minus",
        codepoint: "F374",
        aliases: [
            "remove",
            "horizontal-line"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "minus-box",
        codepoint: "F375",
        aliases: [
            "indeterminate-check-box"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "minus-box-multiple",
        codepoint: "F016C",
        aliases: [
            "library-minus"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "minus-box-multiple-outline",
        codepoint: "F016D",
        aliases: [
            "library-minus-outline"
        ],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "minus-box-outline",
        codepoint: "F6F1",
        aliases: [
            "checkbox-indeterminate-outline"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "minus-circle",
        codepoint: "F376",
        aliases: [
            "do-not-disturb-on",
            "remove-circle",
            "do-not-enter"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "minus-circle-outline",
        codepoint: "F377",
        aliases: [
            "remove-circle-outline",
            "do-not-enter-outline"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "minus-network",
        codepoint: "F378",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "minus-network-outline",
        codepoint: "FC76",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 600-899" ],
    },
    {
        
        name: "mirror",
        codepoint: "F0228",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "mixcloud",
        codepoint: "F62A",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "mixed-martial-arts",
        codepoint: "FD6B",
        aliases: [
            "mma",
            "glove"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "mixed-reality",
        codepoint: "F87E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "mixer",
        codepoint: "F7DC",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "molecule",
        codepoint: "FB88",
        aliases: [],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "monitor",
        codepoint: "F379",
        aliases: [
            "desktop-windows"
        ],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "monitor-cellphone",
        codepoint: "F988",
        aliases: [
            "monitor-mobile-phone",
            "monitor-smartphone"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "monitor-cellphone-star",
        codepoint: "F989",
        aliases: [
            "important-devices",
            "monitor-mobile-phone-star",
            "monitor-smartphone-star"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "monitor-clean",
        codepoint: "F012F",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "monitor-dashboard",
        codepoint: "FA06",
        aliases: [],
        tags: [
            "Device \/ Tech",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "monitor-lock",
        codepoint: "FDB7",
        aliases: [],
        tags: [
            "Device \/ Tech",
            "Lock"
        ],
    },
    {
        
        name: "monitor-multiple",
        codepoint: "F37A",
        aliases: [
            "monitors"
        ],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "monitor-off",
        codepoint: "FD6C",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "monitor-screenshot",
        codepoint: "FE34",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "monitor-speaker",
        codepoint: "FF7C",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "monitor-speaker-off",
        codepoint: "FF7D",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "monitor-star",
        codepoint: "FDB8",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "moon-first-quarter",
        codepoint: "FF7E",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "moon-full",
        codepoint: "FF7F",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "moon-last-quarter",
        codepoint: "FF80",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "moon-new",
        codepoint: "FF81",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "moon-waning-crescent",
        codepoint: "FF82",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "moon-waning-gibbous",
        codepoint: "FF83",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "moon-waxing-crescent",
        codepoint: "FF84",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "moon-waxing-gibbous",
        codepoint: "FF85",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "moped",
        codepoint: "F00B1",
        aliases: [
            "scooter",
            "vespa",
            "delivery-dining"
        ],
        tags: [
            "Transportation + Road",
            "Transportation + Other"
        ],
    },
    {
        
        name: "more",
        codepoint: "F37B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "mother-nurse",
        codepoint: "FCFD",
        aliases: [
            "breast-feed"
        ],
        tags: [
            "Medical \/ Hospital",
            "People \/ Family"
        ],
    },
    {
        
        name: "motion-sensor",
        codepoint: "FD6D",
        aliases: [
            "motion-detector"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "motorbike",
        codepoint: "F37C",
        aliases: [
            "motorcycle"
        ],
        tags: [
            "Transportation + Road",
            "Sport"
        ],
    },
    {
        
        name: "mouse",
        codepoint: "F37D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "mouse-bluetooth",
        codepoint: "F98A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "mouse-off",
        codepoint: "F37E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "mouse-variant",
        codepoint: "F37F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "mouse-variant-off",
        codepoint: "F380",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "move-resize",
        codepoint: "F655",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "move-resize-variant",
        codepoint: "F656",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "movie",
        codepoint: "F381",
        aliases: [
            "slate",
            "clapperboard",
            "film",
            "movie-creation"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "movie-edit",
        codepoint: "F014D",
        aliases: [],
        tags: [
            "Video \/ Movie",
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "movie-edit-outline",
        codepoint: "F014E",
        aliases: [],
        tags: [
            "Video \/ Movie",
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "movie-filter",
        codepoint: "F014F",
        aliases: [],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "movie-filter-outline",
        codepoint: "F0150",
        aliases: [],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "movie-open",
        codepoint: "FFEE",
        aliases: [
            "slate-open",
            "clapperboard-open",
            "film-open",
            "movie-creation"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "movie-open-outline",
        codepoint: "FFEF",
        aliases: [
            "slate-open-outline",
            "clapperboard-open-outline",
            "film-open-outline",
            "movie-creation"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "movie-outline",
        codepoint: "FDB9",
        aliases: [
            "slate-outline",
            "clapperboard-outline",
            "film-outline"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "movie-roll",
        codepoint: "F7DD",
        aliases: [
            "film-reel"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "movie-search",
        codepoint: "F01FD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "movie-search-outline",
        codepoint: "F01FE",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "muffin",
        codepoint: "F98B",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "multiplication",
        codepoint: "F382",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "multiplication-box",
        codepoint: "F383",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "mushroom",
        codepoint: "F7DE",
        aliases: [
            "fungus"
        ],
        tags: [
            "Nature",
            "Food \/ Drink"
        ],
    },
    {
        
        name: "mushroom-outline",
        codepoint: "F7DF",
        aliases: [
            "fungus-outline"
        ],
        tags: [
            "Nature",
            "Food \/ Drink"
        ],
    },
    {
        
        name: "music",
        codepoint: "F759",
        aliases: [],
        tags: [
            "Audio",
            "Music"
        ],
    },
    {
        
        name: "music-accidental-double-flat",
        codepoint: "FF86",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-accidental-double-sharp",
        codepoint: "FF87",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-accidental-flat",
        codepoint: "FF88",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-accidental-natural",
        codepoint: "FF89",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-accidental-sharp",
        codepoint: "FF8A",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-box",
        codepoint: "F384",
        aliases: [],
        tags: [
            "Audio",
            "Music"
        ],
    },
    {
        
        name: "music-box-outline",
        codepoint: "F385",
        aliases: [],
        tags: [
            "Audio",
            "Music"
        ],
    },
    {
        
        name: "music-circle",
        codepoint: "F386",
        aliases: [
            "note-circle"
        ],
        tags: [
            "Audio",
            "Music"
        ],
    },
    {
        
        name: "music-circle-outline",
        codepoint: "FAD3",
        aliases: [
            "note-circle-outline"
        ],
        tags: [
            "Music",
            "Audio"
        ],
    },
    {
        
        name: "music-clef-alto",
        codepoint: "FF8B",
        aliases: [
            "music-c-clef",
            "music-clef-tenor",
            "music-clef-soprano",
            "music-clef-baritone"
        ],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-clef-bass",
        codepoint: "FF8C",
        aliases: [
            "music-f-clef"
        ],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-clef-treble",
        codepoint: "FF8D",
        aliases: [
            "music-g-clef"
        ],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-note",
        codepoint: "F387",
        aliases: [],
        tags: [
            "Audio",
            "Music"
        ],
    },
    {
        
        name: "music-note-bluetooth",
        codepoint: "F5FE",
        aliases: [],
        tags: [
            "Audio"
        ],
    },
    {
        
        name: "music-note-bluetooth-off",
        codepoint: "F5FF",
        aliases: [],
        tags: [
            "Audio"
        ],
    },
    {
        
        name: "music-note-eighth",
        codepoint: "F388",
        aliases: [],
        tags: [
            "Audio",
            "Music"
        ],
    },
    {
        
        name: "music-note-eighth-dotted",
        codepoint: "FF8E",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-note-half",
        codepoint: "F389",
        aliases: [],
        tags: [
            "Audio",
            "Music"
        ],
    },
    {
        
        name: "music-note-half-dotted",
        codepoint: "FF8F",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-note-off",
        codepoint: "F38A",
        aliases: [],
        tags: [
            "Audio",
            "Music"
        ],
    },
    {
        
        name: "music-note-off-outline",
        codepoint: "FF90",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-note-outline",
        codepoint: "FF91",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-note-plus",
        codepoint: "FDBA",
        aliases: [
            "music-note-add"
        ],
        tags: [
            "Audio",
            "Music"
        ],
    },
    {
        
        name: "music-note-quarter",
        codepoint: "F38B",
        aliases: [],
        tags: [
            "Audio",
            "Music"
        ],
    },
    {
        
        name: "music-note-quarter-dotted",
        codepoint: "FF92",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-note-sixteenth",
        codepoint: "F38C",
        aliases: [],
        tags: [
            "Audio",
            "Music"
        ],
    },
    {
        
        name: "music-note-sixteenth-dotted",
        codepoint: "FF93",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-note-whole",
        codepoint: "F38D",
        aliases: [],
        tags: [
            "Audio",
            "Music"
        ],
    },
    {
        
        name: "music-note-whole-dotted",
        codepoint: "FF94",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-off",
        codepoint: "F75A",
        aliases: [],
        tags: [
            "Audio",
            "Music"
        ],
    },
    {
        
        name: "music-rest-eighth",
        codepoint: "FF95",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-rest-half",
        codepoint: "FF96",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-rest-quarter",
        codepoint: "FF97",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-rest-sixteenth",
        codepoint: "FF98",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "music-rest-whole",
        codepoint: "FF99",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "nail",
        codepoint: "FDBB",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "nas",
        codepoint: "F8F2",
        aliases: [
            "network-attached-storage"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "nativescript",
        codepoint: "F87F",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "nature",
        codepoint: "F38E",
        aliases: [
            "plant"
        ],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "nature-people",
        codepoint: "F38F",
        aliases: [
            "plant"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "navigation",
        codepoint: "F390",
        aliases: [
            "arrow-compass"
        ],
        tags: [
            "Navigation"
        ],
    },
    {
        
        name: "near-me",
        codepoint: "F5CD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "necklace",
        codepoint: "FF28",
        aliases: [],
        tags: [
            "Clothing"
        ],
    },
    {
        
        name: "needle",
        codepoint: "F391",
        aliases: [
            "syringe",
            "injection"
        ],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "netflix",
        codepoint: "F745",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "network",
        codepoint: "F6F2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "network-off",
        codepoint: "FC77",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "network-off-outline",
        codepoint: "FC78",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "network-outline",
        codepoint: "FC79",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "network-router",
        codepoint: "F00B2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "network-strength-1",
        codepoint: "F8F3",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "network-strength-1-alert",
        codepoint: "F8F4",
        aliases: [
            "network-strength-1-warning"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "network-strength-2",
        codepoint: "F8F5",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "network-strength-2-alert",
        codepoint: "F8F6",
        aliases: [
            "network-strength-2-warning"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "network-strength-3",
        codepoint: "F8F7",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "network-strength-3-alert",
        codepoint: "F8F8",
        aliases: [
            "network-strength-3-warning"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "network-strength-4",
        codepoint: "F8F9",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "network-strength-4-alert",
        codepoint: "F8FA",
        aliases: [
            "network-strength-4-warning"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "network-strength-off",
        codepoint: "F8FB",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "network-strength-off-outline",
        codepoint: "F8FC",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "network-strength-outline",
        codepoint: "F8FD",
        aliases: [
            "network-strength-0"
        ],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "new-box",
        codepoint: "F394",
        aliases: [
            "fiber-new"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "newspaper",
        codepoint: "F395",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "newspaper-minus",
        codepoint: "FF29",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "newspaper-plus",
        codepoint: "FF2A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "newspaper-variant",
        codepoint: "F0023",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "newspaper-variant-multiple",
        codepoint: "F0024",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "newspaper-variant-multiple-outline",
        codepoint: "F0025",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "newspaper-variant-outline",
        codepoint: "F0026",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "nfc",
        codepoint: "F396",
        aliases: [
            "near-field-communication"
        ],
        tags: [
            "Currency"
        ],
    },
    {
        
        name: "nfc-off",
        codepoint: "FE35",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "nfc-search-variant",
        codepoint: "FE36",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "nfc-tap",
        codepoint: "F397",
        aliases: [
            "near-field-communication-tap"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "nfc-variant",
        codepoint: "F398",
        aliases: [
            "near-field-communication-variant"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "nfc-variant-off",
        codepoint: "FE37",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "ninja",
        codepoint: "F773",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "nintendo-switch",
        codepoint: "F7E0",
        aliases: [
            "nintendo-switch-online"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "nix",
        codepoint: "F0130",
        aliases: [],
        tags: [
            "Developer \/ Languages",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "nodejs",
        codepoint: "F399",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "noodles",
        codepoint: "F01A9",
        aliases: [
            "food-ramen",
            "asian-noodles"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "not-equal",
        codepoint: "F98C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "not-equal-variant",
        codepoint: "F98D",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "note",
        codepoint: "F39A",
        aliases: [
            "paper"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "note-multiple",
        codepoint: "F6B7",
        aliases: [
            "notes"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "note-multiple-outline",
        codepoint: "F6B8",
        aliases: [
            "notes-outline"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "note-outline",
        codepoint: "F39B",
        aliases: [
            "paper-outline"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "note-plus",
        codepoint: "F39C",
        aliases: [
            "note-add"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "note-plus-outline",
        codepoint: "F39D",
        aliases: [
            "note-add-outline"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "note-text",
        codepoint: "F39E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "note-text-outline",
        codepoint: "F0202",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "notebook",
        codepoint: "F82D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "notebook-multiple",
        codepoint: "FE38",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "notebook-outline",
        codepoint: "FEDC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "notification-clear-all",
        codepoint: "F39F",
        aliases: [],
        tags: [
            "Notification"
        ],
    },
    {
        
        name: "npm",
        codepoint: "F6F6",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "npm-variant",
        codepoint: "F98E",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "npm-variant-outline",
        codepoint: "F98F",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "nuke",
        codepoint: "F6A3",
        aliases: [
            "nuclear",
            "atomic-bomb"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "null",
        codepoint: "F7E1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "numeric",
        codepoint: "F3A0",
        aliases: [
            "numbers",
            "1-2-3",
            "one-two-three",
            "123"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-0",
        codepoint: "0030",
        aliases: [
            "number-0",
            "numeric-zero"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-0-box",
        codepoint: "F3A1",
        aliases: [
            "numeric-zero-box",
            "number-0-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-0-box-multiple",
        codepoint: "FF2B",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-0-box-multiple-outline",
        codepoint: "F3A2",
        aliases: [
            "numeric-zero-box-multiple-outline",
            "numeric-0-boxes-outline",
            "number-0-box-multiple-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-0-box-outline",
        codepoint: "F3A3",
        aliases: [
            "numeric-zero-box-outline",
            "number-0-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-0-circle",
        codepoint: "FC7A",
        aliases: [
            "numeric-zero-circle",
            "number-0-circle",
            "number-zero-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-0-circle-outline",
        codepoint: "FC7B",
        aliases: [
            "numeric-zero-circle-outline",
            "number-0-circle-outline",
            "number-zero-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-1",
        codepoint: "0031",
        aliases: [
            "number-1",
            "numeric-one"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-1-box",
        codepoint: "F3A4",
        aliases: [
            "looks-one",
            "numeric-one-box",
            "number-1-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-1-box-multiple",
        codepoint: "FF2C",
        aliases: [],
        tags: [
            "Alpha \/ Numeric",
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-1-box-multiple-outline",
        codepoint: "F3A5",
        aliases: [
            "filter-1",
            "numeric-one-box-multiple-outline",
            "numeric-1-boxes-outline",
            "number-1-box-multiple-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-1-box-outline",
        codepoint: "F3A6",
        aliases: [
            "numeric-one-box-outline",
            "number-1-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-1-circle",
        codepoint: "FC7C",
        aliases: [
            "numeric-one-circle",
            "number-1-circle",
            "number-one-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-1-circle-outline",
        codepoint: "FC7D",
        aliases: [
            "numeric-one-circle-outline",
            "number-1-circle-outline",
            "number-one-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-10",
        codepoint: "F000A",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-10-box",
        codepoint: "FF9A",
        aliases: [],
        tags: [
            "Alpha \/ Numeric",
            "Alpha \/ Numeric",
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-10-box-multiple",
        codepoint: "F000B",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-10-box-multiple-outline",
        codepoint: "F000C",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-10-box-outline",
        codepoint: "FF9B",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-10-circle",
        codepoint: "F000D",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-10-circle-outline",
        codepoint: "F000E",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-2",
        codepoint: "0032",
        aliases: [
            "number-2",
            "numeric-two"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-2-box",
        codepoint: "F3A7",
        aliases: [
            "looks-two",
            "numeric-two-box",
            "number-2-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-2-box-multiple",
        codepoint: "FF2D",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-2-box-multiple-outline",
        codepoint: "F3A8",
        aliases: [
            "filter-2",
            "numeric-two-box-multiple-outline",
            "numeric-2-boxes-outline",
            "number-2-box-multiple-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-2-box-outline",
        codepoint: "F3A9",
        aliases: [
            "numeric-two-box-outline",
            "number-2-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-2-circle",
        codepoint: "FC7E",
        aliases: [
            "numeric-two-circle",
            "number-2-circle",
            "number-two-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-2-circle-outline",
        codepoint: "FC7F",
        aliases: [
            "numeric-two-circle-outline",
            "number-2-circle-outline",
            "number-two-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-3",
        codepoint: "0033",
        aliases: [
            "number-3",
            "numeric-three"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-3-box",
        codepoint: "F3AA",
        aliases: [
            "looks-3",
            "numeric-three-box",
            "number-3-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-3-box-multiple",
        codepoint: "FF2E",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-3-box-multiple-outline",
        codepoint: "F3AB",
        aliases: [
            "filter-3",
            "numeric-three-box-multiple-outline",
            "numeric-3-boxes-outline",
            "number-3-box-multiple-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-3-box-outline",
        codepoint: "F3AC",
        aliases: [
            "numeric-three-box-outline",
            "number-3-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-3-circle",
        codepoint: "FC80",
        aliases: [
            "numeric-three-circle",
            "number-3-circle",
            "number-three-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-3-circle-outline",
        codepoint: "FC81",
        aliases: [
            "numeric-three-circle-outline",
            "number-3-circle-outline",
            "number-three-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-4",
        codepoint: "0034",
        aliases: [
            "number-4",
            "numeric-four"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-4-box",
        codepoint: "F3AD",
        aliases: [
            "looks-4",
            "numeric-four-box",
            "number-4-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-4-box-multiple",
        codepoint: "FF2F",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-4-box-multiple-outline",
        codepoint: "F3AE",
        aliases: [
            "filter-4",
            "numeric-four-box-multiple-outline",
            "numeric-4-boxes-outline",
            "number-4-box-multiple-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-4-box-outline",
        codepoint: "F3AF",
        aliases: [
            "numeric-four-box-outline",
            "number-4-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-4-circle",
        codepoint: "FC82",
        aliases: [
            "numeric-four-circle",
            "number-4-circle",
            "number-four-circle"
        ],
        tags: [
            "Alpha \/ Numeric",
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-4-circle-outline",
        codepoint: "FC83",
        aliases: [
            "numeric-four-circle-outline",
            "number-4-circle-outline",
            "number-four-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-5",
        codepoint: "0035",
        aliases: [
            "number-5",
            "numeric-five"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-5-box",
        codepoint: "F3B0",
        aliases: [
            "looks-5",
            "numeric-five-box",
            "number-5-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-5-box-multiple",
        codepoint: "FF30",
        aliases: [],
        tags: [
            "Alpha \/ Numeric",
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-5-box-multiple-outline",
        codepoint: "F3B1",
        aliases: [
            "filter-5",
            "numeric-five-box-multiple-outline",
            "numeric-5-boxes-outline",
            "number-5-box-multiple-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-5-box-outline",
        codepoint: "F3B2",
        aliases: [
            "numeric-five-box-outline",
            "number-5-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-5-circle",
        codepoint: "FC84",
        aliases: [
            "numeric-five-circle",
            "number-5-circle",
            "number-five-circle"
        ],
        tags: [
            "Alpha \/ Numeric",
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-5-circle-outline",
        codepoint: "FC85",
        aliases: [
            "numeric-five-circle-outline",
            "number-5-circle-outline",
            "number-five-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-6",
        codepoint: "0036",
        aliases: [
            "number-6",
            "numeric-six"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-6-box",
        codepoint: "F3B3",
        aliases: [
            "looks-6",
            "numeric-six-box",
            "number-6-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-6-box-multiple",
        codepoint: "FF31",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-6-box-multiple-outline",
        codepoint: "F3B4",
        aliases: [
            "filter-6",
            "numeric-six-box-multiple-outline",
            "numeric-6-boxes-outline",
            "number-6-box-multiple-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-6-box-outline",
        codepoint: "F3B5",
        aliases: [
            "numeric-six-box-outline",
            "number-6-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-6-circle",
        codepoint: "FC86",
        aliases: [
            "numeric-six-circle",
            "number-6-circle",
            "number-six-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-6-circle-outline",
        codepoint: "FC87",
        aliases: [
            "numeric-six-circle-outline",
            "number-6-circle-outline",
            "number-six-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-7",
        codepoint: "0037",
        aliases: [
            "number-7",
            "numeric-seven"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-7-box",
        codepoint: "F3B6",
        aliases: [
            "numeric-seven-box",
            "number-7-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-7-box-multiple",
        codepoint: "FF32",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-7-box-multiple-outline",
        codepoint: "F3B7",
        aliases: [
            "filter-7",
            "numeric-seven-box-multiple-outline",
            "numeric-7-boxes-outline",
            "number-7-box-multiple-outline"
        ],
        tags: [
            "Alpha \/ Numeric",
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-7-box-outline",
        codepoint: "F3B8",
        aliases: [
            "numeric-seven-box-outline",
            "number-7-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-7-circle",
        codepoint: "FC88",
        aliases: [
            "numeric-seven-circle",
            "number-7-circle",
            "number-seven-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-7-circle-outline",
        codepoint: "FC89",
        aliases: [
            "numeric-seven-circle-outline",
            "number-7-circle-outline",
            "number-seven-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-8",
        codepoint: "0038",
        aliases: [
            "number-8",
            "numeric-eight"
        ],
        tags: [
            "Alpha \/ Numeric",
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-8-box",
        codepoint: "F3B9",
        aliases: [
            "numeric-eight-box",
            "number-8-box"
        ],
        tags: [
            "Alpha \/ Numeric",
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-8-box-multiple",
        codepoint: "FF33",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-8-box-multiple-outline",
        codepoint: "F3BA",
        aliases: [
            "filter-8",
            "numeric-eight-box-multiple-outline",
            "numeric-8-boxes-outline",
            "number-8-box-multiple-outline"
        ],
        tags: [
            "Alpha \/ Numeric",
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-8-box-outline",
        codepoint: "F3BB",
        aliases: [
            "numeric-eight-box-outline",
            "number-8-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-8-circle",
        codepoint: "FC8A",
        aliases: [
            "numeric-eight-circle",
            "number-8-circle",
            "number-eight-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-8-circle-outline",
        codepoint: "FC8B",
        aliases: [
            "numeric-eight-circle-outline",
            "number-8-circle-outline",
            "number-eight-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-9",
        codepoint: "0039",
        aliases: [
            "number-9",
            "numeric-nine"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-9-box",
        codepoint: "F3BC",
        aliases: [
            "numeric-nine-box",
            "number-9-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-9-box-multiple",
        codepoint: "FF34",
        aliases: [],
        tags: [
            "Alpha \/ Numeric",
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-9-box-multiple-outline",
        codepoint: "F3BD",
        aliases: [
            "filter-9",
            "numeric-nine-box-multiple-outline",
            "numeric-9-boxes-outline",
            "number-9-box-multiple-outline"
        ],
        tags: [
            "Alpha \/ Numeric",
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-9-box-outline",
        codepoint: "F3BE",
        aliases: [
            "numeric-nine-box-outline",
            "number-9-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric",
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-9-circle",
        codepoint: "FC8C",
        aliases: [
            "numeric-nine-circle",
            "number-9-circle",
            "number-nine-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-9-circle-outline",
        codepoint: "FC8D",
        aliases: [
            "numeric-nine-circle-outline",
            "number-9-circle-outline",
            "number-nine-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-9-plus",
        codepoint: "F000F",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-9-plus-box",
        codepoint: "F3BF",
        aliases: [
            "numeric-nine-plus-box",
            "number-9-plus-box"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-9-plus-box-multiple",
        codepoint: "FF35",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-9-plus-box-multiple-outline",
        codepoint: "F3C0",
        aliases: [
            "filter-9-plus",
            "numeric-nine-plus-box-multiple-outline",
            "numeric-9-plus-boxes-outline",
            "number-9-plus-box-multiple-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-9-plus-box-outline",
        codepoint: "F3C1",
        aliases: [
            "numeric-nine-plus-box-outline",
            "number-9-plus-box-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-9-plus-circle",
        codepoint: "FC8E",
        aliases: [
            "numeric-nine-plus-circle",
            "number-9-plus-circle",
            "number-nine-plus-circle"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-9-plus-circle-outline",
        codepoint: "FC8F",
        aliases: [
            "numeric-nine-plus-circle-outline",
            "number-9-plus-circle-outline",
            "number-nine-plus-circle-outline"
        ],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "numeric-negative-1",
        codepoint: "F0074",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "nut",
        codepoint: "F6F7",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "nutrition",
        codepoint: "F3C2",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "nuxt",
        codepoint: "F0131",
        aliases: [],
        tags: [
            "Developer \/ Languages",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "oar",
        codepoint: "F67B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "ocarina",
        codepoint: "FDBC",
        aliases: [],
        tags: [
            "Music",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "ocr",
        codepoint: "F0165",
        aliases: [
            "optical-character-recognition"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "octagon",
        codepoint: "F3C3",
        aliases: [],
        tags: [
            "Shape",
            "Transportation + Road"
        ],
    },
    {
        
        name: "octagon-outline",
        codepoint: "F3C4",
        aliases: [],
        tags: [
            "Shape",
            "Transportation + Road"
        ],
    },
    {
        
        name: "octagram",
        codepoint: "F6F8",
        aliases: [
            "starburst"
        ],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "octagram-outline",
        codepoint: "F774",
        aliases: [
            "starburst-outline"
        ],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "odnoklassniki",
        codepoint: "F3C5",
        aliases: [
            "ok-ru"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "offer",
        codepoint: "F0246",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "office",
        codepoint: "F3C6",
        aliases: [
            "microsoft-office"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "office-building",
        codepoint: "F990",
        aliases: [],
        tags: [
            "Places"
        ],
    },
    {
        
        name: "oil",
        codepoint: "F3C7",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "oil-lamp",
        codepoint: "FF36",
        aliases: [
            "wish",
            "genie-lamp"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "oil-level",
        codepoint: "F0075",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "oil-temperature",
        codepoint: "F0019",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "omega",
        codepoint: "F3C9",
        aliases: [
            "ohm",
            "electrical-resistance"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "one-up",
        codepoint: "FB89",
        aliases: [
            "1up",
            "extra-life"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "onedrive",
        codepoint: "F3CA",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "onenote",
        codepoint: "F746",
        aliases: [
            "microsoft-onenote"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "onepassword",
        codepoint: "F880",
        aliases: [
            "1password"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "opacity",
        codepoint: "F5CC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "open-in-app",
        codepoint: "F3CB",
        aliases: [
            "open-in-browser"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "open-in-new",
        codepoint: "F3CC",
        aliases: [
            "external-link"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "open-source-initiative",
        codepoint: "FB8A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "openid",
        codepoint: "F3CD",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "opera",
        codepoint: "F3CE",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "orbit",
        codepoint: "F018",
        aliases: [],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "origin",
        codepoint: "FB2B",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "ornament",
        codepoint: "F3CF",
        aliases: [],
        tags: [
            "Holiday"
        ],
    },
    {
        
        name: "ornament-variant",
        codepoint: "F3D0",
        aliases: [],
        tags: [
            "Holiday"
        ],
    },
    {
        
        name: "outdoor-lamp",
        codepoint: "F0076",
        aliases: [
            "outdoor-light"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "outlook",
        codepoint: "FCFE",
        aliases: [
            "microsoft-outlook"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "overscan",
        codepoint: "F0027",
        aliases: [
            "fullscreen"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "owl",
        codepoint: "F3D2",
        aliases: [],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "pac-man",
        codepoint: "FB8B",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "package",
        codepoint: "F3D3",
        aliases: [
            "box"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "package-down",
        codepoint: "F3D4",
        aliases: [
            "archive",
            "box-down"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "package-up",
        codepoint: "F3D5",
        aliases: [
            "unarchive",
            "box-up"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "package-variant",
        codepoint: "F3D6",
        aliases: [
            "box-variant"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "package-variant-closed",
        codepoint: "F3D7",
        aliases: [
            "box-variant-closed"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "page-first",
        codepoint: "F600",
        aliases: [
            "first-page"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "page-last",
        codepoint: "F601",
        aliases: [
            "last-page"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "page-layout-body",
        codepoint: "F6F9",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "page-layout-footer",
        codepoint: "F6FA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "page-layout-header",
        codepoint: "F6FB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "page-layout-header-footer",
        codepoint: "FF9C",
        aliases: [
            "page-layout-marginals"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "page-layout-sidebar-left",
        codepoint: "F6FC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "page-layout-sidebar-right",
        codepoint: "F6FD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "page-next",
        codepoint: "FB8C",
        aliases: [
            "read-more"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "page-next-outline",
        codepoint: "FB8D",
        aliases: [
            "read-more-outline"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "page-previous",
        codepoint: "FB8E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "page-previous-outline",
        codepoint: "FB8F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "palette",
        codepoint: "F3D8",
        aliases: [
            "color-lens",
            "colour-lens"
        ],
        tags: [
            "Color",
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "palette-advanced",
        codepoint: "F3D9",
        aliases: [],
        tags: [
            "Color",
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "palette-outline",
        codepoint: "FE6C",
        aliases: [],
        tags: [
            "Drawing \/ Art",
            "Color",
            "Geographic Information System"
        ],
    },
    {
        
        name: "palette-swatch",
        codepoint: "F8B4",
        aliases: [
            "style"
        ],
        tags: [
            "Drawing \/ Art",
            "Color"
        ],
    },
    {
        
        name: "palm-tree",
        codepoint: "F0077",
        aliases: [],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "pan",
        codepoint: "FB90",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pan-bottom-left",
        codepoint: "FB91",
        aliases: [
            "pan-down-left"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pan-bottom-right",
        codepoint: "FB92",
        aliases: [
            "pan-down-right"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pan-down",
        codepoint: "FB93",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pan-horizontal",
        codepoint: "FB94",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pan-left",
        codepoint: "FB95",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pan-right",
        codepoint: "FB96",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pan-top-left",
        codepoint: "FB97",
        aliases: [
            "pan-up-left"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pan-top-right",
        codepoint: "FB98",
        aliases: [
            "pan-up-right"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pan-up",
        codepoint: "FB99",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pan-vertical",
        codepoint: "FB9A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "panda",
        codepoint: "F3DA",
        aliases: [],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "pandora",
        codepoint: "F3DB",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "panorama",
        codepoint: "F3DC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "panorama-fisheye",
        codepoint: "F3DD",
        aliases: [
            "panorama-fish-eye"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "panorama-horizontal",
        codepoint: "F3DE",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "panorama-vertical",
        codepoint: "F3DF",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "panorama-wide-angle",
        codepoint: "F3E0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "paper-cut-vertical",
        codepoint: "F3E1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "paper-roll",
        codepoint: "F0182",
        aliases: [
            "lavatory-roll",
            "bathroom-tissue",
            "toilet-paper",
            "kitchen-roll",
            "paper-towels",
            "receipt-roll"
        ],
        tags: [
            "Home Automation",
            "Printer"
        ],
    },
    {
        
        name: "paper-roll-outline",
        codepoint: "F0183",
        aliases: [
            "lavatory-roll-outline",
            "bathroom-tissue-outline",
            "kitchen-roll-outline",
            "paper-towels-outline",
            "toilet-paper-outline",
            "receipt-roll-outline"
        ],
        tags: [
            "Home Automation",
            "Printer"
        ],
    },
    {
        
        name: "paperclip",
        codepoint: "F3E2",
        aliases: [
            "attachment-vertical",
            "attach-file"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "parachute",
        codepoint: "FC90",
        aliases: [],
        tags: [
            "Transportation + Flying"
        ],
    },
    {
        
        name: "parachute-outline",
        codepoint: "FC91",
        aliases: [],
        tags: [
            "Transportation + Flying"
        ],
    },
    {
        
        name: "parking",
        codepoint: "F3E3",
        aliases: [
            "car-park",
            "local-parking"
        ],
        tags: [
            "Places"
        ],
    },
    {
        
        name: "party-popper",
        codepoint: "F0078",
        aliases: [
            "celebration"
        ],
        tags: [
            "Holiday"
        ],
    },
    {
        
        name: "passport",
        codepoint: "F7E2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "passport-biometric",
        codepoint: "FDBD",
        aliases: [
            "passport-electronic"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pasta",
        codepoint: "F018B",
        aliases: [
            "food-italian",
            "spaghetti"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "patio-heater",
        codepoint: "FF9D",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "patreon",
        codepoint: "F881",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "pause",
        codepoint: "F3E4",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "pause-circle",
        codepoint: "F3E5",
        aliases: [
            "pause-circle-filled"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pause-circle-outline",
        codepoint: "F3E6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pause-octagon",
        codepoint: "F3E7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pause-octagon-outline",
        codepoint: "F3E8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "paw",
        codepoint: "F3E9",
        aliases: [
            "pets"
        ],
        tags: [
            "Animal",
            "Nature"
        ],
    },
    {
        
        name: "paw-off",
        codepoint: "F657",
        aliases: [],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "paypal",
        codepoint: "F882",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "pdf-box",
        codepoint: "FE39",
        aliases: [],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "peace",
        codepoint: "F883",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "peanut",
        codepoint: "F001E",
        aliases: [
            "allergen",
            "food-allergy"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "peanut-off",
        codepoint: "F001F",
        aliases: [
            "allergen-off",
            "food-allergy-off"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "peanut-off-outline",
        codepoint: "F0021",
        aliases: [
            "allergen-off-outline",
            "food-allergy-off-outline"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "peanut-outline",
        codepoint: "F0020",
        aliases: [
            "allergen-outline",
            "food-allergy-outline"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "pen",
        codepoint: "F3EA",
        aliases: [],
        tags: [
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "pen-lock",
        codepoint: "FDBE",
        aliases: [],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "pen-minus",
        codepoint: "FDBF",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pen-off",
        codepoint: "FDC0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pen-plus",
        codepoint: "FDC1",
        aliases: [
            "pen-add"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pen-remove",
        codepoint: "FDC2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pencil",
        codepoint: "F3EB",
        aliases: [
            "edit",
            "create",
            "mode-edit"
        ],
        tags: [
            "Drawing \/ Art",
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "pencil-box",
        codepoint: "F3EC",
        aliases: [],
        tags: [
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "pencil-box-multiple",
        codepoint: "F016F",
        aliases: [
            "library-edit"
        ],
        tags: [
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "pencil-box-multiple-outline",
        codepoint: "F0170",
        aliases: [
            "library-edit-outline"
        ],
        tags: [
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "pencil-box-outline",
        codepoint: "F3ED",
        aliases: [],
        tags: [
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "pencil-circle",
        codepoint: "F6FE",
        aliases: [],
        tags: [
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "pencil-circle-outline",
        codepoint: "F775",
        aliases: [],
        tags: [
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "pencil-lock",
        codepoint: "F3EE",
        aliases: [],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "pencil-lock-outline",
        codepoint: "FDC3",
        aliases: [],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "pencil-minus",
        codepoint: "FDC4",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pencil-minus-outline",
        codepoint: "FDC5",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pencil-off",
        codepoint: "F3EF",
        aliases: [
            "edit-off"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pencil-off-outline",
        codepoint: "FDC6",
        aliases: [
            "edit-off-outline"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pencil-outline",
        codepoint: "FC92",
        aliases: [
            "edit-outline",
            "create-outline",
            "mode-edit-outline"
        ],
        tags: [
            "Drawing \/ Art",
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "pencil-plus",
        codepoint: "FDC7",
        aliases: [
            "pencil-add"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pencil-plus-outline",
        codepoint: "FDC8",
        aliases: [
            "pencil-add-outline"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pencil-remove",
        codepoint: "FDC9",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pencil-remove-outline",
        codepoint: "FDCA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "penguin",
        codepoint: "FEDD",
        aliases: [],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "pentagon",
        codepoint: "F6FF",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "pentagon-outline",
        codepoint: "F700",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "percent",
        codepoint: "F3F0",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "periodic-table",
        codepoint: "F8B5",
        aliases: [],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "periodic-table-co2",
        codepoint: "F7E3",
        aliases: [
            "periodic-table-carbon-dioxide"
        ],
        tags: [
            "Science",
            "Home Automation"
        ],
    },
    {
        
        name: "periscope",
        codepoint: "F747",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "perspective-less",
        codepoint: "FCFF",
        aliases: [
            "perspective-decrease"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "perspective-more",
        codepoint: "FD00",
        aliases: [
            "perspective-increase"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "pharmacy",
        codepoint: "F3F1",
        aliases: [
            "chemist",
            "local-pharmacy"
        ],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "phone",
        codepoint: "F3F2",
        aliases: [
            "call",
            "local-phone",
            "telephone"
        ],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-alert",
        codepoint: "FF37",
        aliases: [],
        tags: [
            "Cellphone \/ Phone",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "phone-alert-outline",
        codepoint: "F01B9",
        aliases: [],
        tags: [
            "Cellphone \/ Phone",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "phone-bluetooth",
        codepoint: "F3F3",
        aliases: [
            "phone-bluetooth-speaker",
            "telephone-bluetooth"
        ],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-bluetooth-outline",
        codepoint: "F01BA",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-cancel",
        codepoint: "F00E7",
        aliases: [
            "phone-block"
        ],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-cancel-outline",
        codepoint: "F01BB",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-check",
        codepoint: "F01D4",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-check-outline",
        codepoint: "F01D5",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-classic",
        codepoint: "F602",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-forward",
        codepoint: "F3F4",
        aliases: [
            "phone-forwarded",
            "telephone-forward"
        ],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-forward-outline",
        codepoint: "F01BC",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-hangup",
        codepoint: "F3F5",
        aliases: [
            "call-end",
            "telephone-hangup"
        ],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-hangup-outline",
        codepoint: "F01BD",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-in-talk",
        codepoint: "F3F6",
        aliases: [
            "telephone-in-talk"
        ],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-in-talk-outline",
        codepoint: "F01AD",
        aliases: [
            "telephone-in-talk-outline"
        ],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-incoming",
        codepoint: "F3F7",
        aliases: [
            "telephone-incoming"
        ],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-incoming-outline",
        codepoint: "F01BE",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-lock",
        codepoint: "F3F8",
        aliases: [
            "telephone-locked",
            "phone-locked",
            "telephone-lock"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Lock"
        ],
    },
    {
        
        name: "phone-lock-outline",
        codepoint: "F01BF",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-log",
        codepoint: "F3F9",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-log-outline",
        codepoint: "F01C0",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-message",
        codepoint: "F01C1",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-message-outline",
        codepoint: "F01C2",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-minus",
        codepoint: "F658",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-minus-outline",
        codepoint: "F01C3",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-missed",
        codepoint: "F3FA",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-missed-outline",
        codepoint: "F01D0",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-off",
        codepoint: "FDCB",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-off-outline",
        codepoint: "F01D1",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-outgoing",
        codepoint: "F3FB",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-outgoing-outline",
        codepoint: "F01C4",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-outline",
        codepoint: "FDCC",
        aliases: [
            "telephone-outline",
            "call-outline"
        ],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-paused",
        codepoint: "F3FC",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-paused-outline",
        codepoint: "F01C5",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-plus",
        codepoint: "F659",
        aliases: [
            "add-call"
        ],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-plus-outline",
        codepoint: "F01C6",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-return",
        codepoint: "F82E",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-return-outline",
        codepoint: "F01C7",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-ring",
        codepoint: "F01D6",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-ring-outline",
        codepoint: "F01D7",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-rotate-landscape",
        codepoint: "F884",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-rotate-portrait",
        codepoint: "F885",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-settings",
        codepoint: "F3FD",
        aliases: [
            "settings-phone"
        ],
        tags: [
            "Settings",
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-settings-outline",
        codepoint: "F01C8",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "phone-voip",
        codepoint: "F3FE",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "pi",
        codepoint: "F3FF",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "pi-box",
        codepoint: "F400",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "pi-hole",
        codepoint: "FDCD",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "piano",
        codepoint: "F67C",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "pickaxe",
        codepoint: "F8B6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "picture-in-picture-bottom-right",
        codepoint: "FE3A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "picture-in-picture-bottom-right-outline",
        codepoint: "FE3B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "picture-in-picture-top-right",
        codepoint: "FE3C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "picture-in-picture-top-right-outline",
        codepoint: "FE3D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pier",
        codepoint: "F886",
        aliases: [],
        tags: [
            "Places",
            "Transportation + Water"
        ],
    },
    {
        
        name: "pier-crane",
        codepoint: "F887",
        aliases: [],
        tags: [
            "Transportation + Water"
        ],
    },
    {
        
        name: "pig",
        codepoint: "F401",
        aliases: [],
        tags: [
            "Animal",
            "Agriculture"
        ],
    },
    {
        
        name: "pig-variant",
        codepoint: "F0028",
        aliases: [],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "piggy-bank",
        codepoint: "F0029",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "pill",
        codepoint: "F402",
        aliases: [
            "medicine",
            "capsule"
        ],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "pillar",
        codepoint: "F701",
        aliases: [
            "historic",
            "column"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pin",
        codepoint: "F403",
        aliases: [
            "keep"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pin-off",
        codepoint: "F404",
        aliases: [
            "keep-off"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pin-off-outline",
        codepoint: "F92F",
        aliases: [
            "keep-off-outline"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pin-outline",
        codepoint: "F930",
        aliases: [
            "keep-outline"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pine-tree",
        codepoint: "F405",
        aliases: [
            "forest",
            "plant"
        ],
        tags: [
            "Holiday",
            "Nature",
            "Places"
        ],
    },
    {
        
        name: "pine-tree-box",
        codepoint: "F406",
        aliases: [
            "plant"
        ],
        tags: [
            "Holiday",
            "Nature"
        ],
    },
    {
        
        name: "pinterest",
        codepoint: "F407",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "pinterest-box",
        codepoint: "F408",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "pinwheel",
        codepoint: "FAD4",
        aliases: [
            "toys"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pinwheel-outline",
        codepoint: "FAD5",
        aliases: [
            "toys-outline"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pipe",
        codepoint: "F7E4",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "pipe-disconnected",
        codepoint: "F7E5",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "pipe-leak",
        codepoint: "F888",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "pirate",
        codepoint: "FA07",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pistol",
        codepoint: "F702",
        aliases: [
            "gun"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "piston",
        codepoint: "F889",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "pizza",
        codepoint: "F409",
        aliases: [
            "pizzeria",
            "local-pizza"
        ],
        tags: [
            "Food \/ Drink",
            "Places"
        ],
    },
    {
        
        name: "play",
        codepoint: "F40A",
        aliases: [
            "play-arrow"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "play-box-outline",
        codepoint: "F40B",
        aliases: [
            "slideshow"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "play-circle",
        codepoint: "F40C",
        aliases: [
            "play-circle-filled"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "play-circle-outline",
        codepoint: "F40D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "play-network",
        codepoint: "F88A",
        aliases: [
            "media-network"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "play-network-outline",
        codepoint: "FC93",
        aliases: [
            "media-network-outline"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "play-outline",
        codepoint: "FF38",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "play-pause",
        codepoint: "F40E",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "play-protected-content",
        codepoint: "F40F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "play-speed",
        codepoint: "F8FE",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "playlist-check",
        codepoint: "F5C7",
        aliases: [
            "subscriptions",
            "playlist-add-check",
            "playlist-tick"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "playlist-edit",
        codepoint: "F8FF",
        aliases: [],
        tags: [
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "playlist-minus",
        codepoint: "F410",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "playlist-music",
        codepoint: "FC94",
        aliases: [
            "playlist-note",
            "queue-music"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "playlist-music-outline",
        codepoint: "FC95",
        aliases: [
            "playlist-note-outline",
            "queue-music-outline"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "playlist-play",
        codepoint: "F411",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "playlist-plus",
        codepoint: "F412",
        aliases: [
            "playlist-add"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "playlist-remove",
        codepoint: "F413",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "playlist-star",
        codepoint: "FDCE",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "playstation",
        codepoint: "F414",
        aliases: [
            "sony-playstation",
            "playstation-network"
        ],
        tags: [
            "Brand \/ Logo",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "plex",
        codepoint: "F6B9",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "plus",
        codepoint: "F415",
        aliases: [
            "add"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "plus-box",
        codepoint: "F416",
        aliases: [
            "add-box"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "plus-box-multiple",
        codepoint: "F334",
        aliases: [
            "add-to-photos",
            "library-add",
            "queue",
            "library-plus"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "plus-box-multiple-outline",
        codepoint: "F016E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "plus-box-outline",
        codepoint: "F703",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "plus-circle",
        codepoint: "F417",
        aliases: [
            "add-circle"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "plus-circle-multiple-outline",
        codepoint: "F418",
        aliases: [
            "control-point-duplicate",
            "plus-circles-outline"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "plus-circle-outline",
        codepoint: "F419",
        aliases: [
            "add-circle-outline",
            "control-point",
            "circles-add"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "plus-minus",
        codepoint: "F991",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "plus-minus-box",
        codepoint: "F992",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "plus-network",
        codepoint: "F41A",
        aliases: [
            "add-network"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "plus-network-outline",
        codepoint: "FC96",
        aliases: [
            "add-network-outline"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "plus-one",
        codepoint: "F41B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "plus-outline",
        codepoint: "F704",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "plus-thick",
        codepoint: "F0217",
        aliases: [
            "add-thick"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "pocket",
        codepoint: "F41C",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "podcast",
        codepoint: "F993",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "podium",
        codepoint: "FD01",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "podium-bronze",
        codepoint: "FD02",
        aliases: [
            "podium-third"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "podium-gold",
        codepoint: "FD03",
        aliases: [
            "podium-first"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "podium-silver",
        codepoint: "FD04",
        aliases: [
            "podium-second"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "point-of-sale",
        codepoint: "FD6E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pokeball",
        codepoint: "F41D",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "pokemon-go",
        codepoint: "FA08",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "poker-chip",
        codepoint: "F82F",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "polaroid",
        codepoint: "F41E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "police-badge",
        codepoint: "F0192",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "police-badge-outline",
        codepoint: "F0193",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "poll",
        codepoint: "F41F",
        aliases: [
            "bar-chart"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "poll-box",
        codepoint: "F420",
        aliases: [
            "assessment",
            "insert-chart"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "polymer",
        codepoint: "F421",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "pool",
        codepoint: "F606",
        aliases: [
            "swimming-pool"
        ],
        tags: [
            "Places"
        ],
    },
    {
        
        name: "popcorn",
        codepoint: "F422",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "post",
        codepoint: "F002A",
        aliases: [
            "blog"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "post-outline",
        codepoint: "F002B",
        aliases: [
            "blog-outline"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "postage-stamp",
        codepoint: "FC97",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pot",
        codepoint: "F65A",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "pot-mix",
        codepoint: "F65B",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "pound",
        codepoint: "F423",
        aliases: [
            "hashtag"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pound-box",
        codepoint: "F424",
        aliases: [
            "hashtag-box"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pound-box-outline",
        codepoint: "F01AA",
        aliases: [
            "hashtag-box-outline"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "power",
        codepoint: "F425",
        aliases: [
            "power-settings-new",
            "shutdown"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "power-cycle",
        codepoint: "F900",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "power-off",
        codepoint: "F901",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "power-on",
        codepoint: "F902",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "power-plug",
        codepoint: "F6A4",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "power-plug-off",
        codepoint: "F6A5",
        aliases: [
            "power-off"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "power-settings",
        codepoint: "F426",
        aliases: [
            "settings-power"
        ],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "power-sleep",
        codepoint: "F903",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "power-socket",
        codepoint: "F427",
        aliases: [
            "plug-socket"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "power-socket-au",
        codepoint: "F904",
        aliases: [
            "plug-socket-au",
            "power-socket-type-i",
            "power-socket-cn",
            "power-socket-ar",
            "power-socket-nz",
            "power-socket-pg",
            "power-socket-australia",
            "power-socket-china",
            "power-socket-argentina",
            "power-socket-new-zealand",
            "power-socket-papua-new-guinea"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "power-socket-de",
        codepoint: "F0132",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "power-socket-eu",
        codepoint: "F7E6",
        aliases: [
            "plug-socket-eu",
            "power-socket-europe"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "power-socket-fr",
        codepoint: "F0133",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "power-socket-jp",
        codepoint: "F0134",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "power-socket-uk",
        codepoint: "F7E7",
        aliases: [
            "plug-socket-uk",
            "power-socket-type-g",
            "power-socket-ie",
            "power-socket-hk",
            "power-socket-my",
            "power-socket-cy",
            "power-socket-mt",
            "power-socket-sg",
            "power-socket-united-kingdom",
            "power-socket-ireland",
            "power-socket-hong-kong",
            "power-socket-malaysia",
            "power-socket-cyprus",
            "power-socket-malta",
            "power-socket-singapore"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "power-socket-us",
        codepoint: "F7E8",
        aliases: [
            "plug-socket-us",
            "power-socket-jp",
            "power-socket-ca",
            "power-socket-mx",
            "power-socket-type-b",
            "power-socket-united-states",
            "power-socket-japan",
            "power-socket-canada",
            "power-socket-mexico"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "power-standby",
        codepoint: "F905",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "powershell",
        codepoint: "FA09",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "prescription",
        codepoint: "F705",
        aliases: [],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "presentation",
        codepoint: "F428",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "presentation-play",
        codepoint: "F429",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "printer",
        codepoint: "F42A",
        aliases: [
            "local-printshop",
            "local-print-shop"
        ],
        tags: [
            "Printer",
            "Home Automation"
        ],
    },
    {
        
        name: "printer-3d",
        codepoint: "F42B",
        aliases: [],
        tags: [
            "Printer",
            "Home Automation"
        ],
    },
    {
        
        name: "printer-3d-nozzle",
        codepoint: "FE3E",
        aliases: [],
        tags: [
            "Printer"
        ],
    },
    {
        
        name: "printer-3d-nozzle-alert",
        codepoint: "F01EB",
        aliases: [],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "printer-3d-nozzle-alert-outline",
        codepoint: "F01EC",
        aliases: [],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "printer-3d-nozzle-outline",
        codepoint: "FE3F",
        aliases: [],
        tags: [
            "Printer"
        ],
    },
    {
        
        name: "printer-alert",
        codepoint: "F42C",
        aliases: [
            "printer-warning"
        ],
        tags: [
            "Printer",
            "Home Automation",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "printer-check",
        codepoint: "F0171",
        aliases: [],
        tags: [
            "Printer"
        ],
    },
    {
        
        name: "printer-off",
        codepoint: "FE40",
        aliases: [],
        tags: [
            "Printer"
        ],
    },
    {
        
        name: "printer-pos",
        codepoint: "F0079",
        aliases: [
            "printer-point-of-sale"
        ],
        tags: [
            "Printer"
        ],
    },
    {
        
        name: "printer-settings",
        codepoint: "F706",
        aliases: [],
        tags: [
            "Settings",
            "Printer"
        ],
    },
    {
        
        name: "printer-wireless",
        codepoint: "FA0A",
        aliases: [],
        tags: [
            "Printer"
        ],
    },
    {
        
        name: "priority-high",
        codepoint: "F603",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "priority-low",
        codepoint: "F604",
        aliases: [
            "low-priority"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "professional-hexagon",
        codepoint: "F42D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "progress-alert",
        codepoint: "FC98",
        aliases: [
            "progress-warning"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "progress-check",
        codepoint: "F994",
        aliases: [
            "progress-tick"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "progress-clock",
        codepoint: "F995",
        aliases: [],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "progress-close",
        codepoint: "F0135",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "progress-download",
        codepoint: "F996",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "progress-upload",
        codepoint: "F997",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "progress-wrench",
        codepoint: "FC99",
        aliases: [
            "progress-spanner"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "projector",
        codepoint: "F42E",
        aliases: [],
        tags: [
            "Device \/ Tech",
            "Home Automation"
        ],
    },
    {
        
        name: "projector-screen",
        codepoint: "F42F",
        aliases: [],
        tags: [
            "Device \/ Tech",
            "Home Automation"
        ],
    },
    {
        
        name: "protocol",
        codepoint: "FFF9",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "publish",
        codepoint: "F6A6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "pulse",
        codepoint: "F430",
        aliases: [
            "vitals"
        ],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "pumpkin",
        codepoint: "FB9B",
        aliases: [],
        tags: [
            "Holiday"
        ],
    },
    {
        
        name: "purse",
        codepoint: "FF39",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "purse-outline",
        codepoint: "FF3A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "puzzle",
        codepoint: "F431",
        aliases: [
            "extension",
            "jigsaw"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "puzzle-outline",
        codepoint: "FA65",
        aliases: [
            "jigsaw-outline",
            "extension-outline"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "qi",
        codepoint: "F998",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "qqchat",
        codepoint: "F605",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "qrcode",
        codepoint: "F432",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "qrcode-edit",
        codepoint: "F8B7",
        aliases: [],
        tags: [
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "qrcode-minus",
        codepoint: "F01B7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "qrcode-plus",
        codepoint: "F01B6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "qrcode-remove",
        codepoint: "F01B8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "qrcode-scan",
        codepoint: "F433",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "quadcopter",
        codepoint: "F434",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "quality-high",
        codepoint: "F435",
        aliases: [
            "high-quality",
            "hq"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "quality-low",
        codepoint: "FA0B",
        aliases: [
            "low-quality",
            "lq"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "quality-medium",
        codepoint: "FA0C",
        aliases: [
            "medium-quality",
            "mq"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "quicktime",
        codepoint: "F436",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "quora",
        codepoint: "FD05",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rabbit",
        codepoint: "F906",
        aliases: [
            "bunny"
        ],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "racing-helmet",
        codepoint: "FD6F",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "racquetball",
        codepoint: "FD70",
        aliases: [
            "lacrosse",
            "squash"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "radar",
        codepoint: "F437",
        aliases: [
            "track-changes"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "radiator",
        codepoint: "F438",
        aliases: [
            "heater"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "radiator-disabled",
        codepoint: "FAD6",
        aliases: [
            "heater-disabled"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "radiator-off",
        codepoint: "FAD7",
        aliases: [
            "heater-off"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "radio",
        codepoint: "F439",
        aliases: [],
        tags: [
            "Audio",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "radio-am",
        codepoint: "FC9A",
        aliases: [],
        tags: [
            "Audio"
        ],
    },
    {
        
        name: "radio-fm",
        codepoint: "FC9B",
        aliases: [],
        tags: [
            "Audio"
        ],
    },
    {
        
        name: "radio-handheld",
        codepoint: "F43A",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "radio-off",
        codepoint: "F0247",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "radio-tower",
        codepoint: "F43B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "radioactive",
        codepoint: "F43C",
        aliases: [
            "radiation"
        ],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "radioactive-off",
        codepoint: "FEDE",
        aliases: [
            "radiation-off"
        ],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "radiobox-blank",
        codepoint: "F43D",
        aliases: [
            "radio-button-unchecked"
        ],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "radiobox-marked",
        codepoint: "F43E",
        aliases: [
            "radio-button-checked",
            "record"
        ],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "radius",
        codepoint: "FC9C",
        aliases: [
            "circle-radius",
            "sphere-radius"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "radius-outline",
        codepoint: "FC9D",
        aliases: [
            "circle-radius-outline",
            "sphere-radius-outline"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "railroad-light",
        codepoint: "FF3B",
        aliases: [],
        tags: [
            "Transportation + Other"
        ],
    },
    {
        
        name: "raspberry-pi",
        codepoint: "F43F",
        aliases: [
            "raspberrypi"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "ray-end",
        codepoint: "F440",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "ray-end-arrow",
        codepoint: "F441",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "ray-start",
        codepoint: "F442",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "ray-start-arrow",
        codepoint: "F443",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "ray-start-end",
        codepoint: "F444",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "ray-vertex",
        codepoint: "F445",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "react",
        codepoint: "F707",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "read",
        codepoint: "F447",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "receipt",
        codepoint: "F449",
        aliases: [
            "invoice"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "record",
        codepoint: "F44A",
        aliases: [
            "fiber-manual-record"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "record-circle",
        codepoint: "FEDF",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "record-circle-outline",
        codepoint: "FEE0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "record-player",
        codepoint: "F999",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "record-rec",
        codepoint: "F44B",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "rectangle",
        codepoint: "FE41",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "rectangle-outline",
        codepoint: "FE42",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "recycle",
        codepoint: "F44C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "reddit",
        codepoint: "F44D",
        aliases: [],
        tags: [
            "Social Media",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "redhat",
        codepoint: "F0146",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "redo",
        codepoint: "F44E",
        aliases: [
            "arrow"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "redo-variant",
        codepoint: "F44F",
        aliases: [
            "arrow"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "reflect-horizontal",
        codepoint: "FA0D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "reflect-vertical",
        codepoint: "FA0E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "refresh",
        codepoint: "F450",
        aliases: [
            "loop"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "regex",
        codepoint: "F451",
        aliases: [
            "regular-expression"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "registered-trademark",
        codepoint: "FA66",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "relative-scale",
        codepoint: "F452",
        aliases: [
            "image-aspect-ratio"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "reload",
        codepoint: "F453",
        aliases: [
            "car-engine-start",
            "loop"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "reload-alert",
        codepoint: "F0136",
        aliases: [],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "reminder",
        codepoint: "F88B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "remote",
        codepoint: "F454",
        aliases: [
            "settings-remote"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "remote-desktop",
        codepoint: "F8B8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "remote-off",
        codepoint: "FEE1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "remote-tv",
        codepoint: "FEE2",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "remote-tv-off",
        codepoint: "FEE3",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "rename-box",
        codepoint: "F455",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "reorder-horizontal",
        codepoint: "F687",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "reorder-vertical",
        codepoint: "F688",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "repeat",
        codepoint: "F456",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "repeat-off",
        codepoint: "F457",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "repeat-once",
        codepoint: "F458",
        aliases: [
            "repeat-one"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "replay",
        codepoint: "F459",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "reply",
        codepoint: "F45A",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "reply-all",
        codepoint: "F45B",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "reply-all-outline",
        codepoint: "FF3C",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "reply-circle",
        codepoint: "F01D9",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "reply-outline",
        codepoint: "FF3D",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "reproduction",
        codepoint: "F45C",
        aliases: [],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "resistor",
        codepoint: "FB1F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "resistor-nodes",
        codepoint: "FB20",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "resize",
        codepoint: "FA67",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "resize-bottom-right",
        codepoint: "F45D",
        aliases: [
            "drag"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "responsive",
        codepoint: "F45E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "restart",
        codepoint: "F708",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "restart-alert",
        codepoint: "F0137",
        aliases: [],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "restart-off",
        codepoint: "FD71",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "restore",
        codepoint: "F99A",
        aliases: [
            "loop"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "restore-alert",
        codepoint: "F0138",
        aliases: [],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "rewind",
        codepoint: "F45F",
        aliases: [
            "fast-rewind"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rewind-10",
        codepoint: "FD06",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rewind-30",
        codepoint: "FD72",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rewind-5",
        codepoint: "F0224",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rewind-outline",
        codepoint: "F709",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rhombus",
        codepoint: "F70A",
        aliases: [
            "diamond"
        ],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "rhombus-medium",
        codepoint: "FA0F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rhombus-outline",
        codepoint: "F70B",
        aliases: [
            "diamond-outline"
        ],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "rhombus-split",
        codepoint: "FA10",
        aliases: [
            "collection"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "ribbon",
        codepoint: "F460",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rice",
        codepoint: "F7E9",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "ring",
        codepoint: "F7EA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rivet",
        codepoint: "FE43",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "road",
        codepoint: "F461",
        aliases: [],
        tags: [
            "Transportation + Road",
            "Transportation + Road"
        ],
    },
    {
        
        name: "road-variant",
        codepoint: "F462",
        aliases: [],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "robber",
        codepoint: "F007A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "robot",
        codepoint: "F6A8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "robot-industrial",
        codepoint: "FB21",
        aliases: [
            "autonomous",
            "assembly"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "robot-mower",
        codepoint: "F0222",
        aliases: [
            "lawn-mower"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "robot-mower-outline",
        codepoint: "F021E",
        aliases: [
            "lawn-mower-outline"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "robot-vacuum",
        codepoint: "F70C",
        aliases: [
            "roomba"
        ],
        tags: [
            "Device \/ Tech",
            "Home Automation"
        ],
    },
    {
        
        name: "robot-vacuum-variant",
        codepoint: "F907",
        aliases: [
            "neato"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "rocket",
        codepoint: "F463",
        aliases: [],
        tags: [
            "Transportation + Flying",
            "Science"
        ],
    },
    {
        
        name: "roller-skate",
        codepoint: "FD07",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "rollerblade",
        codepoint: "FD08",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "rollupjs",
        codepoint: "FB9C",
        aliases: [
            "rollup-js"
        ],
        tags: [
            "Brand \/ Logo",
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "roman-numeral-1",
        codepoint: "F00B3",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "roman-numeral-10",
        codepoint: "F00BC",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "roman-numeral-2",
        codepoint: "F00B4",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "roman-numeral-3",
        codepoint: "F00B5",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "roman-numeral-4",
        codepoint: "F00B6",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "roman-numeral-5",
        codepoint: "F00B7",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "roman-numeral-6",
        codepoint: "F00B8",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "roman-numeral-7",
        codepoint: "F00B9",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "roman-numeral-8",
        codepoint: "F00BA",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "roman-numeral-9",
        codepoint: "F00BB",
        aliases: [],
        tags: [
            "Alpha \/ Numeric"
        ],
    },
    {
        
        name: "room-service",
        codepoint: "F88C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "room-service-outline",
        codepoint: "FD73",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rotate-3d",
        codepoint: "FEE4",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rotate-3d-variant",
        codepoint: "F464",
        aliases: [
            "3d-rotation"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rotate-left",
        codepoint: "F465",
        aliases: [
            "arrow-rotate-left"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "rotate-left-variant",
        codepoint: "F466",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rotate-orbit",
        codepoint: "FD74",
        aliases: [
            "gyro",
            "accelerometer"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rotate-right",
        codepoint: "F467",
        aliases: [
            "arrow-rotate-right"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "rotate-right-variant",
        codepoint: "F468",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rounded-corner",
        codepoint: "F607",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "router",
        codepoint: "F020D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "router-wireless",
        codepoint: "F469",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "router-wireless-settings",
        codepoint: "FA68",
        aliases: [],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "routes",
        codepoint: "F46A",
        aliases: [
            "sign-routes"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "routes-clock",
        codepoint: "F007B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rowing",
        codepoint: "F608",
        aliases: [],
        tags: [
            "Sport",
            "Transportation + Water"
        ],
    },
    {
        
        name: "rss",
        codepoint: "F46B",
        aliases: [
            "rss-feed"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rss-box",
        codepoint: "F46C",
        aliases: [
            "rss-feed-box"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rss-off",
        codepoint: "FF3E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "ruby",
        codepoint: "FD09",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "rugby",
        codepoint: "FD75",
        aliases: [
            "rugby-ball"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "ruler",
        codepoint: "F46D",
        aliases: [],
        tags: [
            "Hardware \/ Tools",
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "ruler-square",
        codepoint: "FC9E",
        aliases: [
            "square",
            "carpentry",
            "architecture"
        ],
        tags: [
            "Hardware \/ Tools",
            "Drawing \/ Art"
        ],
    },
    {
        
        name: "ruler-square-compass",
        codepoint: "FEDB",
        aliases: [
            "mason",
            "masonic",
            "freemasonry"
        ],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "run",
        codepoint: "F70D",
        aliases: [
            "directions-run"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "run-fast",
        codepoint: "F46E",
        aliases: [],
        tags: [
            "Home Automation",
            "Sport"
        ],
    },
    {
        
        name: "rv-truck",
        codepoint: "F01FF",
        aliases: [
            "recreational-vehicle",
            "campervan"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "sack",
        codepoint: "FD0A",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "sack-percent",
        codepoint: "FD0B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "safe",
        codepoint: "FA69",
        aliases: [],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "safety-goggles",
        codepoint: "FD0C",
        aliases: [],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "sailing",
        codepoint: "FEE5",
        aliases: [
            "boat"
        ],
        tags: [
            "Sport",
            "Transportation + Water"
        ],
    },
    {
        
        name: "sale",
        codepoint: "F46F",
        aliases: [
            "discount"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "salesforce",
        codepoint: "F88D",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "sass",
        codepoint: "F7EB",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "satellite",
        codepoint: "F470",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "satellite-uplink",
        codepoint: "F908",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "satellite-variant",
        codepoint: "F471",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "sausage",
        codepoint: "F8B9",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "saw-blade",
        codepoint: "FE44",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "saxophone",
        codepoint: "F609",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "scale",
        codepoint: "F472",
        aliases: [],
        tags: [
            "Food \/ Drink",
            "Science"
        ],
    },
    {
        
        name: "scale-balance",
        codepoint: "F5D1",
        aliases: [],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "scale-bathroom",
        codepoint: "F473",
        aliases: [],
        tags: [
            "Home Automation",
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "scale-off",
        codepoint: "F007C",
        aliases: [],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "scanner",
        codepoint: "F6AA",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "scanner-off",
        codepoint: "F909",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "scatter-plot",
        codepoint: "FEE6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "scatter-plot-outline",
        codepoint: "FEE7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "school",
        codepoint: "F474",
        aliases: [
            "graduation-cap",
            "university",
            "college",
            "academic-cap"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "school-outline",
        codepoint: "F01AB",
        aliases: [
            "academic-cap-outline",
            "college-outline",
            "graduation-cap-outline",
            "university-outline"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "scissors-cutting",
        codepoint: "FA6A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "scooter",
        codepoint: "F0214",
        aliases: [],
        tags: [
            "Sport",
            "Transportation + Other"
        ],
    },
    {
        
        name: "screen-rotation",
        codepoint: "F475",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "screen-rotation-lock",
        codepoint: "F476",
        aliases: [
            "screen-lock-rotation"
        ],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "screw-flat-top",
        codepoint: "FDCF",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "screw-lag",
        codepoint: "FE54",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "screw-machine-flat-top",
        codepoint: "FE55",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "screw-machine-round-top",
        codepoint: "FE56",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "screw-round-top",
        codepoint: "FE57",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "screwdriver",
        codepoint: "F477",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "script",
        codepoint: "FB9D",
        aliases: [
            "scroll"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "script-outline",
        codepoint: "F478",
        aliases: [
            "scroll-outline"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "script-text",
        codepoint: "FB9E",
        aliases: [
            "scroll-text"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "script-text-outline",
        codepoint: "FB9F",
        aliases: [
            "scroll-text-outline"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "sd",
        codepoint: "F479",
        aliases: [
            "sd-card",
            "sd-storage"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "seal",
        codepoint: "F47A",
        aliases: [
            "ribbon",
            "prize",
            "award"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "seal-variant",
        codepoint: "FFFA",
        aliases: [
            "ribbon",
            "prize",
            "award"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "search-web",
        codepoint: "F70E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "seat",
        codepoint: "FC9F",
        aliases: [
            "event-seat",
            "chair"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "seat-flat",
        codepoint: "F47B",
        aliases: [
            "airline-seat-flat"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "seat-flat-angled",
        codepoint: "F47C",
        aliases: [
            "airline-seat-flat-angled"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "seat-individual-suite",
        codepoint: "F47D",
        aliases: [
            "airline-seat-individual-suite"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "seat-legroom-extra",
        codepoint: "F47E",
        aliases: [
            "airline-seat-legroom-extra"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "seat-legroom-normal",
        codepoint: "F47F",
        aliases: [
            "airline-seat-legroom-normal"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "seat-legroom-reduced",
        codepoint: "F480",
        aliases: [
            "airline-seat-legroom-reduced"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "seat-outline",
        codepoint: "FCA0",
        aliases: [
            "event-seat-outline",
            "chair-outline"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "seat-passenger",
        codepoint: "F0274",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "seat-recline-extra",
        codepoint: "F481",
        aliases: [
            "airline-seat-recline-extra"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "seat-recline-normal",
        codepoint: "F482",
        aliases: [
            "airline-seat-recline-normal"
        ],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "seatbelt",
        codepoint: "FCA1",
        aliases: [
            "seat-belt",
            "safety-belt"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "security",
        codepoint: "F483",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "security-network",
        codepoint: "F484",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "seed",
        codepoint: "FE45",
        aliases: [],
        tags: [
            "Agriculture",
            "Nature"
        ],
    },
    {
        
        name: "seed-outline",
        codepoint: "FE46",
        aliases: [],
        tags: [
            "Agriculture",
            "Nature"
        ],
    },
    {
        
        name: "segment",
        codepoint: "FEE8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "select",
        codepoint: "F485",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "select-all",
        codepoint: "F486",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "select-color",
        codepoint: "FD0D",
        aliases: [
            "select-colour"
        ],
        tags: [
            "Color"
        ],
    },
    {
        
        name: "select-compare",
        codepoint: "FAD8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 900-1199" ],
    },
    {
        
        name: "select-drag",
        codepoint: "FA6B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "select-group",
        codepoint: "FF9F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "select-inverse",
        codepoint: "F487",
        aliases: [
            "selection-invert"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "select-off",
        codepoint: "F488",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "select-place",
        codepoint: "FFFB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "select-search",
        codepoint: "F022F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "selection",
        codepoint: "F489",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "selection-drag",
        codepoint: "FA6C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "selection-ellipse",
        codepoint: "FD0E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "selection-ellipse-arrow-inside",
        codepoint: "FF3F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "selection-off",
        codepoint: "F776",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "selection-search",
        codepoint: "F0230",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "send",
        codepoint: "F48A",
        aliases: [
            "paper-airplane"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "send-check",
        codepoint: "F018C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "send-check-outline",
        codepoint: "F018D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "send-circle",
        codepoint: "FE58",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "send-circle-outline",
        codepoint: "FE59",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "send-clock",
        codepoint: "F018E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "send-clock-outline",
        codepoint: "F018F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "send-lock",
        codepoint: "F7EC",
        aliases: [
            "send-secure"
        ],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "send-lock-outline",
        codepoint: "F0191",
        aliases: [],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "send-outline",
        codepoint: "F0190",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "serial-port",
        codepoint: "F65C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "server",
        codepoint: "F48B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "server-minus",
        codepoint: "F48C",
        aliases: [
            "server-remove"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "server-network",
        codepoint: "F48D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "server-network-off",
        codepoint: "F48E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "server-off",
        codepoint: "F48F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "server-plus",
        codepoint: "F490",
        aliases: [
            "server-add"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "server-remove",
        codepoint: "F491",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "server-security",
        codepoint: "F492",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "set-all",
        codepoint: "F777",
        aliases: [
            "set-union",
            "set-or",
            "full-outer-join",
            "sql-full-outer-join"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "set-center",
        codepoint: "F778",
        aliases: [
            "set-centre",
            "set-intersection",
            "set-and",
            "inner-join",
            "sql-inner-join"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "set-center-right",
        codepoint: "F779",
        aliases: [
            "set-centre-right",
            "outer-join-right",
            "sql-right-outer-join"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "set-left",
        codepoint: "F77A",
        aliases: [
            "difference-left"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "set-left-center",
        codepoint: "F77B",
        aliases: [
            "set-left-centre",
            "outer-join-left",
            "sql-left-outer-join"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "set-left-right",
        codepoint: "F77C",
        aliases: [
            "exclusion",
            "set-xor"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "set-none",
        codepoint: "F77D",
        aliases: [
            "set-null",
            "set-not"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "set-right",
        codepoint: "F77E",
        aliases: [
            "difference-right"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "set-top-box",
        codepoint: "F99E",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "settings",
        codepoint: "F493",
        aliases: [
            "cog",
            "gear"
        ],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "settings-box",
        codepoint: "F494",
        aliases: [
            "gear-box",
            "cog-box",
            "settings-applications"
        ],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "settings-helper",
        codepoint: "FA6D",
        aliases: [],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "settings-outline",
        codepoint: "F8BA",
        aliases: [
            "cog-outline",
            "gear-outline"
        ],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "settings-transfer",
        codepoint: "F007D",
        aliases: [],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "settings-transfer-outline",
        codepoint: "F007E",
        aliases: [],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "shaker",
        codepoint: "F0139",
        aliases: [
            "pepper",
            "fish-food"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "shaker-outline",
        codepoint: "F013A",
        aliases: [
            "salt",
            "fish-food-outline"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "shape",
        codepoint: "F830",
        aliases: [
            "category",
            "theme"
        ],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "shape-circle-plus",
        codepoint: "F65D",
        aliases: [
            "shape-circle-add"
        ],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "shape-outline",
        codepoint: "F831",
        aliases: [
            "theme-outline",
            "category-outline"
        ],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "shape-oval-plus",
        codepoint: "F0225",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shape-plus",
        codepoint: "F495",
        aliases: [
            "shape-add"
        ],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "shape-polygon-plus",
        codepoint: "F65E",
        aliases: [
            "shape-polygon-add"
        ],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "shape-rectangle-plus",
        codepoint: "F65F",
        aliases: [
            "shape-rectangle-add"
        ],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "shape-square-plus",
        codepoint: "F660",
        aliases: [
            "shape-square-add"
        ],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "share",
        codepoint: "F496",
        aliases: [
            "forward"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "share-all",
        codepoint: "F021F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "share-all-outline",
        codepoint: "F0220",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "share-circle",
        codepoint: "F01D8",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "share-off",
        codepoint: "FF40",
        aliases: [
            "forward-off"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "share-off-outline",
        codepoint: "FF41",
        aliases: [
            "forward-off-outline"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "share-outline",
        codepoint: "F931",
        aliases: [
            "forward-outline"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "share-variant",
        codepoint: "F497",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sheep",
        codepoint: "FCA2",
        aliases: [],
        tags: [
            "Animal",
            "Agriculture"
        ],
    },
    {
        
        name: "shield",
        codepoint: "F498",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "shield-account",
        codepoint: "F88E",
        aliases: [
            "security-account",
            "shield-user",
            "shield-person"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "shield-account-outline",
        codepoint: "FA11",
        aliases: [
            "security-account-outline",
            "shield-user-outline",
            "shield-person-outline"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "shield-airplane",
        codepoint: "F6BA",
        aliases: [
            "shield-aeroplane",
            "shield-plane",
            "plane-shield"
        ],
        tags: [
            "Transportation + Flying"
        ],
    },
    {
        
        name: "shield-airplane-outline",
        codepoint: "FCA3",
        aliases: [
            "shield-aeroplane-outline",
            "shield-plane-outline"
        ],
        tags: [
            "Transportation + Flying"
        ],
    },
    {
        
        name: "shield-alert",
        codepoint: "FEE9",
        aliases: [
            "shield-warning"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "shield-alert-outline",
        codepoint: "FEEA",
        aliases: [
            "shield-warning-outline"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "shield-car",
        codepoint: "FFA0",
        aliases: [
            "car-security",
            "car-insurance"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "shield-check",
        codepoint: "F565",
        aliases: [
            "verified-user",
            "shield-tick",
            "verified"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "shield-check-outline",
        codepoint: "FCA4",
        aliases: [
            "shield-tick-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shield-cross",
        codepoint: "FCA5",
        aliases: [
            "shield-templar",
            "shield-christianity"
        ],
        tags: [
            "Gaming \/ RPG",
            "Religion"
        ],
    },
    {
        
        name: "shield-cross-outline",
        codepoint: "FCA6",
        aliases: [
            "shield-templar-outline",
            "shield-christianity-outline"
        ],
        tags: [
            "Gaming \/ RPG",
            "Religion"
        ],
    },
    {
        
        name: "shield-edit",
        codepoint: "F01CB",
        aliases: [],
        tags: [
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "shield-edit-outline",
        codepoint: "F01CC",
        aliases: [],
        tags: [
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "shield-half-full",
        codepoint: "F77F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shield-home",
        codepoint: "F689",
        aliases: [
            "security-home",
            "shield-house"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "shield-home-outline",
        codepoint: "FCA7",
        aliases: [
            "shield-house-outline"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "shield-key",
        codepoint: "FBA0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shield-key-outline",
        codepoint: "FBA1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shield-link-variant",
        codepoint: "FD0F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shield-link-variant-outline",
        codepoint: "FD10",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shield-lock",
        codepoint: "F99C",
        aliases: [
            "security-lock"
        ],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "shield-lock-outline",
        codepoint: "FCA8",
        aliases: [],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "shield-off",
        codepoint: "F99D",
        aliases: [
            "security-off"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shield-off-outline",
        codepoint: "F99B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shield-outline",
        codepoint: "F499",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "shield-plus",
        codepoint: "FAD9",
        aliases: [
            "shield-add"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shield-plus-outline",
        codepoint: "FADA",
        aliases: [
            "shield-add-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shield-refresh",
        codepoint: "F01CD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shield-refresh-outline",
        codepoint: "F01CE",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shield-remove",
        codepoint: "FADB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shield-remove-outline",
        codepoint: "FADC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shield-search",
        codepoint: "FD76",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shield-star",
        codepoint: "F0166",
        aliases: [
            "badge"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shield-star-outline",
        codepoint: "F0167",
        aliases: [
            "badge-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shield-sun",
        codepoint: "F007F",
        aliases: [
            "sun-protection"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shield-sun-outline",
        codepoint: "F0080",
        aliases: [
            "sun-protection-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "ship-wheel",
        codepoint: "F832",
        aliases: [
            "voyager"
        ],
        tags: [
            "Transportation + Water"
        ],
    },
    {
        
        name: "shoe-formal",
        codepoint: "FB22",
        aliases: [],
        tags: [
            "Clothing"
        ],
    },
    {
        
        name: "shoe-heel",
        codepoint: "FB23",
        aliases: [],
        tags: [
            "Clothing"
        ],
    },
    {
        
        name: "shoe-print",
        codepoint: "FE5A",
        aliases: [
            "footprints"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shopify",
        codepoint: "FADD",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "shopping",
        codepoint: "F49A",
        aliases: [
            "local-mall",
            "marketplace"
        ],
        tags: [
            "Shopping"
        ],
    },
    {
        
        name: "shopping-music",
        codepoint: "F49B",
        aliases: [],
        tags: [
            "Shopping"
        ],
    },
    {
        
        name: "shopping-outline",
        codepoint: "F0200",
        aliases: [
            "local-mall-outline",
            "marketplace-outline"
        ],
        tags: [
            "Shopping"
        ],
    },
    {
        
        name: "shopping-search",
        codepoint: "FFA1",
        aliases: [],
        tags: [
            "Shopping"
        ],
    },
    {
        
        name: "shovel",
        codepoint: "F70F",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "shovel-off",
        codepoint: "F710",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "shower",
        codepoint: "F99F",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "shower-head",
        codepoint: "F9A0",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "shredder",
        codepoint: "F49C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "shuffle",
        codepoint: "F49D",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "shuffle-disabled",
        codepoint: "F49E",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "shuffle-variant",
        codepoint: "F49F",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "sigma",
        codepoint: "F4A0",
        aliases: [
            "summation"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "sigma-lower",
        codepoint: "F62B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sign-caution",
        codepoint: "F4A1",
        aliases: [
            "barrier"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "sign-direction",
        codepoint: "F780",
        aliases: [
            "milestone"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sign-direction-minus",
        codepoint: "F0022",
        aliases: [
            "milestone-minus"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sign-direction-plus",
        codepoint: "FFFD",
        aliases: [
            "milestone-plus",
            "sign-direction-add",
            "milestone-add"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sign-direction-remove",
        codepoint: "FFFE",
        aliases: [
            "milestone-remove"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sign-real-estate",
        codepoint: "F0143",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sign-text",
        codepoint: "F781",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "signal",
        codepoint: "F4A2",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "signal-2g",
        codepoint: "F711",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "signal-3g",
        codepoint: "F712",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "signal-4g",
        codepoint: "F713",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "signal-5g",
        codepoint: "FA6E",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "signal-cellular-1",
        codepoint: "F8BB",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "signal-cellular-2",
        codepoint: "F8BC",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "signal-cellular-3",
        codepoint: "F8BD",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "signal-cellular-outline",
        codepoint: "F8BE",
        aliases: [
            "signal-cellular-0"
        ],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "signal-distance-variant",
        codepoint: "FE47",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "signal-hspa",
        codepoint: "F714",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "signal-hspa-plus",
        codepoint: "F715",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "signal-off",
        codepoint: "F782",
        aliases: [],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "signal-variant",
        codepoint: "F60A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "signature",
        codepoint: "FE5B",
        aliases: [],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "signature-freehand",
        codepoint: "FE5C",
        aliases: [],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "signature-image",
        codepoint: "FE5D",
        aliases: [],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "signature-text",
        codepoint: "FE5E",
        aliases: [],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "silo",
        codepoint: "FB24",
        aliases: [
            "farm"
        ],
        tags: [
            "Agriculture"
        ],
    },
    {
        
        name: "silverware",
        codepoint: "F4A3",
        aliases: [
            "local-dining",
            "restaurant-menu",
            "local-restaurant"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "silverware-clean",
        codepoint: "FFFF",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "silverware-fork",
        codepoint: "F4A4",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "silverware-fork-knife",
        codepoint: "FA6F",
        aliases: [
            "restaurant",
            "fortnite"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "silverware-spoon",
        codepoint: "F4A5",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "silverware-variant",
        codepoint: "F4A6",
        aliases: [],
        tags: [
            "Food \/ Drink",
            "Places"
        ],
    },
    {
        
        name: "sim",
        codepoint: "F4A7",
        aliases: [
            "sim-card",
            "subscriber-identity-module",
            "subscriber-identification-module"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sim-alert",
        codepoint: "F4A8",
        aliases: [
            "sim-warning",
            "sim-card-alert"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "sim-off",
        codepoint: "F4A9",
        aliases: [
            "signal-cellular-no-sim"
        ],
        tags: [
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "sina-weibo",
        codepoint: "FADE",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "sitemap",
        codepoint: "F4AA",
        aliases: [
            "workflow",
            "flowchart"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "skate",
        codepoint: "FD11",
        aliases: [
            "ice-skate"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "skew-less",
        codepoint: "FD12",
        aliases: [
            "skew-decrease"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "skew-more",
        codepoint: "FD13",
        aliases: [
            "skew-increase"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "skip-backward",
        codepoint: "F4AB",
        aliases: [
            "title-backward",
            "previous-title"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "skip-backward-outline",
        codepoint: "FF42",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "skip-forward",
        codepoint: "F4AC",
        aliases: [
            "title-forward",
            "next-title"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "skip-forward-outline",
        codepoint: "FF43",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "skip-next",
        codepoint: "F4AD",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "skip-next-circle",
        codepoint: "F661",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "skip-next-circle-outline",
        codepoint: "F662",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "skip-next-outline",
        codepoint: "FF44",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "skip-previous",
        codepoint: "F4AE",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "skip-previous-circle",
        codepoint: "F663",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "skip-previous-circle-outline",
        codepoint: "F664",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "skip-previous-outline",
        codepoint: "FF45",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "skull",
        codepoint: "F68B",
        aliases: [],
        tags: [
            "Holiday",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "skull-crossbones",
        codepoint: "FBA2",
        aliases: [
            "jolly-roger"
        ],
        tags: [
            "Gaming \/ RPG",
            "Holiday"
        ],
    },
    {
        
        name: "skull-crossbones-outline",
        codepoint: "FBA3",
        aliases: [
            "jolly-roger-outline"
        ],
        tags: [
            "Gaming \/ RPG",
            "Holiday"
        ],
    },
    {
        
        name: "skull-outline",
        codepoint: "FBA4",
        aliases: [],
        tags: [
            "Holiday",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "skype",
        codepoint: "F4AF",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "skype-business",
        codepoint: "F4B0",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "slack",
        codepoint: "F4B1",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "slackware",
        codepoint: "F90A",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "slash-forward",
        codepoint: "F0000",
        aliases: [
            "divide",
            "division"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "slash-forward-box",
        codepoint: "F0001",
        aliases: [
            "divide-box",
            "division-box"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "sleep",
        codepoint: "F4B2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sleep-off",
        codepoint: "F4B3",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "slope-downhill",
        codepoint: "FE5F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "slope-uphill",
        codepoint: "FE60",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "slot-machine",
        codepoint: "F013F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "slot-machine-outline",
        codepoint: "F0140",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "smart-card",
        codepoint: "F00E8",
        aliases: [],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "smart-card-outline",
        codepoint: "F00E9",
        aliases: [],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "smart-card-reader",
        codepoint: "F00EA",
        aliases: [],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "smart-card-reader-outline",
        codepoint: "F00EB",
        aliases: [],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "smog",
        codepoint: "FA70",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "smoke-detector",
        codepoint: "F392",
        aliases: [
            "nest-protect",
            "subwoofer"
        ],
        tags: [
            "Device \/ Tech",
            "Home Automation"
        ],
    },
    {
        
        name: "smoking",
        codepoint: "F4B4",
        aliases: [
            "cigarette",
            "smoking-area",
            "smoking-rooms"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "smoking-off",
        codepoint: "F4B5",
        aliases: [
            "no-smoking",
            "cigarette-off",
            "smoke-free"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "snapchat",
        codepoint: "F4B6",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "snowflake",
        codepoint: "F716",
        aliases: [],
        tags: [
            "Weather",
            "Holiday",
            "Automotive"
        ],
    },
    {
        
        name: "snowflake-alert",
        codepoint: "FF46",
        aliases: [
            "cold-alert",
            "snow-advisory",
            "freeze-advisory"
        ],
        tags: [
            "Weather",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "snowflake-variant",
        codepoint: "FF47",
        aliases: [],
        tags: [
            "Holiday",
            "Weather"
        ],
    },
    {
        
        name: "snowman",
        codepoint: "F4B7",
        aliases: [],
        tags: [
            "Holiday"
        ],
    },
    {
        
        name: "soccer",
        codepoint: "F4B8",
        aliases: [
            "football"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "soccer-field",
        codepoint: "F833",
        aliases: [
            "football-pitch"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "sofa",
        codepoint: "F4B9",
        aliases: [
            "couch"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "solar-panel",
        codepoint: "FD77",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "solar-panel-large",
        codepoint: "FD78",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "solar-power",
        codepoint: "FA71",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "soldering-iron",
        codepoint: "F00BD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "solid",
        codepoint: "F68C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sort",
        codepoint: "F4BA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sort-alphabetical",
        codepoint: "F4BB",
        aliases: [
            "sort-by-alpha",
            "sort-alphabetically"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sort-alphabetical-ascending",
        codepoint: "F0173",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sort-alphabetical-descending",
        codepoint: "F0174",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sort-ascending",
        codepoint: "F4BC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sort-descending",
        codepoint: "F4BD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sort-numeric",
        codepoint: "F4BE",
        aliases: [
            "sort-numerically"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sort-variant",
        codepoint: "F4BF",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sort-variant-lock",
        codepoint: "FCA9",
        aliases: [],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "sort-variant-lock-open",
        codepoint: "FCAA",
        aliases: [],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "sort-variant-remove",
        codepoint: "F0172",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "soundcloud",
        codepoint: "F4C0",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "source-branch",
        codepoint: "F62C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "source-commit",
        codepoint: "F717",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "source-commit-end",
        codepoint: "F718",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "source-commit-end-local",
        codepoint: "F719",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "source-commit-local",
        codepoint: "F71A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "source-commit-next-local",
        codepoint: "F71B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "source-commit-start",
        codepoint: "F71C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "source-commit-start-next-local",
        codepoint: "F71D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "source-fork",
        codepoint: "F4C1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "source-merge",
        codepoint: "F62D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "source-pull",
        codepoint: "F4C2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "source-repository",
        codepoint: "FCAB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "source-repository-multiple",
        codepoint: "FCAC",
        aliases: [
            "source-repositories"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "soy-sauce",
        codepoint: "F7ED",
        aliases: [
            "soya-sauce"
        ],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "spa",
        codepoint: "FCAD",
        aliases: [
            "flower-lotus",
            "plant"
        ],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "spa-outline",
        codepoint: "FCAE",
        aliases: [
            "flower-lotus-outline",
            "plant"
        ],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "space-invaders",
        codepoint: "FBA5",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "spade",
        codepoint: "FE48",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "speaker",
        codepoint: "F4C3",
        aliases: [],
        tags: [
            "Audio",
            "Home Automation"
        ],
    },
    {
        
        name: "speaker-bluetooth",
        codepoint: "F9A1",
        aliases: [],
        tags: [
            "Audio"
        ],
    },
    {
        
        name: "speaker-multiple",
        codepoint: "FD14",
        aliases: [
            "speakers"
        ],
        tags: [
            "Audio"
        ],
    },
    {
        
        name: "speaker-off",
        codepoint: "F4C4",
        aliases: [],
        tags: [
            "Audio",
            "Home Automation"
        ],
    },
    {
        
        name: "speaker-wireless",
        codepoint: "F71E",
        aliases: [],
        tags: [
            "Audio",
            "Home Automation"
        ],
    },
    {
        
        name: "speedometer",
        codepoint: "F4C5",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "speedometer-medium",
        codepoint: "FFA2",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "speedometer-slow",
        codepoint: "FFA3",
        aliases: [],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "spellcheck",
        codepoint: "F4C6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "spider",
        codepoint: "F0215",
        aliases: [
            "arachnid"
        ],
        tags: [
            "Holiday",
            "Nature"
        ],
    },
    {
        
        name: "spider-thread",
        codepoint: "F0216",
        aliases: [
            "arachnid-thread"
        ],
        tags: [
            "Holiday",
            "Nature"
        ],
    },
    {
        
        name: "spider-web",
        codepoint: "FBA6",
        aliases: [
            "cobweb",
            "arachnid-web"
        ],
        tags: [
            "Holiday"
        ],
    },
    {
        
        name: "spotify",
        codepoint: "F4C7",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "spotlight",
        codepoint: "F4C8",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "spotlight-beam",
        codepoint: "F4C9",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "spray",
        codepoint: "F665",
        aliases: [
            "paint",
            "aerosol"
        ],
        tags: [
            "Agriculture"
        ],
    },
    {
        
        name: "spray-bottle",
        codepoint: "FADF",
        aliases: [
            "cleaning"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sprinkler",
        codepoint: "F0081",
        aliases: [
            "irrigation"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "sprinkler-variant",
        codepoint: "F0082",
        aliases: [
            "irrigation"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "sprout",
        codepoint: "FE49",
        aliases: [
            "seedling",
            "plant"
        ],
        tags: [
            "Agriculture",
            "Nature"
        ],
    },
    {
        
        name: "sprout-outline",
        codepoint: "FE4A",
        aliases: [
            "seedling-outline",
            "plant-outline"
        ],
        tags: [
            "Agriculture",
            "Nature"
        ],
    },
    {
        
        name: "square",
        codepoint: "F763",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "square-edit-outline",
        codepoint: "F90B",
        aliases: [],
        tags: [
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "square-inc",
        codepoint: "F4CA",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "square-inc-cash",
        codepoint: "F4CB",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Banking"
        ],
    },
    {
        
        name: "square-medium",
        codepoint: "FA12",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "square-medium-outline",
        codepoint: "FA13",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "square-outline",
        codepoint: "F762",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "square-root",
        codepoint: "F783",
        aliases: [],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "square-root-box",
        codepoint: "F9A2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "square-small",
        codepoint: "FA14",
        aliases: [
            "bullet"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "squeegee",
        codepoint: "FAE0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "ssh",
        codepoint: "F8BF",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "stack-exchange",
        codepoint: "F60B",
        aliases: [
            "stackexchange"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "stack-overflow",
        codepoint: "F4CC",
        aliases: [
            "stackoverflow"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "stadium",
        codepoint: "F001A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "stadium-variant",
        codepoint: "F71F",
        aliases: [
            "arena"
        ],
        tags: [
            "Places",
            "Sport"
        ],
    },
    {
        
        name: "stairs",
        codepoint: "F4CD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "stamper",
        codepoint: "FD15",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "standard-definition",
        codepoint: "F7EE",
        aliases: [],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "star",
        codepoint: "F4CE",
        aliases: [
            "grade",
            "star-rate"
        ],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "star-box",
        codepoint: "FA72",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "star-box-outline",
        codepoint: "FA73",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "star-circle",
        codepoint: "F4CF",
        aliases: [
            "stars"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "star-circle-outline",
        codepoint: "F9A3",
        aliases: [
            "feature-highlight"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "star-face",
        codepoint: "F9A4",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "star-four-points",
        codepoint: "FAE1",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "star-four-points-outline",
        codepoint: "FAE2",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "star-half",
        codepoint: "F4D0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "star-off",
        codepoint: "F4D1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "star-outline",
        codepoint: "F4D2",
        aliases: [
            "star-border"
        ],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "star-three-points",
        codepoint: "FAE3",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "star-three-points-outline",
        codepoint: "FAE4",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "state-machine",
        codepoint: "F021A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "steam",
        codepoint: "F4D3",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "steam-box",
        codepoint: "F90C",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "steering",
        codepoint: "F4D4",
        aliases: [
            "search-hands-free"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "steering-off",
        codepoint: "F90D",
        aliases: [
            "search-hands-free-off"
        ],
        tags: [
            "Automotive"
        ],
    },
    {
        
        name: "step-backward",
        codepoint: "F4D5",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "step-backward-2",
        codepoint: "F4D6",
        aliases: [
            "frame-backward"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "step-forward",
        codepoint: "F4D7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "step-forward-2",
        codepoint: "F4D8",
        aliases: [
            "frame-forward"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "stethoscope",
        codepoint: "F4D9",
        aliases: [],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "sticker",
        codepoint: "F5D0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sticker-emoji",
        codepoint: "F784",
        aliases: [],
        tags: [
            "Emoji"
        ],
    },
    {
        
        name: "stocking",
        codepoint: "F4DA",
        aliases: [],
        tags: [
            "Holiday"
        ],
    },
    {
        
        name: "stomach",
        codepoint: "F00BE",
        aliases: [],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "stop",
        codepoint: "F4DB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "stop-circle",
        codepoint: "F666",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "stop-circle-outline",
        codepoint: "F667",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "store",
        codepoint: "F4DC",
        aliases: [
            "shop",
            "store-mall-directory"
        ],
        tags: [
            "Places",
            "Shopping"
        ],
    },
    {
        
        name: "store-24-hour",
        codepoint: "F4DD",
        aliases: [
            "local-convenience-store",
            "shop-24-hour"
        ],
        tags: [
            "Places",
            "Shopping"
        ],
    },
    {
        
        name: "storefront",
        codepoint: "F00EC",
        aliases: [
            "awning"
        ],
        tags: [
            "Shopping"
        ],
    },
    {
        
        name: "stove",
        codepoint: "F4DE",
        aliases: [
            "cooker",
            "oven"
        ],
        tags: [
            "Food \/ Drink",
            "Home Automation"
        ],
    },
    {
        
        name: "strategy",
        codepoint: "F0201",
        aliases: [
            "football-play"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "strava",
        codepoint: "FB25",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "stretch-to-page",
        codepoint: "FF48",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format",
            "Arrow"
        ],
    },
    {
        
        name: "stretch-to-page-outline",
        codepoint: "FF49",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format",
            "Arrow"
        ],
    },
    {
        
        name: "subdirectory-arrow-left",
        codepoint: "F60C",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "subdirectory-arrow-right",
        codepoint: "F60D",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "subtitles",
        codepoint: "FA15",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "subtitles-outline",
        codepoint: "FA16",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "subway",
        codepoint: "F6AB",
        aliases: [
            "metro",
            "tube",
            "underground"
        ],
        tags: [
            "Transportation + Other"
        ],
    },
    {
        
        name: "subway-alert-variant",
        codepoint: "FD79",
        aliases: [
            "subway-warning-variant"
        ],
        tags: [
            "Alert \/ Error",
            "Transportation + Other"
        ],
    },
    {
        
        name: "subway-variant",
        codepoint: "F4DF",
        aliases: [
            "metro-variant",
            "tube-variant",
            "underground-variant",
            "directions-subway",
            "directions-transit"
        ],
        tags: [
            "Transportation + Other"
        ],
    },
    {
        
        name: "summit",
        codepoint: "F785",
        aliases: [
            "peak"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sunglasses",
        codepoint: "F4E0",
        aliases: [],
        tags: [
            "Clothing"
        ],
    },
    {
        
        name: "surround-sound",
        codepoint: "F5C5",
        aliases: [],
        tags: [
            "Audio"
        ],
    },
    {
        
        name: "surround-sound-2-0",
        codepoint: "F7EF",
        aliases: [
            "stereo"
        ],
        tags: [
            "Audio"
        ],
    },
    {
        
        name: "surround-sound-3-1",
        codepoint: "F7F0",
        aliases: [],
        tags: [
            "Audio"
        ],
    },
    {
        
        name: "surround-sound-5-1",
        codepoint: "F7F1",
        aliases: [],
        tags: [
            "Audio"
        ],
    },
    {
        
        name: "surround-sound-7-1",
        codepoint: "F7F2",
        aliases: [],
        tags: [
            "Audio"
        ],
    },
    {
        
        name: "svg",
        codepoint: "F720",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "swap-horizontal",
        codepoint: "F4E1",
        aliases: [
            "arrow-left-right"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "swap-horizontal-bold",
        codepoint: "FBA9",
        aliases: [
            "arrow-left-right-bold"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "swap-horizontal-circle",
        codepoint: "F0002",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "swap-horizontal-circle-outline",
        codepoint: "F0003",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "swap-horizontal-variant",
        codepoint: "F8C0",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "swap-vertical",
        codepoint: "F4E2",
        aliases: [
            "import-export",
            "arrow-up-down"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "swap-vertical-bold",
        codepoint: "FBAA",
        aliases: [
            "arrow-up-down-bold",
            "import-export-bold"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "swap-vertical-circle",
        codepoint: "F0004",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "swap-vertical-circle-outline",
        codepoint: "F0005",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "swap-vertical-variant",
        codepoint: "F8C1",
        aliases: [
            "swap-calls"
        ],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "swim",
        codepoint: "F4E3",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "switch",
        codepoint: "F4E4",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sword",
        codepoint: "F4E5",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "sword-cross",
        codepoint: "F786",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "symfony",
        codepoint: "FAE5",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sync",
        codepoint: "F4E6",
        aliases: [
            "loop",
            "counterclockwise-arrows",
            "circular-arrows",
            "circle-arrows"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "sync-alert",
        codepoint: "F4E7",
        aliases: [
            "sync-warning",
            "sync-problem"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "sync-off",
        codepoint: "F4E8",
        aliases: [
            "sync-disabled"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tab",
        codepoint: "F4E9",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tab-minus",
        codepoint: "FB26",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tab-plus",
        codepoint: "F75B",
        aliases: [
            "tab-add"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tab-remove",
        codepoint: "FB27",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tab-unselected",
        codepoint: "F4EA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "table",
        codepoint: "F4EB",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "table-border",
        codepoint: "FA17",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "table-chair",
        codepoint: "F0083",
        aliases: [
            "restaurant",
            "kitchen",
            "dining"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "table-column",
        codepoint: "F834",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "table-column-plus-after",
        codepoint: "F4EC",
        aliases: [
            "table-column-add-after"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "table-column-plus-before",
        codepoint: "F4ED",
        aliases: [
            "table-column-add-before"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "table-column-remove",
        codepoint: "F4EE",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "table-column-width",
        codepoint: "F4EF",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "table-edit",
        codepoint: "F4F0",
        aliases: [],
        tags: [
            "Edit \/ Modify",
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "table-eye",
        codepoint: "F00BF",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "table-headers-eye",
        codepoint: "F0248",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "table-headers-eye-off",
        codepoint: "F0249",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "table-large",
        codepoint: "F4F1",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format",
            "Geographic Information System"
        ],
    },
    {
        
        name: "table-large-plus",
        codepoint: "FFA4",
        aliases: [
            "table-large-add"
        ],
        tags: [
            "Text \/ Content \/ Format",
            "Geographic Information System"
        ],
    },
    {
        
        name: "table-large-remove",
        codepoint: "FFA5",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format",
            "Geographic Information System"
        ],
    },
    {
        
        name: "table-merge-cells",
        codepoint: "F9A5",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "table-of-contents",
        codepoint: "F835",
        aliases: [
            "toc"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "table-plus",
        codepoint: "FA74",
        aliases: [
            "table-add"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "table-remove",
        codepoint: "FA75",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "table-row",
        codepoint: "F836",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "table-row-height",
        codepoint: "F4F2",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "table-row-plus-after",
        codepoint: "F4F3",
        aliases: [
            "table-row-add-after"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "table-row-plus-before",
        codepoint: "F4F4",
        aliases: [
            "table-row-add-before"
        ],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "table-row-remove",
        codepoint: "F4F5",
        aliases: [],
        tags: [
            "Text \/ Content \/ Format"
        ],
    },
    {
        
        name: "table-search",
        codepoint: "F90E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "table-settings",
        codepoint: "F837",
        aliases: [],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "table-tennis",
        codepoint: "FE4B",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "tablet",
        codepoint: "F4F6",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "tablet-android",
        codepoint: "F4F7",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "tablet-cellphone",
        codepoint: "F9A6",
        aliases: [
            "mobile-devices",
            "tablet-mobile-phone",
            "tablet-smartphone"
        ],
        tags: [
            "Cellphone \/ Phone",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "tablet-dashboard",
        codepoint: "FEEB",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "tablet-ipad",
        codepoint: "F4F8",
        aliases: [
            "tablet-mac"
        ],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "taco",
        codepoint: "F761",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "tag",
        codepoint: "F4F9",
        aliases: [
            "local-offer"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tag-faces",
        codepoint: "F4FA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tag-heart",
        codepoint: "F68A",
        aliases: [
            "loyalty"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tag-heart-outline",
        codepoint: "FBAB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tag-minus",
        codepoint: "F90F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ], 
    },
    {
        
        name: "tag-minus-outline",
        codepoint: "F024A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tag-multiple",
        codepoint: "F4FB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tag-off",
        codepoint: "F024B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tag-off-outline",
        codepoint: "F024C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tag-outline",
        codepoint: "F4FC",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tag-plus",
        codepoint: "F721",
        aliases: [
            "tag-add"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tag-plus-outline",
        codepoint: "F024D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tag-remove",
        codepoint: "F722",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tag-remove-outline",
        codepoint: "F024E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tag-text",
        codepoint: "F024F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tag-text-outline",
        codepoint: "F4FD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tank",
        codepoint: "FD16",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tanker-truck",
        codepoint: "F0006",
        aliases: [
            "fuel-truck",
            "oil-truck",
            "water-truck",
            "tanker"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "tape-measure",
        codepoint: "FB28",
        aliases: [
            "measuring-tape"
        ],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "target",
        codepoint: "F4FE",
        aliases: [
            "registration-mark"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "target-account",
        codepoint: "FBAC",
        aliases: [
            "crosshairs-account",
            "target-user"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "target-variant",
        codepoint: "FA76",
        aliases: [
            "registration-mark"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "taxi",
        codepoint: "F4FF",
        aliases: [
            "local-taxi"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "tea",
        codepoint: "FD7A",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "tea-outline",
        codepoint: "FD7B",
        aliases: [],
        tags: [
            "Food \/ Drink"
        ],
    },
    {
        
        name: "teach",
        codepoint: "F88F",
        aliases: [
            "teacher",
            "teaching",
            "lecture",
            "college",
            "blackboard",
            "whiteboard"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "teamviewer",
        codepoint: "F500",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "telegram",
        codepoint: "F501",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "telescope",
        codepoint: "FB29",
        aliases: [],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "television",
        codepoint: "F502",
        aliases: [
            "tv"
        ],
        tags: [
            "Device \/ Tech",
            "Home Automation"
        ],
    },
    {
        
        name: "television-box",
        codepoint: "F838",
        aliases: [
            "tv-box",
            "tv-guide"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "television-classic",
        codepoint: "F7F3",
        aliases: [
            "tv-classic"
        ],
        tags: [
            "Device \/ Tech",
            "Home Automation"
        ],
    },
    {
        
        name: "television-classic-off",
        codepoint: "F839",
        aliases: [
            "tv-classic-off"
        ],
        tags: [
            "Device \/ Tech",
            "Home Automation"
        ],
    },
    {
        
        name: "television-clean",
        codepoint: "F013B",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "television-guide",
        codepoint: "F503",
        aliases: [],
        tags: [
            "Device \/ Tech",
            "Home Automation"
        ],
    },
    {
        
        name: "television-off",
        codepoint: "F83A",
        aliases: [
            "tv-off"
        ],
        tags: [
            "Device \/ Tech",
            "Home Automation"
        ],
    },
    {
        
        name: "television-pause",
        codepoint: "FFA6",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "television-play",
        codepoint: "FEEC",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "television-stop",
        codepoint: "FFA7",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "temperature-celsius",
        codepoint: "F504",
        aliases: [
            "temperature-centigrade"
        ],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "temperature-fahrenheit",
        codepoint: "F505",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "temperature-kelvin",
        codepoint: "F506",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "tennis",
        codepoint: "FD7C",
        aliases: [
            "tennis-racquet",
            "tennis-racket"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "tennis-ball",
        codepoint: "F507",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "tent",
        codepoint: "F508",
        aliases: [
            "camping"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "terraform",
        codepoint: "F0084",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "terrain",
        codepoint: "F509",
        aliases: [],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "test-tube",
        codepoint: "F668",
        aliases: [],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "test-tube-empty",
        codepoint: "F910",
        aliases: [],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "test-tube-off",
        codepoint: "F911",
        aliases: [],
        tags: [
            "Science"
        ],
    },
    {
        
        name: "text",
        codepoint: "F9A7",
        aliases: [
            "notes"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "text-recognition",
        codepoint: "F0168",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "text-shadow",
        codepoint: "F669",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "text-short",
        codepoint: "F9A8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "text-subject",
        codepoint: "F9A9",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "text-to-speech",
        codepoint: "F50A",
        aliases: [
            "tts",
            "microphone-message"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "text-to-speech-off",
        codepoint: "F50B",
        aliases: [
            "tts-off",
            "microphone-message-off"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "textarea",
        codepoint: "F00C0",
        aliases: [],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "textbox",
        codepoint: "F60E",
        aliases: [
            "rename"
        ],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "textbox-password",
        codepoint: "F7F4",
        aliases: [],
        tags: [
            "Form"
        ],
    },
    {
        
        name: "texture",
        codepoint: "F50C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "texture-box",
        codepoint: "F0007",
        aliases: [
            "surface-area"
        ],
        tags: [
            "Math"
        ],
    },
    {
        
        name: "theater",
        codepoint: "F50D",
        aliases: [
            "cinema",
            "theatre"
        ],
        tags: [
            "Places"
        ],
    },
    {
        
        name: "theme-light-dark",
        codepoint: "F50E",
        aliases: [
            "sun-moon-stars"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "thermometer",
        codepoint: "F50F",
        aliases: [],
        tags: [
            "Weather",
            "Home Automation",
            "Automotive"
        ],
    },
    {
        
        name: "thermometer-alert",
        codepoint: "FE61",
        aliases: [
            "thermometer-warning"
        ],
        tags: [
            "Home Automation",
            "Weather",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "thermometer-chevron-down",
        codepoint: "FE62",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "thermometer-chevron-up",
        codepoint: "FE63",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "thermometer-high",
        codepoint: "F00ED",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "thermometer-lines",
        codepoint: "F510",
        aliases: [],
        tags: [
            "Weather",
            "Home Automation"
        ],
    },
    {
        
        name: "thermometer-low",
        codepoint: "F00EE",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "thermometer-minus",
        codepoint: "FE64",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "thermometer-plus",
        codepoint: "FE65",
        aliases: [
            "thermometer-add"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "thermostat",
        codepoint: "F393",
        aliases: [
            "nest"
        ],
        tags: [
            "Device \/ Tech",
            "Home Automation"
        ],
    },
    {
        
        name: "thermostat-box",
        codepoint: "F890",
        aliases: [],
        tags: [
            "Home Automation",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "thought-bubble",
        codepoint: "F7F5",
        aliases: [
            "comic-bubble",
            "thinking"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "thought-bubble-outline",
        codepoint: "F7F6",
        aliases: [
            "comic-thought-bubble-outline",
            "thinking-outline",
            "think-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "thumb-down",
        codepoint: "F511",
        aliases: [
            "dislike",
            "thumbs-down"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "thumb-down-outline",
        codepoint: "F512",
        aliases: [
            "dislike-outline",
            "thumbs-down-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "thumb-up",
        codepoint: "F513",
        aliases: [
            "like",
            "thumbs-up"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "thumb-up-outline",
        codepoint: "F514",
        aliases: [
            "like-outline",
            "thumbs-up-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "thumbs-up-down",
        codepoint: "F515",
        aliases: [
            "like-dislike"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "ticket",
        codepoint: "F516",
        aliases: [
            "local-activity",
            "local-play",
            "local-attraction"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "ticket-account",
        codepoint: "F517",
        aliases: [
            "ticket-user"
        ],
        tags: [
            "Account \/ User"
        ],
    },
    {
        
        name: "ticket-confirmation",
        codepoint: "F518",
        aliases: [
            "confirmation-number"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "ticket-outline",
        codepoint: "F912",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "ticket-percent",
        codepoint: "F723",
        aliases: [
            "coupon",
            "voucher"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tie",
        codepoint: "F519",
        aliases: [],
        tags: [
            "Clothing"
        ],
    },
    {
        
        name: "tilde",
        codepoint: "F724",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "timelapse",
        codepoint: "F51A",
        aliases: [],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "timeline",
        codepoint: "FBAD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "timeline-alert",
        codepoint: "FFB2",
        aliases: [],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "timeline-alert-outline",
        codepoint: "FFB5",
        aliases: [],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "timeline-clock",
        codepoint: "F0226",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "timeline-clock-outline",
        codepoint: "F0227",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "timeline-help",
        codepoint: "FFB6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "timeline-help-outline",
        codepoint: "FFB7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "timeline-outline",
        codepoint: "FBAE",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "timeline-plus",
        codepoint: "FFB3",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "timeline-plus-outline",
        codepoint: "FFB4",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "timeline-text",
        codepoint: "FBAF",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "timeline-text-outline",
        codepoint: "FBB0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "timer",
        codepoint: "F51B",
        aliases: [
            "stopwatch"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "timer-10",
        codepoint: "F51C",
        aliases: [
            "timer-ten"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "timer-3",
        codepoint: "F51D",
        aliases: [
            "timer-three"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "timer-off",
        codepoint: "F51E",
        aliases: [
            "stopwatch-off"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "timer-sand",
        codepoint: "F51F",
        aliases: [
            "hourglass"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "timer-sand-empty",
        codepoint: "F6AC",
        aliases: [
            "hourglass-empty"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "timer-sand-full",
        codepoint: "F78B",
        aliases: [
            "hourglass-full"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "timetable",
        codepoint: "F520",
        aliases: [],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "toaster",
        codepoint: "F0085",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "toaster-off",
        codepoint: "F01E2",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "toaster-oven",
        codepoint: "FCAF",
        aliases: [],
        tags: [
            "Home Automation",
            "Food \/ Drink"
        ],
    },
    {
        
        name: "toggle-switch",
        codepoint: "F521",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "toggle-switch-off",
        codepoint: "F522",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "toggle-switch-off-outline",
        codepoint: "FA18",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "toggle-switch-outline",
        codepoint: "FA19",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "toilet",
        codepoint: "F9AA",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "toolbox",
        codepoint: "F9AB",
        aliases: [],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "toolbox-outline",
        codepoint: "F9AC",
        aliases: [
            "service-toolbox"
        ],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "tools",
        codepoint: "F0086",
        aliases: [
            "wrench",
            "screwdriver"
        ],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "tooltip",
        codepoint: "F523",
        aliases: [],
        tags: [
            "Tooltip"
        ],
    },
    {
        
        name: "tooltip-account",
        codepoint: "F00C",
        aliases: [
            "tooltip-user",
            "tooltip-person",
            "account-location"
        ],
        tags: [
            "Account \/ User",
            "Tooltip"
        ],
    },
    {
        
        name: "tooltip-edit",
        codepoint: "F524",
        aliases: [],
        tags: [
            "Tooltip",
            "Edit \/ Modify"
        ],
    },
    {
        
        name: "tooltip-image",
        codepoint: "F525",
        aliases: [],
        tags: [
            "Tooltip"
        ],
    },
    {
        
        name: "tooltip-image-outline",
        codepoint: "FBB1",
        aliases: [],
        tags: [
            "Tooltip"
        ],
    },
    {
        
        name: "tooltip-outline",
        codepoint: "F526",
        aliases: [],
        tags: [
            "Tooltip"
        ],
    },
    {
        
        name: "tooltip-plus",
        codepoint: "FBB2",
        aliases: [
            "tooltip-add"
        ],
        tags: [
            "Tooltip"
        ],
    },
    {
        
        name: "tooltip-plus-outline",
        codepoint: "F527",
        aliases: [
            "tooltip-outline-plus",
            "tooltip-add-outline"
        ],
        tags: [
            "Tooltip"
        ],
    },
    {
        
        name: "tooltip-text",
        codepoint: "F528",
        aliases: [],
        tags: [
            "Tooltip"
        ],
    },
    {
        
        name: "tooltip-text-outline",
        codepoint: "FBB3",
        aliases: [],
        tags: [
            "Tooltip"
        ],
    },
    {
        
        name: "tooth",
        codepoint: "F8C2",
        aliases: [
            "dentist"
        ],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "tooth-outline",
        codepoint: "F529",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "toothbrush",
        codepoint: "F0154",
        aliases: [
            "dentist",
            "oral-hygiene"
        ],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "toothbrush-electric",
        codepoint: "F0157",
        aliases: [
            "dentist",
            "oral-hygiene"
        ],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "toothbrush-paste",
        codepoint: "F0155",
        aliases: [
            "dentist",
            "oral-hygiene"
        ],
        tags: [
            "Medical \/ Hospital"
        ],
    },
    {
        
        name: "tor",
        codepoint: "F52A",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "tortoise",
        codepoint: "FD17",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tournament",
        codepoint: "F9AD",
        aliases: [
            "bracket"
        ],
        tags: [
            "Gaming \/ RPG",
            "Sport"
        ],
    },
    {
        
        name: "tower-beach",
        codepoint: "F680",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tower-fire",
        codepoint: "F681",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "towing",
        codepoint: "F83B",
        aliases: [
            "auto-towing",
            "truck"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "track-light",
        codepoint: "F913",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "trackpad",
        codepoint: "F7F7",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "trackpad-lock",
        codepoint: "F932",
        aliases: [],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "tractor",
        codepoint: "F891",
        aliases: [
            "farm"
        ],
        tags: [
            "Agriculture",
            "Transportation + Road"
        ],
    },
    {
        
        name: "trademark",
        codepoint: "FA77",
        aliases: [
            "tm"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "traffic-light",
        codepoint: "F52B",
        aliases: [],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "train",
        codepoint: "F52C",
        aliases: [
            "directions-railway"
        ],
        tags: [
            "Navigation",
            "Transportation + Other"
        ],
    },
    {
        
        name: "train-car",
        codepoint: "FBB4",
        aliases: [
            "commute",
            "transportation",
            "travel"
        ],
        tags: [
            "Transportation + Other"
        ],
    },
    {
        
        name: "train-variant",
        codepoint: "F8C3",
        aliases: [],
        tags: [
            "Transportation + Other"
        ],
    },
    {
        
        name: "tram",
        codepoint: "F52D",
        aliases: [],
        tags: [
            "Navigation",
            "Transportation + Other"
        ],
    },
    {
        
        name: "tram-side",
        codepoint: "F0008",
        aliases: [],
        tags: [
            "Transportation + Other"
        ],
    },
    {
        
        name: "transcribe",
        codepoint: "F52E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "transcribe-close",
        codepoint: "F52F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "transfer",
        codepoint: "F0087",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "transfer-down",
        codepoint: "FD7D",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "transfer-left",
        codepoint: "FD7E",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "transfer-right",
        codepoint: "F530",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "transfer-up",
        codepoint: "FD7F",
        aliases: [],
        tags: [
            "Arrow"
        ],
    },
    {
        
        name: "transit-connection",
        codepoint: "FD18",
        aliases: [],
        tags: [
            "Navigation"
        ],
    },
    {
        
        name: "transit-connection-variant",
        codepoint: "FD19",
        aliases: [],
        tags: [
            "Navigation"
        ],
    },
    {
        
        name: "transit-detour",
        codepoint: "FFA8",
        aliases: [],
        tags: [
            "Navigation"
        ],
    },
    {
        
        name: "transit-transfer",
        codepoint: "F6AD",
        aliases: [
            "transfer-within-a-station"
        ],
        tags: [
            "Transportation + Other",
            "Navigation"
        ],
    },
    {
        
        name: "transition",
        codepoint: "F914",
        aliases: [
            "animation",
            "motion",
            "translate"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "transition-masked",
        codepoint: "F915",
        aliases: [
            "masked-transitions"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "translate",
        codepoint: "F5CA",
        aliases: [
            "language"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "translate-off",
        codepoint: "FE66",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "transmission-tower",
        codepoint: "FD1A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "trash-can",
        codepoint: "FA78",
        aliases: [
            "delete",
            "rubbish-bin",
            "trashcan",
            "garbage-can"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "trash-can-outline",
        codepoint: "FA79",
        aliases: [
            "delete-outline",
            "rubbish-bin-outline",
            "trashcan-outline",
            "garbage-can-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "treasure-chest",
        codepoint: "F725",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "tree",
        codepoint: "F531",
        aliases: [
            "plant"
        ],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "tree-outline",
        codepoint: "FE4C",
        aliases: [
            "plant"
        ],
        tags: [
            "Nature"
        ],
    },
    {
        
        name: "trello",
        codepoint: "F532",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "trending-down",
        codepoint: "F533",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "trending-neutral",
        codepoint: "F534",
        aliases: [
            "trending-flat"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "trending-up",
        codepoint: "F535",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "triangle",
        codepoint: "F536",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "triangle-outline",
        codepoint: "F537",
        aliases: [],
        tags: [
            "Shape"
        ],
    },
    {
        
        name: "triforce",
        codepoint: "FBB5",
        aliases: [
            "zelda"
        ],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "trophy",
        codepoint: "F538",
        aliases: [
            "achievement"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "trophy-award",
        codepoint: "F539",
        aliases: [
            "achievement-award"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "trophy-broken",
        codepoint: "FD80",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "trophy-outline",
        codepoint: "F53A",
        aliases: [
            "achievement-outline"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "trophy-variant",
        codepoint: "F53B",
        aliases: [
            "achievement-variant"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "trophy-variant-outline",
        codepoint: "F53C",
        aliases: [
            "achievement-variant-outline"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "truck",
        codepoint: "F53D",
        aliases: [
            "lorry",
            "local-shipping",
            "courier"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "truck-check",
        codepoint: "FCB0",
        aliases: [
            "truck-tick",
            "lorry-check",
            "courier-check"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "truck-delivery",
        codepoint: "F53E",
        aliases: [
            "lorry-delivery"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "truck-fast",
        codepoint: "F787",
        aliases: [
            "lorry-fast",
            "courier-fast"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "truck-trailer",
        codepoint: "F726",
        aliases: [],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "trumpet",
        codepoint: "F00C1",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "tshirt-crew",
        codepoint: "FA7A",
        aliases: [
            "t-shirt-crew"
        ],
        tags: [
            "Clothing"
        ],
    },
    {
        
        name: "tshirt-crew-outline",
        codepoint: "F53F",
        aliases: [
            "t-shirt-crew-outline"
        ],
        tags: [
            "Clothing"
        ],
    },
    {
        
        name: "tshirt-v",
        codepoint: "FA7B",
        aliases: [
            "t-shirt-v"
        ],
        tags: [
            "Clothing"
        ],
    },
    {
        
        name: "tshirt-v-outline",
        codepoint: "F540",
        aliases: [
            "t-shirt-v-outline"
        ],
        tags: [
            "Clothing"
        ],
    },
    {
        
        name: "tumble-dryer",
        codepoint: "F916",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "tumble-dryer-alert",
        codepoint: "F01E5",
        aliases: [],
        tags: [
            "Home Automation",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "tumble-dryer-off",
        codepoint: "F01E6",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "tumblr",
        codepoint: "F541",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "tumblr-box",
        codepoint: "F917",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "tumblr-reblog",
        codepoint: "F542",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "tune",
        codepoint: "F62E",
        aliases: [
            "mixer-settings",
            "equaliser"
        ],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "tune-vertical",
        codepoint: "F66A",
        aliases: [
            "equaliser-vertical",
            "instant-mix"
        ],
        tags: [
            "Settings"
        ],
    },
    {
        
        name: "turnstile",
        codepoint: "FCB1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "turnstile-outline",
        codepoint: "FCB2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "turtle",
        codepoint: "FCB3",
        aliases: [],
        tags: [
            "Animal"
        ],
    },
    {
        
        name: "twitch",
        codepoint: "F543",
        aliases: [],
        tags: [
            "Social Media",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "twitter",
        codepoint: "F544",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Social Media"
        ],
    },
    {
        
        name: "twitter-box",
        codepoint: "F545",
        aliases: [],
        tags: [
            "Social Media",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "twitter-circle",
        codepoint: "F546",
        aliases: [],
        tags: [
            "Social Media",
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "twitter-retweet",
        codepoint: "F547",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "two-factor-authentication",
        codepoint: "F9AE",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "typewriter",
        codepoint: "FF4A",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "uber",
        codepoint: "F748",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "ubisoft",
        codepoint: "FBB6",
        aliases: [
            "uplay"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "ubuntu",
        codepoint: "F548",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "ufo",
        codepoint: "F00EF",
        aliases: [
            "unidentified-flying-object",
            "alien"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "ufo-outline",
        codepoint: "F00F0",
        aliases: [
            "unidentified-flying-object-outline",
            "alien"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "ultra-high-definition",
        codepoint: "F7F8",
        aliases: [
            "uhd"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "umbraco",
        codepoint: "F549",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "umbrella",
        codepoint: "F54A",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "umbrella-closed",
        codepoint: "F9AF",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "umbrella-outline",
        codepoint: "F54B",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "undo",
        codepoint: "F54C",
        aliases: [
            "arrow"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "undo-variant",
        codepoint: "F54D",
        aliases: [
            "arrow"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "unfold-less-horizontal",
        codepoint: "F54E",
        aliases: [
            "chevron-down-up",
            "collapse-horizontal"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "unfold-less-vertical",
        codepoint: "F75F",
        aliases: [
            "chevron-right-left",
            "collapse-vertical"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "unfold-more-horizontal",
        codepoint: "F54F",
        aliases: [
            "chevron-up-down",
            "expand-horizontal"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "unfold-more-vertical",
        codepoint: "F760",
        aliases: [
            "chevron-left-right",
            "expand-vertical"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "ungroup",
        codepoint: "F550",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "unicode",
        codepoint: "FEED",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "unity",
        codepoint: "F6AE",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "unreal",
        codepoint: "F9B0",
        aliases: [
            "unreal-engine"
        ],
        tags: [
            "Brand \/ Logo",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "untappd",
        codepoint: "F551",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "update",
        codepoint: "F6AF",
        aliases: [
            "clockwise",
            "clock-arrow"
        ],
        tags: [
            "Date \/ Time"
        ],
    },
    {
        
        name: "upload",
        codepoint: "F552",
        aliases: [
            "file-upload"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "upload-multiple",
        codepoint: "F83C",
        aliases: [
            "uploads"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "upload-network",
        codepoint: "F6F5",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "upload-network-outline",
        codepoint: "FCB4",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "upload-off",
        codepoint: "F00F1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "upload-off-outline",
        codepoint: "F00F2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "upload-outline",
        codepoint: "FE67",
        aliases: [
            "file-upload-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "usb",
        codepoint: "F553",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "usb-port",
        codepoint: "F021B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "valve",
        codepoint: "F0088",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "valve-closed",
        codepoint: "F0089",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "valve-open",
        codepoint: "F008A",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "van-passenger",
        codepoint: "F7F9",
        aliases: [],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "van-utility",
        codepoint: "F7FA",
        aliases: [
            "van-candy"
        ],
        tags: [
            "Transportation + Road"
        ],
    },
    {
        
        name: "vanish",
        codepoint: "F7FB",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "vanity-light",
        codepoint: "F020C",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "variable",
        codepoint: "FAE6",
        aliases: [],
        tags: [
            "Developer \/ Languages",
            "Math"
        ],
    },
    {
        
        name: "variable-box",
        codepoint: "F013C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "vector-arrange-above",
        codepoint: "F554",
        aliases: [],
        tags: [
            "Vector",
            "Arrange",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-arrange-below",
        codepoint: "F555",
        aliases: [],
        tags: [
            "Vector",
            "Arrange",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-bezier",
        codepoint: "FAE7",
        aliases: [],
        tags: [
            "Vector"
        ],
    },
    {
        
        name: "vector-circle",
        codepoint: "F556",
        aliases: [],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-circle-variant",
        codepoint: "F557",
        aliases: [],
        tags: [
            "Vector"
        ],
    },
    {
        
        name: "vector-combine",
        codepoint: "F558",
        aliases: [],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-curve",
        codepoint: "F559",
        aliases: [
            "bezier"
        ],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-difference",
        codepoint: "F55A",
        aliases: [],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-difference-ab",
        codepoint: "F55B",
        aliases: [],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-difference-ba",
        codepoint: "F55C",
        aliases: [],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-ellipse",
        codepoint: "F892",
        aliases: [],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-intersection",
        codepoint: "F55D",
        aliases: [],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-line",
        codepoint: "F55E",
        aliases: [],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-link",
        codepoint: "F0009",
        aliases: [],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-point",
        codepoint: "F55F",
        aliases: [],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-polygon",
        codepoint: "F560",
        aliases: [],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-polyline",
        codepoint: "F561",
        aliases: [],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-polyline-edit",
        codepoint: "F0250",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "vector-polyline-minus",
        codepoint: "F0251",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "vector-polyline-plus",
        codepoint: "F0252",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "vector-polyline-remove",
        codepoint: "F0253",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "vector-radius",
        codepoint: "F749",
        aliases: [],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-rectangle",
        codepoint: "F5C6",
        aliases: [],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-selection",
        codepoint: "F562",
        aliases: [],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-square",
        codepoint: "F001",
        aliases: [
            "mdi"
        ],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-triangle",
        codepoint: "F563",
        aliases: [],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "vector-union",
        codepoint: "F564",
        aliases: [],
        tags: [
            "Vector",
            "Geographic Information System"
        ],
    },
    {
        
        name: "venmo",
        codepoint: "F578",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "vhs",
        codepoint: "FA1A",
        aliases: [
            "video-home-system",
            "vhs-cassette",
            "vhs-tape"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "vibrate",
        codepoint: "F566",
        aliases: [
            "vibration"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "vibrate-off",
        codepoint: "FCB5",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "video",
        codepoint: "F567",
        aliases: [
            "videocam"
        ],
        tags: [
            "Video \/ Movie",
            "Home Automation"
        ],
    },
    {
        
        name: "video-3d",
        codepoint: "F7FC",
        aliases: [],
        tags: [
            "Video \/ Movie",
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-3d-variant",
        codepoint: "FEEE",
        aliases: [],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-4k-box",
        codepoint: "F83D",
        aliases: [
            "4k"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-account",
        codepoint: "F918",
        aliases: [
            "video-user"
        ],
        tags: [
            "Account \/ User",
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-check",
        codepoint: "F008B",
        aliases: [],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-check-outline",
        codepoint: "F008C",
        aliases: [],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-image",
        codepoint: "F919",
        aliases: [],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-input-antenna",
        codepoint: "F83E",
        aliases: [
            "settings-input-antenna"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-input-component",
        codepoint: "F83F",
        aliases: [
            "video-input-composite",
            "settings-input-component",
            "settings-input-composite",
            "video-input-ypbpr",
            "rca"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-input-hdmi",
        codepoint: "F840",
        aliases: [
            "settings-input-hdmi"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-input-scart",
        codepoint: "FFA9",
        aliases: [],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-input-svideo",
        codepoint: "F841",
        aliases: [
            "settings-input-svideo"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-minus",
        codepoint: "F9B1",
        aliases: [
            "video-remove"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-off",
        codepoint: "F568",
        aliases: [
            "videocam-off"
        ],
        tags: [
            "Video \/ Movie",
            "Home Automation"
        ],
    },
    {
        
        name: "video-off-outline",
        codepoint: "FBB7",
        aliases: [
            "videocam-off-outline"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-outline",
        codepoint: "FBB8",
        aliases: [
            "videocam-outline"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-plus",
        codepoint: "F9B2",
        aliases: [
            "video-call",
            "video-add"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-stabilization",
        codepoint: "F91A",
        aliases: [
            "video-stabilisation"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "video-switch",
        codepoint: "F569",
        aliases: [
            "switch-video"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-vintage",
        codepoint: "FA1B",
        aliases: [
            "video-film",
            "video-classic"
        ],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-wireless",
        codepoint: "FEEF",
        aliases: [],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "video-wireless-outline",
        codepoint: "FEF0",
        aliases: [],
        tags: [
            "Video \/ Movie"
        ],
    },
    {
        
        name: "view-agenda",
        codepoint: "F56A",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-agenda-outline",
        codepoint: "F0203",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-array",
        codepoint: "F56B",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-carousel",
        codepoint: "F56C",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-column",
        codepoint: "F56D",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-comfy",
        codepoint: "FE4D",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-compact",
        codepoint: "FE4E",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-compact-outline",
        codepoint: "FE4F",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-dashboard",
        codepoint: "F56E",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-dashboard-outline",
        codepoint: "FA1C",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-dashboard-variant",
        codepoint: "F842",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-day",
        codepoint: "F56F",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-grid",
        codepoint: "F570",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-grid-outline",
        codepoint: "F0204",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-grid-plus",
        codepoint: "FFAA",
        aliases: [
            "view-grid-add"
        ],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-grid-plus-outline",
        codepoint: "F0205",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-headline",
        codepoint: "F571",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-list",
        codepoint: "F572",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-module",
        codepoint: "F573",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-parallel",
        codepoint: "F727",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-quilt",
        codepoint: "F574",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-sequential",
        codepoint: "F728",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-split-horizontal",
        codepoint: "FBA7",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-split-vertical",
        codepoint: "FBA8",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-stream",
        codepoint: "F575",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "view-week",
        codepoint: "F576",
        aliases: [],
        tags: [
            "View"
        ],
    },
    {
        
        name: "vimeo",
        codepoint: "F577",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "violin",
        codepoint: "F60F",
        aliases: [],
        tags: [
            "Music"
        ],
    },
    {
        
        name: "virtual-reality",
        codepoint: "F893",
        aliases: [
            "vr"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "visual-studio",
        codepoint: "F610",
        aliases: [
            "visualstudio"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "visual-studio-code",
        codepoint: "FA1D",
        aliases: [
            "vs-code"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "vk",
        codepoint: "F579",
        aliases: [
            "vkontakte"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "vk-box",
        codepoint: "F57A",
        aliases: [
            "vkontakte-box"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "vk-circle",
        codepoint: "F57B",
        aliases: [
            "vkontakte-circle"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "vlc",
        codepoint: "F57C",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "voice",
        codepoint: "F5CB",
        aliases: [
            "record-voice-over",
            "speak",
            "talk",
            "speaking",
            "talking"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "voice-off",
        codepoint: "FEF1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "voicemail",
        codepoint: "F57D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "volleyball",
        codepoint: "F9B3",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "volume-high",
        codepoint: "F57E",
        aliases: [
            "audio",
            "speaker",
            "speakerphone"
        ],
        tags: [
            "Audio",
            "Home Automation",
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "volume-low",
        codepoint: "F57F",
        aliases: [
            "audio",
            "speaker"
        ],
        tags: [
            "Audio",
            "Home Automation",
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "volume-medium",
        codepoint: "F580",
        aliases: [
            "audio",
            "speaker"
        ],
        tags: [
            "Audio",
            "Home Automation",
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "volume-minus",
        codepoint: "F75D",
        aliases: [
            "volume-decrease"
        ],
        tags: [
            "Audio",
            "Home Automation",
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "volume-mute",
        codepoint: "F75E",
        aliases: [],
        tags: [
            "Audio",
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "volume-off",
        codepoint: "F581",
        aliases: [
            "mute",
            "audio-off",
            "speaker-off",
            "speakerphone-off"
        ],
        tags: [
            "Audio",
            "Home Automation",
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "volume-plus",
        codepoint: "F75C",
        aliases: [
            "volume-increase"
        ],
        tags: [
            "Audio",
            "Home Automation",
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "volume-source",
        codepoint: "F014B",
        aliases: [],
        tags: [
            "Cellphone \/ Phone",
            "Audio"
        ],
    },
    {
        
        name: "volume-variant-off",
        codepoint: "FE68",
        aliases: [],
        tags: [
            "Audio",
            "Cellphone \/ Phone"
        ],
    },
    {
        
        name: "volume-vibrate",
        codepoint: "F014C",
        aliases: [],
        tags: [
            "Cellphone \/ Phone",
            "Audio"
        ],
    },
    {
        
        name: "vote",
        codepoint: "FA1E",
        aliases: [
            "how-to-vote"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "vote-outline",
        codepoint: "FA1F",
        aliases: [
            "how-to-vote-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "vpn",
        codepoint: "F582",
        aliases: [
            "virtual-private-network"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "vuejs",
        codepoint: "F843",
        aliases: [
            "vue-js"
        ],
        tags: [
            "Brand \/ Logo",
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "vuetify",
        codepoint: "FE50",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "walk",
        codepoint: "F583",
        aliases: [
            "directions-walk",
            "walker",
            "walking"
        ],
        tags: [
            "Sport",
            "Transportation + Other"
        ],
    },
    {
        
        name: "wall",
        codepoint: "F7FD",
        aliases: [
            "bricks"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "wall-sconce",
        codepoint: "F91B",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "wall-sconce-flat",
        codepoint: "F91C",
        aliases: [
            "ceiling-light-flat"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "wall-sconce-variant",
        codepoint: "F91D",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "wallet",
        codepoint: "F584",
        aliases: [
            "account-balance-wallet"
        ],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "wallet-giftcard",
        codepoint: "F585",
        aliases: [
            "card-giftcard",
            "redeem"
        ],
        tags: [
            "Shopping",
            "Banking"
        ],
    },
    {
        
        name: "wallet-membership",
        codepoint: "F586",
        aliases: [
            "card-membership"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "wallet-outline",
        codepoint: "FBB9",
        aliases: [
            "account-balance-wallet-outline"
        ],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "wallet-plus",
        codepoint: "FFAB",
        aliases: [
            "wallet-add"
        ],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "wallet-plus-outline",
        codepoint: "FFAC",
        aliases: [
            "wallet-add-outline"
        ],
        tags: [
            "Banking"
        ],
    },
    {
        
        name: "wallet-travel",
        codepoint: "F587",
        aliases: [
            "card-travel"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "wallpaper",
        codepoint: "FE69",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "wan",
        codepoint: "F588",
        aliases: [
            "wide-area-network"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "wardrobe",
        codepoint: "FFAD",
        aliases: [
            "closet"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "wardrobe-outline",
        codepoint: "FFAE",
        aliases: [
            "closet-outline"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "warehouse",
        codepoint: "FFBB",
        aliases: [],
        tags: [
            "Places"
        ],
    },
    {
        
        name: "washing-machine",
        codepoint: "F729",
        aliases: [
            "laundrette",
            "local-laundry-service"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "washing-machine-alert",
        codepoint: "F01E7",
        aliases: [],
        tags: [
            "Home Automation",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "washing-machine-off",
        codepoint: "F01E8",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "watch",
        codepoint: "F589",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "watch-export",
        codepoint: "F58A",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "watch-export-variant",
        codepoint: "F894",
        aliases: [],
        tags: [
            "Device \/ Tech",
            "Device \/ Tech"
        ],
    },
    {
        
        name: "watch-import",
        codepoint: "F58B",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "watch-import-variant",
        codepoint: "F895",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "watch-variant",
        codepoint: "F896",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "watch-vibrate",
        codepoint: "F6B0",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "watch-vibrate-off",
        codepoint: "FCB6",
        aliases: [],
        tags: [
            "Device \/ Tech"
        ],
    },
    {
        
        name: "water",
        codepoint: "F58C",
        aliases: [
            "drop",
            "blood",
            "water-drop"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "water-boiler",
        codepoint: "FFAF",
        aliases: [
            "water-heater"
        ],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "water-boiler-alert",
        codepoint: "F01DE",
        aliases: [],
        tags: [
            "Home Automation",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "water-boiler-off",
        codepoint: "F01DF",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "water-off",
        codepoint: "F58D",
        aliases: [
            "format-color-reset"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "water-outline",
        codepoint: "FE6A",
        aliases: [
            "drop-outline",
            "blood-outline",
            "water-drop-outline"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "water-percent",
        codepoint: "F58E",
        aliases: [
            "humidity"
        ],
        tags: [
            "Weather",
            "Home Automation"
        ],
    },
    {
        
        name: "water-pump",
        codepoint: "F58F",
        aliases: [],
        tags: [
            "Agriculture",
            "Home Automation"
        ],
    },
    {
        
        name: "water-pump-off",
        codepoint: "FFB0",
        aliases: [],
        tags: [
            "Agriculture",
            "Home Automation"
        ],
    },
    {
        
        name: "water-well",
        codepoint: "F008D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "water-well-outline",
        codepoint: "F008E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "watermark",
        codepoint: "F612",
        aliases: [
            "branding-watermark"
        ],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "wave",
        codepoint: "FF4B",
        aliases: [
            "water"
        ],
        tags: [
            "Transportation + Water"
        ],
    },
    {
        
        name: "waves",
        codepoint: "F78C",
        aliases: [
            "ocean",
            "lake",
            "flood",
            "water"
        ],
        tags: [
            "Weather",
            "Transportation + Water"
        ],
    },
    {
        
        name: "waze",
        codepoint: "FBBA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "weather-cloudy",
        codepoint: "F590",
        aliases: [],
        tags: [
            "Weather",
            "Cloud"
        ],
    },
    {
        
        name: "weather-cloudy-alert",
        codepoint: "FF4C",
        aliases: [],
        tags: [
            "Weather",
            "Alert \/ Error",
            "Cloud"
        ],
    },
    {
        
        name: "weather-cloudy-arrow-right",
        codepoint: "FE51",
        aliases: [],
        tags: [
            "Weather",
            "Cloud"
        ],
    },
    {
        
        name: "weather-fog",
        codepoint: "F591",
        aliases: [
            "weather-mist"
        ],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-hail",
        codepoint: "F592",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-hazy",
        codepoint: "FF4D",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-hurricane",
        codepoint: "F897",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-lightning",
        codepoint: "F593",
        aliases: [
            "weather-storm",
            "weather-thunder",
            "weather-flash"
        ],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-lightning-rainy",
        codepoint: "F67D",
        aliases: [
            "weather-thunder-rainy",
            "weather-storm"
        ],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-night",
        codepoint: "F594",
        aliases: [
            "moon-and-stars",
            "night-sky"
        ],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-night-partly-cloudy",
        codepoint: "FF4E",
        aliases: [],
        tags: [
            "Weather",
            "Weather",
            "Cloud"
        ],
    },
    {
        
        name: "weather-partly-cloudy",
        codepoint: "F595",
        aliases: [
            "weather-partlycloudy"
        ],
        tags: [
            "Weather",
            "Cloud"
        ],
    },
    {
        
        name: "weather-partly-lightning",
        codepoint: "FF4F",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-partly-rainy",
        codepoint: "FF50",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-partly-snowy",
        codepoint: "FF51",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-partly-snowy-rainy",
        codepoint: "FF52",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-pouring",
        codepoint: "F596",
        aliases: [
            "weather-heavy-rain"
        ],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-rainy",
        codepoint: "F597",
        aliases: [
            "weather-drizzle",
            "weather-spitting"
        ],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-snowy",
        codepoint: "F598",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-snowy-heavy",
        codepoint: "FF53",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-snowy-rainy",
        codepoint: "F67E",
        aliases: [
            "weather-sleet"
        ],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-sunny",
        codepoint: "F599",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-sunny-alert",
        codepoint: "FF54",
        aliases: [
            "heat-alert",
            "heat-advisory",
            "sun-advisory"
        ],
        tags: [
            "Weather",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "weather-sunset",
        codepoint: "F59A",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-sunset-down",
        codepoint: "F59B",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-sunset-up",
        codepoint: "F59C",
        aliases: [
            "sunrise"
        ],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-tornado",
        codepoint: "FF55",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-windy",
        codepoint: "F59D",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "weather-windy-variant",
        codepoint: "F59E",
        aliases: [],
        tags: [
            "Weather"
        ],
    },
    {
        
        name: "web",
        codepoint: "F59F",
        aliases: [
            "language"
        ],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "web-box",
        codepoint: "FFB1",
        aliases: [
            "language-box"
        ],
        tags: [
            "Geographic Information System"
        ],
    },
    {
        
        name: "web-clock",
        codepoint: "F0275",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "webcam",
        codepoint: "F5A0",
        aliases: [
            "web-camera"
        ],
        tags: [
            "Video \/ Movie",
            "Home Automation"
        ],
    },
    {
        
        name: "webhook",
        codepoint: "F62F",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "webpack",
        codepoint: "F72A",
        aliases: [],
        tags: [
            "Brand \/ Logo",
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "webrtc",
        codepoint: "F0273",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "wechat",
        codepoint: "F611",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "weight",
        codepoint: "F5A1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "weight-gram",
        codepoint: "FD1B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "weight-kilogram",
        codepoint: "F5A2",
        aliases: [
            "weight-kg"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "weight-lifter",
        codepoint: "F0188",
        aliases: [
            "barbell",
            "crossfit"
        ],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "weight-pound",
        codepoint: "F9B4",
        aliases: [
            "weight-lb"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "whatsapp",
        codepoint: "F5A3",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "wheelchair-accessibility",
        codepoint: "F5A4",
        aliases: [
            "accessible"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "whistle",
        codepoint: "F9B5",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "white-balance-auto",
        codepoint: "F5A5",
        aliases: [
            "wb-auto"
        ],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "white-balance-incandescent",
        codepoint: "F5A6",
        aliases: [
            "wb-incandescent"
        ],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "white-balance-iridescent",
        codepoint: "F5A7",
        aliases: [
            "wb-iridescent"
        ],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "white-balance-sunny",
        codepoint: "F5A8",
        aliases: [
            "wb-sunny"
        ],
        tags: [
            "Photography"
        ],
    },
    {
        
        name: "widgets",
        codepoint: "F72B",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "wifi",
        codepoint: "F5A9",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "wifi-off",
        codepoint: "F5AA",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "wifi-star",
        codepoint: "FE6B",
        aliases: [
            "wifi-favourite",
            "network-favourite"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "wifi-strength-1",
        codepoint: "F91E",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "wifi-strength-1-alert",
        codepoint: "F91F",
        aliases: [
            "wifi-strength-1-warning"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "wifi-strength-1-lock",
        codepoint: "F920",
        aliases: [],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "wifi-strength-2",
        codepoint: "F921",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "wifi-strength-2-alert",
        codepoint: "F922",
        aliases: [
            "wifi-strength-2-warning"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "wifi-strength-2-lock",
        codepoint: "F923",
        aliases: [],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "wifi-strength-3",
        codepoint: "F924",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1200-1499" ],
    },
    {
        
        name: "wifi-strength-3-alert",
        codepoint: "F925",
        aliases: [
            "wifi-strength-3-warning"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "wifi-strength-3-lock",
        codepoint: "F926",
        aliases: [],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "wifi-strength-4",
        codepoint: "F927",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "wifi-strength-4-alert",
        codepoint: "F928",
        aliases: [
            "wifi-strength-4-warning"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "wifi-strength-4-lock",
        codepoint: "F929",
        aliases: [],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "wifi-strength-alert-outline",
        codepoint: "F92A",
        aliases: [
            "wifi-strength-warning-outline",
            "wifi-strength-0-alert",
            "wifi-strength-0-warning"
        ],
        tags: [
            "Alert \/ Error"
        ],
    },
    {
        
        name: "wifi-strength-lock-outline",
        codepoint: "F92B",
        aliases: [
            "wifi-strength-0-lock"
        ],
        tags: [
            "Lock"
        ],
    },
    {
        
        name: "wifi-strength-off",
        codepoint: "F92C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "wifi-strength-off-outline",
        codepoint: "F92D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "wifi-strength-outline",
        codepoint: "F92E",
        aliases: [
            "wifi-strength-0"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "wii",
        codepoint: "F5AB",
        aliases: [
            "nintendo-wii"
        ],
        tags: [
            "Brand \/ Logo",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "wiiu",
        codepoint: "F72C",
        aliases: [
            "nintendo-wiiu"
        ],
        tags: [
            "Brand \/ Logo",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "wikipedia",
        codepoint: "F5AC",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "wind-turbine",
        codepoint: "FD81",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "window-close",
        codepoint: "F5AD",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "window-closed",
        codepoint: "F5AE",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "window-closed-variant",
        codepoint: "F0206",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "window-maximize",
        codepoint: "F5AF",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "window-minimize",
        codepoint: "F5B0",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "window-open",
        codepoint: "F5B1",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "window-open-variant",
        codepoint: "F0207",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "window-restore",
        codepoint: "F5B2",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "window-shutter",
        codepoint: "F0147",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "window-shutter-alert",
        codepoint: "F0148",
        aliases: [],
        tags: [
            "Home Automation",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "window-shutter-open",
        codepoint: "F0149",
        aliases: [],
        tags: [
            "Home Automation"
        ],
    },
    {
        
        name: "windows",
        codepoint: "F5B3",
        aliases: [
            "microsoft-windows"
        ],
        tags: [
            "Brand \/ Logo",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "windows-classic",
        codepoint: "FA20",
        aliases: [
            "microsoft-windows-classic"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "wiper",
        codepoint: "FAE8",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "wiper-wash",
        codepoint: "FD82",
        aliases: [
            "wiper-fluid",
            "washer-fluid"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "wordpress",
        codepoint: "F5B4",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "worker",
        codepoint: "F5B5",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "wrap",
        codepoint: "F5B6",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "wrap-disabled",
        codepoint: "FBBB",
        aliases: [
            "unwrap"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "wrench",
        codepoint: "F5B7",
        aliases: [
            "build",
            "spanner"
        ],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "wrench-outline",
        codepoint: "FBBC",
        aliases: [
            "build-outline",
            "spanner-outline"
        ],
        tags: [
            "Hardware \/ Tools"
        ],
    },
    {
        
        name: "wunderlist",
        codepoint: "F5B8",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "xamarin",
        codepoint: "F844",
        aliases: [
            "microsoft-xamarin"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "xamarin-outline",
        codepoint: "F845",
        aliases: [
            "microsoft-xamarin-outline"
        ],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "xaml",
        codepoint: "F673",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "xbox",
        codepoint: "F5B9",
        aliases: [
            "xbox-live",
            "microsoft"
        ],
        tags: [
            "Social Media",
            "Brand \/ Logo",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "xbox-controller",
        codepoint: "F5BA",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "xbox-controller-battery-alert",
        codepoint: "F74A",
        aliases: [
            "xbox-controller-battery-warning"
        ],
        tags: [
            "Battery",
            "Gaming \/ RPG",
            "Alert \/ Error"
        ],
    },
    {
        
        name: "xbox-controller-battery-charging",
        codepoint: "FA21",
        aliases: [],
        tags: [
            "Gaming \/ RPG",
            "Battery"
        ],
    },
    {
        
        name: "xbox-controller-battery-empty",
        codepoint: "F74B",
        aliases: [],
        tags: [
            "Battery",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "xbox-controller-battery-full",
        codepoint: "F74C",
        aliases: [],
        tags: [
            "Battery",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "xbox-controller-battery-low",
        codepoint: "F74D",
        aliases: [],
        tags: [
            "Battery",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "xbox-controller-battery-medium",
        codepoint: "F74E",
        aliases: [],
        tags: [
            "Battery",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "xbox-controller-battery-unknown",
        codepoint: "F74F",
        aliases: [],
        tags: [
            "Battery",
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "xbox-controller-menu",
        codepoint: "FE52",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "xbox-controller-off",
        codepoint: "F5BB",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "xbox-controller-view",
        codepoint: "FE53",
        aliases: [],
        tags: [
            "Gaming \/ RPG"
        ],
    },
    {
        
        name: "xda",
        codepoint: "F5BC",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "xing",
        codepoint: "F5BD",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "xing-box",
        codepoint: "F5BE",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "xing-circle",
        codepoint: "F5BF",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "xml",
        codepoint: "F5C0",
        aliases: [
            "code"
        ],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "xmpp",
        codepoint: "F7FE",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "yahoo",
        codepoint: "FB2A",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "yammer",
        codepoint: "F788",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "yeast",
        codepoint: "F5C1",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "yelp",
        codepoint: "F5C2",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "yin-yang",
        codepoint: "F67F",
        aliases: [
            "taoism"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "yoga",
        codepoint: "F01A7",
        aliases: [],
        tags: [
            "Sport"
        ],
    },
    {
        
        name: "youtube",
        codepoint: "F5C3",
        aliases: [
            "video-youtube",
            "youtube-play"
        ],
        tags: [
            "Brand \/ Logo",
            "Social Media"
        ],
    },
    {
        
        name: "youtube-creator-studio",
        codepoint: "F846",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "youtube-gaming",
        codepoint: "F847",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "youtube-subscription",
        codepoint: "FD1C",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "youtube-tv",
        codepoint: "F448",
        aliases: [],
        tags: [
            "Brand \/ Logo"
        ],
    },
    {
        
        name: "z-wave",
        codepoint: "FAE9",
        aliases: [
            "zwave"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "zend",
        codepoint: "FAEA",
        aliases: [],
        tags: [
            "Developer \/ Languages"
        ],
    },
    {
        
        name: "zigbee",
        codepoint: "FD1D",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "zip-box",
        codepoint: "F5C4",
        aliases: [
            "compressed-file"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "zip-box-outline",
        codepoint: "F001B",
        aliases: [
            "compressed-file-outline"
        ],
        tags: [
            "Files \/ Folders"
        ],
    },
    {
        
        name: "zip-disk",
        codepoint: "FA22",
        aliases: [],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "zodiac-aquarius",
        codepoint: "FA7C",
        aliases: [
            "horoscope-aquarius"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "zodiac-aries",
        codepoint: "FA7D",
        aliases: [
            "horoscope-aries"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "zodiac-cancer",
        codepoint: "FA7E",
        aliases: [
            "horoscope-cancer"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "zodiac-capricorn",
        codepoint: "FA7F",
        aliases: [
            "horoscope-capricorn"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "zodiac-gemini",
        codepoint: "FA80",
        aliases: [
            "horoscope-gemini"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "zodiac-leo",
        codepoint: "FA81",
        aliases: [
            "horoscope-leo"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "zodiac-libra",
        codepoint: "FA82",
        aliases: [
            "horoscope-libra"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "zodiac-pisces",
        codepoint: "FA83",
        aliases: [
            "horoscope-pisces"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "zodiac-sagittarius",
        codepoint: "FA84",
        aliases: [
            "horoscope-sagittarius"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "zodiac-scorpio",
        codepoint: "FA85",
        aliases: [
            "horoscope-scorpio"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "zodiac-taurus",
        codepoint: "FA86",
        aliases: [
            "horoscope-taurus"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    },
    {
        
        name: "zodiac-virgo",
        codepoint: "FA87",
        aliases: [
            "horoscope-virgo"
        ],
        tags: [ "empty_tag", "Unallocated 1500-1546" ],
    }
]

// function give_me_ico_by_tag(arg) {
//     var data = ico_list.map(ico_list => {
//         //console.log('arg: '+arg+' : '+ico_list.tags.length+ ' name: '+ico_list.name);
//         ico_list.tags.map((comment, index) =>  {
//             var arraycontainsturtles = (comment.indexOf(arg) > -1);
//             if(arraycontainsturtles) {
//                 console.log(comment.length+ ' ' +comment+' name: '+ico_list.name+' hex: '+ico_list.codepoint)
//             }
//         })

//     });
// }
