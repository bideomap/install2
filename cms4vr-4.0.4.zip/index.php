<?php
/**
 * Copyright (c) VR System Studio Paweł Jakubowski - All rights reserved
 * Copying or/and redistributing of this software without the express permission
 * granted by VR System Studio Paweł Jakubowski is strictly prohibited.
 */

$subdirPart = str_replace('/admin', '', dirname($_SERVER['PHP_SELF']));

// default settings
$templatesName = 'rubee';
$type = 'blank';
$panoId = 0;
$panoName = false;
$lang = 'en';
$view_h = 0;
$view_v = 0;
$view_f = 90;
$poiName = 'false';
$viewType = 'nv';
$fromlink = 'false';
$defaultProjectTitle = 'VRM';
$defaultProjectDescription = '';
$geoTag = false;

$initvars = "{templates_name:'%TEMPLATE%',%STICKER%mydata:'%MYDATA%'}";

$db = new SQLite3(__DIR__ . '/admin/data/vrm.db');

// SSL redirect
if((!isset($_SERVER["HTTPS"]) || strtolower($_SERVER["HTTPS"]) !== "on") && getSetting('force_ssl') == 1 && !isset($_GET['no_ssl'])) {
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit;
}

// set template name
if (getSetting('template')) {
    $templatesName = getSetting('template');
}
$initvars = str_replace('%TEMPLATE%', $templatesName, $initvars);

if (getSetting('default_language')) {
    $lang = getSetting('default_language');
}

$req = $subdirPart != '/' ? str_replace($subdirPart, '', $_SERVER['REQUEST_URI']) : $_SERVER['REQUEST_URI'];
$req = strtok($req, '?');

if (isset(explode('/', $req)[1]) && in_array(explode('/', $req)[1], ['poi', 'postcard', 'link', 'sticker'])) {
    $linkDetails = json_decode(getLink(explode('/', $req)[2]), true);

    if (isset($linkDetails['mydata'])) {
        $initvars = str_replace('%MYDATA%', $linkDetails['mydata'], $initvars);
        $linkParams = explode('|', $linkDetails['mydata']);
        $panoId = str_replace('scene_p', '', $linkParams[1]);
        $lang = $linkParams[2];
    }

    if (isset($linkDetails['type']) && $linkDetails['type'] == 'sticker') {
        $initvars = str_replace('%STICKER%', "sticker:'" . $linkDetails['typeVal'] . "',", $initvars);
    } else {
        $initvars = str_replace('%STICKER%', '', $initvars);
    }
} else {

    $initvars = str_replace('%STICKER%', '', $initvars);

    $re = '/scene_(\d+)_([a-z]{2}).html\/?(poi.*)?$/';
    preg_match_all($re, $req, $matches, PREG_SET_ORDER, 0);

    if (isset($matches[0][1])) {
        $type = 'link';
        $panoId = $matches[0][1];
        $panoDetails = getSinglePano($panoId);
        $startView = explode(',', $panoDetails['start_view']);

        if (count(array_filter($startView))) {
            $view_h = trim($startView[0]);
            $view_v = trim($startView[1]);
            $view_f = trim($startView[2]);
        }
    }

    // get first panoId if it was not revealed from the matching (for main url visits)
    $readFile = file_exists('tourdata-backup.xml') ? 'tourdata-backup.xml' : 'tourdata.xml';
    if (!$panoId && file_exists($readFile)) {
        $xmlFile = simplexml_load_file($readFile);
        if ($xmlFile->xpath('structure/cat[contains(@hide,"false")]/pano')) {
            $firstPanoName = (string)$xmlFile->xpath('structure/cat[contains(@hide,"false")]/pano')[0]->attributes()['name'];
            $panoId = str_replace('scene_p', '', $firstPanoName);
        }
    }

    if (isset($matches[0][2])) {
        $lang = $matches[0][2];
    }

    if (isset($matches[0][3])) {
        $poiId = str_replace('poi_', '', $matches[0][3]);
        $poiName = getPoiName($poiId);
        $poiName = $poiName ? $poiName : 'false';
        $type = 'poi';
    }

    $mydata = $type . "|" . ($panoId ? 'scene_p' . $panoId : 0) . "|" . $lang . "|" . $view_h . "|" . $view_v . "|" . $view_f . "|" . $viewType . "|" . $poiName;
    $initvars = str_replace('%MYDATA%', $mydata, $initvars);
}

$panoDetails = getSinglePano($panoId);
if ($panoDetails['lat'] != '' && $panoDetails['lng'] != '') {
    $geoTag['lat'] = $panoDetails['lat'];
    $geoTag['lng'] = $panoDetails['lng'];
}

$projectLangSettings = json_decode(getSetting('project_lang_settings'), true);
if (isset($projectLangSettings[$lang]['name'])) {
    $defaultProjectTitle = $projectLangSettings[$lang]['name'];
    $defaultProjectDescription = strip_tags($projectLangSettings[$lang]['description']);
}

function getSetting($key) {
    global $db;
    $q = $db->prepare('SELECT value FROM settings WHERE key=:key');
    $q->bindValue(':key', $key, SQLITE3_TEXT);
    $result = $q->execute()->fetchArray();
    return $result['value'];
}

function getPanoDetails($panoId, $lang) {
    global $db;
    global $panoName;
    $stmt = $db->prepare('SELECT * from pano_phrases pp JOIN languages l ON l.id = pp.languages_id WHERE panos_id = :panos_id AND short = :lang AND l.public = 1');
    $stmt->bindValue(':panos_id', $panoId, SQLITE3_INTEGER);
    $stmt->bindValue(':lang', $lang, SQLITE3_TEXT);

    $panoDetails = '';

    $result = $stmt->execute();
    while ($row = $result->fetchArray()) {
        $panoName = $row['name'];
        $panoDetails .= '<h1>' . $row['name'] . '</h1>' . PHP_EOL;
        $panoDetails .= $row['description'] . PHP_EOL;
    }

    return $panoDetails;
}

function getSinglePano($panoId) {
    global $db;
    $q = $db->prepare('SELECT * FROM panos WHERE id=:id');
    $q->bindValue(':id', $panoId, SQLITE3_INTEGER);
    $result = $q->execute()->fetchArray();
    return $result;
}

function getAllPanos() {
    global $db;
    $stmt = $db->prepare('SELECT * FROM pano_phrases pp JOIN languages l ON l.id = pp.languages_id WHERE l.public = 1');

    $result = $stmt->execute();
    $return = [];
    while ($row = $result->fetchArray()) {
        if (!isset($return[$row['panos_id']])) {
            $return[$row['panos_id']] = [];
        }
        $return[$row['panos_id']][$row['short']] = $row['name'];
    }
    return $return;
}

function getLink($link) {
    global $db;
    $stmt = $db->prepare('SELECT * FROM shortlinks WHERE link = :link');
    $stmt->bindValue(':link', $link, SQLITE3_TEXT);
    $result = $stmt->execute()->fetchArray();
    return $result['params'];
}

function getPoiName($poiId) {
    global $db;
    $stmt = $db->prepare('SELECT * FROM poi WHERE id = :id');
    $stmt->bindValue(':id', $poiId, SQLITE3_INTEGER);
    $result = $stmt->execute()->fetchArray();
    return $result['name'];
}

function getPoiFromPano($panoId, $lang) {
    global $db;
    $stmt = $db->prepare('SELECT p.id AS poiId, pp.name AS poiName FROM poi p JOIN poi_phrases pp ON pp.poi_id = p.id JOIN languages l ON l.id = pp.languages_id
                                WHERE panos_id = :panos_id AND short = :lang');
    $stmt->bindValue(':panos_id', $panoId, SQLITE3_INTEGER);
    $stmt->bindValue(':lang', $lang, SQLITE3_TEXT);

    $result = $stmt->execute();
    while ($row = $result->fetchArray()) {
        echo '<li><a href="scene_' . $panoId . '_' . $lang . '.html/poi_' . $row['poiId'] . '">' . $row['poiName'] . '</a></li>' . PHP_EOL;
    }
}

$allPanos = getAllPanos();

$settings = json_decode(getSetting('global_modules'));
$googleUA = isset($settings->m_analytics->id) ? $settings->m_analytics->id : '';

$facebookAppId = false;
if (isset($settings->m_facebook->aktyw) && $settings->m_facebook->aktyw) {
    $facebookAppId = isset($settings->m_facebook->app_id) ? $settings->m_facebook->app_id : false;
}

$panoDetails = getPanoDetails($panoId, $lang);

$isSsl = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== '';
?>
<!DOCTYPE html>
<html>
<head>
    <title><?= $defaultProjectTitle ?><?= $panoName ? ' : ' . $panoName : ''; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
    <meta http-equiv="x-ua-compatible" content="IE=edge" />
    <base href="<?= $subdirPart != '/' ? $subdirPart . '/' : '/' ?>" />
    <?php if ($defaultProjectDescription) { ?>
    <meta name="description" content="<?= $defaultProjectDescription ?>" />
    <?php } ?>
    <?php if ($googleUA) { ?>
    <!-- Google Analytics -->
    <script>
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

        ga('create', '<?= $googleUA ?>', 'auto');
        ga('send', 'pageview');
    </script>
    <!-- End Google Analytics -->
    <?php } ?>

    <script type="text/javascript" src="admin/assets/js/jquery-1.10.2.js"></script>
    <!--  Paper Dashboard core CSS    -->
    <!-- <link href="admin/assets/css/paper-dashboard.css" rel="stylesheet"/> -->
    <link href="admin/assets/css/themify-icons.css" rel="stylesheet">


    <style>
        @-ms-viewport { width:device-width; }
        @media only screen and (min-device-width:800px) { html { overflow:hidden; } }
        html { height:100%; overflow:hidden;}
        body { height:100%; overflow:hidden; margin:0; padding:0; font-family:Arial, Helvetica, sans-serif; font-size:16px;}
        #krpanoSWFObject pre { background: none;}
        @media only screen and (max-device-width:768px){

            body.modal-open {
                overflow: hidden;
                /*position: fixed;*/
            }
        }

        body.viewport-lg {
            position: absolute;
        }
    </style>
    <!-- for Facebook -->
    <meta property="og:updated_time" content="<?=time()?>" />
    <?php if ($facebookAppId) { ?>
    <meta property="fb:app_id" content="<?= $facebookAppId ?>"/>
    <?php } ?>
    <meta property="og:url" content="<?= ($isSsl ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] ?>" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="<?= $defaultProjectTitle ?><?= $panoName ? ' : ' . $panoName : ''; ?>" />
    <meta property="og:description" content="<?= $defaultProjectDescription ?>" />
    <meta property="og:site_name" content="<?= $defaultProjectTitle ?>"/>
    <?php

    $thumbName = file_exists(__DIR__ . '/panos/p' . $panoId . '.tiles/fb_thumb.jpg') ? 'fb_thumb.jpg' : 'thumb.jpg';
    $imageSize = getimagesize(__DIR__ . '/panos/p' . $panoId . '.tiles/' . $thumbName);

    if ($panoId) {
        $imageLink = ($isSsl ? "https" : "http") . '://' . $_SERVER['HTTP_HOST'] . ($subdirPart !== '/' ? $subdirPart : '');
        $imageLink .= '/panos/p' . $panoId . '.tiles/' . $thumbName . '?nc=' . uniqid();
        echo '<meta property="og:image" content="' . $imageLink . '" />';
        $isSsl = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== '';
        if ($isSsl) {
            echo '<meta property="og:image:secure_url" content="' . $imageLink . '" />';
        }
    ?>
    <meta property="og:image:width" content="<?= $imageSize[0] ?>" />
    <meta property="og:image:height" content="<?= $imageSize[1] ?>" />
    <meta property="og:image:alt" content="thumbnail" />
    <meta property="og:image:type" content="image/jpeg" />

    <!-- for Twitter -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="<?= $defaultProjectTitle ?>" />
    <meta name="twitter:description" content="<?= $defaultProjectDescription ?>" />
    <meta name="twitter:image" content="<?= $imageLink ?>" />

    <?php if ($geoTag) { ?>
    <meta name="geo.position" content="<?= $geoTag['lat'] ?>;<?= $geoTag['lng'] ?>" />
    <meta name="ICBM" content="<?= $geoTag['lat'] ?>, <?= $geoTag['lng'] ?>" />
    <?php } ?>
    <?php } ?>
</head>

<?php
$cookie = 1;
if (getSetting('m_privacy') === 'true') {
    $cookie = isset($_COOKIE['cms4vr-privacy-fe']) ? (int)$_COOKIE['cms4vr-privacy-fe'] : 0;
}
?>

<body<?= $cookie === 0 ? ' style="background: #f4f6fa"' : ''?>>

<?php

function isBot() {
    return isset($_SERVER['HTTP_USER_AGENT']) && preg_match('/bot|curl|crawl|facebook|fetch|mediapartners|slurp|spider/i',
            $_SERVER['HTTP_USER_AGENT']);
}

if ($cookie === 0 && trim(strip_tags(getSetting('privacy_fe_' . $lang))) && !isBot()) { ?>
<div id="privacy" style="width: 90%; height: 100%;margin: auto;">
    <div class="row-fluid" style="padding-top:60px">
        <div class="col-md-5" style="background: #ffffff; float: none; margin: 0 auto;-moz-border-radius:20px;-webkit-border-radius:20px;-ms-border-radius:20px;-o-border-radius:20px;border-radius:20px;-moz-box-shadow: 0 0 4px 1px rgba(0, 0, 0, .05);-webkit-box-shadow: 0 0 4px 1px rgba(0, 0, 0, .05);-o-box-shadow: 0 0 4px 1px rgba(0, 0, 0, .05);-ms-box-shadow: 0 0 4px 1px rgba(0, 0, 0, .05);box-shadow: 0 0 4px 1px rgba(0, 0, 0, .05);border: 1px solid #ccc">
            <div class="page-heading animated fadeInDownBig">
                <h1 class="text-center"><i class="ti-info-alt" style="padding-left:20px;"></i></h1>
            </div>
            <hr />
            <div class="box-info full" style="padding-left:20px;">
                <?= getSetting('privacy_fe_' . $lang) ?>
            </div>
            <hr />
            <footer style="padding-left:20px;">
                <button id="cookieAccept" class="btn btn-success"><i class="ti-check"></i></button>
                <button id="cookieReject" class="btn btn-danger pull-right"><i class="ti-close"></i></button>
            </footer>
            <br />
        </div>
    </div>
</div>
<?php } else { ?>
<script src="tour.js?nc=<?= getSetting('version') ?>"></script>
<div id="pano" style="width:100%;height:100%;position: absolute;">
    <script>
        if (navigator.msPointerEnabled)
        {
          navigator.__defineGetter__("msPointerEnabled", function(){return false;});
          navigator.__defineGetter__("pointerEnabled", function(){return true;});
        }
        // navigator.pointerEnabled = navigator.maxTouchPoints > 0;               // Edge 17 touch support workaround
        document.documentElement.ontouchstart = navigator.maxTouchPoints > 0;  // Chrome 70 touch support workaround
        <?php if ($panoId !== 0) { ?>
        embedpano({xml:"tour.xml?nc=<?= uniqid() ?>", target:"pano", html5:(navigator.userAgent.toLowerCase().indexOf("googlebot") >= 0 ? "always" : "auto"), initvars:<?= $initvars ?>, mobilescale:1.0, passQueryParameters:true,onready:krpano_onready_callback});
        <?php } else { ?>
        embedpano({id : "krpanoSWFObject", xml:"plugins/under_construction.xml",target : "pano", passQueryParameters : false});
        <?php } ?>

        function krpano_onready_callback(krpano_interface) {krpano = krpano_interface};
    </script>
</div>
<div id="loadinginfo" style="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);padding:10px;pointer-events:none;z-index:2;"><img src="plugins/loader.gif"></div>
<?php } ?>

<article>
    <?= $panoDetails ?>
</article>
<aside>
    <ul>
        <?php getPoiFromPano($panoId, $lang); ?>
    </ul>
</aside>
<nav>
    <ul>
        <?php
        foreach ($allPanos as $panoId => $languages) {
            foreach ($languages as $lang => $langPhrase) {
                echo '<li><a href="scene_' . $panoId . '_' . $lang . '.html">' . $langPhrase . '</a></li>' . PHP_EOL;
            }
        }
        ?>
    </ul>
</nav>

<div id="vrModal" class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" style="z-index:2000000">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><i class="mdi mdi-window-close"></i></button>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function(){
        $('#vrModal').on('hide.bs.modal', function (e) {
            var krpano = document.getElementById("krpanoSWFObject");
            krpano.set('html_popup_is_open', false);
        });
        $('#cookieAccept').click(function(e){
            e.preventDefault();
            var CookieDate = new Date;
            CookieDate.setFullYear(CookieDate.getFullYear() + 1);
            document.cookie = 'cms4vr-privacy-fe=1; expires=' + CookieDate.toGMTString() + ';';
            window.location.reload();
        });
        $('#cookieReject').click(function(e){
            e.preventDefault();
            document.cookie = 'cms4vr-privacy-fe=0';
            window.location.reload();
        });
    });
</script>
</body>
</html>
