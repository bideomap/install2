/*
	krpano - color setter plugin
*/

var krpanoplugin = function()
{
	var local = this;

	var krpano = null;
	var plugin = null;

	var inputelement = null;

	local.registerplugin = function(krpanointerface, pluginpath, pluginobject)
	{
		krpano = krpanointerface;
		plugin = pluginobject;

		inputelement = document.createElement("input");
		inputelement.type = "color";
		inputelement.style.width  = "100%";
		inputelement.style.height = "100%";
		inputelement.style.border = 0;
		inputelement.style.borderRadius = "0%";

		plugin.registerattribute("value", "", value_set, value_get);
    //plugin.registerattribute("color", inputelement.value);
		plugin.registerattribute("onchanged", null);

		inputelement.addEventListener("change", value_changed, true);

		plugin.sprite.appendChild(inputelement);
	}

	local.unloadplugin = function()
	{
		plugin = null;
		krpano = null;
	}

	function value_set(newtext)
	{
    //alert(newtext);
    if(newtext != null) {
      inputelement.value = newtext;
    }
	}

	function value_get()
	{
    return inputelement.value;
	}

	function value_changed()
	{
    krpano.call(plugin.onchanged, plugin);
    //krpano.trace('JS : '+inputelement.value)
	}

};
