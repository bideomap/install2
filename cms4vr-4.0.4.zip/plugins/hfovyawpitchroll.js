/*
	krpano - super simple html5 text input plugin
*/

var krpanoplugin = function()
{
	var local = this;

	var krpano = null;
	var plugin = null; 

	var inputelement = null;

	local.registerplugin = function(krpanointerface, pluginpath, pluginobject)
	{
		krpano = krpanointerface;
		plugin = pluginobject;

		inputelement = document.createElement("input");
		inputelement.type = "text";
		inputelement.id  = plugin.name;
		inputelement.style.width  = "100%";
		inputelement.style.height = "100%";
		inputelement.style.backgroundColor = "#ffffff";
		inputelement.style.color = "#000000";
		inputelement.style.paddingLeft = '10px';
		inputelement.style.borderRadius = '5px';
		inputelement.style.border = 0;
		inputelement.style.textAlign = 'center';

		plugin.registerattribute("text", "", text_set, text_get);
		plugin.registerattribute("placeholder", "", placeholder_set, placeholder_get);
		plugin.registerattribute("onchanged", null);

		inputelement.placeholder = plugin.placeholder;

		inputelement.addEventListener("input", text_changed, true);

		plugin.sprite.appendChild(inputelement);
	}

	local.unloadplugin = function()
	{
		plugin = null;
		krpano = null;
	}

	function text_set(newtext)
	{
	    if(newtext != null) {
			inputelement.value = newtext;
	    }
	}

	function text_get()
	{
		return convert(inputelement.value);
	}

	 function placeholder_set(newvalue)
    {
        if (newvalue != null)
        {
            inputelement.placeholder = newvalue;
        }
    }

    function placeholder_get()
    {
        return inputelement.placeholder;
    }


	function text_changed()
	{
		krpano.call(plugin.onchanged, plugin);
		//console.log('zmiana : '+inputelement.value)
	}

  function convert(str)
  {
    str = str.replace(/,/g, ".");
    return str;
  }




};
