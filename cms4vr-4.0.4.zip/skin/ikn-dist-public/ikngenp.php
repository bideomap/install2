<?php

/**
* All right reserved for HISELL Piotr Jakubowski nad www.cms4vr.com team
*/

include "vendor/autoload.php";
$ikngen = new Ikngen\Ikngenlib\Ikngen();

$setters = [
    'bg_color' => 'setBackgroundColor',
    'bg_opacity' => 'setBackgroundOpacity',
    'fg_color' => 'setForegroundColor',
    'icon_size' => 'setIconSize',
    'image_size' => 'setImageSize',
    'antialiasing' => 'setAntialiasing',
    'bg_radius' => 'setBackgroundRadius',
    'angle' => 'setAngle'
];

foreach ($setters as $setter => $action) {
    if (isset($_GET[$setter])) {
        try {
            switch ($setter) {
                case 'antialiasing':
                    call_user_func([$ikngen, $action], $_GET[$setter] === '1');
                break;
                case 'bg_color':
                case 'fg_color':
                    call_user_func([$ikngen, $action], $_GET[$setter]);
                break;
                default:
                    call_user_func([$ikngen, $action], intval($_GET[$setter]));
                break;
            }
        } catch (Exception $e) {
            echo "Error: " . $e;
            exit(0);
        }
    }
}

//we generate to the browser
$filename = null;

//read GET
if (isset($_GET['filename'])) {
    $filename = $_GET['filename'];
}

if (isset($_GET['code']) && isset($_GET['symbol'])) {
    echo 'Error: provide only one of two: code or symbol.';
    exit(1);
} elseif (isset($_GET['code'])) {
    try {
        $ikngen->generate($_GET['code'], $filename);
    } catch (Exception $e) {
        echo 'Error: ' . $e->getMessage();
        exit(1);
    }
} elseif (isset($_GET['symbol'])) {
    try {
        $ikngen->generateBySymbol($_GET['symbol'], $filename);
    } catch (Exception $e) {
        echo 'Error: ' . $e->getMessage();
        exit(1);
    }
} else {
    echo 'Error: provide one of two: code or symbol.';
    exit(1);
}
