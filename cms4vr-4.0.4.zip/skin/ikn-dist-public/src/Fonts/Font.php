<?php

namespace Ikngen\Ikngenlib\Fonts;

use OutOfRangeException;

abstract class Font
{
    /**
     * Path to the TTF file which represents the font.
     *
     * @var string
     */
    const PATH = '';

    /**
     * Array of symbols and codes, for example:
     *   'F0A33' => 'calendar-week',
     *   'F0A34' => 'calendar-week-begin',
     *
     * @var array
     */
    const SYMBOLS = [];

    /**
     * Gets full path to the icons file.
     *
     * @return string
     */
    public function getIconsFile()
    {
        return __DIR__ . DIRECTORY_SEPARATOR . $this::PATH;
    }

    /**
     * Gets code for the given symbol, returns false if not found.
     *
     * @param string $symbol (ie. calendar-week)
     * @throws OutOfRangeException
     * @return bool|string
     */
    public function getCodeBySymbol($symbol)
    {
        $code = array_search($symbol, $this::SYMBOLS);
        if (!$code) {
            return false;
        }

        return $code;
    }

    /**
     * Checks if code exists in the font, if not fails with exception, if true returns the symbol.
     *
     * @throws OutOfRangeException
     * @param string $code (ie. F00AE)
     * @return string symbol (ie calendar-week)
     */
    public function checkCode($code)
    {
        if (!array_key_exists($code, $this::SYMBOLS)) {
            throw new OutOfRangeException('Code does not exist in the selected font.');
        }

        return $this::SYMBOLS[$code];
    }

    /**
     * Gets the icon's code in a format which can be used inside GD lib's string rendering functions.
     *
     * @param string $code
     * @return string
     */
    public function getIcon($code)
    {
        return "&#x' . $code . ';";
    }
}
