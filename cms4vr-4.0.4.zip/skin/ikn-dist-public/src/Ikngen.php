<?php

namespace Ikngen\Ikngenlib;

use GDText\Box;
use GDText\Color;
use Ikngen\Ikngenlib\Fonts\Font;
use Ikngen\Ikngenlib\Fonts\Mdi;
use InvalidArgumentException;
use OutOfRangeException;

class Ikngen
{
    protected $font;
    protected $imageSize;
    protected $backgroundOpacity;
    protected $backgroundColor;
    protected $foregroundColor;
    protected $iconSize;
    protected $backgroundRadius;
    protected $antialiasing;
    protected $angle;

    /**
     * Creates the new instance and sets default values.
     *
     * @return $this
     */
    public function __construct()
    {
        $this->setImageSize(64)
             ->setBackgroundColor('FF0000')
             ->setForegroundColor('FFFFFF')
             ->setBackgroundOpacity(100)
             ->setFont(new Mdi())
             ->setBackgroundRadius(25)
             ->setAngle(0)
             ;
    }

    /**
     * Enables or disables antialiasing.
     *
     * @param bool $antialiasing
     * @throws InvalidArgumentException
     * @return $this;
     */
    public function setAntialiasing($antialiasing)
    {
        if (!is_bool($antialiasing)) {
            throw new InvalidArgumentException("Boolean expected.");
        }

        $this->antialiasing = $antialiasing;

        return $this;
    }

    /**
     * Informs if antialiasing is enabled.
     *
     * @return bool
     */
    public function getAntialiasing()
    {
        return $this->antialiasing;
    }

    /**
     * Sets the used font which must be an object which extends `Fonts/Font.php`.
     *
     * @param Font $font
     * @return $this
     */
    public function setFont(Font $font)
    {
        $this->font = $font;

        return $this;
    }

    /**
     * Gets the assigned font object.
     *
     * @return Font
     */
    public function getFont()
    {
        return $this->font;
    }

    /**
     * Sets the dimension of the square icon in pixels.
     *
     * @param int $pixels
     * @return $this
     * @throws InvalidArgumentException
     */
    public function setImageSize($pixels)
    {
        if (!is_int($pixels) || $pixels < 1 || $pixels > 4096) {
            throw new InvalidArgumentException('Image size must be a valid integer between 1 and 4096.');
        }

        $this->imageSize = $pixels;

        return $this;
    }

    /**
     * Sets the rotation angle in degrees (0-360).
     *
     * @param int $angle
     * @throws InvalidArgumentException
     * @return $this
     */
    public function setAngle($angle)
    {
        if (!is_int($angle) || $angle < 0 || $angle > 460) {
            throw new InvalidArgumentException('Angle must be a valid integer between 0 and 360.');
        }
        $this->angle = $angle;

        return $this;
    }

    /**
     * Gets the image dimension in pixels.
     *
     * @return int
     */
    public function getImageSize()
    {
        return $this->imageSize;
    }

    /**
     * Sets the background opacity. 100 means fully opaque, 0 fully transparent.
     *
     * @param int $opacity
     * @throws InvalidArgumentException
     * @return $this
     */
    public function setBackgroundOpacity($opacity)
    {
        if (!is_int($opacity) || $opacity < 0 || $opacity > 100) {
            throw new InvalidArgumentException('Opacity must be a valid integer between 0 and 100.');
        }

        $this->backgroundOpacity = $opacity;

        return $this;
    }

    /**
     * Gets the background opacity.
     * 100 means fully opaque, 0 fully transparent.
     *
     * @return int
     */
    public function getBackgroundOpacity()
    {
        return $this->backgroundOpacity;
    }

    /**
     * Sets the background color in hex format: for example FF0000 or FFAACE.
     *
     * @param string $color
     * @throws InvalidArgumentException
     * @return $this
     */
    public function setBackgroundColor($color)
    {
        if (!preg_match('/^[a-f0-9]{6}$/i', $color)) { //hex color is valid
            throw new InvalidArgumentException('Color must be provided in hexadecimal format, ie. FFAACE or 93ADEA.');
        }

        $this->backgroundColor = $color;

        return $this;
    }

    /**
     * Gets the background color in hex format: for example FF0000 or FFAACE.
     *
     * @return string
     */
    public function getBackgroundColor()
    {
        return $this->backgroundColor;
    }

    /**
     * Sets the foreground (icon) color in hex format: for example FF0000 or FFAACE.
     *
     * @param string $color
     * @throws InvalidArgumentException
     * @return $this
     */
    public function setForegroundColor($color)
    {
        if (!preg_match('/^[a-f0-9]{6}$/i', $color)) { //hex color is valid
            throw new InvalidArgumentException('Color must be provided in hexadecimal format, ie. FFAACE or 93ADEA.');
        }

        $this->foregroundColor = $color;

        return $this;
    }

    /**
     * Gets the foreground color in hex format: for example FF0000 or FFAACE.
     *
     * @return string
     */
    public function getForegroundColor()
    {
        return $this->foregroundColor;
    }

    /**
     * Sets the size of the icon (of the foreground) in pixels.
     *
     * @param int $size
     * @throws InvalidArgumentException
     * @return $this
     */
    public function setIconSize($size)
    {
        if (!is_int($size) || $size < 1 || $size > 4096) {
            throw new InvalidArgumentException('Icon size must be a valid integer between 1 and 4096.');
        }

        $this->iconSize = $size;

        return $this;
    }

    /**
     * Gets the angle in degrees.
     *
     * @return int
     */
    public function getAngle()
    {
        return $this->angle;
    }

    /**
     * Gets the size of the icon (of the foreground) in pixels.
     *
     * @return int
     */
    public function getIconSize()
    {
        return $this->iconSize;
    }

    /**
     * Sets the radius of the background: 50 means circle, 0 square.
     *
     * @param int $radius
     * @throws InvalidArgumentException
     * @return $this
     */
    public function setBackgroundRadius($radius)
    {
        if (!is_int($radius) || $radius < 0 || $radius > 50) {
            throw new InvalidArgumentException('Radius must be a valid integer between 0 and 50.');
        }

        $this->backgroundRadius = $radius;

        return $this;
    }

    /**
     * Gets the radius of the background: 50 means circle, 0 square.
     */
    public function getBackgroundRadius()
    {
        return $this->backgroundRadius;
    }

    /**
     * Generates the icon based on the provided symbol which must exist in the font.
     *
     * For example: `calendar-range-outline`. Refer to the used font's file.
     *
     * If filename is provided then forces download instead of generation straight to default output (browser usually).
     *
     * @param string $symbol (ie. `calendar-range-outline`)
     * @param string|null $filename
     * @throws OutOfRangeException
     * @return void
     */
    public function generateBySymbol($symbol, $filename = null)
    {
        $font = $this->getFont();
        $this->generate($font->getCodeBySymbol($symbol), $filename);
    }

    /**
     * Generates the icon based on the provided code which must exist in the font.
     *
     * For example: `F0B68`. Refer to the used font's file.
     *
     * If filename is provided then forces download instead of generation straight to default output (browser usually).
     *
     * @param string $symbol (ie. `F0B68`)
     * @param string|null $filename
     * @throws OutOfRangeException
     * @return void
     */
    public function generate($code, $filename = null)
    {
        //gets the loaded font
        $font = $this->getFont();
        if (!$font->checkCode($code)) {
            throw new OutOfRangeException("Code does not exist in the selected font");
        }
        $fontFile = $font->getIconsFile();

        //gets the image size
        $imageSize = $this->getImageSize();

        //gets the icon size and defaults to 50%
        $iconSize = $this->getIconSize();
        if ($iconSize === null) {
            $iconSize = 0.5 * $imageSize;
        }

        //set temporary attributes, for scaling (better quality)
        $temporaryImageSize = $imageSize * 2;
        $temporaryIconSize = $iconSize * 2;
        $roundness = $this->getBackgroundRadius();

        //prepare the transparent Background
        $background = $this->createTransparentImage($temporaryImageSize, $temporaryImageSize);
        list($r, $g, $b) = $this->extractRgb($this->getBackgroundColor());

        $bgOpacity = 0;
        switch (intval($this->getBackgroundOpacity())) {
            case 100:
                $bgOpacity = 127;
            break;
            case 0:
                $bgOpacity = 0;
            break;
            default:
                $bgOpacity = $this->getBackgroundOpacity() / 100 * 127;
            break;
        }

        $bgColor = imagecolorallocatealpha($background, $r, $g, $b, 127 - $bgOpacity);

        //draw the rectange
        switch ($roundness) {
            case 0:
                imagefilledrectangle($background, 0, 0, $temporaryImageSize, $temporaryImageSize, $bgColor);
            break;
            case 50:
                $half = $temporaryImageSize / 2;
                imagefilledellipse($background, $half, $half, $temporaryImageSize, $temporaryImageSize, $bgColor);
            break;
            default:
                $percent = $roundness * 2 / 100;
                $this->imagefillroundedrect($background, 0, 0, $temporaryImageSize, $temporaryImageSize, $percent * $temporaryImageSize / 2, $bgColor);
            break;
        }

        //create image for merging sub images
        $mergedImage = $this->createTransparentImage($temporaryImageSize, $temporaryImageSize);
        $iconImage = $this->createTransparentImage($temporaryImageSize, $temporaryImageSize);

        //draw the icon
        list($r, $g, $b) = $this->extractRgb($this->getForegroundColor());

        //in a centered box
        $textbox = new Box($iconImage);
        $textbox->setFontSize($temporaryIconSize);
        $textbox->setFontFace($fontFile);
        $textbox->setFontColor(new Color($r, $g, $b));
        $textbox->setBox(
            $temporaryImageSize/2 - $temporaryIconSize /2,  // distance from left edge
            0,  // distance from top edge
            $temporaryImageSize, // textbox width
            $temporaryImageSize  // textbox height
        );

        // text will be aligned inside textbox to center horizontally and to top vertically
        $textbox->setTextAlign('left', 'center');
        $textbox->draw(trim($font->getIcon($code)));

        //merge in the background
        imagecopy($mergedImage, $background, 0, 0, 0, 0, $temporaryImageSize, $temporaryImageSize);

        if ($this->getAngle() !== 0) {
            $bgColorIcon = imagecolorallocatealpha($iconImage, 0, 0, 0, 127);
            $iconImage = imagerotate($iconImage, 360 - $this->getAngle(), $bgColorIcon);
            if ($this->getAngle() % 90 !== 0) {
                //size may have changed
                $x = imagesx($iconImage) / 2 - $temporaryImageSize /2;
                $y = imagesy($iconImage) / 2 - $temporaryImageSize /2;
                $temp = $this->createTransparentImage($temporaryImageSize, $temporaryImageSize);
                imagecopy($temp, $iconImage, 0, 0, $x, $y, $temporaryImageSize, $temporaryImageSize);
                imagedestroy($iconImage);
                $iconImage = $temp;
            }
        }

        //merge in the icon
        imagecopy($mergedImage, $iconImage, 0, 0, 0, 0, $temporaryImageSize, $temporaryImageSize);

        //create final, resized image
        $resized = $this->createTransparentImage($imageSize, $imageSize);
        if ($this->getAntialiasing()) {
            imagecopyresampled($resized, $mergedImage, 0, 0, 0, 0, $imageSize, $imageSize, $temporaryImageSize, $temporaryImageSize);
        } else {
            imagecopyresized($resized, $mergedImage, 0, 0, 0, 0, $imageSize, $imageSize, $temporaryImageSize, $temporaryImageSize);
        }

        if ($filename) {
            header("Content-Description: File Transfer");
            header("Content-Type: application/octet-stream");
            header("Content-Disposition: attachment; filename=\"". $filename .".png\"");
            imagepng($resized, null, 0);
            imagedestroy($resized);
        } else {
            header("Content-Type: image/png");
            imagepng($resized, null, 0);
            imagedestroy($resized);
        }
        exit(0);
    }

    /**
     * Extract R G B parts from the hex color string (FF00AE).
     *
     * @param string $color hex string (ie. FF00AE).
     * @return string[] [r, g, b]
     */
    protected function extractRgb($color)
    {
        $r = hexdec(substr($color, 0, 2));
        $g = hexdec(substr($color, 2, 2));
        $b = hexdec(substr($color, 4, 2));

        return [ $r, $g, $b];
    }

    /**
     * Creates a rounded-corners rectangle.
     *
     * @param Resource $im Image
     * @param int $x start X
     * @param int $y start Y
     * @param int $cx width X
     * @param int $cy width Y
     * @param int $rad Radius in proportion of the full size
     * @param Resource $col Color
     * @return void
     */
    protected function imagefillroundedrect($im, $x, $y, $cx, $cy, $rad, $col)
    {
        //little trick to fix ugly antialiasing
        $offset = $this->getAntialiasing() ? 0 : 1;

        // Draw the middle cross shape of the rectangle
        imagefilledrectangle($im, $offset, $y+$rad, $rad -1, $cy-$rad -1, $col);
        imagefilledrectangle($im, $cx - $rad, $y+$rad, $cx -1, $cy-$rad -1, $col);
        imagefilledrectangle($im, $x+$rad, $y + $offset, $cx-$rad -1, $cy -1, $col);
        $dia = $rad*2;

        //left top
        $image = $this->createTransparentImage($rad, $rad);
        imagefilledellipse($image, $rad, $rad, $dia, $dia, $col);
        imagecopy($im, $image, 0, 0, 0, 0, $rad, $rad);
        imagedestroy($image);

        //left bottom
        $image = $this->createTransparentImage($rad, $rad);
        imagefilledellipse($image, $rad, 0, $dia, $dia, $col);
        imagecopy($im, $image, 0, $cx - $rad, 0, 0, $rad, $rad);
        imagedestroy($image);

        //right bottom
        $image = $this->createTransparentImage($rad, $rad);
        imagefilledellipse($image, 0, 0, $dia, $dia, $col);
        imagecopy($im, $image, $cx - $rad, $cy - $rad, 0, 0, $rad, $rad);
        imagedestroy($image);

        //right top
        $image = $this->createTransparentImage($rad, $rad);
        imagefilledellipse($image, 0, $rad, $dia, $dia, $col);
        imagecopy($im, $image, $cx - $rad, 0, 0, 0, $rad, $rad);
        imagedestroy($image);
    }

    /**
     * Creates a transparent image resource.
     *
     * @param int $width
     * @param int $height
     * @throws InvalidArgumentException
     * @return Resource (image)
     */
    protected function createTransparentImage($width, $heigth)
    {
        if (!is_numeric($width) || !is_numeric($heigth) || $width < 1 || $heigth < 1) {
            throw new InvalidArgumentException("Dimensions must be positive numbers.");
        }
        $image = imagecreatetruecolor($width, $heigth);
        imagealphablending($image, true);
        imagesavealpha($image, true);
        $transparency = imagecolorallocatealpha($image, 0, 0, 0, 127);
        imagefill($image, 0, 0, $transparency);

        return $image;
    }
}
