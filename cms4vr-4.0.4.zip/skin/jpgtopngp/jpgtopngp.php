<?php

/**
* All right reserved for HISELL Piotr Jakubowski nad www.cms4vr.com team
*/


include "vendor/autoload.php";
$ikngen = new Ikngen\Ikngenlib\JpgToPngIkn();

$setters = [
    'image_size' => 'setImageSize',
    'border_radius' => 'setBorderRadius',
    'border_width' => 'setBorderWidth',
    'border_color' => 'setBorderColor',
    'antialiasing' => 'setAntialiasing',
];

foreach ($setters as $setter => $action) {
    if (isset($_GET[$setter])) {
        try {
            switch ($setter) {
                case 'antialiasing':
                    call_user_func([$ikngen, $action], $_GET[$setter] === '1');
                break;
                case 'border_color':
                    call_user_func([$ikngen, $action], $_GET[$setter]);
                break;
                default:
                    call_user_func([$ikngen, $action], intval($_GET[$setter]));
                break;
            }
        } catch (Exception $e) {
            echo "Error: " . $e;
            exit(0);
        }
    }
}

//we generate to the browser
$filename = null;

//read GET
if (isset($_GET['filename'])) {
    $filename = $_GET['filename'];
}

try {
    $ikngen->generate($_GET['src'], $filename);
} catch (Exception $e)
{
    echo "Error: " . $e->getMessage() . PHP_EOL;
    exit(1);
}