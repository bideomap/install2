<?php

/**
* All right reserved for HISELL Piotr Jakubowski nad www.cms4vr.com team
*/

namespace Ikngen\Ikngenlib;

use InvalidArgumentException;
use LogicException;
use OutOfRangeException;
use RuntimeException;

class JpgToPngIkn
{
    const LAST_ACCESS_FILE = 'last_access';
    protected $imageSize;
    protected $borderColor;
    protected $borderRadius;
    protected $borderWidth;
    protected $antialiasing;
    protected $cacheEnabled;
    protected $keepCacheTime;
    protected $httpEnabled;
    protected $pathsAccepted;

    /**
     * Creates the new instance and sets default values.
     *
     * @return $this
     */
    public function __construct()
    {
        $this->setImageSize(64)
             ->setBorderColor('FF0000')
             ->setBorderRadius(25)
             ->setBorderWidth(4)
             ->setCacheEnabled(true)
             ->setKeepCacheTime(24 * 3600)
             ->setHttpEnabled(true)
             ->setPathsAccepted(null)
             ;
    }

    public function getHttpEnabled()
    {
        return $this->httpEnabled;
    }

    public function setHttpEnabled($enabled)
    {
        $this->httpEnabled = $enabled;

        return $this;
    }

    public function setPathsAccepted($pathsAccepted)
    {
        $this->pathsAccepted = [];
        if (is_array($pathsAccepted)) {
            foreach ($pathsAccepted as $path) {
                $realpath = realpath($path);
                $this->pathsAccepted[] = $realpath;
            }
        }

        return $this;
    }

    public function getPathsAccepted()
    {
        return $this->pathsAccepted;
    }

    public function getKeepCacheTime()
    {
        return $this->keepCacheTime;
    }

    public function setKeepCacheTime($time)
    {
        if (!is_int($time) || $time < 1) {
            throw new InvalidArgumentException("Time must be a positive integer.");
        }

        $this->keepCacheTime = $time;

        return $this;
    }

    public function setCacheEnabled($cacheEnabled)
    {
        $this->cacheEnabled = $cacheEnabled;

        return $this;
    }

    public function getCacheEnabled()
    {
        return $this->cacheEnabled;
    }

    /**
     * Enables or disables antialiasing.
     *
     * @param bool $antialiasing
     * @throws InvalidArgumentException
     * @return $this;
     */
    public function setAntialiasing($antialiasing)
    {
        if (!is_bool($antialiasing)) {
            throw new InvalidArgumentException("Boolean expected.");
        }

        $this->antialiasing = $antialiasing;

        return $this;
    }

    /**
     * Informs if antialiasing is enabled.
     *
     * @return bool
     */
    public function getAntialiasing()
    {
        return $this->antialiasing;
    }

    /**
     * Sets the dimension of the square icon in pixels.
     *
     * @param int $pixels
     * @return $this
     * @throws InvalidArgumentException
     */
    public function setImageSize($pixels)
    {
        if (!is_int($pixels) || $pixels < 1 || $pixels > 4096) {
            throw new InvalidArgumentException('Image size must be a valid integer between 1 and 4096.');
        }

        $this->imageSize = $pixels;

        return $this;
    }

    /**
     * Gets the image dimension in pixels.
     *
     * @return int
     */
    public function getImageSize()
    {
        return $this->imageSize;
    }

    /**
     * Sets the background color in hex format: for example FF0000 or FFAACE.
     *
     * @param string $color
     * @throws InvalidArgumentException
     * @return $this
     */
    public function setBorderColor($color)
    {
        if (!preg_match('/^[a-f0-9]{6}$/i', $color)) { //hex color is valid
            throw new InvalidArgumentException('Color must be provided in hexadecimal format, ie. FFAACE or 93ADEA.');
        }

        $this->borderColor = $color;

        return $this;
    }

    /**
     * Gets the background color in hex format: for example FF0000 or FFAACE.
     *
     * @return string
     */
    public function getBorderColor()
    {
        return $this->borderColor;
    }

    /**
     * Sets the radius of the background: 50 means circle, 0 square.
     *
     * @param int $radius
     * @throws InvalidArgumentException
     * @return $this
     */
    public function setBorderRadius($radius)
    {
        if (!is_int($radius) || $radius < 0 || $radius > 50) {
            throw new InvalidArgumentException('Radius must be a valid integer between 0 and 50.');
        }

        $this->borderRadius = $radius;

        return $this;
    }

    /**
     * Gets the radius of the background: 50 means circle, 0 square.
     */
    public function getBorderRadius()
    {
        return $this->borderRadius;
    }

    /**
     * Sets the radius of the background: 50 means circle, 0 square.
     *
     * @param int $radius
     * @throws InvalidArgumentException
     * @return $this
     */
    public function setBorderWidth($width)
    {
        if (!is_int($width) || $width < 0) {
            throw new InvalidArgumentException('Radius must be a valid, non-negative integer.');
        }

        $this->borderWidth = $width;

        return $this;
    }

    /**
     * Gets the radius of the background: 50 means circle, 0 square.
     */
    public function getBorderWidth()
    {
        return $this->borderWidth;
    }

    public function imagealphamask(&$picture, $mask, $size)
    {
        // Get sizes and set up new picture
        $xSize = $ySize = $size;
        $newPicture = imagecreatetruecolor($xSize, $ySize);
        imagesavealpha($newPicture, true);
        imagefill($newPicture, 0, 0, imagecolorallocatealpha($newPicture, 0, 0, 0, 127));

        // Resize mask if necessary
        // if ($xSize != imagesx($mask) || $ySize != imagesy($mask)) {
        //     $tempPic = imagecreatetruecolor($xSize, $ySize);
        //     imagecopyresampled($tempPic, $mask, 0, 0, 0, 0, $xSize, $ySize, imagesx($mask), imagesy($mask));
        //     imagedestroy($mask);
        //     $mask = $tempPic;
        // }

        // Perform pixel-based alpha map application
        for ($x = 0; $x < $xSize; $x++) {
            for ($y = 0; $y < $ySize; $y++) {
                $alpha = imagecolorsforindex($mask, imagecolorat($mask, $x, $y));

                if (($alpha['red'] == 0) && ($alpha['green'] == 0) && ($alpha['blue'] == 0) && ($alpha['alpha'] == 0)) {
                    // It's a black part of the mask
                        imagesetpixel($newPicture, $x, $y, imagecolorallocatealpha($newPicture, 0, 0, 0, 127)); // Stick a black, but totally transparent, pixel in.
                } else {
                    // Check the alpha state of the corresponding pixel of the image we're dealing with.
                    $alphaSource = imagecolorsforindex($picture, imagecolorat($picture, $x, $y));

                    if (($alphaSource['alpha'] == 127)) {
                        imagesetpixel($newPicture, $x, $y, imagecolorallocatealpha($newPicture, 0, 0, 0, 127)); // Stick a black, but totally transparent, pixel in.
                    } else {
                        $color = imagecolorsforindex($picture, imagecolorat($picture, $x, $y));
                        imagesetpixel($newPicture, $x, $y, imagecolorallocatealpha($newPicture, $color[ 'red' ], $color[ 'green' ], $color[ 'blue' ], $color['alpha'])); // Stick the pixel from the source image in
                    }
                }
            }
        }

        // Copy back to original picture
        imagedestroy($picture);
        $picture = $newPicture;
    }

    /**
     * Generates the icon based on the provided jpg image.
     *
     * If filename is provided then forces download instead of generation straight to default output (browser usually).
     *
     * @param string $url (relative or absolute file path or http/https url)
     * @param string|null $filename
     * @throws OutOfRangeException
     * @throws RuntimeException
     * @throws LogicException
     * @return void
     */
    public function generate($url, $filename = null)
    {
        $this->clearCache();

        $httpFile = strlen($url) >= 6 && (strtolower(substr($url, 0, 5)) === 'http:' || strtolower(substr($url, 0, 6)) === 'https:');
        if ($this->getHttpEnabled() !== true && $httpFile) {
            throw new RuntimeException("HTTP access disabled.");
        }

        if (!$httpFile && !$this->fileInAcceptedPaths($url)) {
            throw new RuntimeException("File in illegal path.");
        }

        if ($this->getCacheEnabled()) {
            $hash = $this->getCacheHash($url);
            $path = $this->buildCachePath($hash);
            if ($this->checkCache($hash)) {
                if ($filename) {
                    header("Content-Description: File Transfer");
                    header("Content-Type: application/octet-stream");
                    header("Content-Disposition: attachment; filename=\"". $filename .".png\"");
                } else {
                    header("Content-Type: image/png");
                }

                $file = fopen($path, 'r');
                fpassthru($file);
                fclose($file);
                exit(0);
            }
        }

        $qf = 2;
        //gets the image size
        $imageSize = $this->getImageSize();
        $temporaryImageSize = $imageSize * $qf;

        if ($this->getBorderWidth() >= $imageSize / 2) {
            throw new LogicException("Border width must be lower than half of image size.");
        }

        //inner image
        $sourcePre = imagecreatefromjpeg($url);
        if (!$url || !$sourcePre) {
            throw new RuntimeException("Could not load the file.");
        }

        $x = imagesx($sourcePre);
        $y = imagesy($sourcePre);

        $iconSize = $imageSize - 2 * $this->getBorderWidth();
        $temporaryIconSize = $iconSize * $qf;
        $source = $this->createTransparentImage($temporaryIconSize, $temporaryIconSize);
        imagecopyresampled($source, $sourcePre, 0, 0, 0, 0, $temporaryIconSize, $temporaryIconSize, $x, $y);
        imagedestroy($sourcePre);

        //border
        $roundness = $this->getBorderRadius();
        $background = $this->createTransparentImage($temporaryImageSize, $temporaryImageSize);
        list($r, $g, $b) = $this->extractRgb($this->getBorderColor());
        $bgColor = imagecolorallocatealpha($background, $r, $g, $b, 0);

        $offset = $this->getAntialiasing() ? -1 : 0;
        //draw the rectange
        switch ($roundness) {
            case 0:
                imagefilledrectangle($background, 0, 0, $temporaryImageSize, $temporaryImageSize, $bgColor);
            break;
            case 50:
                $half = $temporaryImageSize / 2;
                imagefilledellipse($background, $half, $half, $temporaryImageSize + $offset, $temporaryImageSize + $offset, $bgColor);
            break;
            default:
                $percent = $roundness * 2 / 100;
                $this->imagefillroundedrect($background, 0, 0, $temporaryImageSize, $temporaryImageSize, $percent * $temporaryImageSize / 2, $bgColor);
            break;
        }

        //mask
        $mask = $this->createTransparentImage($temporaryIconSize, $temporaryIconSize);

        //fill with black
        imagefill($mask, 0, 0, imagecolorallocatealpha($mask, 0, 0, 0, 0));

        //fill with mask
        $maskTransparency = imagecolorallocate($mask, 255, 255, 255);
        switch ($roundness) {
            case 0:
                imagefilledrectangle($mask, 0, 0, $temporaryIconSize, $temporaryIconSize, $maskTransparency);
            break;
            case 50:
                $half = $temporaryIconSize / 2;
                imagefilledellipse($mask, $half, $half, $temporaryIconSize + $offset, $temporaryIconSize + $offset, $maskTransparency);
            break;
            default:
                $percent = $roundness * 2 / 100;
                $this->imagefillroundedrect($mask, 0, 0, $temporaryIconSize, $temporaryIconSize, $percent * $temporaryIconSize / 2, $maskTransparency);
            break;
        }

        $this->imagealphamask($source, $mask, $temporaryIconSize);
        imagedestroy($mask);

        //create image for merging sub images
        $mergedImage = $this->createTransparentImage($temporaryImageSize, $temporaryImageSize);

        //merge in the background
        imagecopy($mergedImage, $background, 0, 0, 0, 0, $temporaryImageSize, $temporaryImageSize);

        //merge in the icon
        $pos = $temporaryImageSize / 2 - $temporaryIconSize /2;
        imagecopy($mergedImage, $source, $pos, $pos, 0, 0, $temporaryIconSize, $temporaryIconSize);

        //create final, resized image
        $resized = $this->createTransparentImage($imageSize, $imageSize);
        if ($this->getAntialiasing()) {
            imagecopyresampled($resized, $mergedImage, 0, 0, 0, 0, $imageSize, $imageSize, $temporaryImageSize, $temporaryImageSize);
        } else {
            imagecopyresized($resized, $mergedImage, 0, 0, 0, 0, $imageSize, $imageSize, $temporaryImageSize, $temporaryImageSize);
        }

        if ($this->getCacheEnabled()) {
            imagepng($resized, $this->buildCachePath($this->getCacheHash($url), true), 0);
        }

        if ($filename) {
            header("Content-Description: File Transfer");
            header("Content-Type: application/octet-stream");
            header("Content-Disposition: attachment; filename=\"". $filename .".png\"");
            imagepng($resized, null, 0);
            imagedestroy($resized);
        } else {
            header("Content-Type: image/png");
            imagepng($resized, null, 0);
            imagedestroy($resized);
        }
        exit(0);
    }

    /**
     * Checks if entry exists already in the cache.
     *
     * `true` if exists.
     *
     * @param string $hash
     * @throws InvalidArgumentException
     * @return bool
     */
    public function checkCache($hash)
    {
        if (!is_string($hash)) {
            throw new InvalidArgumentException('Hash must be a string');
        }

        $path = $this->buildCachePath($hash);

        if (file_exists($path)) {
            if (time()-filemtime($path) > $this->getKeepCacheTime()) {
                // file older than 7 days
                unlink($path);

                return false;
            } else {
                return true;
            }
        }

        return false;
    }

    protected function removeEmptySubFolders($path)
    {
        $empty=true;
        foreach (glob($path.DIRECTORY_SEPARATOR."*") as $file) {
            $empty &= is_dir($file) && $this->removeEmptySubFolders($file);
        }

        return $empty && rmdir($path);
    }

    protected function clearCache()
    {
        $cacheAccess = date('Ymd');
        if (file_exists($this::LAST_ACCESS_FILE)) {
            $cacheLastAccess = file_get_contents($this::LAST_ACCESS_FILE);
            if ($cacheLastAccess !== $cacheAccess) {
                $cachedFiles = glob('cache' . DIRECTORY_SEPARATOR . '*' . DIRECTORY_SEPARATOR . '*' . DIRECTORY_SEPARATOR . '*');
                foreach ($cachedFiles as $file) {
                    if (time()-filemtime($file) > $this->getKeepCacheTime()) {
                        unlink($file);
                    }
                }

                $this->removeEmptySubFolders('cache');
                file_put_contents($this::LAST_ACCESS_FILE, $cacheAccess);
            }
        } else {
            file_put_contents($this::LAST_ACCESS_FILE, $cacheAccess);
        }
    }

    /**
     * Checks if path is within one of the accepted paths (if any set).
     *
     * `true` if file is accepted.
     *
     * @param string path
     * @return bool
     */
    protected function fileInAcceptedPaths($path)
    {
        if (empty($this->getPathsAccepted())) {
            return true;
        }

        $realPath = realpath($path);
        foreach ($this->getPathsAccepted() as $accepted) {
            if ($accepted !== false && strncmp($realPath, $accepted, strlen($accepted)) === 0) {
                return true;
            }
        }

        return false;
    }

    /**
     * Extract R G B parts from the hex color string (FF00AE).
     *
     * @param string $color hex string (ie. FF00AE).
     * @return string[] [r, g, b]
     */
    protected function extractRgb($color)
    {
        $r = hexdec(substr($color, 0, 2));
        $g = hexdec(substr($color, 2, 2));
        $b = hexdec(substr($color, 4, 2));

        return [ $r, $g, $b];
    }

    /**
     * Creates a rounded-corners rectangle.
     *
     * @param Resource $im Image
     * @param int $x start X
     * @param int $y start Y
     * @param int $cx width X
     * @param int $cy width Y
     * @param int $rad Radius in proportion of the full size
     * @param Resource $col Color
     * @return void
     */
    protected function imagefillroundedrect($im, $x, $y, $cx, $cy, $rad, $col)
    {
        //little trick to fix ugly antialiasing
        $offset = $this->getAntialiasing() ? 0 : 1;
        $offset = 0;
        // Draw the middle cross shape of the rectangle
        imagefilledrectangle($im, $offset, $y+$rad, $rad -1, $cy-$rad -1, $col);
        imagefilledrectangle($im, $cx - $rad, $y+$rad, $cx -1, $cy-$rad -1, $col);
        imagefilledrectangle($im, $x+$rad, $y + $offset, $cx-$rad -1, $cy -1, $col);
        $dia = $rad*2;

        //left top
        $image = $this->createTransparentImage($rad, $rad);
        imagefilledellipse($image, $rad, $rad, $dia, $dia, $col);
        imagecopy($im, $image, 0, 0, 0, 0, $rad, $rad);
        imagedestroy($image);

        //left bottom
        $image = $this->createTransparentImage($rad, $rad);
        imagefilledellipse($image, $rad, 0, $dia, $dia, $col);
        imagecopy($im, $image, 0, $cx - $rad, 0, 0, $rad, $rad);
        imagedestroy($image);

        //right bottom
        $image = $this->createTransparentImage($rad, $rad);
        imagefilledellipse($image, 0, 0, $dia, $dia, $col);
        imagecopy($im, $image, $cx - $rad, $cy - $rad, 0, 0, $rad, $rad);
        imagedestroy($image);

        //right top
        $image = $this->createTransparentImage($rad, $rad);
        imagefilledellipse($image, 0, $rad, $dia, $dia, $col);
        imagecopy($im, $image, $cx - $rad, 0, 0, 0, $rad, $rad);
        imagedestroy($image);
    }

    /**
     * Creates a transparent image resource.
     *
     * @param int $width
     * @param int $height
     * @throws InvalidArgumentException
     * @return Resource (image)
     */
    protected function createTransparentImage($width, $heigth)
    {
        if (!is_numeric($width) || !is_numeric($heigth) || $width < 1 || $heigth < 1) {
            throw new InvalidArgumentException("Dimensions must be positive numbers.");
        }
        $image = imagecreatetruecolor($width, $heigth);
        imagealphablending($image, true);
        imagesavealpha($image, true);
        $transparency = imagecolorallocatealpha($image, 0, 0, 0, 127);
        imagefill($image, 0, 0, $transparency);

        return $image;
    }

    /**
     * Based on the url and current settings return a hash for the new file.
     *
     * @param string $url
     * @return string
     */
    protected function getCacheHash($url)
    {
        return md5($url . '%' . $this->getImageSize() . '%' . $this->getBorderColor() . '%' . $this->getBorderRadius() . '%' . $this->getBorderWidth() . '%' . ($this->getAntialiasing() ? 'true' : 'false'));
    }

    /**
     * Builds the cache path for retrieval of the file, creates the directory structure
     * if second argument is set to true.
     *
     * @param string $hash
     * @param bool $saving
     * @return string
     */
    protected function buildCachePath($hash, $saving = false)
    {
        $level0 = __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'cache';
        $level1 = $level0 . DIRECTORY_SEPARATOR . substr($hash, 0, 2);
        $level2 = $level1 . DIRECTORY_SEPARATOR . substr($hash, 2, 2);
        if ($saving) {
            if (!is_dir($level0)) {
                mkdir($level0);
            }

            if (!is_dir($level1)) {
                mkdir($level1);
            }

            if (!is_dir($level2)) {
                mkdir($level2);
            }
        }

        return $level2 . DIRECTORY_SEPARATOR . $hash;
    }
}
