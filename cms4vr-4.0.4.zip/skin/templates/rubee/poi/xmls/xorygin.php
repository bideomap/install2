<?php 
	
	$src = $_POST['src'];
    $valid = 1;
    $heade = @get_headers($src, 1);

    if (!$heade || stripos($heade[0], '200 ok') === false) {
    	$valid = 0;
    }

    // Check X-Frame-Option
    elseif (isset($heade['X-Frame-Options']) && (stripos($heade['X-Frame-Options'], 'SAMEORIGIN') !== false || stripos($heade['X-Frame-Options'], 'deny') !== false)) {
        //return false;
        $valid = 0;
    } 

    // overwrite
    $valid = 1;

    echo json_encode($valid);
?>